/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro;

import java.awt.event.ActionEvent;
import java.util.ArrayList;
import javax.swing.JMenu;

import pedro.view.NavigationTree;
import pedro.view.RecordView;
import pedro.util.HelpEnabledMenuItem;

import pedro.util.HelpDialog;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class WindowMenuActionListener extends MenuActionListener {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================

   // ==========================================
   // Section Construction
   // ==========================================
   public WindowMenuActionListener(PedroDialog parentDialog,
								   NavigationTree navigationTree,
								   RecordView recordPanel) {
	  super(parentDialog,
			navigationTree,
			recordPanel);

	  menu.setText("Windows");
   }

   // ==========================================
   // Section Accessors
   // ==========================================


   // ==========================================
   // Section Mutators
   // ==========================================
   public void updateWindowList(ArrayList activeFiles) {
	  menu.removeAll();

	  String title = parentDialog.getTitle();
	  int numberOfActiveFiles = activeFiles.size();
	  for ( int i = 0; i < numberOfActiveFiles; i++) {
		 String currentFileName = (String) activeFiles.get(i);
		 HelpEnabledMenuItem currentItem = new HelpEnabledMenuItem(currentFileName);

		 currentItem.setHelpLink(createHelpLink("ActiveWindow.html") );
		 currentItem.addActionListener(this);
		 menu.add(currentItem);
	  } // end for ()
   }

   public void enableContextHelp(boolean enableContextHelp) {
	  int numberOfMenuItems = menu.getItemCount();
	  
	  for ( int i = 0; i < numberOfMenuItems; i++) {
		 HelpEnabledMenuItem currentItem
			= (HelpEnabledMenuItem) menu.getItem(i);

		 currentItem.enableContextHelp(enableContextHelp);
	  } // end for ()
   }



   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================
   public void actionPerformed(ActionEvent event) {
	  HelpEnabledMenuItem menuItem = (HelpEnabledMenuItem) event.getSource();

	  if ( menuItem.isContextHelpEnabled() == true) {
		 HelpDialog helpDialog = HelpDialog.getHelpDialog();
		 helpDialog.setHelpLink(menuItem.getHelpLink() );
		 helpDialog.show();
		 return;
		 
	  } //end if ()

	  WindowRegistry windowRegistry = WindowRegistry.getWindowRegistry();
	  windowRegistry.activateWindow(menuItem.getText() );
   }


   // ==========================================
   // Section Overload
   // ==========================================

}

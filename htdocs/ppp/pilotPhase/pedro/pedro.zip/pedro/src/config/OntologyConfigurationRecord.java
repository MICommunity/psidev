/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.config;


/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class OntologyConfigurationRecord {

   
   // ==========================================
   // Section Constants
   // ==========================================
   public static final int WEB_SERVICE = 11;
   public static final int LOCAL_FILE = 12;

   // ==========================================
   // Section Properties
   // ==========================================
   private String name;
   private String description;
   private Class localServiceClass;
   private String localServiceParameters;
   private Class remoteServiceClass;
   private String remoteServiceParameters;

   // ==========================================
   // Section Construction
   // ==========================================
   public OntologyConfigurationRecord() {
	  localServiceParameters = null;
	  localServiceClass = null;
	  remoteServiceParameters = null;
	  remoteServiceClass = null;
   }

   // ==========================================
   // Section Accessors
   // ==========================================

   /**
	* Get the value of name.
	* @return value of name.
	*/
   public String getName() {
	  return name;
   }

   /**
	* Get the value of description.
	* @return value of description.
	*/
   public String getDescription() {
	  return description;
   }
   
  
   public Class getLocalServiceClass() {
	  return localServiceClass;
   }

   public String getLocalServiceParameters() {
	  return localServiceParameters;
   }

   public Class getRemoteServiceClass() {
	  return remoteServiceClass;
   }

   public String getRemoteServiceParameters() {
	  return remoteServiceParameters;
   }

   public void print() {
	  /*
	  System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++");
	  System.out.println("Ontology Configuration");
	  if ( localServiceClass == null) {
		 System.out.println("Local Service:NONE");
	  } //end if ()
	  else {
		 System.out.println("Local Service:");
		 System.out.println("Name:"+localServiceClass.getName() );
		 System.out.println("Parameters:"+localServiceParameters);
	  } //end else
	  
	  if ( remoteServiceClass == null) {
		 System.out.println("Remote Service:NONE");
	  } //end if ()
	  else {
		 System.out.println("Remote Service:");
		 System.out.println("Name:"+remoteServiceClass.getName() );
		 System.out.println("Parameters:"+remoteServiceParameters);
	  } //end else
	  */
   }

   // ==========================================
   // Section Mutators
   // ==========================================
   public void setDescription(String description) {
	  this.description = description;
   }
   
   public void setName(String name) {
	  this.name = name;
   }

   public void setLocalServiceClass(Class localServiceClass) {
	  this.localServiceClass = localServiceClass;
   }

   public void setLocalServiceParameters(String localServiceParameters) {
	  this.localServiceParameters = localServiceParameters;
   }

   public void setRemoteServiceClass(Class remoteServiceClass) {
	  this.remoteServiceClass = remoteServiceClass;
   }

   public void setRemoteServiceParameters(String remoteServiceParameters) {
	  this.remoteServiceParameters = remoteServiceParameters;
   }



   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================

}

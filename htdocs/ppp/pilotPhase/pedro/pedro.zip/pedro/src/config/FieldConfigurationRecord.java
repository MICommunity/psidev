/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.config;

import java.net.URL;
import java.util.ArrayList;

import pedro.ontology.OntologyService;
import pedro.validation.Validator;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class FieldConfigurationRecord {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private String recordType;
   private String fieldName;
   private URL helpLink;
   private String formComments;
   private String units;
   private String defaultValue;
   private ArrayList ontologyServices;
   private boolean isDisplayNameComponent;
   private boolean isScrollingTextField;
   private boolean disableFreeText;
   private ArrayList validators;
   

   // ==========================================
   // Section Construction
   // ==========================================
   public FieldConfigurationRecord(String recordType,
							String fieldName) {
	  this.recordType = recordType;
	  this.fieldName = fieldName;
	  ontologyServices = new ArrayList();
	  isDisplayNameComponent = false;
	  defaultValue = "";
	  units = "";
	  isScrollingTextField = false;
	  disableFreeText = false;
	  validators = new ArrayList();
	  formComments = "";
   }

   // ==========================================
   // Section Accessors
   // ==========================================
   public String getFormComments() {
	  return formComments;
   }

   public String getRecordType() {
	  return recordType;
   }

   public String getUnits() {
	  return units;
   }

   public String getFieldName() {
	  return fieldName;
   }
   public URL getHelpLink() {
	  return helpLink;
   }

   public ArrayList getOntologyServices() {
	  return ontologyServices;
   }

   public boolean isDisplayNameComponent() {
	  return isDisplayNameComponent;
   }

   public boolean isScrollingTextField() {
	  return isScrollingTextField;
   }
   
   public boolean disableFreeText() {
	  return disableFreeText;
   }

   public String getDefaultValue() {
	  return defaultValue;
   }

   public ArrayList getValidators() {
	  return validators;
   }

   // ==========================================
   // Section Mutators
   // ==========================================
   public void setHelpLink(URL _helpLink) {
	  this.helpLink = _helpLink;
   } 

   public void setFormComments(String formComments) {
	  this.formComments = formComments;
   }

   public void setDefaultValue(String _defaultValue) {
	  this.defaultValue = _defaultValue;
   }

   public void setDisplayNameComponent(boolean _isDisplayNameComponent) {
	  this.isDisplayNameComponent = _isDisplayNameComponent;
   }

   public void setScrollingTextField(boolean _isScrollingTextField) {
	  this.isScrollingTextField = _isScrollingTextField;
   }

   public void setDisableFreeText(boolean _disableFreeText) {
	  this.disableFreeText = _disableFreeText;
   }

   public void addOntologyService(OntologyService _ontologyService) {
	  ontologyServices.add(_ontologyService);
   }
   
   public void setUnits(String _units) {
	  this.units = _units;
   }
   
   public void addValidator(Validator validator) {
	  validators.add(validator);
   }

   public void print() {
	  System.out.println("=======================================================");
	  System.out.println("Configuration for " + recordType + " field " + fieldName);
	  if ( helpLink == null) {
		 System.out.println("Help Link:NONE");
	  } //end if ()
	  else {
		 System.out.println("Help Link:"+helpLink.toString() );
	  } //end else
	  
	  if ( isDisplayNameComponent == false) {
		 System.out.println("Display Name Component:FALSE");
	  } //end if ()
	  else {
		 System.out.println("Display Name Component:TRUE");
	  } //end else
	  
	  if ( ontologyServices.size() == 0) {
		 System.out.println("Ontologies:NONE");
	  } //end if ()
	  else {
		 System.out.println("Ontologies:");
		 int numberOfOntologies = ontologyServices.size();
		 for ( int i = 0; i < numberOfOntologies; i++) {
			OntologyConfigurationRecord currentConfiguration
			   = (OntologyConfigurationRecord) ontologyServices.get(i);
			currentConfiguration.print();
		 } // end for ()
		 

	  } //end else
	  
	  


   }



   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================

}

/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/
package pedro.config;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.ParserConfigurationException;

import java.lang.reflect.Constructor;
import java.lang.Class;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import org.w3c.dom.Text;

import java.util.ArrayList;
import java.io.File;
import java.net.URL;
import java.io.IOException;

import pedro.ontology.OntologyService;
import pedro.ontology.OntologySource;
import pedro.ontology.OntologyFactory;
import pedro.ontology.OntologyServiceDescription;

import pedro.validation.Validator;
import pedro.util.ErrorDialog;
import pedro.system.GlobalConstants;
import pedro.system.PedroException;
import pedro.system.ModelClassLoader;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class ConfigurationFileReader {


   public static void main (String[] args) {
	  ConfigurationFileReader reader = new ConfigurationFileReader();
	  try {
		 reader.parseDocument(new File("C://out//models//tutorial//config//ConfigurationFile.xml"));
	  } 
	  catch (PedroException err1) {
		 ErrorDialog.show(err1.toString());
	  } // end try-catch
	  catch (Exception err2) {
		 ErrorDialog.show(err2.toString());
	  } // end try-catch
	  

   } // end main ()
   
   
   // ==========================================
   // Section Constants
   // ==========================================
   private static ConfigurationFileReader configurationFileReader = null;

   // ==========================================
   // Section Properties
   // ==========================================
   private ArrayList recordImporterClasses;
   private ArrayList fieldConfigurations;
   private String helpFilePath;

   // ==========================================
   // Section Construction
   // ==========================================
   public ConfigurationFileReader() {
	  fieldConfigurations = new ArrayList();
	  recordImporterClasses = new ArrayList();

	  File modelDirectory = GlobalConstants.getModelDirectory();
	  
	  StringBuffer buffer = new StringBuffer();
	  buffer.append(modelDirectory.getAbsolutePath() );
	  buffer.append(File.separator);
	  buffer.append("doc");
	  buffer.append(File.separator);
	  helpFilePath = buffer.toString();
   }

   static public ConfigurationFileReader getConfigurationFileReader() {
	  if ( configurationFileReader == null) {
		 configurationFileReader = new ConfigurationFileReader();
	  } //end if ()
	  
	  return configurationFileReader;
   }

   // ==========================================
   // Section Accessors
   // ==========================================
   public void parseDocument(File file) 
	  throws ParserConfigurationException, 
			 PedroException,
			 SAXException,
			 IOException {
	  
	  DocumentBuilderFactory documentBuilderFactory
		 = DocumentBuilderFactory.newInstance();
	  
	  DocumentBuilder documentBuilder
		 = documentBuilderFactory.newDocumentBuilder();
	  
	  Document document = documentBuilder.parse(file);

	  Element schemaNode = null;
	  Node currentChild = document.getFirstChild();

	  while ( currentChild != null) {
		 if ( currentChild.getNodeType() == Node.ELEMENT_NODE) {
			Element element = (Element) currentChild;
			if ( element.getTagName().equals("schema") == true) {
			   schemaNode = element;
			   break;
			} //end if ()
			
		 } //end if ()
		 currentChild = currentChild.getNextSibling();
	  } //end while ()

	  if ( schemaNode == null) {
		 throw new PedroException("Experiment file doesn't specify schema information");
	  } //end if ()

	  //now parse records
	  currentChild = schemaNode.getFirstChild();

	  while ( currentChild != null) {
		 if ( currentChild.getNodeType() == Node.ELEMENT_NODE) {
			Element currentElement = (Element) currentChild;
			
			if ( parseRecordImportMenuClasses(currentElement) == false) {
			   if ( parseSchemaLocation(currentElement) == false) {
				  if ( parseSchemaInstance(currentElement) == false) {
					 if ( parseStyleSheet(currentElement) == false) {
						if ( parseRecord(currentElement) == false) {
						   ErrorDialog.show("Unrecognized tag in configuration file");
						}
					 } //end if ()
				  } //end if ()
			   } //end if ()
			}
		 }
		 currentChild = currentChild.getNextSibling();
	  } //end while ()

   }

   private boolean parseRecordImportMenuClasses(Element importFormatsElement) {

	  String importFormatsTag = importFormatsElement.getTagName();
	  if ( importFormatsTag.equals("recordImportFormats") == false) {
		 return false;
	  } //end if ()

	  //we should expect a number of record import tags
	  Node currentChild = importFormatsElement.getFirstChild();

	  ModelClassLoader modelClassLoader
		 = ModelClassLoader.getModelClassLoader();

	  try {
		 
		 while ( currentChild != null) {
			if ( currentChild.getNodeType() == Node.ELEMENT_NODE) {
			   Element formatElement = (Element) currentChild;
			   
			   Node fieldChild  = formatElement.getFirstChild();
			   if ( fieldChild.getNodeType() == Node.TEXT_NODE) {
				  Text text = (Text) fieldChild;
				  String data = text.getData();
				  data = data.trim();
				  if ( data.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) == false) {
					 Class recordImporterClass = modelClassLoader.loadClass(data);
					 recordImporterClasses.add(recordImporterClass);
				  }
			   }
			} //end if ()
		 
			currentChild = currentChild.getNextSibling();
		 } //end while ()
		 
	  } catch (Exception err) {
		 ErrorDialog.show(err.toString());
	  } // end try-catch

	  return true;
   }

   private boolean parseSchemaLocation(Element schemaLocationElement) {

	  String schemaLocationTag = schemaLocationElement.getTagName();
	  if ( schemaLocationTag.equals("schemaLocation") == false) {
		 return false;
	  } //end if ()

	  try {
		 Node fieldChild  = schemaLocationElement.getFirstChild();
		 if ( fieldChild.getNodeType() == Node.TEXT_NODE) {
			Text text = (Text) fieldChild;
			String data = text.getData();
			data = data.trim();
			if ( data.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) == false) {
			   //set the GlobalConstants value
			   GlobalConstants.setSchemaLocation(data);
			}
		 }
	  } catch (Exception err) {
		 ErrorDialog.show(err.toString());
	  } // end try-catch

	  return true;
   }

   private boolean parseSchemaInstance(Element schemaInstanceElement) {
	  String schemaInstanceTag = schemaInstanceElement.getTagName();

	  if ( schemaInstanceTag.equals("schemaInstance") == false) {
		 return false;
	  } //end if ()

	  try {
		 Node fieldChild  = schemaInstanceElement.getFirstChild();
		 if ( fieldChild.getNodeType() == Node.TEXT_NODE) {
			Text text = (Text) fieldChild;
			String data = text.getData();
			data = data.trim();
			if ( data.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) == false) {
			   //set the GlobalConstants value
			   GlobalConstants.setSchemaInstance(data);
			}
		 }
	  } catch (Exception err) {
		 ErrorDialog.show(err.toString());
	  } // end try-catch

	  return true;
   }

   private boolean parseStyleSheet(Element styleSheetElement) {
	  String styleSheetTag = styleSheetElement.getTagName();

	  if ( styleSheetTag.equals("styleSheet") == false) {
		 return false;
	  } //end if ()

	  //we should expect a number of record import tags
	  try {

		 Node fieldChild  = styleSheetElement.getFirstChild();
		 if ( fieldChild.getNodeType() == Node.TEXT_NODE) {
			Text text = (Text) fieldChild;
			String data = text.getData();
			data = data.trim();
			if ( data.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) == false) {
			   //set the GlobalConstants value
			   GlobalConstants.setStyleSheet(data);
			}
		 }
	  } catch (Exception err) {
		 ErrorDialog.show(err.toString());
	  } // end try-catch

	  return true;
   }

   private boolean parseRecord(Element record) throws PedroException {

	  String recordName = record.getTagName();

	  FieldConfigurationRecord recordConfiguration 
		 = getConfigurationRecord(recordName, null);

	  if (recordConfiguration == null) {
		 recordConfiguration = new FieldConfigurationRecord(recordName,
														   null);
	  } //end if ()

	  Node currentChild = record.getFirstChild();

	  while ( currentChild != null) {
		 if ( currentChild.getNodeType() == Node.ELEMENT_NODE) {
			Element currentElement = (Element) currentChild;
			String tagName = currentElement.getTagName();
			if ( tagName.equals("helpLink") == true) {

			   Node fieldChild  = currentElement.getFirstChild();
			   if ( fieldChild.getNodeType() == Node.TEXT_NODE) {
				  Text text = (Text) fieldChild;
				  String data = text.getData();
				  data = data.trim();
				  if ( data.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) == false) {
					 
					 try {
						String currentHelpFileName = helpFilePath+data;
						File currentHelpFile = new File(currentHelpFileName);
						URL helpLink = currentHelpFile.toURL();
						
						//for some reason this step is necessary if we want to
						//read html files of the format blah.html#heading
						helpLink = new URL(helpLink.toString() );
						recordConfiguration.setHelpLink(helpLink);
					 } catch (Exception err) {
						ErrorDialog.show(err.toString() );
					 } // end try-catch
					 
				  }
			   }
			} //end if ()
			else if ( tagName.equals("fields") == true) {
			   parseFields(recordName,
						   currentElement);
			} //end else ()
			else if ( tagName.equals("formComments") == true) {
			   Node fieldChild  = currentElement.getFirstChild();
			   if ( fieldChild.getNodeType() == Node.TEXT_NODE) {
				  Text text = (Text) fieldChild;
				  String data = text.getData();
				  data = data.trim();
				  if ( data.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) == false) {
					 recordConfiguration.setFormComments(data);
				  }
			   }
			} //end else ()


		 } //end if ()

		 currentChild = currentChild.getNextSibling();
	  } //end while ()

	  addConfiguration(recordConfiguration);

	  return true;
   }

   public ArrayList getRecordImporterClasses() {
	  return recordImporterClasses;
   }

   public FieldConfigurationRecord getConfigurationRecord(String recordName, 
														  String fieldName) {

	  int numberOfFields = fieldConfigurations.size();

	  for ( int i = 0; i < numberOfFields; i++) {
		 FieldConfigurationRecord currentField = (FieldConfigurationRecord) fieldConfigurations.get(i);
		 String currentRecordType = currentField.getRecordType();
		 String currentFieldName = currentField.getFieldName();

		 if ( currentRecordType.equals(recordName) == true) {
			if ( currentFieldName == null) {
			   if ( fieldName == null) {
				  return currentField;
			   } //end if ()
			} //end if ()
			else if ( currentFieldName.equals(fieldName) == true) {
			   return currentField;
			} //end else ()
		 } //end if ()

	  } // end for ()

	  return null;
   }

   private String getFieldValue(Element element) {
	  Node fieldChild  = element.getFirstChild();
	  if ( fieldChild.getNodeType() == Node.TEXT_NODE) {
		 Text text = (Text) fieldChild;
		 String data = text.getData();
		 data = data.trim();
		 return data;
	  }
	  return "";
   }

   private void parseField(String recordType,
						   Element field) throws PedroException {

	  String fieldName = field.getTagName();

	  FieldConfigurationRecord fieldConfiguration = getConfigurationRecord(recordType, fieldName);
	  if ( fieldConfiguration == null) {
		 fieldConfiguration = new FieldConfigurationRecord(recordType,
														   fieldName);


	  } //end if ()
	  

	  Node currentChild = field.getFirstChild();

	  //parsing attributes for field
	  while ( currentChild != null) {
		 if ( currentChild.getNodeType() == Node.ELEMENT_NODE) {
			Element currentElement = (Element) currentChild;
			String attributeName = currentElement.getTagName();

			if ( attributeName.equals("ontologyService") == true) {
			   OntologyService ontologyService 
				  = parseOntologyService(recordType, fieldName, currentElement);
			   fieldConfiguration.addOntologyService( ontologyService );
			} //end else ()
			else {
			   String fieldValue = getFieldValue(currentElement);
			   if ( fieldValue.equals("") == false) {
					 
				  if ( attributeName.equals("helpLink") == true) {
					 try {

						String currentHelpFileName = helpFilePath+fieldValue;
						File currentHelpFile = new File(currentHelpFileName);


						URL helpLink = currentHelpFile.toURL();
						//for some reason this step is necessary if we want to
						//read html files of the format blah.html#heading
						helpLink = new URL(helpLink.toString() );
						fieldConfiguration.setHelpLink(helpLink);
					 } catch (Exception err) {
						StringBuffer errorMessage = new StringBuffer();
						errorMessage.append("Can't parse the help link for record \"");
						errorMessage.append(recordType);
						errorMessage.append("\" field \"");
						errorMessage.append(fieldName);
						errorMessage.append("\"");
						throw new PedroException(errorMessage.toString() );
					 } // end try-catch
					 
				  } //end if ()
				  else if ( attributeName.equals("formComments") == true) {
					 fieldConfiguration.setFormComments(fieldValue);
				  }
				  else if ( attributeName.equals("validator") == true) {
					 try {

						ModelClassLoader modelClassLoader
						   = ModelClassLoader.getModelClassLoader();
						Class validatorClass = modelClassLoader.loadClass(fieldValue);
						
						//use reflection to instantiate
						Constructor constructor 
						   = validatorClass.getConstructor(new Class[0]);
						Validator validator 
						   = (Validator) constructor.newInstance(new Object[0]);
						fieldConfiguration.addValidator(validator);

					 } catch (Exception err) {
						StringBuffer errorMessage = new StringBuffer();
						errorMessage.append("Can't parse the validator class for record \"");
						errorMessage.append(recordType);
						errorMessage.append("\" field \"");
						errorMessage.append(fieldName);
						errorMessage.append("\"");
						throw new PedroException(errorMessage.toString() );
					 } // end try-catch
					 
				  } //end else ()
				  else if ( attributeName.equals("default") == true) {
					 fieldConfiguration.setDefaultValue(fieldValue);
				  } //end else ()
				  else if ( attributeName.equals("units") == true) {
					 fieldConfiguration.setUnits(fieldValue);
				  } //end else ()
				  else if ( attributeName.equals("disableFreeText") == true) {
					 if ( fieldValue.toUpperCase().equals("TRUE") == true) {
						fieldConfiguration.setDisableFreeText(true);
					 } //end if ()
					 else {
						fieldConfiguration.setDisableFreeText(false);
					 } //end else
				  } //end else ()
				  else if (attributeName.equals("partOfRecordDisplayName") == true) {
					 if ( fieldValue.toUpperCase().equals("TRUE") == true) {
						fieldConfiguration.setDisplayNameComponent(true);
					 } //end if ()
					 else {
						fieldConfiguration.setDisplayNameComponent(false);
					 } //end else
				  } //end else ()
				  else if (attributeName.equals("isScrollingTextField") == true) {
					 if ( fieldValue.toUpperCase().equals("TRUE") == true) {
						fieldConfiguration.setScrollingTextField(true);
					 } //end if ()
					 else {
						fieldConfiguration.setScrollingTextField(false);
					 } //end else
				  } //end else ()
			   } //end if ()
			} //end if ()

			
		 } //end else
		 
		 currentChild = currentChild.getNextSibling();
	  } //end while ()
	  
	  addConfiguration(fieldConfiguration);

	  
   }

   private OntologyService parseOntologyService(String recordType,
												String fieldName,
												Element localService) throws PedroException {
	  
	  Class serviceClass = null;
	  String file = null;
	  String parameters = null;

	  Node currentChild = localService.getFirstChild();

	  OntologyServiceDescription serviceDescription
		 = new OntologyServiceDescription();

	  while ( currentChild != null) {
		 if ( currentChild.getNodeType() == Node.ELEMENT_NODE) {
			Element currentElement = (Element) currentChild;
			String attributeName = currentElement.getTagName();

			Node fieldChild  = currentElement.getFirstChild();
			if ( fieldChild.getNodeType() == Node.TEXT_NODE) {
			   Text text = (Text) fieldChild;
			   String data = text.getData();
			   data = data.trim();
			   if ( data.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) == false) {
				  if ( attributeName.equals("ontologyParserClass") == true) {
					 try {

						ModelClassLoader modelClassLoader
						   = ModelClassLoader.getModelClassLoader();
						serviceClass = modelClassLoader.loadClass(data);
						serviceDescription.setOntologyParserClass(serviceClass);

					 } catch (ClassNotFoundException err) {
						StringBuffer errorMessage = new StringBuffer();
						errorMessage.append("Unknown ontology class value \n\"");
						errorMessage.append(data);
						errorMessage.append("\"");
						errorMessage.append("encountered in configuration file \n");
						errorMessage.append("record ");
						errorMessage.append(recordType);
						errorMessage.append(" field ");
						errorMessage.append(fieldName);
						throw new PedroException(errorMessage.toString());
					 } // end try-catch
				  }
				  else if ( attributeName.equals("ontologyViewerClass") == true) {

				  } //end else ()
				  else if ( attributeName.equals("name") == true) {
					 serviceDescription.setName(data);
				  } //end else ()
				  else if ( attributeName.equals("description") == true) {
					 serviceDescription.setDescription(data);
				  } //end else ()
				  else if ( attributeName.equals("isLocalService") == true) {
					 String localOrRemote = data;
					 localOrRemote = localOrRemote.toUpperCase();
					 if ( localOrRemote.equals(GlobalConstants.TRUE) == true) {
						serviceDescription.setLocalService(true);
					 } //end if ()
					 else {
						serviceDescription.setLocalService(false);
					 } //end else

				  } //end else ()
				  else if ( attributeName.equals("parserInputFile") == true) {
					 serviceDescription.setParserInputFile(data);
				  } //end else ()
				  else if ( attributeName.equals("parameters") == true) {
					 parameters = data;
				  } //end else ()
				  else {
					 StringBuffer errorMessage = new StringBuffer();
					 errorMessage.append("Unknown ontology attribute \n\"");
					 errorMessage.append(attributeName);
					 errorMessage.append("\"");
					 errorMessage.append("encountered in configuration file \n");
					 errorMessage.append("record ");
					 errorMessage.append(recordType);
					 errorMessage.append(" field ");
					 errorMessage.append(fieldName);
					 
					 throw new PedroException(errorMessage.toString());
				  } //end else
			   }
			} //end else ()
		 }
		 currentChild = currentChild.getNextSibling();
	  } //end while ()


	  OntologyFactory ontologyFactory = OntologyFactory.getOntologyFactory();
	  
	  OntologySource ontologySource 
		 = ontologyFactory.createSource(serviceDescription.getOntologyParserClass(),
										serviceDescription.getParserInputFile() );

	  if ( parameters != null) {
		 //a parameterized view is needed
		 ontologySource = ontologySource.getView(parameters);
	  } //end if ()

	  OntologyService ontologyService = new OntologyService(serviceDescription,
															ontologySource);

	  return ontologyService;
   }

   private void parseFields(String recordName,
							Element fields) throws PedroException {

	  Node currentChild = fields.getFirstChild();
	  
	  String element = null;
	  while ( currentChild != null) {

		 if ( currentChild.getNodeType() == Node.ELEMENT_NODE) {
			Element currentField = (Element) currentChild;
			parseField(recordName,currentField);
		 } //end if ()

		 currentChild = currentChild.getNextSibling();
	  } //end while ()

   }

   private void addConfiguration(FieldConfigurationRecord configuration) {
	  
	  if ( fieldConfigurations.contains(configuration) == false) {
		 fieldConfigurations.add(configuration);
	  } //end if ()
	  

   }

   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================

}

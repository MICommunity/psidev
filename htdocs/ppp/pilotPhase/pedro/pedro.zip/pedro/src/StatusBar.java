/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro;

import javax.swing.JPanel;

import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Font;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class StatusBar {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private static StatusBar statusBar = null;
   private JLabel label;
   private JTextField body;
   private JPanel panel;

   // ==========================================
   // Section Construction
   // ==========================================
   public StatusBar() {
	  panel = new JPanel(new GridBagLayout() );
	  
	  GridBagConstraints gc = new GridBagConstraints();
	  gc.anchor = GridBagConstraints.SOUTHWEST;
	  gc.fill = GridBagConstraints.NONE;
	  gc.gridx = 0;
	  gc.gridy = 0;
	  gc.weightx = 0;
	  
	  label = new JLabel("Status:");
	  panel.add(label,gc);

	  
	  gc.gridx = 1;
	  gc.weightx = 100;
	  gc.fill = GridBagConstraints.HORIZONTAL;
	  body = new JTextField();
	  body.setEditable(false);
	  body.setBackground(label.getBackground() );
	  panel.add(body, gc);
   }

   // ==========================================
   // Section Accessors
   // ==========================================
   static public StatusBar getStatusBar() {
	  if ( statusBar == null) {
		 statusBar = new StatusBar();
	  } //end if ()
	  return statusBar;
   }
   
   public JPanel getPanel() {
	  return panel;
   }

   // ==========================================
   // Section Mutators
   // ==========================================
   public void setFont(Font font) {
	  label.setFont(font);
	  body.setFont(font);
   }

   public void setMessage(String message) {
	  body.setText(message);
   }

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================

}

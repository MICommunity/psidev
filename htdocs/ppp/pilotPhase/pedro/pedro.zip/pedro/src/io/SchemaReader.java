/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.io;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.ParserConfigurationException;


import org.w3c.dom.Document;
import org.xml.sax.SAXException;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import org.w3c.dom.Text;

import java.util.ArrayList;
import java.net.URL;

import pedro.validation.IntegerValidator;
import pedro.validation.BoundedIntegerValidator;
import pedro.validation.DoubleValidator;
import pedro.validation.BoundedDoubleValidator;
import pedro.validation.FloatValidator;
import pedro.validation.BoundedFloatValidator;
import pedro.validation.StringValidator;
import pedro.validation.StringMaskValidator;
import pedro.validation.DateValidator;
import pedro.validation.Validator;

import pedro.model.RecordModelFactory;
import pedro.model.ListFieldModel;
import pedro.model.EditFieldModel;
import pedro.model.RecordModel;
import pedro.model.DataFieldModel;
import pedro.model.TextFieldModel;

import pedro.ontology.OntologyService;

import pedro.util.ErrorDialog;

import pedro.system.GlobalConstants;
import pedro.system.PedroException;

import pedro.config.FieldConfigurationRecord;
import pedro.config.ConfigurationFileReader;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class SchemaReader extends PedroSchemaParser {

   
   // ==========================================
   // Section Constants
   // ==========================================


   // ==========================================
   // Section Properties
   // ==========================================

   private RecordModel topLevelRecord;
   private String schemaName;
   private String schemaXMLN;
   private SchemaListParser listParser;
   private SchemaEditFieldParser editFieldParser;

   private ConfigurationFileReader configurationFileReader;
   private File modelDirectory;

   // ==========================================
   // Section Construction
   // ==========================================
   public SchemaReader() {
	  configurationFileReader
		 = ConfigurationFileReader.getConfigurationFileReader();

	  modelDirectory = GlobalConstants.getModelDirectory();

	  StringBuffer configurationPath = new StringBuffer();
	  configurationPath.append(modelDirectory.getAbsolutePath() );
	  configurationPath.append(File.separator);
	  configurationPath.append("config");
	  configurationPath.append(File.separator);
	  configurationPath.append("ConfigurationFile.xml");
	  
	  File configurationFile = new File(configurationPath.toString() );

	  try {
		 configurationFileReader.parseDocument(configurationFile);
	  } catch (Exception err) {
		 ErrorDialog.show(err.toString());
		 System.exit(0);
	  } // end try-catch
   }

   public void parseDocument(File file) 
   throws ParserConfigurationException, 
		  SAXException,
		  PedroException,
		  IOException {

	  listParser = new SchemaListParser();
	  editFieldParser = new SchemaEditFieldParser();

	  DocumentBuilderFactory documentBuilderFactory
		 = DocumentBuilderFactory.newInstance();
	  DocumentBuilder documentBuilder
		 = documentBuilderFactory.newDocumentBuilder();

	  Document document = documentBuilder.parse(file);

	  topLevelRecord = null;

	  Element schemaElement = PedroSchemaParser.getFirstChildElement(document);

	  String xmlns = schemaElement.getAttribute("xmlns:xs");
	  GlobalConstants.setSchemaInstance(xmlns);


	  Element topLevelElement = PedroSchemaParser.getFirstChildElement(schemaElement);

	  if ( topLevelElement == null) {
		 StringBuffer errorMessage = new StringBuffer();
		 errorMessage.append("model data tag must have at least one element child.");
		 throw new PedroException(errorMessage.toString() );
	  } //end if ()

	  String name = topLevelElement.getAttribute("name");

	  identifyRecord(topLevelElement);

	  //go through and parse all the other ones
	  Node currentNode = topLevelElement.getNextSibling();
	  while ( currentNode != null) {
		 if ( currentNode.getNodeType() == Node.ELEMENT_NODE) {
			Element currentElement = (Element) currentNode;
			RecordModel currentModel = identifyRecord(currentElement);
			if ( currentModel == null) {
			   String nm = currentElement.getAttribute("name");

			   //could be group tag definitions
			   ListFieldModel listFieldModel 
				  = listParser.identifyListField(currentElement);

			} //end if ()

		 } //end if ()
		 
		 currentNode = currentNode.getNextSibling();
	  } //end while ()

	  //takes care of <xs:group ref="ListFieldFactory" ...> cases!
	  RecordModelFactory recordModelFactory
		 = RecordModelFactory.getRecordModelFactory();
	  recordModelFactory.resolveProxyFields();

	  topLevelRecord = recordModelFactory.createRecordModel(name);

	  if ( topLevelRecord == null) {
		 StringBuffer errorMessage = new StringBuffer();
		 errorMessage.append("No top level record was defined.");
		 throw new PedroException(errorMessage.toString() );
	  } //end if ()

   }
   
   public RecordModel getTopLevelRecord() {
	  return topLevelRecord;
   }

   
   /*   private void verifyDataModelInformation(Document document) 
   throws PedroException {

	  Element xmlSchemaElement = getElement(document, "xs:schema");

	  if ( xmlSchemaElement == null) {
		 StringBuffer errorMessage = new StringBuffer();
		 errorMessage.append("You're missing a line that begins with ");
		 errorMessage.append("\"<xs:schema xmlns:xs=\"file....\"");
		 throw new PedroException(errorMessage.toString() );
	  } //end if ()

	  Element dataModelTag = getElement(xmlSchemaElement, 
										"xs:element",
										"dataModel");
	  if ( xmlSchemaElement == null) {
		 StringBuffer errorMessage = new StringBuffer();
		 errorMessage.append("No tag specifying data model\n");
		 errorMessage.append("name and version.");
		 throw new PedroException(errorMessage.toString() );
	  } //end if ()

	  this.schemaName = name;
   }
   */

   public String getSchemaXMLN() {
	  return schemaXMLN;
   }

   public String getSchemaName() {
	  return schemaName;
   }

   private RecordModel identifyRecord(Element element) throws PedroException {

	  boolean firstEditField = true;

	  //1. Make sure element has tag name of element
	  if ( element.getTagName().equals("xs:element") == false) {
		 return null;
	  } //end if ()

	  //2. Make sure first child of element is a complexType
	  Element complexTypeCandidate = getFirstChildElement(element);

	  if ( complexTypeCandidate == null) {
		 //has no first element
		 return null;
	  } //end if ()

	  //records begin with complexType tag
	  if ( complexTypeCandidate.getTagName().equals("xs:complexType") == false) {
		 //first element child isn't named "xs:complexType"
		 return null;
	  } //end if ()

	  //3.  make sure that complexType tag has sequence for a first child
	  Element sequenceElement = getFirstChildElement(complexTypeCandidate);

	  if ( sequenceElement == null) {
		 //"xs:complexType" has no first element
		 return null;
	  } //end if ()

	  //records begin with sequence tag
	  if ( sequenceElement.getTagName().equals("xs:sequence") == false) {
		 return null;
	  } //end if ()


	  //!!!! NOW we know it's a record so extract the name, etc

	  //get the record class name
	  String recordClassName = element.getAttribute("name");

	  if ( recordClassName == null) {
		 //this is an error
		 throw new PedroException("record with no name encountered");
	  } //end if ()
	  
	  RecordModel recordModel = new RecordModel();
	  recordModel.setRecordClassName(recordClassName);
	  
	  Node currentChild = sequenceElement.getFirstChild();
	  while ( currentChild != null) {
		 
		 if ( currentChild.getNodeType() == Node.ELEMENT_NODE) {
			Element currentElement = (Element) currentChild;
			
			RecordModel childRecord = identifyRecord(currentElement);
			if ( childRecord == null) {
			   EditFieldModel editFieldModel = editFieldParser.identifyEditField(currentElement);
			   if ( editFieldModel == null) {
				  ListFieldModel listFieldModel = listParser.identifyListField(currentElement);
				  if (listFieldModel == null) {
					 StringBuffer message = new StringBuffer();
					 message.append("Structure is not recognized ");
					 message.append("as a record,edit field or list field.");
					 throw new PedroException(message.toString() );
				  } //end if ()
				  else {
					 recordModel.addField(listFieldModel);
				  } //end else
			   } //end if ()
			   else {
				  //encountered an edit field
				  if ( firstEditField == true) {
					 firstEditField = false;
					 editFieldModel.setDisplayNameComponent(true);
				  } //end if ()
				  recordModel.addField(editFieldModel);
			   } //end else
			} //end if ()
			else {
			   //encountered a nested record, so add in 
			   ListFieldModel listFieldForSingleRecord 
				  = listParser.createListFieldForRecord(currentElement,
														childRecord);

			   recordModel.addField(listFieldForSingleRecord);
			} //end else
			
		 } //end if ()

		 currentChild = currentChild.getNextSibling();
	  } //end while ()

	  addConfigurationDetailsToRecord(recordModel);

	  RecordModelFactory recordModelFactory = RecordModelFactory.getRecordModelFactory();
	  if (recordModelFactory.recordClassRegistered(recordClassName) == false) {
		 recordModelFactory.addFactory(recordClassName,
								  recordModel);
	  } //end if ()

	  return recordModel;

   }

   private void addConfigurationDetailsToRecord(RecordModel recordModel) {

	  String recordClassName = recordModel.getRecordClassName();

	  ArrayList fields = recordModel.getFields();
	  int numberOfFields = fields.size();

	  FieldConfigurationRecord recordConfiguration 
		 = configurationFileReader.getConfigurationRecord(recordClassName,
														  null);
	  if ( recordConfiguration != null) {
		 recordModel.setHelpLink(recordConfiguration.getHelpLink());
	  } //end if ()
	  else {

	  } //end else
	  
	  for ( int i = 0; i < numberOfFields; i++) {

		 DataFieldModel dataFieldModel = (DataFieldModel) fields.get(i);
		 String fieldName = dataFieldModel.getName();

		 FieldConfigurationRecord fieldConfiguration 
			= configurationFileReader.getConfigurationRecord(recordClassName,
															 fieldName);
		 
		 if ( fieldConfiguration != null) {
			dataFieldModel.setHelpLink(fieldConfiguration.getHelpLink() );

			if ( dataFieldModel instanceof EditFieldModel) {
			   EditFieldModel editFieldModel = (EditFieldModel) dataFieldModel;


			   ArrayList validators = fieldConfiguration.getValidators();
			   int numberOfValidators = validators.size();
			   for ( int ithValidator = 0; ithValidator < numberOfValidators; ithValidator++) {
				  Validator currentValidator = (Validator) validators.get(ithValidator);
				  editFieldModel.addValidator(currentValidator);
			   } // end for ()
			   
			   //set default
			   String defaultValue = fieldConfiguration.getDefaultValue();
			   editFieldModel.setDefaultValue(defaultValue);

			   if ( defaultValue.equals("") == false) {
				  try {
					 recordModel.setValue(fieldName,defaultValue,false);
				  } catch (Exception  err) {
					 System.out.println("Blah" + err);
				  } // end try-catch
			   } //end if ()

			   String units = fieldConfiguration.getUnits();
			   editFieldModel.setUnits(units);

			   //setDisplayNameComponent
			   boolean isDisplayNameComponent 
				  = fieldConfiguration.isDisplayNameComponent();

			   editFieldModel.setDisplayNameComponent(isDisplayNameComponent);
			} //end if ()

		 } //end if ()
		 
		 
	  } // end for ()
   }

   // ==========================================
   // Section Accessors
   // ==========================================


   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================

}



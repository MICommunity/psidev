/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.io;


import java.util.ArrayList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

import pedro.model.EditFieldModel;
import pedro.model.TextFieldModel;
import pedro.model.GroupFieldModel;

import pedro.validation.IntegerValidator;
import pedro.validation.BoundedIntegerValidator;
import pedro.validation.DoubleValidator;
import pedro.validation.BoundedDoubleValidator;
import pedro.validation.FloatValidator;
import pedro.validation.BoundedFloatValidator;
import pedro.validation.StringValidator;
import pedro.validation.StringMaskValidator;
import pedro.validation.DateValidator;
import pedro.validation.URLValidator;
import pedro.validation.Choose1FromNValidator;

import pedro.system.GlobalConstants;
import pedro.system.PedroException;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class SchemaEditFieldParser extends PedroSchemaParser {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================

   // ==========================================
   // Section Construction
   // ==========================================
   public SchemaEditFieldParser() {




   }

   // ==========================================
   // Section Accessors
   // ==========================================
   public EditFieldModel identifyEditField(Element element) 
	  throws PedroException {

	  String ref = element.getAttribute("ref");
	  if ( ref.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) == false ) {
		 //don't accept things with "ref"
		 return null;
		 
	  } //end if ()
	  

	  String tagName = element.getTagName();

	  if (tagName.equals("xs:element") == true) {
		 
		 EditFieldModel simpleTypeCandidate = identifySimpleType(element);
		 if ( simpleTypeCandidate != null) {
			return simpleTypeCandidate;
		 } //end if ()
		 
		 //otherwise it's a simple type!

		 String minOccurs = element.getAttribute("minOccurs");
		 String name = element.getAttribute("name");
		 String type = element.getAttribute("type");
		 if ( type.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) == true) {
			type = "xs:string";
		 } //end if ()
		 

		 if ( type.equals("xs:boolean") == true) {
			return createBooleanField(name,
									  minOccurs);
		 } //end if ()
		 else if ( type.equals("xs:integer") == true) {
			return createIntegerField(name,
									  minOccurs,
									  GlobalConstants.NO_ATTRIBUTE_VALUE,
									  GlobalConstants.NO_ATTRIBUTE_VALUE,
									  GlobalConstants.NO_ATTRIBUTE_VALUE,
									  GlobalConstants.NO_ATTRIBUTE_VALUE);
		 } //end else ()
		 else if ( type.equals("xs:float") == true) {
			return createFloatField(name,
									minOccurs,
									GlobalConstants.NO_ATTRIBUTE_VALUE,
									GlobalConstants.NO_ATTRIBUTE_VALUE,
									GlobalConstants.NO_ATTRIBUTE_VALUE,
									GlobalConstants.NO_ATTRIBUTE_VALUE);
		 } //end else ()
		 else if (( type.equals("xs:double") == true) || (type.equals("xs:decimal") == true) ) {
			return createDoubleField(name,
									 minOccurs,
									 GlobalConstants.NO_ATTRIBUTE_VALUE,
									 GlobalConstants.NO_ATTRIBUTE_VALUE,
									 GlobalConstants.NO_ATTRIBUTE_VALUE,
									 GlobalConstants.NO_ATTRIBUTE_VALUE);
		 } //end else ()
		 else if ( type.equals("xs:string") == true) {
			return createStringField(name,
									 minOccurs,
									 GlobalConstants.NO_ATTRIBUTE_VALUE);
		 } //end else ()
		 else if ( type.toUpperCase().equals("XS:ANYURI") == true) {
			return createURLField(name,
								  minOccurs);
		 } //end else ()
		 else if ( type.equals("xs:date") == true) {
			return createDateField(name,
								   minOccurs);
		 } //end else ()
		 else {
			StringBuffer errorMessage = new StringBuffer();
			errorMessage.append("This application doesn't recognize");
			errorMessage.append(" elements of type \"");
			errorMessage.append(tagName);
			errorMessage.append("\"");
			throw new PedroException(errorMessage.toString() );
		 } //end else

	  } //end if ()
	  else if ( tagName.equals("xs:simpleType") == true) {

		 return identifySimpleType(element);
	  } //end else ()
	  else {
		 return null;
	  } //end else
   }

   private ArrayList getEnumerations(Element restrictionTag) {
	  ArrayList items = new ArrayList();

	  Node currentChild = restrictionTag.getFirstChild();
	  while ( currentChild != null) {
		 if ( currentChild.getNodeType() == Node.ELEMENT_NODE) {
			Element currentElement = (Element) currentChild;
			if ( currentElement.getTagName().equals("xs:enumeration") == true) {
			   String value = currentElement.getAttribute("value");
			   if ( value.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) == false) {
				  items.add(value);
			   } //end if ()
			} //end if ()
		 } //end if ()
		 currentChild = currentChild.getNextSibling();
	  } //end while ()
	  
	  return items;

   }

   private EditFieldModel identifySimpleType(Element element)
	  throws PedroException {

	  Element simpleTypeElement = PedroSchemaParser.getFirstChildElement(element);
	  if ( simpleTypeElement == null) {
		 //must have at least an immediate element for a child
		 return null;
	  } //end if ()

	  if ( simpleTypeElement.getTagName().equals("xs:simpleType") == false) {
		 //this immediate element child must be called "xs:simpleType"
		 return null;
	  } //end if ()






	  //element is a simple type

	  //get values for name and whether field is optional or required
	  String minOccurs = element.getAttribute("minOccurs");
	  String name = element.getAttribute("name");


	  //extract the restrictions
	  Element restrictionTag = getElement(simpleTypeElement,
										  "xs:restriction");

	  String minInclusive = GlobalConstants.NO_ATTRIBUTE_VALUE;
	  String maxInclusive = GlobalConstants.NO_ATTRIBUTE_VALUE;
	  String minExclusive = GlobalConstants.NO_ATTRIBUTE_VALUE;
	  String maxExclusive = GlobalConstants.NO_ATTRIBUTE_VALUE;
	  String pattern = GlobalConstants.NO_ATTRIBUTE_VALUE;


	  if ( restrictionTag == null) {
		 StringBuffer errorMessage = new StringBuffer();
		 errorMessage.append("Have encountered a \"simpleType\"");
		 errorMessage.append("that doesn't have a restriction clause.");
		 
		 throw new PedroException(errorMessage.toString() );
	  } //end if ()
	  
	  String type = restrictionTag.getAttribute("base");
	  if ( type.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) == true) {
		 //NO TYPE SPECIFIED
		 StringBuffer errorMessage = new StringBuffer();
		 errorMessage.append("Restriction has no type specified.");
		 throw new PedroException(errorMessage.toString() );
	  } //end if ()
	  
	  ArrayList combinationChoices = getEnumerations(restrictionTag);
	  //now decide what kind of field to create
	  if ( combinationChoices.size() > 0) {
		 return createCombinationField(name,
									   minOccurs,
									   combinationChoices);
	  } //end if ()


	  //must be a simple field 
	  if ( (type.equals("xs:integer") || type.equals("xs:float") || type.equals("xs:double") ) ) {
		 //check for lower and upper bounds

		 Element minInclusiveTag = getElement(restrictionTag,
											  "xs:minInclusive");

		 if ( minInclusiveTag != null) {
			minInclusive = minInclusiveTag.getAttribute("value");
		 } //end if ()
		 

		 Element maxInclusiveTag = getElement(restrictionTag,
											  "xs:maxInclusive");
		 if ( maxInclusiveTag != null) {
			maxInclusive = maxInclusiveTag.getAttribute("value");
		 }

		 Element minExclusiveTag = getElement(restrictionTag,
											  "xs:minExclusive");
		 if ( minExclusiveTag != null) {
			minExclusive = minExclusiveTag.getAttribute("value");
		 } //end if ()
		 
		 
		 Element maxExclusiveTag = getElement(restrictionTag,
											  "xs:maxExclusive");
		 if ( maxExclusiveTag != null) {
			maxExclusive = maxExclusiveTag.getAttribute("value");
		 } //end if ()
		 

	  } //end if ()
	  else if ( type.equals("xs:string") == true) {
		 //check for regular expression mask
		 Element patternTag = getElement(restrictionTag,
										 "xs:pattern");

		 pattern = patternTag.getAttribute("value");
	  } //end else ()
	  else if ( type.equals("xs:date") == true) {
		 //no attributes yet...

	  } //end else ()
	  else {
		 StringBuffer errorMessage = new StringBuffer();
		 errorMessage.append("Type ");
		 errorMessage.append(type);
		 errorMessage.append(" is not handled by this application.");
		 throw new PedroException(errorMessage.toString() );
	  } //end else


	  if ( type.equals("xs:integer") ) {
		 return createIntegerField(name,
								   minOccurs,
								   minInclusive,
								   maxInclusive,
								   minExclusive,
								   maxExclusive);
	  } //end else ()
	  else if ( type.equals("xs:string") ) {
		 return createStringField(name,
								  minOccurs,
								  pattern);
	  } //end else ()
	  else if ( type.equals("xs:float") ) {
		 return createFloatField(name,
								 minOccurs,
								 minInclusive,
								 maxInclusive,
								 minExclusive,
								 maxExclusive);
		 
	  } //end else ()
	  else if ( type.equals("xs:double") ) {
		 return createDoubleField(name,
								   minOccurs,
								   minInclusive,
								   maxInclusive,
								   minExclusive,
								   maxExclusive);
		 
	  } //end else ()
	  else if ( type.equals("xs:date") ) {
		 return createDateField(name,
								minOccurs);
	  } //end else ()
	  else {
		 return createBooleanField(name,
								   minOccurs);
	  } //end else
   }


   //==========================================================================
   //Creation fields
   //==========================================================================

   private EditFieldModel createFloatField(String name,
										   String minOccurs,
										   String minInclusive,
										   String maxInclusive,
										   String minExclusive,
										   String maxExclusive) throws PedroException {
	  
	  try {
		 
		 TextFieldModel textFieldModel = new TextFieldModel();
		 textFieldModel.setUIRenderingType(GlobalConstants.TEXT_FIELD);
		 textFieldModel.setRequiredField(isRequiredOrOptional(minOccurs));
		 textFieldModel.setName(name);

		 DomainBoundaryChecker boundaryChecker =
			new DomainBoundaryChecker(minInclusive,
									  maxInclusive,
									  minExclusive,
									  maxExclusive);

		 String lowerBound = boundaryChecker.getLowerBound();
		 String upperBound = boundaryChecker.getUpperBound();
		 boolean isLowerBoundInclusive = boundaryChecker.isLowerBoundInclusive();
		 boolean isUpperBoundInclusive = boundaryChecker.isUpperBoundInclusive();

		 if ( lowerBound.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) &&
			  (upperBound.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) )) {
			//just put in an integer validator
			textFieldModel.addValidator(new FloatValidator() );
			return textFieldModel;
		 } //end if ()

		 //boundary conditions were specified
		 BoundedFloatValidator validator = new BoundedFloatValidator();


		 try {
			if ( lowerBound.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) == false) {
			   float lowerBoundValue = Float.parseFloat(lowerBound);
			   validator.setLowerBound(lowerBoundValue,
									   isLowerBoundInclusive);
			} //end if ()
		 } catch (NumberFormatException err1) {
			StringBuffer errorMessage = new StringBuffer();
			errorMessage.append("Field ");
			errorMessage.append(name);
			errorMessage.append(" has an illegal float value ");
			errorMessage.append("\"");
			errorMessage.append(lowerBound);
			errorMessage.append("\" as a lower bound");
			throw new PedroException(errorMessage.toString() );
		 } // end try-catch

		 try {
			if ( upperBound.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) == false) {
			   float upperBoundValue = Float.parseFloat(upperBound);
			   validator.setUpperBound(upperBoundValue,
									   isUpperBoundInclusive);
			} //end if ()
		 } catch (NumberFormatException err2) {
			StringBuffer errorMessage = new StringBuffer();
			errorMessage.append("Field ");
			errorMessage.append(name);
			errorMessage.append(" has an illegal float value ");
			errorMessage.append("\"");
			errorMessage.append(lowerBound);
			errorMessage.append("\" as an upper bound");
			throw new PedroException(errorMessage.toString() );
		 } // end try-catch

		 textFieldModel.addValidator(validator);
		 return textFieldModel;
		 
	  } catch (NumberFormatException err) {
		 StringBuffer errorMessage = new StringBuffer();
		 errorMessage.append(" ");
		 errorMessage.append("\"<xs:schema xmlns:xs=\"file....\"");
		 throw new PedroException(errorMessage.toString() );
	  } // end try-catch


   }

   private EditFieldModel createDoubleField(String name,
											String minOccurs,
											String minInclusive,
											String maxInclusive,
											String minExclusive,
											String maxExclusive) throws PedroException {

	  try {

		 TextFieldModel textFieldModel = new TextFieldModel();
		 textFieldModel.setUIRenderingType(GlobalConstants.TEXT_FIELD);
		 textFieldModel.setRequiredField(isRequiredOrOptional(minOccurs));
		 textFieldModel.setName(name);


		 DomainBoundaryChecker boundaryChecker =
			new DomainBoundaryChecker(minInclusive,
									  maxInclusive,
									  minExclusive,
									  maxExclusive);

		 String lowerBound = boundaryChecker.getLowerBound();
		 String upperBound = boundaryChecker.getUpperBound();

		 boolean isLowerBoundInclusive = boundaryChecker.isLowerBoundInclusive();
		 boolean isUpperBoundInclusive = boundaryChecker.isUpperBoundInclusive();


		 if ( lowerBound.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) &&
			  (upperBound.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) )) {
			//just put in an integer validator
			textFieldModel.addValidator(new DoubleValidator() );
			return textFieldModel;
		 } //end if ()

		 //boundary conditions were specified
		 BoundedDoubleValidator validator = new BoundedDoubleValidator();


		 try {
			if ( lowerBound.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) == false) {
			   double lowerBoundValue = Double.parseDouble(lowerBound);
			   validator.setLowerBound(lowerBoundValue,
									   isLowerBoundInclusive);
			} //end if ()
		 } catch (NumberFormatException err1) {
			StringBuffer errorMessage = new StringBuffer();
			errorMessage.append("Field ");
			errorMessage.append(name);
			errorMessage.append(" has an illegal double value ");
			errorMessage.append("\"");
			errorMessage.append(lowerBound);
			errorMessage.append("\" as a lower bound");
			throw new PedroException(errorMessage.toString() );
		 } // end try-catch

		 try {
			if ( upperBound.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) == false) {
			   double upperBoundValue = Double.parseDouble(upperBound);
			   validator.setUpperBound(upperBoundValue,
									   isUpperBoundInclusive);
			} //end if ()
		 } catch (NumberFormatException err2) {
			StringBuffer errorMessage = new StringBuffer();
			errorMessage.append("Field ");
			errorMessage.append(name);
			errorMessage.append(" has an illegal double value ");
			errorMessage.append("\"");
			errorMessage.append(lowerBound);
			errorMessage.append("\" as an upper bound");
			throw new PedroException(errorMessage.toString() );
		 } // end try-catch

		 textFieldModel.addValidator(validator);
		 return textFieldModel;
		 
	  } catch (NumberFormatException err) {
		 StringBuffer errorMessage = new StringBuffer();
		 errorMessage.append(" ");
		 errorMessage.append("\"<xs:schema xmlns:xs=\"file....\"");
		 throw new PedroException(errorMessage.toString() );
	  } // end try-catch


   }

   private EditFieldModel createIntegerField(String name,
											 String minOccurs,
											 String minInclusive,
											 String maxInclusive,
											 String minExclusive,
											 String maxExclusive) throws PedroException {

	  try {
		 
		 TextFieldModel textFieldModel = new TextFieldModel();
		 textFieldModel.setRequiredField(isRequiredOrOptional(minOccurs));
		 textFieldModel.setUIRenderingType(GlobalConstants.TEXT_FIELD);
		 textFieldModel.setName(name);

		 DomainBoundaryChecker boundaryChecker =
			new DomainBoundaryChecker(minInclusive,
									  maxInclusive,
									  minExclusive,
									  maxExclusive);

		 String lowerBound = boundaryChecker.getLowerBound();
		 String upperBound = boundaryChecker.getUpperBound();
		 boolean isLowerBoundInclusive = boundaryChecker.isLowerBoundInclusive();
		 boolean isUpperBoundInclusive = boundaryChecker.isUpperBoundInclusive();

		 if ( lowerBound.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) &&
			  (upperBound.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) )) {
			//just put in an integer validator
			textFieldModel.addValidator(new IntegerValidator() );
			return textFieldModel;
		 } //end if ()

		 //boundary conditions were specified
		 BoundedIntegerValidator validator = new BoundedIntegerValidator();

		 try {
			if ( lowerBound.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) == false) {
			   int lowerBoundValue = Integer.parseInt(lowerBound);
			   validator.setLowerBound(lowerBoundValue,
									   isLowerBoundInclusive);
			} //end if ()
		 } catch (NumberFormatException err1) {
			StringBuffer errorMessage = new StringBuffer();
			errorMessage.append("Field ");
			errorMessage.append(name);
			errorMessage.append(" has an illegal integer value ");
			errorMessage.append("\"");
			errorMessage.append(lowerBound);
			errorMessage.append("\" as a lower bound");
			throw new PedroException(errorMessage.toString() );
		 } // end try-catch

		 try {
			if ( upperBound.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) == false) {
			   int upperBoundValue = Integer.parseInt(upperBound);
			   validator.setUpperBound(upperBoundValue,
									   isUpperBoundInclusive);
			} //end if ()
		 } catch (NumberFormatException err2) {
			StringBuffer errorMessage = new StringBuffer();
			errorMessage.append("Field ");
			errorMessage.append(name);
			errorMessage.append(" has an illegal integer value ");
			errorMessage.append("\"");
			errorMessage.append(lowerBound);
			errorMessage.append("\" as an upper bound");
			throw new PedroException(errorMessage.toString() );
		 } // end try-catch
		 
		 textFieldModel.addValidator(validator);
		 return textFieldModel;
		 
	  } catch (NumberFormatException err) {
		 StringBuffer errorMessage = new StringBuffer();
		 errorMessage.append(" ");
		 errorMessage.append("\"<xs:schema xmlns:xs=\"file....\"");
		 throw new PedroException(errorMessage.toString() );
	  } // end try-catch


   }

   private EditFieldModel createDateField(String name,
										  String minOccurs) {

	  EditFieldModel dateFieldModel = new EditFieldModel();
	  dateFieldModel.setName(name);
	  dateFieldModel.setUIRenderingType(GlobalConstants.DATE_FIELD);
	  dateFieldModel.setRequiredField(isRequiredOrOptional(minOccurs));
	  dateFieldModel.addValidator(new DateValidator() );
	  return dateFieldModel;
   }

   private EditFieldModel createURLField(String name,
									String minOccurs) {

	  EditFieldModel urlFieldModel = new EditFieldModel();
	  urlFieldModel.setUIRenderingType(GlobalConstants.URL_FIELD);
	  urlFieldModel.setRequiredField(isRequiredOrOptional(minOccurs));
	  urlFieldModel.setName(name);
	  urlFieldModel.addValidator(new URLValidator() );
	  return urlFieldModel;
   }

   private EditFieldModel createStringField(String name,
											String minOccurs,
											String pattern) {


	  TextFieldModel textFieldModel = new TextFieldModel();
	  textFieldModel.setRequiredField(isRequiredOrOptional(minOccurs));
	  textFieldModel.setUIRenderingType(GlobalConstants.TEXT_FIELD);
	  textFieldModel.setName(name);

	  if ( pattern.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) == true) {
		 textFieldModel.addValidator(new StringValidator() );
	  } //end if ()
	  else {
		 textFieldModel.addValidator(new StringMaskValidator(pattern) );
	  } //end else
	  
	  return textFieldModel;
   }

   private EditFieldModel createCombinationField(String name,
												 String minOccurs,
												 ArrayList choiceList) {
	  
	  GroupFieldModel groupFieldModel = new GroupFieldModel();
	  groupFieldModel.setRequiredField(isRequiredOrOptional(minOccurs));
	  groupFieldModel.setName(name);


	  int numberOfChoices = choiceList.size();
	  String[] choices = (String[]) choiceList.toArray(new String[0]);
	  groupFieldModel.setChoices(choices);

	  if ( (numberOfChoices >= 2) && (numberOfChoices <= 3) ) {
		 //create a RadioField
		 groupFieldModel.setUIRenderingType(GlobalConstants.RADIO_FIELD);
	  } //end if ()
	  else {
		 groupFieldModel.setUIRenderingType(GlobalConstants.COMBINATION_FIELD);
	  } //end else

	  groupFieldModel.addValidator(new Choose1FromNValidator(choices) );

	  return groupFieldModel;
   }

   private EditFieldModel createBooleanField(String name,
											 String minOccurs) {
	  
	  GroupFieldModel groupFieldModel = new GroupFieldModel();
	  groupFieldModel.setRequiredField(isRequiredOrOptional(minOccurs));

	  String[] trueFalse = new String[2];
	  trueFalse[0] = GroupFieldModel.TRUE;
	  trueFalse[1] = GroupFieldModel.FALSE;
	  
	  groupFieldModel.setUIRenderingType(GlobalConstants.RADIO_FIELD);
	  groupFieldModel.setName(name);
	  groupFieldModel.setChoices(trueFalse);
	  groupFieldModel.addValidator(new Choose1FromNValidator(trueFalse) );

	  return groupFieldModel;
   }


   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================

}

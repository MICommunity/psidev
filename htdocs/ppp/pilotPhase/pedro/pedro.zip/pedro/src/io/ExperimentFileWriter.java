/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.io;

import java.io.FileOutputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.PrintWriter;
import java.io.PrintStream;
import java.io.File;
import java.util.ArrayList;
import javax.swing.tree.DefaultTreeModel;

import java.util.zip.ZipOutputStream;
import java.util.zip.ZipFile;
import java.util.zip.ZipException;
import java.util.zip.ZipEntry;

import pedro.view.NavigationTree;
import pedro.view.NavigationTreeNode;

import pedro.model.RecordModel;
import pedro.model.RecordModelFactory;
import pedro.model.EditFieldModel;
import pedro.model.DataFieldModel;
import pedro.model.ListFieldModel;

import pedro.system.GlobalConstants;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class ExperimentFileWriter {

   
   // ==========================================
   // Section Constants
   // ==========================================
   private static final int BUFFER_SIZE = 2048;


   // ==========================================
   // Section Properties
   // ==========================================
   private boolean writeChildRecords;
   private boolean writeTemplate;
   private RecordModel topRecordModel;

   // ==========================================
   // Section Construction
   // ==========================================
   public ExperimentFileWriter() {
	  writeChildRecords = true;
	  writeTemplate = false;
   }

   // ==========================================
   // Section Accessors
   // ==========================================
   public void setWriteTemplate(boolean writeTemplate) {
	  this.writeTemplate = writeTemplate;
   }

   /**
	* assumes file will be of format "x.pdz"
	*/
   public void writeFile(File file, 
						 NavigationTreeNode node,
						 boolean writeChildRecords) {
	  
	  try {
		 //derive "x.pdr"
		 String zipFileName = file.getAbsolutePath();
		 int dotPosition = zipFileName.lastIndexOf(".");
		 String nativeFileName = zipFileName.substring(0,dotPosition);
		 nativeFileName = nativeFileName + ".pdr";
		 File nativeFile = new File(nativeFileName);
		 
		 writeNativeFormatFile(nativeFile,
							   node,
							   writeChildRecords);
		 
		 createZipFile(file,
					   nativeFile);

		 nativeFile.delete();

	  } catch (Exception err) {
		 System.out.println(err);
	  } // end try-catch

   }

   /**
	* assumes file will be of format "x.pdr"
	*/
   private void writeNativeFormatFile(File file, NavigationTreeNode node, boolean writeChildRecords) {

	  this.writeChildRecords = writeChildRecords;

	  try {
		 PrintWriter out
			= new PrintWriter(new FileOutputStream(file) );

		 topRecordModel = node.getRecordModel();

		 RecordModelFactory recordModelFactory = RecordModelFactory.getRecordModelFactory();
		 String schemaName = GlobalConstants.getModelName();

		 if ( writeTemplate == true) {
			out.print("<template ");
			
			//put in the model stamp
			out.print(recordModelFactory.getModelStamp() );
			out.println(">");
			out.flush();
			
			visitRecordModel(0,topRecordModel,out);
			out.println("</template>");
			out.flush();
		 } //end if ()
		 else {
			visitRecordModel(0,topRecordModel,out);
			out.flush();
		 } //end else
		 out.flush();
		 out.close();

	  } catch (Exception err) {
		 
	  } // end try-catch

   }


   /**
	* assumes file is of the format "x.pdr"
	*/
   private void createZipFile(File zipFile,
							  File nativeFormatFile) throws Exception {

	  FileOutputStream plainFileStream
		 = new FileOutputStream(zipFile);
	  
	  //feed this stream to a Zip stream
	  ZipOutputStream zipOut 
		 = new ZipOutputStream(new BufferedOutputStream(plainFileStream));
	  byte[] data = new byte[BUFFER_SIZE];

	  FileInputStream nativeFileStream
		 = new FileInputStream(nativeFormatFile);
	  BufferedInputStream bufferedNativeFileStream
		 = new BufferedInputStream(nativeFileStream, BUFFER_SIZE);

	  ZipEntry entry = new ZipEntry(nativeFormatFile.getName());
	  zipOut.putNextEntry(entry);

	  int count = 0;
	  while((count = bufferedNativeFileStream.read(data, 0, BUFFER_SIZE)) != -1) {
		 zipOut.write(data, 0, count);
	  }
	  zipOut.flush();

	  bufferedNativeFileStream.close();
	  zipOut.close();

   }

   private void visitRecordModel(int indentationLevel,
								 RecordModel recordModel, 
								 PrintWriter out) {

	  StringBuffer recordIndentation = new StringBuffer();
	  for ( int i = 0; i < indentationLevel; i++) {
		 recordIndentation.append("\t");
	  } // end for ()
	  
	  StringBuffer fieldIndentation = new StringBuffer();
	  for ( int i = 0; i < indentationLevel+1; i++) {
		 fieldIndentation.append("\t");
	  } // end for ()
	  
	  StringBuffer dataIndentation = new StringBuffer();
	  for ( int i = 0; i < indentationLevel+2; i++) {
		 dataIndentation.append("\t");
	  } // end for ()

	  String name = recordModel.getRecordClassName();
	  if ( recordModel == topRecordModel) {

		 RecordModelFactory recordModelFactory =
			RecordModelFactory.getRecordModelFactory();
		 String styleSheetTag = recordModelFactory.getStyleSheetStamp();
		 if ( styleSheetTag != null) {
			out.println(styleSheetTag);
		 } //end if ()

		 out.print(recordIndentation.toString()+ "<"+name);

		 //write out the file stamp details

		 out.print(" ");

		 out.print(recordModelFactory.getModelStamp() );
		 out.println(">");
	  } //end if ()
	  else {
		 out.print(recordIndentation.toString()+ "<"+name);
		 out.println(">");
	  } //end else
	  
	  out.flush();

	  ArrayList fields = recordModel.getFields();
	  int numberOfFields = fields.size();

	  for ( int i = 0; i < numberOfFields; i++) {

		 DataFieldModel currentFieldModel = (DataFieldModel) fields.get(i);
		 String fieldName = currentFieldModel.getName();


		 if ( currentFieldModel instanceof EditFieldModel) {
			EditFieldModel editField = (EditFieldModel) currentFieldModel;

			out.println(fieldIndentation.toString()+"<"+fieldName + ">");
			out.println(dataIndentation.toString() + editField.getValue() );
			out.println(fieldIndentation.toString()+"</" + fieldName + ">"); 
			out.flush();

		 } //end if ()
		 else if ( ( currentFieldModel instanceof ListFieldModel) &&
				   (writeChildRecords == true)) {

			ListFieldModel listField = (ListFieldModel) currentFieldModel;
			ArrayList listChildren = listField.getChildren();
			int numberOfChildren = listChildren.size();

			//out.println(fieldIndentation.toString()+"<"+fieldName + " type=\"listField\">"); 
			out.println(fieldIndentation.toString()+"<"+fieldName + ">"); 

			for (int j = 0; j < numberOfChildren; j++ ) {
			   RecordModel currentChild = (RecordModel) listChildren.get(j);
			   visitRecordModel(indentationLevel + 2,
								currentChild, 
								out);
			} // end for ()


			out.println(fieldIndentation.toString()+"</" + fieldName + ">"); 
			out.flush();

		 } //end else ()

	  } // end for ()
	  out.println(recordIndentation.toString()+"</" + name + ">");
	  out.flush();

   }

   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================

}

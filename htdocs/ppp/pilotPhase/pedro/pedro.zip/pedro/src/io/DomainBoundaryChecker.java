/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.io;

import pedro.system.GlobalConstants;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class DomainBoundaryChecker {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // =========================================
   private boolean isLowerBoundInclusive;
   private boolean isUpperBoundInclusive;
   private String lowerBound;
   private String upperBound;

   // ==========================================
   // Section Construction
   // ==========================================
   public DomainBoundaryChecker(String minInclusive,
								String maxInclusive,
								String minExclusive,
								String maxExclusive) {

	  isLowerBoundInclusive = false;
	  isUpperBoundInclusive = false;

	  lowerBound = "";

	  if ( minInclusive.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) == false) {
		 isLowerBoundInclusive = true;
		 lowerBound = minInclusive;
	  } //end if ()
	  else if ( minExclusive.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) == false) {
		 isLowerBoundInclusive = false;
		 lowerBound = minExclusive;
	  } //end else ()
	  
	  upperBound = "";
	  if ( maxInclusive.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) == false) {
		 isUpperBoundInclusive = true;
		 upperBound = maxInclusive;
	  } //end if ()
	  else if ( maxExclusive.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) == false) {
		 isUpperBoundInclusive = false;
		 upperBound = maxExclusive;
	  } //end else ()


   }


   // ==========================================
   // Section Accessors
   // ==========================================
  public boolean isLowerBoundInclusive() {
	  return isLowerBoundInclusive;
   }

   public boolean isUpperBoundInclusive() {
	  return isUpperBoundInclusive;
   }

   public String getLowerBound() {
	  return lowerBound;
   }

   public String getUpperBound() {
  return upperBound;
   }


   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================

}

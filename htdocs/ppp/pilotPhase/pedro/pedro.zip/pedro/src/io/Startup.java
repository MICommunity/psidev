/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.io;

import java.io.File;

import java.lang.StringBuffer;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashSet;
import java.io.FilenameFilter;


import pedro.system.PedroException;
import pedro.system.ModelSelectorDialog;
import pedro.system.GlobalConstants;
import pedro.util.ErrorDialog;
import pedro.util.ClassFileNameFilter;
import pedro.system.ModelClassLoader;
import pedro.model.RecordModelFactory;
import pedro.model.RecordModel;
import pedro.model.ListFieldModel;


/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class Startup {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private static Startup startup = null;
   private boolean isSchemaAmbiguous;

   // ==========================================
   // Section Construction
   // ==========================================
   public Startup() {

	  try {

		 String selectedModel = null;
		 String pedroUtility = GlobalConstants.getPedroUtilityUsed();
		 if ( pedroUtility != null) {
			selectedModel = pedroUtility;
		 } //end if ()
		 else {
			ModelSelectorDialog modelSelectorDialog
			   = new ModelSelectorDialog();
			
			String[] models = detectModels();
			if ( models.length == 0) {
			   StringBuffer noModels = new StringBuffer();
			   noModels.append("You don't have any models installed besides the tutorial.");
			   noModels.append("Go download or copy a model folder into pedro");
			   noModels.append(File.separator);
			   noModels.append("models");
			   noModels.append(File.separator);
			   noModels.append("Then start Pedro again.");
			   ErrorDialog.show(noModels.toString() );
			   System.exit(0);
			} //end if ()
			else if ( models.length == 1) {
			   selectedModel = models[0];
			} //end else ()
			else {
			   modelSelectorDialog.setModels(detectModels() );
			   modelSelectorDialog.show();
			   selectedModel = modelSelectorDialog.getSelectedModel();
			} //end else
		 } //end else

		 File modelDirectory = new File("models"+File.separator+selectedModel);
		 GlobalConstants.setModelDirectory(modelDirectory);

		 StringBuffer modelPath = new StringBuffer();
		 ModelClassLoader modelClassLoader
			= ModelClassLoader.getModelClassLoader();
		 modelClassLoader.loadModelClasses();
		 modelPath.append(modelDirectory.getAbsolutePath() );
		 modelPath.append(File.separator);
		 modelPath.append("model");
		 modelPath.append(".");

		 File dataModelDirectory = new File(modelPath.toString() );

		 XSDFileFilter xsdFileFilter = new XSDFileFilter();
		 //XMLFileFilter xmlFileFilter = new XMLFileFilter();
		 String[] schemaFiles = dataModelDirectory.list(xsdFileFilter);
		 if ( schemaFiles == null) {
			//means the model path wasn't a legal path
			ErrorDialog.show(modelPath.toString() +" is not a valid path for a model folder");
			System.exit(0);

		 } //end if ()

		 if ( schemaFiles.length == 0) {
			StringBuffer noXSDBuffer = new StringBuffer();
			noXSDBuffer.append("You must have an XML schema ");
			noXSDBuffer.append("file ending in *.xsd in ");
			noXSDBuffer.append("the directory: \n");
			noXSDBuffer.append(modelPath.toString());
			ErrorDialog.show(noXSDBuffer.toString() );
			System.exit(0);
		 } //end if ()
		 
		 if ( schemaFiles.length != 1) {
			StringBuffer moreThanOneBuffer = new StringBuffer();
			moreThanOneBuffer.append("You should only have one XML schema ");
			moreThanOneBuffer.append("in the directory ");
			moreThanOneBuffer.append(modelPath.toString() );
			ErrorDialog.show(moreThanOneBuffer.toString() );
			System.exit(0);
		 } //end if ()

		 StringBuffer dataModelName = new StringBuffer();
		 dataModelName.append(modelDirectory.getAbsolutePath() );
		 dataModelName.append(File.separator);
		 dataModelName.append("model");
		 dataModelName.append(File.separator);
		 dataModelName.append(schemaFiles[0]);

		 File dataModel = new File(dataModelName.toString() );
		 loadModel(dataModel);

	  } catch (Exception err) {
		 ErrorDialog.show(err.toString());
		 System.exit(0);
	  } // end try-catch

   }

   private String[] detectModels() {

	  File modelDirectory = new File("models"+File.separator);
	  File[] files = modelDirectory.listFiles();

	  ArrayList modelDirectories = new ArrayList();

	  for ( int i = 0; i < files.length; i++) {
		 if ( files[i].isDirectory() == true) {
			String currentDirectoryName = files[i].getName();
			if ( ( currentDirectoryName.equals("tutorial") == false) &&
				 (currentDirectoryName.equals("toolSurvey") == false) &&
				 (currentDirectoryName.equals("bugReport") == false) ) {

			   modelDirectories.add(files[i].getName() );
			} //end if ()
		 } //end if ()
	  } // end for ()
	  
	  String[] folderNames = (String[]) modelDirectories.toArray(new String[0]);
	  
	  return folderNames;

   }


   public Startup(File modelFile) {
	  try {
		 loadModel(modelFile);
	  } catch (Exception err) {
		 ErrorDialog.show(err.toString());
		 System.exit(0);
	  } // end try-catch
   }

	  
   public void loadModel(File modelFile) throws Exception {
	  SchemaReader schemaReader = new SchemaReader();
	  schemaReader.parseDocument(modelFile);
	  
	  RecordModelFactory recordModelFactory 
		 = RecordModelFactory.getRecordModelFactory();
	  
	  RecordModel topLevelRecord = schemaReader.getTopLevelRecord();
	  
	  recordModelFactory.setTopLevelRecordModelClass(topLevelRecord.getRecordClassName() );
	  GlobalConstants.setSchemaName(modelFile.getAbsolutePath() );
	  determineSchemaAmbiguities();
   }

   public static Startup getStartup() {
	  if ( startup == null) {
		 startup = new Startup();
	  } //end if ()
	  
	  return startup;

   }

   public boolean isSchemaAmbiguous() {
	  return isSchemaAmbiguous;
   }
   
   private void determineSchemaAmbiguities() {
	  RecordModelFactory recordModelFactory
		 = RecordModelFactory.getRecordModelFactory();

	  ArrayList recordFactories
		 = recordModelFactory.getRecordFactories();
	  int numberOfFactories = recordFactories.size();
	  for ( int i = 0; i < numberOfFactories; i++) {
		 RecordModel currentModel
			= (RecordModel) recordFactories.get(i);
		 if ( recordModelContainsAmbiguity(currentModel) == true) {
			isSchemaAmbiguous = true;
			return;
		 } //end if ()
	  } // end for ()
	  isSchemaAmbiguous = false;

   }

   /**
	* ambiguity means the model has at least two fields that can have
	* the same child type subrecord
	*/
   private boolean recordModelContainsAmbiguity(RecordModel recordModel) {
	  HashSet childTypes = new HashSet();
	  
	  ArrayList listFields = recordModel.getListFields();
	  int numberOfListFields = listFields.size();
	  for ( int i = 0; i < numberOfListFields; i++) {
		 ListFieldModel currentListFieldModel
			= (ListFieldModel) listFields.get(i);
		 String[] childRecordTypes = currentListFieldModel.getChildTypes();
		 for ( int j = 0; j < childRecordTypes.length; j++) {
			if ( childTypes.contains(childRecordTypes[j]) == true) {
			   return true;
			} //end if ()
			else {
			   childTypes.add(childRecordTypes[j]);
			} //end else
		 } // end for ()
	  } // end for ()

	  return false;
   }


   // ==========================================
   // Section Accessors
   // ==========================================


   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================

}

class XSDFileFilter implements FilenameFilter {

   private static String xsd = ".XSD";

   public boolean accept(File directory,
						 String name) {
	  
	  String fileName = name.toUpperCase();
	  if ( fileName.endsWith(xsd) == true) {
		 return true;
	  } //end if ()
	  
	  return false;

   }

}

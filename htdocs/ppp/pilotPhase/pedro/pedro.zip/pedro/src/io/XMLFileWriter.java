/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.io;

import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.File;
import java.util.ArrayList;
import javax.swing.tree.DefaultTreeModel;

import pedro.view.NavigationTree;
import pedro.view.NavigationTreeNode;

import pedro.model.RecordModel;
import pedro.model.RecordModelFactory;
import pedro.model.EditFieldModel;
import pedro.model.DataFieldModel;
import pedro.model.ListFieldModel;

import pedro.system.GlobalConstants;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class XMLFileWriter {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private boolean writeChildRecords;
   private RecordModel topRecordModel;

   // ==========================================
   // Section Construction
   // ==========================================
   public XMLFileWriter() {
	  writeChildRecords = true;
   }

   // ==========================================
   // Section Accessors
   // ==========================================
   /*
   public void writeFile(File file, NavigationTree navigationTree) {
	  try {
		 PrintWriter out = new PrintWriter(new FileOutputStream(file) );
		 
		 DefaultTreeModel model = (DefaultTreeModel) navigationTree.getModel();

		 NavigationTreeNode node 
			= (NavigationTreeNode) model.getRoot();

		 topRecordModel = node.getRecordModel();

		 visitRecordModel(0,topRecordModel,out);

		 out.flush();
		 out.close();

	  } catch (Exception err) {
		 
	  } // end try-catch

   }
   */
   public void writeFile(File file, NavigationTreeNode node, boolean writeChildRecords) {

	  this.writeChildRecords = writeChildRecords;

	  try {
		 FileOutputStream fos = new FileOutputStream(file);
		 PrintWriter out = new PrintWriter(fos );
		 
		 topRecordModel = node.getRecordModel();

		 String schemaName = GlobalConstants.getModelName();

		 visitRecordModel(0,topRecordModel,out);
		 out.flush();

		 fos.close();
		 out.close();
	  } catch (Exception err) {
		 
	  } // end try-catch
   }

   private void visitRecordModel(int indentationLevel,
								 RecordModel recordModel, 
								 PrintWriter out) {

	  StringBuffer recordIndentation = new StringBuffer();
	  for ( int i = 0; i < indentationLevel; i++) {
		 recordIndentation.append("\t");
	  } // end for ()
	  
	  StringBuffer fieldIndentation = new StringBuffer();
	  for ( int i = 0; i < indentationLevel+1; i++) {
		 fieldIndentation.append("\t");
	  } // end for ()
	  
	  StringBuffer dataIndentation = new StringBuffer();
	  for ( int i = 0; i < indentationLevel+2; i++) {
		 dataIndentation.append("\t");
	  } // end for ()

	  String name = recordModel.getRecordClassName();

	  if ( recordModel == topRecordModel) {

		 RecordModelFactory recordModelFactory =
			RecordModelFactory.getRecordModelFactory();
		 String styleSheetTag = recordModelFactory.getStyleSheetStamp();
		 if ( styleSheetTag != null) {
			out.print(styleSheetTag);
		 } //end if ()

		 out.print(recordIndentation.toString()+ "<"+name);

		 //write out the file stamp details

		 out.print(" ");

		 out.print(recordModelFactory.getModelStamp() );
		 out.println(">");
	  } //end if ()
	  else {
		 out.print(recordIndentation.toString()+ "<"+name);
		 out.println(">");
	  } //end else

	  out.flush();

	  ArrayList fields = recordModel.getFields();
	  int numberOfFields = fields.size();

	  for ( int i = 0; i < numberOfFields; i++) {

		 DataFieldModel currentFieldModel = (DataFieldModel) fields.get(i);
		 String fieldName = currentFieldModel.getName();


		 if ( currentFieldModel instanceof EditFieldModel) {
			EditFieldModel editField = (EditFieldModel) currentFieldModel;

			String editFieldValue = editField.getValue();
			if ( editFieldValue.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) == false) {
			   out.print(fieldIndentation.toString()+"<"+fieldName + ">"); 
			   out.print(editField.getValue() );
			   out.println("</" + fieldName + ">"); 
			   out.flush();
			} //end if ()

		 } //end if ()
		 else if ( ( currentFieldModel instanceof ListFieldModel) &&
				   (writeChildRecords == true)) {

			ListFieldModel listField = (ListFieldModel) currentFieldModel;
			ArrayList listChildren = listField.getChildren();
			int numberOfChildren = listChildren.size();

			for (int j = 0; j < numberOfChildren; j++ ) {
			   RecordModel currentChild = (RecordModel) listChildren.get(j);
			   visitRecordModel(indentationLevel + 1,
								currentChild, 
								out);
			} // end for ()

			out.flush();

		 } //end else ()

	  } // end for ()
	  out.println(recordIndentation.toString()+"</" + name + ">");
	  out.flush();

   }

   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================

}

/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.io;

import java.io.File;
import java.io.FileOutputStream;
import java.io.BufferedOutputStream;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipEntry;
import java.io.FileInputStream;
import java.io.PrintWriter;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import org.w3c.dom.Text;
import org.w3c.dom.NodeList;

import java.util.ArrayList;

import pedro.model.RecordModel;
import pedro.model.DataFieldModel;
import pedro.model.ListFieldModel;
import pedro.model.RecordModelFactory;
import pedro.view.NavigationTreeNode;
import pedro.view.NavigationTree;

import pedro.util.ErrorDialog;
import pedro.system.PedroException;
import pedro.system.GlobalConstants;
/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class XMLFileReader {

   
   // ==========================================
   // Section Constants
   // ==========================================

   // ==========================================
   // Section Properties
   // ==========================================
   private NavigationTreeNode rootNode;
   private NavigationTree navigationTree;
   private RecordModelFactory recordModelFactory;

   public int count;

   // ==========================================
   // Section Construction
   // ==========================================
   public XMLFileReader() {
	  rootNode = null;
	  recordModelFactory = RecordModelFactory.getRecordModelFactory();
	  count = 0;
   }

   public void readFile(File xmlFile, NavigationTree navigationTree) throws Exception {
	  parseXMLFile(xmlFile, navigationTree);
   }

   private void parseXMLFile(File file, NavigationTree navigationTree) 
	  throws Exception {

	  this.navigationTree = navigationTree;

	  DocumentBuilderFactory documentBuilderFactory
		 = DocumentBuilderFactory.newInstance();
	  
	  DocumentBuilder documentBuilder
		 = documentBuilderFactory.newDocumentBuilder();

	  Document document = documentBuilder.parse(file);

	  //the file will either start like:
	  //<headElement ...>
	  //...
	  //</headElement>

	  //===============================================================================
	  //Part I: Obtain schema information and compare it to currently loaded data model
	  //===============================================================================

	  Element topElement = PedroSchemaParser.getFirstChildElement(document);
	  String experimentSchemaName = topElement.getAttribute("xsi:schemaLocation");


	  if ( experimentSchemaName.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) == true) {
		 ErrorDialog.show("Experiment file doesn't specify schema information");
		 return;
	  } //end if ()

	  RecordModelFactory recordModelFactory = RecordModelFactory.getRecordModelFactory();
	  String applicationSchemaName = GlobalConstants.getModelName();

	  if ( recordModelFactory.schemaMatchesCurrentDataModel(applicationSchemaName,
															experimentSchemaName) == false) {

		 StringBuffer errorMessage = new StringBuffer();
		 errorMessage.append("Experiment file uses schema \"");
		 errorMessage.append(experimentSchemaName);
		 errorMessage.append("\" \n but the application is using schema \"");
		 errorMessage.append(applicationSchemaName);
		 errorMessage.append("\"");
		 ErrorDialog.show(errorMessage.toString() );
		 return;
	  } //end if ()

	  //===============================================================================
	  //Part II: read in the records
	  //===============================================================================


	  navigationTree.enableUpdateUI(false);
	  
	  //	  try {
	  
		 rootNode = visitRecordModel(topElement);
		 
		 RecordModel rootRecordModel = rootNode.getRecordModel();
		 String topLevelClass = recordModelFactory.getTopLevelRecordModelClass();
		 
		 
		 if ( rootRecordModel.getRecordClassName().equals(topLevelClass) == false) {
			StringBuffer message = new StringBuffer();
			message.append("The top level element of your file does not ");
			message.append("start with a recordModel of type ");
			message.append(rootRecordModel.getRecordClassName() );
			throw new PedroException(message.toString() );
		 } //end if ()
		 
		 navigationTree.enableUpdateUI(true);
		 
		 //} catch (Exception err) {
		 //System.out.println("XML file reader Blah blah blah");
		 //System.out.println(err);
		 //} // end try-catch

	  //out.close();
   }

   public void fillEditField(RecordModel recordModel, Element element) 
	  throws Exception {
	  String fieldName = element.getTagName();
	  Text text = (Text) element.getFirstChild();
	  String value = text.getData();

	  if ( value != null) {
		 value = value.trim();
		 if ( ( value.equals("") == false) && (value.equals("null") == false) ) {
			try {

			   recordModel.setValue(fieldName,value, false);
			   //System.out.println("XMLFileReader fillEditField 3");

			} catch (Exception err) {
			   //if we've encountered an error, we should check to 
			   //see if the problem has to do with the date


			   DataFieldModel field = recordModel.getField(fieldName);
			   if ( field != null) {
				  int uiRenderingType = field.getUIRenderingType();
				  if ( uiRenderingType == GlobalConstants.DATE_FIELD) {
					 throw new PedroException("Field " + fieldName+ " has an improperly formatted date.");
				  } //end if ()
			   } //end if ()
			   else {
				  throw err;
			   } //end else
			   //System.out.println("XMLFileReader fillEditField 5");
			} // end try-catch
			
		 } //end if ()
	  } //end if ()
   }

   public void addRecordToAppropriateField(NavigationTreeNode parentNode,
									  NavigationTreeNode childNode) {

	  RecordModel parentRecordModel = parentNode.getRecordModel();
	  
	  RecordModel childRecordModel = childNode.getRecordModel();
	  String childRecordType = childRecordModel.getRecordClassName();

	  ListFieldModel listFieldModel 
		 = parentRecordModel.getListModelForChildType(childRecordType);
	  
	  if ( listFieldModel == null) {
		 StringBuffer message = new StringBuffer();
		 message.append("The record ");
		 message.append(childRecordType);
		 message.append(" does not fit into any ");
		 message.append("kind of list field in a ");
		 message.append("record of type ");
		 message.append(parentRecordModel.getRecordClassName() );
		 ErrorDialog.show(message.toString() );
		 return;
	  } //end if ()
	  
	  parentNode.add(childNode);
	  parentRecordModel.addChild(listFieldModel.getName(), 
								 childRecordModel, 
								 false);
   }


   public void fillListField(NavigationTreeNode parentNode, 
							 Element element) {

	  String fieldName = element.getTagName();
	  RecordModel parentRecordModel = parentNode.getRecordModel();
	  
	  Node currentChild = element.getFirstChild();

	  int ithChild = 1;
	  while ( currentChild != null) {
		 ithChild++;
		 if ( currentChild.getNodeType() == Node.ELEMENT_NODE) {
			Element childElement = (Element) currentChild;

			String tagName = childElement.getTagName();
			if ( recordModelFactory.recordClassRegistered(tagName) == true) {

			   try {
				  NavigationTreeNode currentNode = visitRecordModel(childElement);
				  parentNode.add(currentNode);

				  RecordModel currentRecordModel = currentNode.getRecordModel();
				  String classType = currentRecordModel.getRecordClassName();

				  /**
				   * this is the only real difference between this reader and the
				   * regular experiment file reader.  The regular reader assumes
				   * that field names will be inserted.  This one has to work with 
				   * files where the field names have been removed.  To do this, it
				   * asks the parent record model to find the first list field that 
				   * supports the particular class type.  This class assumes that 
				   * the schemas are unambiguous.  An ambiguous schema is one where
				   * a record model has two list fields that have at least one common
				   * child record type
				   */
				  ListFieldModel listFieldModel 
					 = parentRecordModel.getListModelForChildType(classType);

				  if ( listFieldModel == null) {
					 StringBuffer message = new StringBuffer();
					 message.append("The record ");
					 message.append(classType);
					 message.append(" does not fit into any ");
					 message.append("kind of list field in a ");
					 message.append("record of type ");
					 message.append(parentRecordModel.getRecordClassName() );
					 ErrorDialog.show(message.toString() );
					 return;
				  } //end if ()

				  parentRecordModel.addChild(listFieldModel.getName(), 
											 currentRecordModel, 
											 false);
				  
			   } catch (Exception e) {
				  System.out.println(e);
			   } // end try-catch
			   
			} //end if ()
		 } //end if ()

		 currentChild = currentChild.getNextSibling();
	  } //end while ()

   }

   private NavigationTreeNode visitRecordModel(Element element) throws Exception {

	  String recordModelType = element.getTagName();

	  RecordModel recordModel = recordModelFactory.createRecordModel(recordModelType);
	  count++;
	  NavigationTreeNode node = new NavigationTreeNode(recordModel);

	  //now scan for fields
	  NodeList children = element.getChildNodes();
	  int numberOfChildren = children.getLength();
	  
	  Element currentElement = null;
	  String currentFieldValue = null;
	  
	  Node currentNode = element.getFirstChild();
	  while ( currentNode != null) {
		 int nodeType = currentNode.getNodeType();

		 if ( nodeType == Node.ELEMENT_NODE) {
		    currentElement = (Element) currentNode;

			String dataFieldTagName = currentElement.getTagName();

			if ( recordModel.isEditField(dataFieldTagName) == true) {
			   fillEditField(recordModel,currentElement);
			} //end else ()
			else {
			   //this is a record that should be inserted into 
			   //one of the list fields
			   NavigationTreeNode listRecord = visitRecordModel(currentElement);
			   addRecordToAppropriateField(node,listRecord);
			} //end if ()

		 } //end if ()
		 
		 currentNode = currentNode.getNextSibling();

	  } // end for ()

	  recordModel.updateDisplayName();
	  recordModel.addChangeListener(navigationTree);

	  return node;
   }


// ==========================================
   // Section Accessors
   // ==========================================
   public NavigationTreeNode getRoot() {
	  return rootNode;
   }


   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================

}


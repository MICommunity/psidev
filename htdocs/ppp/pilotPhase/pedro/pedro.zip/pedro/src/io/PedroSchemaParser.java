/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.io;

import org.w3c.dom.Node;
import org.w3c.dom.Element;

import pedro.system.GlobalConstants;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class PedroSchemaParser {

   
   // ==========================================
   // Section Constants
   // ==========================================


   // ==========================================
   // Section Properties
   // ==========================================

   // ==========================================
   // Section Construction
   // ==========================================


   // ==========================================
   // Section Accessors
   // ==========================================
   protected boolean isRequiredOrOptional(String minOccurs) {
	  boolean isRequired = false;
	  if ( minOccurs.equals("0") ) {
		 isRequired = false;
	  } //end if ()
	  else {
		 isRequired = true;
	  } //end else

	  return isRequired;
   }



   protected Element getNextSiblingElement(Element element) {
	  Node currentSibling = element.getNextSibling();
	  
	  while ( currentSibling != null) {
		 
		 if ( currentSibling.getNodeType() == Node.ELEMENT_NODE) {
			
			Element currentElement = (Element) currentSibling;
			return currentElement;
		 } //end if ()
		 currentSibling = currentSibling.getNextSibling();
	  } //end while ()
	  
	  return null;

   }

   static public Element getFirstChildElement(Node node) {
	  Node currentChild = node.getFirstChild();

	  while ( currentChild != null) {
		 
		 if ( currentChild.getNodeType() == Node.ELEMENT_NODE) {
			
			Element currentElement = (Element) currentChild;
			return currentElement;
		 } //end if ()
		 currentChild = currentChild.getNextSibling();
	  } //end while ()
	  
	  return null;

   }


   protected Element getElement(Node node, String tagName) {
	  Element targetElement = null;
	  Node currentChild = node.getFirstChild();
	  while ( currentChild != null) {
		 if ( currentChild.getNodeType() == Node.ELEMENT_NODE) {
			Element currentElement = (Element) currentChild;
			if ( currentElement.getTagName().equals(tagName) == true) {
			   targetElement = currentElement;
			   break;
			} //end if ()
		 } //end if ()
		 currentChild = currentChild.getNextSibling();
	  } //end while ()

	  return targetElement;
   }

   protected Element getElement(Node node, 
							  String tagName, 
							  String elementName) {
	  Element targetElement = null;
	  Node currentChild = node.getFirstChild();

	  while ( currentChild != null) {

		 if ( currentChild.getNodeType() == Node.ELEMENT_NODE) {
			Element currentElement = (Element) currentChild;
			if ( currentElement.getTagName().equals(tagName) == true) {
			   String name = currentElement.getAttribute("name");

			   if ( name.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) == false) {
				  targetElement = currentElement;
			   } //end if ()
			   break;
			} //end if ()
		 } //end if ()
		 currentChild = currentChild.getNextSibling();
	  } //end while ()

	  return targetElement;
   }


   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================

}

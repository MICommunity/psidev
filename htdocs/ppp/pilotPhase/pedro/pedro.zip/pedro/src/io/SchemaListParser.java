/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.io;

import java.util.ArrayList;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

import pedro.model.ListFieldModel;
import pedro.model.ProxyListFieldModel;
import pedro.model.DataFieldModel;
import pedro.model.RecordModel;
import pedro.model.RecordModelFactory;

import pedro.system.GlobalConstants;
import pedro.system.PedroException;


/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class SchemaListParser extends PedroSchemaParser {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================

   // ==========================================
   // Section Construction
   // ==========================================


   // ==========================================
   // Section Accessors
   // ==========================================

   public ListFieldModel createListFieldForRecord(Element element,
												  RecordModel recordModel) {
	  
	  String minOccurs = element.getAttribute("minOccurs");
	  boolean isRequired = isRequiredOrOptional(minOccurs);
	  
	  ListFieldModel listFieldModel = new ListFieldModel();
	  listFieldModel.setRequiredField(isRequired);

	  String recordClassName = recordModel.getRecordClassName();
	  listFieldModel.setName(recordClassName);

	  String[] childTypes = new String[1];
	  childTypes[0] = recordClassName;
	  listFieldModel.setChildTypes(childTypes);

	  listFieldModel.setUIRenderingType(GlobalConstants.ONE_TYPE_ONE_VALUE_LIST);
	  return listFieldModel;
   }

   private boolean isMultipleValueList(String maxOccurs) {
	  if ( maxOccurs.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) ) {
		 //assume value is "1", therefore single value
		 return false;
	  } //end if ()
	  else if ( maxOccurs.equals("1") == true) {
		 return false;
	  } //end else ()
	  else if ( maxOccurs.equals("unbounded") ) {
		 return true;
	  } //end else ()
	  else {
		 return false;
	  } //end else
   }

   private ListFieldModel createProxyListFieldModel(String minOccurs,
													String maxOccurs,
													String reference) {

	  boolean isRequired = isRequiredOrOptional(minOccurs);
	  boolean isMultipleValueList = isMultipleValueList(maxOccurs);

	  ProxyListFieldModel proxyListFieldModel = new ProxyListFieldModel();
	  proxyListFieldModel.setRequiredField(isRequired);
	  proxyListFieldModel.setMultipleValueList(isMultipleValueList);
	  proxyListFieldModel.setName(reference);
	  proxyListFieldModel.setListFactoryName(reference);

	  return proxyListFieldModel;

   }

   private ListFieldModel createListField(String name,
										  String minOccurs,
										  String maxOccurs,
										  boolean isMultipleTypeList,
										  ArrayList childTypeNames) throws PedroException {

	  boolean isRequired = isRequiredOrOptional(minOccurs);
	  boolean isMultipleValueList = isMultipleValueList(maxOccurs);

	  ListFieldModel listFieldModel = new ListFieldModel();
	  listFieldModel.setRequiredField(isRequired);
	  listFieldModel.setName(name);


	  StringBuffer buffer = new StringBuffer();
	  buffer.append("createListField list="+name+"==");
	  buffer.append("multiValueList="+isMultipleValueList+"==");
	  buffer.append("multiTypeList="+isMultipleTypeList+"==");

	  if ( isMultipleTypeList == true) {
		 String[] childTypes = (String[]) childTypeNames.toArray(new String[0]);
		 listFieldModel.setChildTypes(childTypes);

		 if ( isMultipleValueList == true) {
			//multiple type multiple value list
			listFieldModel.setUIRenderingType(GlobalConstants.N_TYPE_N_VALUE_LIST);
		 } //end if ()
		 else {
			//multiple type single value list
			listFieldModel.setUIRenderingType(GlobalConstants.N_TYPE_ONE_VALUE_LIST);
		 } //end else
	  } //end if ()
	  else {
		 String[] childTypes = new String[1];
		 childTypes[0] = (String) childTypeNames.get(0);
		 listFieldModel.setChildTypes(childTypes);

		 if ( isMultipleValueList == true) {
			//single type multiple value list
			listFieldModel.setUIRenderingType(GlobalConstants.ONE_TYPE_N_VALUE_LIST);
		 } //end if ()
		 else {
			//single type single value list
			listFieldModel.setUIRenderingType(GlobalConstants.ONE_TYPE_ONE_VALUE_LIST);
		 } //end else
	  } //end else
	  
	  //register this list model in case other things reference it
	  RecordModelFactory recordModelFactory 
		 = RecordModelFactory.getRecordModelFactory();
	  recordModelFactory.addListFieldFactory(name, listFieldModel);

	  return listFieldModel;
   }


   public ListFieldModel identifySingleTypeList(Element element) throws PedroException {

	  //we're looking for something like:
	  //<xs:element name="fieldName" ref="RecordType" minOccurs="1" maxOccurs="unbounded"/>
	  //or...
	  //<xs:element ref="RecordType" minOccurs="1" maxOccurs="unbounded"/>
	 
	  String tagName = element.getTagName();

	  if ( tagName.equals("xs:element") == false) {
		 //must have "element" tag
		 return null;
	  } //end if ()

	  String reference = element.getAttribute("ref");
	  if (reference.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) == true) {
		 //must have a "ref" value
		 return null;
	  }
	  
	  String minOccurs = element.getAttribute("minOccurs");
	  String maxOccurs = element.getAttribute("maxOccurs");
	  String name = element.getAttribute("name");
	  boolean isMultipleValue = isMultipleValueList(maxOccurs);
	  boolean isMultipleTypeList = false;
	  boolean isRequired = isRequiredOrOptional(minOccurs);

	  ListFieldModel listFieldModel = new ListFieldModel();
	  listFieldModel.setRequiredField(isRequired);

	  if ( name.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) == true) {
		 //eg: <xs:element ref="RecordType"..../>
		 
		 //let the field name equal the record type
		 name = reference;
	  } //end if ()
	  
	  listFieldModel.setName(name);

	  ArrayList childTypeNames = new ArrayList();
	  childTypeNames.add(reference);

	  return createListField(name,
							 minOccurs,
							 maxOccurs,
							 isMultipleTypeList,
							 childTypeNames);

   }

   public ListFieldModel identifyMultipleTypeList(Element element) throws PedroException {

	  /**
	   * Looking for:
	   * <xs:group ref="OtherGroupClass" minOccurs="1" maxOccurs="1"/>
	   *
	   * or...
	   *
	   * <xs:group ref="OtherGroupClass" minOccurs="1" maxOccurs="1"/>
	   * 
	   * or...
	   *
	   * <xs:group name="fieldName">
	   * <xs:choice>
	   * ...
	   * </xs:choice>
	   *
	   */

	  String tagName = element.getTagName();

	  if ( tagName.equals("xs:group") == false) {
		 //must have "group" tag
		 return null;
	  } //end if ()

	  //Step 1: Extract attributes that determine optional/required, multi/single value list
	  // eg: <group name="..." minOccurs="..." maxOccurs="...">
	  String minOccurs = element.getAttribute("minOccurs");
	  String maxOccurs = element.getAttribute("maxOccurs");
	  String name = element.getAttribute("name");
	  boolean isMultipleValue = isMultipleValueList(maxOccurs);
	  boolean isMultipleTypeList = true;
	  boolean isRequired = isRequiredOrOptional(minOccurs);

	  String reference = element.getAttribute("ref");
	  if (reference.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) == true) {
		 //no reference defined, this must be a list model!

		 /**
		  *Step 2:get tag for immediate child to determine if list will
		  *support one type or multiple types:
		  *eg1: single type
		  *     <group....>
		  *     <sequence> </sequence>
		  *     </group>
		  *eg2: multiple type
		  *     <group....>
		  *     <choice></choice>
		  *     </group>
		  */

		 Element typeCardinalityElement = PedroSchemaParser.getFirstChildElement(element);
		 if ( typeCardinalityElement == null) {
			StringBuffer errorMessage = new StringBuffer();
			errorMessage.append("Lists are defined by a \"group\"");
			errorMessage.append("tag containing either a \"");
			errorMessage.append("choice\" or \"sequence\" tag. Group ");
			errorMessage.append("\"");
			errorMessage.append(name);
			errorMessage.append("\" has neither.");
			
			if ( typeCardinalityElement == null) {
			   throw new PedroException(errorMessage.toString() );
			} //end if ()
			
		 } //end if ()
		 
		 String typeCardinalityTagIndicator = typeCardinalityElement.getTagName();
		 if ( ( typeCardinalityTagIndicator.equals("xs:choice") == false) &&
			  (typeCardinalityTagIndicator.equals("xs:sequence") == false) ) {
			
			StringBuffer errorMessage = new StringBuffer();
			errorMessage.append("Lists are defined by a \"group\"");
			errorMessage.append("tag containing either a \"");
			errorMessage.append("choice\" or \"sequence\" tag. Group ");
			errorMessage.append("\"");
			errorMessage.append(name);
			errorMessage.append("\" has neither.");
			
			throw new PedroException(errorMessage.toString() );
			
		 } //end if ()
		 
		 ArrayList childTypeNames = getChildTypeNames(typeCardinalityElement);
		 
		 ListFieldModel listFieldModel = createListField(name,
														 minOccurs,
														 maxOccurs,
														 isMultipleTypeList,
														 childTypeNames);

		 return listFieldModel;

	  }
	  else {
		 //there is a value for ref, which means it's a proxy list field model
		 return createProxyListFieldModel(minOccurs,
										  maxOccurs,
										  reference);
	  } //end else

   }

   public ListFieldModel identifyListField(Element element) 
	  throws PedroException {
	  String tagName = element.getTagName();

	  //check if it's one of those: <xs:element ref="RecordType"/> entries
	  ListFieldModel listFieldModel = identifySingleTypeList(element);
	  if ( listFieldModel != null) {
		 return listFieldModel;
	  } //end if ()

	  //otherwise it must be a multiple type list
	  listFieldModel = identifyMultipleTypeList(element);
	  
	  return listFieldModel;
   }

   private ArrayList getChildTypeNames(Element typeList) {
	  ArrayList childTypes = new ArrayList();
	  Node currentNode = typeList.getFirstChild();

	  while ( currentNode != null) {
		 if ( currentNode.getNodeType() == Node.ELEMENT_NODE) {
			Element currentElement = (Element) currentNode;
			String currentRecordType = currentElement.getAttribute("ref");
			if ( currentRecordType.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) == false) {
			   childTypes.add(currentRecordType);
			} //end if ()
		 } //end if ()
		 
		 currentNode = currentNode.getNextSibling();
	  } //end while ()
	  
	  return childTypes;
   }

   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================

}

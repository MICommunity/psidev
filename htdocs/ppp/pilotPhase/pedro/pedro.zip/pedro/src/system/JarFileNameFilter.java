/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
* @version 1.0
*
*/

package pedro.system;

import java.io.FilenameFilter;
import java.io.File;

/**
 * used by file choosers to filter based on *.jar files
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */


/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class JarFileNameFilter implements FilenameFilter {

   
   // ==========================================
   // Section Constants
   // ==========================================
   private static String jarExtension = "JAR";

   // ==========================================
   // Section Properties
   // ==========================================

   // ==========================================
   // Section Construction
   // ==========================================



   // ==========================================
   // Section Accessors
   // ==========================================


   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================
   public boolean accept(File directory, String fileName) {
	  int i = fileName.lastIndexOf('.');
	  if ( ( i > 0) && (i < fileName.length() - 1) ) {
		 String suffix = fileName.substring(i+1).toUpperCase();
		 if ( suffix.equals(jarExtension) == true ) {
			return true;
		 } //end if ()
	  } //end if ()
	  return false;
   }



   // ==========================================
   // Section Overload
   // ==========================================

}

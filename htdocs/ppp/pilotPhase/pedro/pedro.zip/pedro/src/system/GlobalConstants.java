/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.system;

import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.io.File;
import javax.swing.ImageIcon;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;

/**
 * contains constants that are used throughout the application.  It also maintains other system properties such as the context help cursor and the model directory specified on the command line startup of the program:
 *
 * eg: C:>java -classpath .... PedroDialog model
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class GlobalConstants {

   
   // ==========================================
   // Section Constants
   // ==========================================
   public static String NONE = "none";
   public static String ICON_PATH = ".//img//";
   public static String SHOW_ALL_RECORDS = "All Records";
   public static String NO_ATTRIBUTE_VALUE = "";

   /** the directory in the pedro distribution that contains model
	* information.  The model directory will always appear under
	* pedro/dist/models
	*/
   private static File modelDirectory = null;

   private static String schemaLocation = null;
   private static String schemaInstance = null;
   private static String styleSheet = null;
   private static String schemaName = null;

   public static String FALSE = "FALSE";
   public static String TRUE = "TRUE";
   
   /** text field UI rendering type */
   public static final int TEXT_FIELD = 41;
   /** date field UI rendering type */

   public static final int DATE_FIELD = 42;
   /** radio field UI rendering type */
   public static final int RADIO_FIELD = 43;
   /** combination UI field rendering type */
   public static final int COMBINATION_FIELD = 44;

   /** 
	* list field UI field rendering type for lists that support only one 
	* subrecord type and only one subrecord value
	*/
   public static final int ONE_TYPE_ONE_VALUE_LIST = 45;

   /**
	* list field UI field rendering type for lists that support only one 
	* subrecord type but have multiple values
	*/
   public static final int ONE_TYPE_N_VALUE_LIST = 46;


   /** 
	* list field UI field rendering type for lists that support only multiple subrecord types but only one subrecord value
	*/
   public static final int N_TYPE_ONE_VALUE_LIST = 47;

   /** 
	* list field UI field rendering type for lists that support only 
	* multiple subrecord types and multiple subrecord value
	*/
   public static final int N_TYPE_N_VALUE_LIST = 48;

   /**
	* URL field UI rendering type
	*/ 
   public static final int URL_FIELD = 49;

   /** used to truncate the length of long record display names */
   public static final int MAXIMUM_DISPLAY_NAME_LENGTH = 50;

   // ==========================================
   // Section Properties
   // ==========================================
   /** the context help cursor */
   private static Cursor helpCursor = null;

   private static String pedroUtilityUsed = null;
   // ==========================================
   // Section Construction
   // ==========================================


   // ==========================================
   // Section Accessors
   // ==========================================
   
   public static String getPedroUtilityUsed() {
	  return pedroUtilityUsed;
   }

   /**
	* returns the model directory.  It will be something like
	* pedro/dist/models/tutorial, or pedro/dist/models/mymodel etc. ...
	*/
   public static File getModelDirectory() {
	  return modelDirectory;
   }

   /**
	* creates the cursor used when context sensitive help is
	* turned on.
	* @return the cursor object that contains the little question mark
	*/
   public static Cursor getHelpCursor() {

	  if ( helpCursor == null) {
		 StringBuffer cursorImagePath = new StringBuffer();
		 cursorImagePath.append(".");
		 cursorImagePath.append(File.separator);
		 cursorImagePath.append("img");
		 cursorImagePath.append(File.separator);
		 cursorImagePath.append("helpCursor2.gif");

		 ImageIcon currentIcon = new ImageIcon(cursorImagePath.toString() );
		 ImageObserver imageObserver = currentIcon.getImageObserver();

		 Image image = currentIcon.getImage();
		 int width = image.getWidth(imageObserver);
		 int height = image.getHeight(imageObserver);
		 
		 Point hotSpot = new Point(0,0);
		 Toolkit toolKit = Toolkit.getDefaultToolkit(); 

		 BufferedImage bufferedImage = new BufferedImage(width,height,BufferedImage.TYPE_INT_RGB);
		 Graphics graphics = bufferedImage.getGraphics();
		 
		 graphics.drawImage(image, 
							0,
							0,
							width,
						    height,
							null);

		 helpCursor = toolKit.createCustomCursor(bufferedImage, 
												 hotSpot, 
												 "help"); 

	  }

	  return helpCursor;

   }

   public static String getSchemaInstance() {
	  //System.out.println("GC get schemaInstance=="+schemaInstance+"==");
	  return schemaInstance;
   }
   
   public static String getModelName() {
	  return schemaName;
   }

   public static String getStyleSheet() {
	  return styleSheet;
   }

   public static String getSchemaLocation() {
	  return schemaLocation;
   }



   // ==========================================
   // Section Mutators
   // ==========================================
   /**
	* sets the model directory
	* @param modelDirectory the model folder that contains all the information
	* related to the data model that is used by Pedro
	*/
   public static void setModelDirectory(File _modelDirectory) {
	  modelDirectory = _modelDirectory;
   }

   public static void setPedroUtilityUsed(String _pedroUtilityUsed) {
	  pedroUtilityUsed = _pedroUtilityUsed;
   }

   public static void setSchemaLocation(String schemaLocation) {
	  schemaLocation = schemaLocation;
	  //System.out.println("GC set schemaLocation=="+schemaLocation+"==");
   }

   public static void setSchemaName(String _schemaName) {
	  schemaName = _schemaName;
	  //System.out.println("GC set schemaName=="+schemaName+"==");
   }

   public static void setSchemaInstance(String _schemaInstance) {
	  schemaInstance = _schemaInstance;
	  //System.out.println("GC set schemaInstance=="+schemaInstance+"==");
   }

   public static void setStyleSheet(String _styleSheet) {
	  styleSheet = _styleSheet;
	  System.out.println("GC set styleSheet=="+styleSheet+"==");

   }

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================

   // ==========================================
   // Section Interfaces
   // ==========================================

   // ==========================================
   // Section Overload
   // ==========================================

}

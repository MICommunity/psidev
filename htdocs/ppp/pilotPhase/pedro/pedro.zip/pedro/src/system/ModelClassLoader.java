/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
* @version 1.0
*
*/

package pedro.system;

import java.io.File;
import java.lang.reflect.Constructor;
import java.net.URL;
import java.net.URLClassLoader;

/**
 * a class loader that looks in the model directory's "lib" directory
 * for class files.  Scans for *.class and *.jar files.
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class ModelClassLoader extends URLClassLoader {
   
   // ==========================================
   // Section Constants
   // ==========================================

   // ==========================================
   // Section Properties
   // ==========================================
   /** used to ensure only one class loader is instantiated */
   static private ModelClassLoader modelClassLoader = null;

   // ==========================================
   // Section Construction
   // ==========================================

   /**
	* constructor
	*/
   public ModelClassLoader() {
	  super(new URL[0]);
   }

   /**
	* instantiation is done through this method only, to 
	* ensure that only one instance of the class is created
	*/
   static public ModelClassLoader getModelClassLoader() {
	  if (modelClassLoader == null) {
		 modelClassLoader = new ModelClassLoader();
	  } //end if ()
	  return modelClassLoader;
   }

   /**
	* loads class and jar files found in the model directory "lib" folder
	* eg: pedro/dist/models/tutorial/lib
	*/
   public void loadModelClasses() throws PedroException {

	  try {
		 File modelDirectory = GlobalConstants.getModelDirectory();
		 
		 String classDirectoryName 
			= modelDirectory.getAbsolutePath() 
			+ File.separator
			+ "lib"
			+ File.separator;

		 File classDirectory = new File(classDirectoryName);
		 if ( classDirectory.exists() == false) {
			return;
		 } //end if ()

		 URL[] urls = new URL[1];
		 urls[0] = classDirectory.toURL();
		 
		 JarFileNameFilter jarFileFilter 
			= new JarFileNameFilter();

		 File[] files = classDirectory.listFiles(jarFileFilter);
		 

		 addURL(classDirectory.toURL() );

		 for ( int i = 0; i < files.length; i++) {
			
			addURL(files[i].toURL());
		 } // end for ()

	  } catch (Exception err) {
		 throw new PedroException(err.toString() );
	  }
   }


   // ==========================================
   // Section Accessors
   // ==========================================


   // ==========================================
   // Section Mutators
   // ==========================================
   public Class loadClass(String className) throws ClassNotFoundException {
	  return super.loadClass(className);
   }

   /** 
	* convenience method to get an instance of a class by 
	* the given class name
	* @param className the fully qualified class name
	* @return an instance of the class
	*/
   public Object getInstance(String className) throws PedroException {
	  try {
		 Class cls = loadClass(className);
		 Constructor constructor = cls.getConstructor(new Class[0]);
		 return constructor.newInstance(new Object[0]);
	  } catch (Exception err) {
		 throw new PedroException(err.toString() );
	  } // end try-catch
	  
   }

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================

   // ==========================================
   // Section Interfaces
   // ==========================================

   // ==========================================
   // Section Overload
   // ==========================================

}



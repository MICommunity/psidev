/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro;

import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JFileChooser;
import javax.swing.JSeparator;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.tree.DefaultTreeModel;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.Component;
import java.io.File;
import java.util.ArrayList;
import java.lang.reflect.Constructor;
import java.lang.Class;


import pedro.util.TextFileFilter;
import pedro.util.XMLFileFilter;
import pedro.dataImport.HeaderRemovalDialog;
import pedro.dataImport.FlatFileReader;
import pedro.dataImport.ImportDataToFieldDialog;
import pedro.dataImport.ImportRecordSelectorDialog;
import pedro.dataImport.DefaultTextImporter;
import pedro.dataImport.RecordImportMenuItem;
import pedro.dataImport.RecordImporter;

import pedro.config.ConfigurationFileReader;

import pedro.view.RecordView;
import pedro.model.RecordModel;
import pedro.model.ListFieldModel;
import pedro.util.PedroFileFilter;
import pedro.util.XMLFileFilter;
import pedro.util.PedroBackupFileFilter;
import pedro.io.ExperimentFileReader;
import pedro.io.ExperimentFileWriter;
import pedro.io.XMLFileReader;
import pedro.io.XMLFileWriter;
import pedro.view.NavigationTreeNode;
import pedro.view.NavigationTree;

import pedro.system.GlobalConstants;
import pedro.system.PedroException;

import pedro.util.ErrorDialog;
import pedro.util.HelpEnabledMenuItem;
import pedro.util.HelpDialog;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class FileMenuActionListener extends MenuActionListener {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private HelpEnabledMenuItem newFile;
   private HelpEnabledMenuItem openFile;
   private HelpEnabledMenuItem save;
   private HelpEnabledMenuItem saveAs;

   private ArrayList recordImportMenuItems;

   private HelpEnabledMenuItem importFromXML;
   private HelpEnabledMenuItem exportToXML;
   private HelpEnabledMenuItem close;

   private JLabel templateLabel;
   private HelpEnabledMenuItem saveTemplate;
   private HelpEnabledMenuItem openTemplate;
   private HelpEnabledMenuItem exit;
   private JMenu favourites;

   //private File currentFile;
   private File currentTemplateFile;
   private ExperimentFileWriter writer;
   private ExperimentFileReader reader;
   private ArrayList favouriteFileMenuItems;

   private JFileChooser experimentFileChooser;
   private JFileChooser templateFileChooser;

   // ==========================================
   // Section Construction
   // ==========================================
   public FileMenuActionListener(PedroDialog parentDialog,
								 NavigationTree navigationTree,
								 RecordView recordView) {

	  super(parentDialog,navigationTree, recordView);

	  reader = new ExperimentFileReader();
	  writer = new ExperimentFileWriter();

	  menu.setText("File");
	  newFile = new HelpEnabledMenuItem("New File");
	  newFile.addActionListener(this);
	  newFile.setHelpLink( createHelpLink("New.html") );
	  menu.add(newFile);

	  openFile = new HelpEnabledMenuItem("Open...");
	  openFile.addActionListener(this);
	  openFile.setHelpLink( createHelpLink("Open.html") );

	  menu.add(openFile);


	  save = new HelpEnabledMenuItem("Save");
	  save.addActionListener(this);
	  save.setHelpLink( createHelpLink("Save.html") );

	  menu.add(save);

	  saveAs = new HelpEnabledMenuItem("Save As...");
	  saveAs.addActionListener(this);
	  saveAs.setHelpLink( createHelpLink("SaveAs.html") );

	  menu.add(saveAs);

	  establishRecordImportFeatures();

	  close = new HelpEnabledMenuItem("Close");
	  close.addActionListener(this);
	  close.setHelpLink( createHelpLink("Close.html") );

	  menu.add(close);

	  FavouriteFileRegistry favouriteFileRegistry
		 = FavouriteFileRegistry.getFavouriteFileRegistry();

	  File[] favouriteFiles = favouriteFileRegistry.getFavouriteFiles();

	  favourites = new JMenu("Favourites");
	  favouriteFileMenuItems = new ArrayList();
	  for ( int i = 0; i < favouriteFiles.length; i++) {
		 HelpEnabledMenuItem currentFavourite = new HelpEnabledMenuItem( favouriteFiles[i].getAbsolutePath() );
		 currentFavourite.setHelpLink( createHelpLink("FavouriteFile.html") );

		 favouriteFileMenuItems.add(currentFavourite);
		 currentFavourite.addActionListener(this);
		 favourites.add(currentFavourite);
	  } // end for ()
	  

	  if ( favouriteFiles.length > 0) {
		 menu.add(favourites);
	  } //end if ()

	  menu.add(new JSeparator() );

	  importFromXML = new HelpEnabledMenuItem("Import from XML...");
	  importFromXML.addActionListener(this);
	  importFromXML.setHelpLink( createHelpLink("ImportFromXML.html") );
	  menu.add(importFromXML);

	  exportToXML = new HelpEnabledMenuItem("Export to XML...");
	  exportToXML.addActionListener(this);
	  exportToXML.setHelpLink( createHelpLink("ExportToXML.html") );
	  menu.add(exportToXML);

	  menu.add(new JSeparator() );

	  JMenu templates = new JMenu("Templates");

	  saveTemplate = new HelpEnabledMenuItem("Save Template");
	  saveTemplate.addActionListener(this);
	  saveTemplate.setHelpLink( createHelpLink("SaveTemplate.html") );
	  templates.add(saveTemplate);

	  openTemplate = new HelpEnabledMenuItem("Open Template");
	  openTemplate.addActionListener(this);
	  openTemplate.setHelpLink( createHelpLink("OpenTemplate.html") );
	  templates.add(openTemplate);

	  menu.add(templates);

	  //currentFile = null;
	  currentTemplateFile = null;


	  File modelDirectory = GlobalConstants.getModelDirectory();

	  experimentFileChooser = new JFileChooser();

	  
	  File experimentDirectory = favouriteFileRegistry.getDataDirectory();
	  experimentFileChooser.setCurrentDirectory(experimentDirectory);

	  PedroFileFilter pedroFileFilter = new PedroFileFilter();
	  experimentFileChooser.addChoosableFileFilter(pedroFileFilter );
	  experimentFileChooser.addChoosableFileFilter(new PedroBackupFileFilter() );
	  experimentFileChooser.setFileFilter(pedroFileFilter);

	  templateFileChooser = new JFileChooser();

	  File templateDirectory = favouriteFileRegistry.getTemplateDirectory();
	  templateFileChooser.setCurrentDirectory(templateDirectory);
	  templateFileChooser.addChoosableFileFilter(new PedroFileFilter() );





	  exit = new HelpEnabledMenuItem("Exit");
	  exit.addActionListener(this);
	  exit.setHelpLink( createHelpLink("Exit.html") );
	  menu.add(exit);

   }

   public void establishRecordImportFeatures() {

	  recordImportMenuItems = new ArrayList();

	  JMenu importRecords = new JMenu("Import Records");

	  DefaultTextImporter defaultTextImporter
		 = new DefaultTextImporter();

	  RecordImportMenuItem defaultImport
		 = new RecordImportMenuItem(defaultTextImporter.getName(),
									defaultTextImporter);

	  defaultImport.addActionListener(this);
	  defaultImport.setHelpLink( createHelpLink("ImportData.html") );
	  importRecords.add(defaultImport);

	  //call up the configuration 
	  ConfigurationFileReader configurationFileReader
		 = ConfigurationFileReader.getConfigurationFileReader();

	  try {
		 ArrayList recordImporterClasses 
			= configurationFileReader.getRecordImporterClasses();
		 int numberOfRecordImporterClasses = recordImporterClasses.size();
		 for ( int i = 0; i < numberOfRecordImporterClasses; i++) {
			Class recordImporterClass 
			   = (Class) recordImporterClasses.get(i);
			
			//use reflection to instantiate
			Constructor constructor 
			   = recordImporterClass.getConstructor(new Class[0]);
			RecordImporter recordImporter 
			   = (RecordImporter) constructor.newInstance(new Object[0]);
			
			RecordImportMenuItem importMenuItem
			   = new RecordImportMenuItem(recordImporter.getName(),
										  recordImporter);
			importMenuItem.addActionListener(this);
			importMenuItem.setHelpLink( createHelpLink("ImportData.html") );

			importRecords.add(importMenuItem);
			
		 } // end for ()
	  } catch (Exception err) {
		 ErrorDialog.show(err.toString() );
	  } // end try-catch

	  recordImportMenuItems.add(defaultImport);

	  menu.add(importRecords);
   }

   // ==========================================
   // Section Accessors
   // ==========================================
  

   // ==========================================
   // Section Mutators
   // ==========================================
   public void enableContextHelp(boolean enableContextHelp) {
	  newFile.enableContextHelp(enableContextHelp);
	  openFile.enableContextHelp(enableContextHelp);
	  save.enableContextHelp(enableContextHelp);
	  saveAs.enableContextHelp(enableContextHelp);


	  int numberOfImportFormats = recordImportMenuItems.size();
	  for ( int i = 0; i < numberOfImportFormats; i++) {
		 RecordImportMenuItem currentImportMenuItem
			= (RecordImportMenuItem) recordImportMenuItems.get(i);
		 currentImportMenuItem.enableContextHelp(enableContextHelp);
	  } // end for ()
	
	  importFromXML.enableContextHelp(enableContextHelp);
	  exportToXML.enableContextHelp(enableContextHelp);
	  close.enableContextHelp(enableContextHelp);
	  saveTemplate.enableContextHelp(enableContextHelp);
	  openTemplate.enableContextHelp(enableContextHelp);
	  exit.enableContextHelp(enableContextHelp);
   }

   public void allowXMLImport(boolean allowXMLImport) {
	  importFromXML.setEnabled(allowXMLImport);
   }

   private void newFile() {
	  PedroDialog dialog = new PedroDialog();
	  dialog.setNewFile(true);

	  WindowRegistry windowRegistry = WindowRegistry.getWindowRegistry();
	  windowRegistry.registerWindowWithNewFile(dialog);
	  dialog.show();
   }

   private void open() {

	  int result = experimentFileChooser.showOpenDialog(parentDialog);
	  if ( result == JFileChooser.CANCEL_OPTION) {
		 return;
	  } //end if ()

	  File file = experimentFileChooser.getSelectedFile();
	  if ( file == null) {
		 return;
	  } //end if ()
	  openFile(file);

   }

   private void importFromXML() {
	  JFileChooser xmlFileChooser = new JFileChooser();

	  FavouriteFileRegistry favouriteFileRegistry
		 = FavouriteFileRegistry.getFavouriteFileRegistry();

	  File experimentDirectory = favouriteFileRegistry.getDataDirectory();
	  xmlFileChooser.setCurrentDirectory(experimentDirectory);
	  xmlFileChooser.setFileFilter(new XMLFileFilter() );

	  int result = xmlFileChooser.showOpenDialog(parentDialog);
	  if ( result == JFileChooser.CANCEL_OPTION) {
		 return;
	  } //end if ()

	  File file = xmlFileChooser.getSelectedFile();
	  if ( file == null) {
		 return;
	  } //end if ()

	  //determine if file already exists
	  WindowRegistry windowRegistry = WindowRegistry.getWindowRegistry();

	  PedroDialog dialogForFile = windowRegistry.getWindowForFile(file);
	  if ( dialogForFile != null) {
		 dialogForFile.toFront();
		 return;
	  } //end if ()

	  //file requires dialog instantiation
	  if ( windowRegistry.isFirstWindow() == true) {
		 dialogForFile = parentDialog;
	  }
	  else {
		 dialogForFile = new PedroDialog();
	  } //end else

	  NavigationTree tree = dialogForFile.getTree();

	  try {
		 XMLFileReader xmlFileReader = new XMLFileReader();
		 xmlFileReader.readFile(file,tree);

		 NavigationTreeNode root = xmlFileReader.getRoot();

		 dialogForFile.setRoot(root);
		 dialogForFile.setNewFile(false);

		 dialogForFile.setFile(file);
		 
		 if ( windowRegistry.isFirstWindow() == true) {
			windowRegistry.updateWindow(dialogForFile);
			windowRegistry.setFirstWindow(false);
		 } //end if ()
		 else {
			windowRegistry.registerWindowWithExistingFile(dialogForFile);
		 } //end else

		 dialogForFile.show();

		 //set this as a new file to force user to save it as a particular
		 //file name.  After an XML file is imported, the idea is that they
		 //should save it as "x.pdz".
		 parentDialog.setNewFile(true);

	  } catch (Exception err) {
		 if ( err instanceof PedroException) {
			PedroException pedroException = (PedroException) err;
		 ErrorDialog.show(pedroException.getMessage());
		 } //end if ()
		 else {
			System.out.println("FMAL - err");
			ErrorDialog.show(err.toString() );
		 } //end else
		 
		 
	  } // end try-catch
   }

   private void openFile(File file) {

	  //determine if file already exists
	  WindowRegistry windowRegistry = WindowRegistry.getWindowRegistry();

	  PedroDialog dialogForFile = windowRegistry.getWindowForFile(file);
	  if ( dialogForFile != null) {
		 dialogForFile.toFront();
		 return;
	  } //end if ()

	  //file requires dialog instantiation

	  if ( windowRegistry.isFirstWindow() == true) {
		 dialogForFile = parentDialog;
	  }
	  else {
		 dialogForFile = new PedroDialog();
	  } //end else
	  
	  NavigationTree tree = dialogForFile.getTree();

	  try {
		 reader.setReadTemplate(false);
		 reader.readFile(file,tree);
		 NavigationTreeNode root = reader.getRoot();
		 dialogForFile.setRoot(root);
		 dialogForFile.setNewFile(false);
		 dialogForFile.setFile(file);
		 
		 if ( windowRegistry.isFirstWindow() == true) {
			windowRegistry.updateWindow(dialogForFile);
			windowRegistry.setFirstWindow(false);
		 } //end if ()
		 else {
			windowRegistry.registerWindowWithExistingFile(dialogForFile);
		 } //end else

		 dialogForFile.show();
		 
		 FavouriteFileRegistry favouriteFileRegistry
			= FavouriteFileRegistry.getFavouriteFileRegistry();
		 favouriteFileRegistry.registerFavouriteFile(file);
		 
		 File parentDirectory = file.getParentFile();		 
		 favouriteFileRegistry.setDataDirectory(parentDirectory);

	  } catch (Exception err) {
		 System.out.println("Open Favourite 2222- " + err);
	  } // end try-catch

   }

   private void openFavourite(HelpEnabledMenuItem favouriteFileMenuItem) {
	  File file = new File(favouriteFileMenuItem.getText());
	  openFile(file);
   }

   private boolean saveAs() throws PedroException {


	  parentDialog.saveChanges(false);


	  //keep asking for a file name until they pick a new file name
	  //or agree to overwrite an existing file.
	  boolean doSaveFile = false;

	  File currentFile = null;

	  int result = experimentFileChooser.showSaveDialog(parentDialog);
	  if ( result == JFileChooser.CANCEL_OPTION) {
		 return true;
	  } //end if ()


	  currentFile = experimentFileChooser.getSelectedFile();


	  String currentFileName = currentFile.getAbsolutePath();
	  if ( currentFileName.toUpperCase().endsWith(".PDZ") == false) {
		 currentFileName = currentFileName + ".pdz";
	  } //end if ()
	  
	  currentFile = new File(currentFileName);
	  

	  if ( currentFile == null) {
		 return true;
	  } //end if ()

	  //check first whether there is some window already up
	  //with this file.  if so, then flag error message
	  WindowRegistry windowRegistry = WindowRegistry.getWindowRegistry();
	  PedroDialog dialog = windowRegistry.getWindowForFile(currentFile);
	  if ( (dialog!= null) && (dialog != parentDialog ) ) {
		 StringBuffer errorMessage = new StringBuffer();
		 errorMessage.append("You are trying to save to a file \n");
		 errorMessage.append("that is already open and in use.\n");
		 errorMessage.append("Either choose another file name or \n");
		 errorMessage.append("close the window that is using the \n");
		 errorMessage.append("file you want to overwrite.");

		 ErrorDialog.show(errorMessage.toString() );
		 return false;
	  } //end if ()

	  if ( currentFile.exists() == true) {
		 StringBuffer message = new StringBuffer();
		 message.append("File ");
		 message.append(currentFile.getName() );
		 message.append(" already exists.  Overwrite the ");
		 message.append("existing file?");
		 
		 int answer = JOptionPane.showConfirmDialog(null, 
													message.toString(),
													"Save Changes", 
													JOptionPane.YES_NO_OPTION,
													JOptionPane.WARNING_MESSAGE,
													null);
		 
		 if ( answer == JOptionPane.NO_OPTION) {
			return false;
		 }
	  }

	  parentDialog.setNewFile(false);
	  parentDialog.setFile(currentFile);
	  
	  String fileName = currentFile.getAbsolutePath();
	  if ( fileName.endsWith(".pdz~") == true) {
		 int lastIndex = fileName.lastIndexOf('~');
		 fileName = fileName.substring(0,lastIndex - 1);
	  } //end if ()
		 
	  if ( fileName.endsWith(".pdz") == false) {
		 fileName = currentFile.getAbsolutePath() + ".pdz";
		 currentFile = new File(fileName);
	  } //end if ()
	  
	  currentFile.delete();


	  DefaultTreeModel model = (DefaultTreeModel) navigationTree.getModel();
	  NavigationTreeNode rootNode 
		 = (NavigationTreeNode) model.getRoot();

	  writer.setWriteTemplate(false);
	  writer.writeFile(currentFile, rootNode, true );
	  windowRegistry.updateWindow(parentDialog);
	  
	  
	  FavouriteFileRegistry favouriteFileRegistry
			= FavouriteFileRegistry.getFavouriteFileRegistry();
	  favouriteFileRegistry.registerFavouriteFile(currentFile);
	  
	  parentDialog.acknowledgeChangesMade();

	  return true;
	  
   }
   
   private boolean save(boolean showSaveChangesPrompt) throws PedroException {
	  if ( parentDialog.isNewFile() == true) {
		 return saveAs();
	  }
	  
	  if (parentDialog.saveChanges(showSaveChangesPrompt) == false) {
		 //just means user didn't want to save changes
		 return false;
	  } //end if ()
	  
	  //if any backup by the name of *pdz~ exists, delete it
	  File oldFile = parentDialog.getFile();


	  //save the current file name


	  String backupFileName = oldFile.getAbsolutePath();
	  
	  String upperCaseFileName = backupFileName.toUpperCase();
	  if ( upperCaseFileName.endsWith("PDZ") == false) {
		 backupFileName = backupFileName + ".pdz";
	  } //end if ()
	  
	  backupFileName = backupFileName + "~";
	  File backupFile = new File(backupFileName);
	  if ( backupFile.exists() == true) {
		 if ( backupFile.delete() == false) {
		 } //end if ()
	  } //end if ()

	  //now rename the current file to the backup file

	  boolean result = oldFile.renameTo(backupFile);
	  
	  //recreate the currentFile
	  String currentFileName = oldFile.getAbsolutePath();
	  File currentFile = new File(currentFileName);

	  //write the current change
	  DefaultTreeModel model = (DefaultTreeModel) navigationTree.getModel();
	  NavigationTreeNode rootNode 
		 = (NavigationTreeNode) model.getRoot();

	  writer.setWriteTemplate(false);
	  writer.writeFile(currentFile, rootNode, true );
	  parentDialog.acknowledgeChangesMade();

	  return true;
   }

   private void recordImport(RecordImporter recordImporter) {
	  //choose file
	  try {

		 String errors = recordView.validateEditFields(true);
		 if ( errors.equals("") == false) {
			ErrorDialog.show(errors);
			return;
		 } //end if ()
		 

		 //=========================================================
		 //Step 1: Select a File
		 //=========================================================


		 FavouriteFileRegistry favouriteFileRegistry
			= FavouriteFileRegistry.getFavouriteFileRegistry();

		 recordImporter.setDirectory(favouriteFileRegistry.getImportDirectory() );

		 if ( recordImporter.selectFile() == false) {
			return;
		 } //end if ()

		 //=========================================================
		 //Step 2: Choose the destination list field in the record
		 //=========================================================

		 RecordModel recordModel = recordView.getRecordModel();
		 if ( recordModel == null) {
			String errorMessage 
			   = "No destination record available";
			ErrorDialog.show(errorMessage);
			return;
		 } //end if ()

		 ImportRecordSelectorDialog recordSelector 
			= new ImportRecordSelectorDialog();
		 
		 recordSelector.setRecordModel(recordModel);
		 recordSelector.chooseImportField();

		 String importFieldName = recordSelector.getSelectedFieldName();
		 String selectedChildRecordType 
			= recordSelector.getSelectedChildRecordType();

		 if ( importFieldName == null) {
			return;
		 } //end if ()
		 
		 recordImporter.setImportRecordType(selectedChildRecordType);
		 ArrayList importedRecords = recordImporter.importRecords();

		 if ( importedRecords.size() == 0) {
			return;
		 } //end if ()

		 navigationTree.enableUpdateUI(false);

		 ArrayList changeListeners = recordModel.getChangeListeners();
		 int numberOfImportedRecordModels = importedRecords.size();

		 for ( int i = 0; i < numberOfImportedRecordModels; i++) {
			RecordModel currentRecordModel 
			   = (RecordModel) importedRecords.get(i);
			currentRecordModel.setChangeListeners(changeListeners);

			//navigationTree.addToKeyList(templateRootNode);
			recordModel.addChild(importFieldName, 
								 currentRecordModel,
								 true);

			navigationTree.addNode(recordModel,
								   currentRecordModel);
		 } // end for ()

		 recordView.refreshList(importFieldName);

		 //now ensure that all the items appear visible.  
		 //to do this, we need only to force the first child to be visible
		 if ( numberOfImportedRecordModels > 0) {
			RecordModel firstChild = (RecordModel) importedRecords.get(0);
			navigationTree.showNode(firstChild);
		 } //end if ()

		 navigationTree.enableUpdateUI(true);

		 recordView.updateUI();
		 navigationTree.updateUI();

	  }
	  catch (Exception err) {
		 ErrorDialog.show(err.toString() );
	  } // end try-catch
   }

   /**
	* exports the pedro format file to an xml file format
	*/
   private void exportToXML() {

	  navigationTree.validateRecordModelTree();
	  if ( navigationTree.fileHasErrors() == true) {
		 StringBuffer errorMessage = new StringBuffer();
		 errorMessage.append("Your file has some errors, and you may be \n");
		 errorMessage.append("missing some required subrecords.  You are not \n");
		 errorMessage.append("to export to XML until you fix the errors. \n");
		 errorMessage.append("To clear the tree display, click the \"View\" \n");
		 errorMessage.append("menu, then the \"Clear\" option.");
		 ErrorDialog.show(errorMessage.toString() );
	  } //end if ()

	  XMLFileWriter xmlFileWriter = new XMLFileWriter();

	  DefaultTreeModel model = (DefaultTreeModel) navigationTree.getModel();
	  NavigationTreeNode rootNode 
		 = (NavigationTreeNode) model.getRoot();

	  File currentFile = null;

	  if ( parentDialog.isNewFile() == true) {
		 //we have to establish a file name

		 int result = experimentFileChooser.showSaveDialog(parentDialog);
		 if ( result == JFileChooser.CANCEL_OPTION) {
			return;
		 } //end if ()
		 
		 currentFile = experimentFileChooser.getSelectedFile();

		 if ( currentFile == null) {
			return;
		 } //end if ()
		 
		 String currentFileName = currentFile.getAbsolutePath();
		 if ( currentFileName.toUpperCase().endsWith(".PDZ") == false) {
			currentFileName = currentFileName + ".pdz";
		 } //end if ()
		 
		 currentFile = new File(currentFileName);
	  }
	  else {
		 currentFile = parentDialog.getFile();
	  } //end else

	  //the current file will be of the format "x.pdz".  We want to create
	  //something of the kind "x.xml".
	  String currentFileName = currentFile.getAbsolutePath();
	  int dotPosition = currentFileName.lastIndexOf(".");
	  currentFileName = currentFileName.substring(0,dotPosition);
	  currentFileName = currentFileName + ".xml";
	  currentFile = new File(currentFileName);

	  xmlFileWriter.writeFile(currentFile, rootNode, true );

   }

   public boolean close() {

	  try {
	  
		 WindowRegistry windowRegistry = WindowRegistry.getWindowRegistry();


		 if (parentDialog.isNewFile() == true) {

			StringBuffer message = new StringBuffer();
			message.append("Save file ");
			message.append(parentDialog.getTitle() );
			message.append("?");

			int answer = JOptionPane.showConfirmDialog(null, 
													   message.toString(),
													   "Save Changes", 
													   JOptionPane.YES_NO_CANCEL_OPTION,
													   JOptionPane.WARNING_MESSAGE,
													   null);
			

			if ( answer == JOptionPane.YES_OPTION) {
			   if ( saveAs() == false) {
				  //close should succeed.
				  return true;
			   } //end if ()
			} //end if ()
			else if ( answer == JOptionPane.CANCEL_OPTION) {
			   //close should fail
			   return false;
			} //end else ()
		 }
		 else {
			if ( save(true) == false) {
			   return false;
			} //end if ()
		 } //end else
		 
		 parentDialog.dispose();
		 windowRegistry.deregisterWindow(parentDialog);

		 ArrayList activeWindows = windowRegistry.getActiveWindows();
		 int numberOfWindows = activeWindows.size();
		 if ( numberOfWindows == 0) {
			cleanupAndTerminate();
		 } //end if ()

		 return true;
		 
	  } catch (PedroException error) {
		 ErrorDialog.show(error.getMessage() );
		 return false;
	  } // end try-catch
   }
   
   private void saveTemplate() {
	  int result = templateFileChooser.showSaveDialog(parentDialog);
	  if ( result == JFileChooser.CANCEL_OPTION) {
		 return;
	  } //end if ()

	  File selectedFile = templateFileChooser.getSelectedFile();
	  if ( selectedFile == null) {
		 return;
	  } //end if ()

	  String fileName = selectedFile.getAbsolutePath();
	  if ( fileName.endsWith(".pdz") == false) {
		 fileName = selectedFile.getAbsolutePath() + ".pdz";
	  } //end if ()
	  
	  File currentTemplateFile = new File(fileName);


	  NavigationTreeNode node = navigationTree.getActiveNode();
	  if ( node == null) {
		 ErrorDialog.show("Nothing in the tree was selected");
		 return;
	  } //end if ()

	  boolean includeChildrenInTemplate = false;
	  
	  int numberOfChildren = node.getChildCount();
	  
	  if ( numberOfChildren > 0) {
		 SaveTemplateDialog saveTemplateDialog = new SaveTemplateDialog(true);
		 saveTemplateDialog.show();
		 
		 if ( saveTemplateDialog.isCancelled() == true) {
			return;
		 } //end if ()

		 includeChildrenInTemplate = saveTemplateDialog.writeChildRecords();

	  } //end if ()
	  
	  writer.setWriteTemplate(true);
	  writer.writeFile(currentTemplateFile,
					   node,
					   includeChildrenInTemplate);
   }

   private void openTemplate() {



	  int result = templateFileChooser.showOpenDialog(parentDialog);
	  if ( result == JFileChooser.CANCEL_OPTION) {
		 return;
	  }

	  currentTemplateFile = templateFileChooser.getSelectedFile();
	  File parentDirectory = currentTemplateFile.getParentFile();
	

	  FavouriteFileRegistry favouriteFileRegistry
		 = FavouriteFileRegistry.getFavouriteFileRegistry();
	  
	  favouriteFileRegistry.setTemplateDirectory(parentDirectory);

	  if ( currentTemplateFile == null) {
		 return;
	  } //end if ()
	  
	  try {

		 ExperimentFileReader templateReader = new ExperimentFileReader();
		 templateReader.setReadTemplate(true);
		 templateReader.readFile(currentTemplateFile, navigationTree);

		 NavigationTreeNode templateRootNode = templateReader.getRoot();
		 RecordModel templateRootRecordModel = templateRootNode.getRecordModel();

		 ImportRecordSelectorDialog recordSelector 
			= new ImportRecordSelectorDialog();

		 NavigationTreeNode currentNode = navigationTree.getActiveNode();
		 
		 RecordModel currentRecordModel = currentNode.getRecordModel();


		 String currentRecordModelClass = currentRecordModel.getRecordClassName();

		 String templateRecordModelClass = templateRootRecordModel.getRecordClassName();
		 if ( currentRecordModelClass.equals(templateRecordModelClass) == false) {

			StringBuffer errorMessage = new StringBuffer();
			errorMessage.append("You're trying to import a template");
			errorMessage.append("starting with \n record type \"" );
			errorMessage.append(templateRecordModelClass);
			errorMessage.append("\" into a field that expects \n a ");
			errorMessage.append(" record of type \"");
			errorMessage.append(currentRecordModelClass);
			errorMessage.append("\"");

			ErrorDialog.show(errorMessage.toString() );

			return;
		 } //end if ()


		 navigationTree.pasteNode(currentRecordModel,
								  templateRootRecordModel);
		 
		 navigationTree.updateUI();

	  } 
	  catch (Exception err) {
		 ErrorDialog.show(err.getMessage() );
	  } // end try-catch
	  
   }

   private void exit() {

	  WindowRegistry windowRegistry = WindowRegistry.getWindowRegistry();

	  ArrayList activeWindows = windowRegistry.getActiveWindows();
	  int numberOfWindows = activeWindows.size();
	  for ( int i = 0; i < numberOfWindows; i++) {
		 PedroDialog currentWindow = (PedroDialog) activeWindows.get(i);
		 boolean closedSuccessfully = currentWindow.close();
		 if ( closedSuccessfully == false) {
			return;
		 } //end if ()
	  } // end for ()

	  cleanupAndTerminate();
   }

   private void cleanupAndTerminate() {
	  FavouriteFileRegistry favouriteFileRegistry
		 = FavouriteFileRegistry.getFavouriteFileRegistry();

	  try {
		 favouriteFileRegistry.setDataDirectory(experimentFileChooser.getCurrentDirectory() );
		 favouriteFileRegistry.setTemplateDirectory(templateFileChooser.getCurrentDirectory());
		 favouriteFileRegistry.writeFavouritesFile();
	  } catch (Exception err) {
		 ErrorDialog.show(err.toString() );
	  } // end try-catch
	  

	  System.exit(0);
   }

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================
   public void actionPerformed(ActionEvent event) {
	  HelpEnabledMenuItem menuItem = (HelpEnabledMenuItem) event.getSource();

	  if ( menuItem.isContextHelpEnabled() == true) {

		 try {
			HelpDialog helpDialog = HelpDialog.getHelpDialog();
			helpDialog.setHelpLink(menuItem.getHelpLink() );
			helpDialog.show();
		 }
		 catch (Exception err) {
			System.out.println(err);
		 } // end catch

		 return;
		 
	  } //end if ()
	  if ( menuItem instanceof RecordImportMenuItem) {
		 RecordImportMenuItem importMenuItem
			= (RecordImportMenuItem) menuItem;
		 RecordImporter recordImporter
			= (RecordImporter) importMenuItem.getRecordImporter();
		 recordImport(recordImporter);
	  } //end if ()
	  
	  try {
	  
		 if ( menuItem == newFile) {
			newFile();
		 } //end if ()
		 else if ( menuItem == openFile) {
			open();
		 } //end else ()
		 else if ( menuItem == save) {
			save(false);
		 } //end else ()
		 else if ( menuItem == saveAs) {
			saveAs();
		 } //end else ()
		 else if (menuItem == close) {
			close();
		 } //end else ()
		 else if (menuItem == importFromXML) {
			importFromXML();
		 } //end else ()
		 else if (menuItem == exportToXML) {
			exportToXML();
		 } //end else ()
		 else if ( menuItem == openTemplate) {
			openTemplate();
		 } //end else ()
		 else if ( menuItem == saveTemplate) {
			saveTemplate();
		 } //end else ()
		 else if ( menuItem == exit) {
			exit();
		 } //end else ()
		 else if (favouriteFileMenuItems.contains(menuItem) == true ) {
			openFavourite(menuItem);
		 } //end else ()

	  } catch (PedroException error) {
		 ErrorDialog.show(error.getMessage() );
	  } // end try-catch


   }


   // ==========================================
   // Section Overload
   // ==========================================

}




/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
* @version 1.0
*
*/

package pedro.ontology;

import java.util.ArrayList;

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class OntologyServiceManager {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private ArrayList services;
   private boolean useBackupServices;

   // ==========================================
   // Section Construction
   // ==========================================
   public OntologyServiceManager() {
	  services = new ArrayList();
	  useBackupServices = false;
   }

   // ==========================================
   // Section Accessors
   // ==========================================
   public ArrayList getServices() {
	  return services;
   }

   public OntologyService getPrimaryService() {
	  if ( services == null) {
		 return null;
	  } //end if ()
	  
	  int numberOfServices = services.size();

	  if ( numberOfServices > 0) {
		 for ( int i = 0; i < numberOfServices; i++) {
			OntologyService currentService
			   = (OntologyService) services.get(0);
			if ( currentService.isActivated() == true) {


			   if ( useBackupServices == false) {
				  //just take the first service
				  return currentService;
			   } //end if ()
			   else {
				  OntologySource ontologySource 
					 = currentService.getSource();

				  if ( ontologySource.isWorking() == true) {
					 return currentService;
				  } //end if ()
			   } //end else

			} //end if ()
			
		 } // end for ()
		 
		 return null;
	  } //end if ()
	  else {
		 return null;
	  } //end else

   }
   
   public ArrayList getActiveServices() {
	  ArrayList activeServices = new ArrayList();
	  int numberOfServices = services.size();

	  for ( int i = 0; i < numberOfServices; i++) {
		 OntologyService ontologyService
			= (OntologyService) services.get(i);

		 if ( ontologyService.isActivated() == true) {
			activeServices.add(ontologyService);
		 } //end if ()
		 
	  } // end for ()
	  
	  return activeServices;
   }

   // ==========================================
   // Section Mutators
   // ==========================================
   public void addService(OntologyService ontologyService) {
	  services.add(ontologyService);
   }

   public void setOntologyServices(ArrayList ontologyServices) {
	  services = ontologyServices;

	  if ( services != null) {
		 if ( services.size() > 0) {
			OntologyService primaryOntologyService
			   = (OntologyService) services.get(0);
			primaryOntologyService.setActivated(true);
		 } //end if ()
		 

	  } //end if ()

   }

   


   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================

}

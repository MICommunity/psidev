/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.ontology;

import javax.swing.JPopupMenu;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

public interface OntologyProvider {
   public JPopupMenu getMenu();
   public void setOntologyListener(OntologyListener ontologyListener);
   public void allowClearValuesOption(boolean allowClearValuesOption);
}

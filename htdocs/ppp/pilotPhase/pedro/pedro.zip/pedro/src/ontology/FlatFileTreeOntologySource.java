/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/
package pedro.ontology;

import java.io.File;
import java.util.Hashtable;
import java.io.FileReader;
import java.io.BufferedReader;


import pedro.util.ErrorDialog;
import pedro.system.GlobalConstants;
/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class FlatFileTreeOntologySource extends AbstractTreeOntologySource {
 
   public static void main (String[] args) {

   } // end main ()
   
  
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private Hashtable rootsForIndentationLevels;
   private OntologyTermNode overAllRootNode;
   private int numberOfIndents;
   // ==========================================
   // Section Construction
   // ==========================================
   public FlatFileTreeOntologySource() {
	  isSourceWorking = false;
   }

   public void load() {

	  try {

		 File modelDirectory = GlobalConstants.getModelDirectory();
		 StringBuffer fileNameBuffer = new StringBuffer();
		 fileNameBuffer.append(modelDirectory.getAbsolutePath());
		 fileNameBuffer.append(File.separator);
		 fileNameBuffer.append("resources");
		 fileNameBuffer.append(File.separator);
		 fileNameBuffer.append(fileName.trim() );
		 
		 file = new File(fileNameBuffer.toString());
		 if ( file.exists() == false) {
			status = new StringBuffer();
			status.append("ERROR: ");
			status.append("Can't find a file called ");
			status.append(file.getAbsolutePath() );
			isSourceWorking = false;
			return;
		 } //end if ()
		 

		 rootsForIndentationLevels = new Hashtable();
		 overAllRootNode 
			= new OntologyTermNode(new OntologyTerm("root") );
		 
		 FileReader fileReader = new FileReader(file);
		 BufferedReader bufferedReader = new BufferedReader(fileReader);
		 String currentLine = bufferedReader.readLine();

		 
		 while (currentLine != null ) {
			numberOfIndents = countIndentationLevels(currentLine);
			String currentTerm = currentLine.trim();
			OntologyTermNode currentNode 
			   = new OntologyTermNode(new OntologyTerm(currentTerm));

			if ( numberOfIndents == 0) {
			   overAllRootNode.add(currentNode);
			}
			else {
			   OntologyTermNode levelNode 
			   = (OntologyTermNode) rootsForIndentationLevels.get(new Integer(numberOfIndents - 1) );
			   levelNode.add(currentNode);
			   
			} //end if ()
			
			rootsForIndentationLevels.remove(new Integer(numberOfIndents) );
			rootsForIndentationLevels.put( new Integer(numberOfIndents),
										   currentNode);
			
			currentLine = bufferedReader.readLine();
		 } //end while ()
		 

		 //if there was only one term with no indentations, then 
		 //it is a single hierarchy; therefore just make that the root node
		 //otherwise, several hierarchies have been defined and need a common
		 //parent.
		 int numberOfChildren = overAllRootNode.getChildCount();
		 if ( numberOfChildren == 1) {
			OntologyTermNode firstChild
			   = (OntologyTermNode) overAllRootNode.getChildAt(0);
			rootNode = firstChild;
		 } //end if ()
		 else {
			rootNode = overAllRootNode;
		 } //end if ()


		 isSourceWorking = true;

		 status = new StringBuffer();
		 status.append("File ");
		 status.append(file.getAbsolutePath() );
		 status.append("is accessible and the contents can ");
		 status.append("be interpretted correctly.");

	  } catch (Exception err) {
		 status = new StringBuffer();
		 status.append("ERRORxxx: ");
		 status.append(err.toString() );
		 isSourceWorking = false;
	  } // end try-catch
	  
   }
   
   private int countIndentationLevels(String value) {
	  int numberOfCharacters = value.length();

	  int numberOfTabs = 0;

	  for ( int i = 0; i < value.length(); i++ ) {
		 if ( value.charAt(i) == '\t' ) {
			numberOfTabs++;
		 } //end if ()
		 else {
			break;
		 } //end else
	  } // end for ()
	  
	  return numberOfTabs;
   }

   // ==========================================
   // Section Accessors
   // ==========================================


   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================


   // ==========================================
   // Section Overload
   // ==========================================
   public void setFileName(String _fileName) {
	  this.fileName = _fileName;
	  load();
   }

}

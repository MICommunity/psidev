/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
* @version 1.0
*
*/

package pedro.ontology;

import javax.swing.JCheckBox;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableCellEditor;
import javax.swing.DefaultCellEditor;

import java.awt.Component;
import javax.swing.JTable;

import pedro.system.GlobalConstants;

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class ActiveServiceTableCellRenderer extends JCheckBox 
   implements TableCellRenderer {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================

   // ==========================================
   // Section Construction
   // ==========================================


   // ==========================================
   // Section Accessors
   // ==========================================

   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================

   public Component getTableCellRendererComponent(JTable table,
												  Object value,
												  boolean isSelected,
												  boolean hasFocus,
												  int row,
												  int column) {

	  String trueFalse = (String) value;
	  if ( trueFalse.equals("true") == true) {
		 setSelected(true);
	  } //end if ()
	  else {
		 setSelected(false);
	  } //end else
	  return this;

   }
   


   // ==========================================
   // Section Overload
   // ==========================================

}

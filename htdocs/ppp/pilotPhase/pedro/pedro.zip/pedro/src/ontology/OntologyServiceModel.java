/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
* @version 1.0
*
*/

package pedro.ontology;


import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;
import javax.swing.JTable;
import java.util.Hashtable;
import javax.swing.JCheckBox;
import pedro.system.GlobalConstants;
/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class OntologyServiceModel extends AbstractTableModel {

   
   // ==========================================
   // Section Constants
   // ==========================================
   public static final int ACTIVATION = 0;
   public static final int SERVICE_PRIORITY = 1;
   public static final int SERVICE_NAME = 2;
   public static final int LOCAL_OR_REMOTE_SERVICE = 3;
   public static final int STATUS = 4;

   // ==========================================
   // Section Properties
   // ==========================================
   private ArrayList ontologyServices;
   private String[] fieldNames;
   private int numberOfRows;

   private JTable table;

   // ==========================================
   // Section Construction
   // ==========================================
   public OntologyServiceModel() {
	  fieldNames = new String[5];
	  fieldNames[ACTIVATION] = "Activation";
	  fieldNames[SERVICE_PRIORITY] = "Priority";
	  fieldNames[SERVICE_NAME] = "Name";
	  fieldNames[LOCAL_OR_REMOTE_SERVICE] = "Local/Remote";
	  fieldNames[STATUS] = "Status";


   }

   public void setTable(JTable _table) {
	  this.table = _table;
   }

   // ==========================================
   // Section Accessors
   // ==========================================
   public void setOntologyServices(ArrayList _ontologyServices) {
	  this.ontologyServices = _ontologyServices;
	  numberOfRows = ontologyServices.size();
   }



   // ==========================================
   // Section Mutators
   // ==========================================
   public void adjustServicePriority(int startRowPosition,
									 int endRowPosition) {
	  
	  Object targetService 
		 = ontologyServices.get(startRowPosition);
	  
	  ontologyServices.remove(startRowPosition);
	  ontologyServices.add(endRowPosition, targetService);
   }




   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================

   // ==========================================
   // Section Interfaces
   // ==========================================
   public boolean isCellEditable(int row, 
								 int column) {

	  if ( column == ACTIVATION) {
		 return true;
	  } //end if ()
	  
	  return false;
   }



   // ==========================================
   // Section Overload
   // ==========================================
   public OntologyService getService(int row) {
	  OntologyService ontologyService 
		 = (OntologyService) ontologyServices.get(row);

	  return ontologyService;
   }

   public String getColumnName(int column) {
	  return fieldNames[column];
   }

   public int getRowCount() {
	  return numberOfRows;
   }

   public int getColumnCount() {
	  return 5;
   }
   
   public void setActiveService(int row, boolean isActivated) {
	  OntologyService ontologyService 
		 = (OntologyService) ontologyServices.get(row);

	  ontologyService.setActivated(isActivated);
   }

   public Object getValueAt(int row, 
							int column) {
	  
	  OntologyService ontologyService 
		 = (OntologyService) ontologyServices.get(row);

	  OntologyServiceDescription serviceDescription
		 = ontologyService.getServiceDescription();

	  if ( column == SERVICE_PRIORITY) {
		 return String.valueOf(row+1);
	  } //end if ()
	  else if ( column == ACTIVATION) {
		 if ( ontologyService.isActivated() == true) {
			return "true";
		 } //end if ()
		 else {
			return "false";
		 } //end else

	  } //end else ()
	  else if ( column == SERVICE_NAME) {
		 return serviceDescription.getName();
	  } //end else ()
	  else if ( column == LOCAL_OR_REMOTE_SERVICE) {
		 if ( serviceDescription.isLocalService() == true) {
			return "Local";
		 } //end if ()
		 else {
			return "Remote";
		 } //end else
	  } //end else ()
	  else {
		 //column is status
		 if ( ontologyService.isActivated() == true) {
			
			OntologySource source = ontologyService.getSource();
			if ( source.isWorking() == true) {
			   return "OK";
			} //end if ()
			else {
			   return "Failed";
			} //end else
		 } //end if ()
		 else {
			return "Unknown";
		 } //end else
		 
	  } //end else ()
	  
   }


   public void setValueAt(Object value,
						  int row,
						  int column) {


	  OntologyService ontologyService 
		 = (OntologyService) ontologyServices.get(row);

	  if ( column == ACTIVATION) {

		 Boolean result = (Boolean) value;

		 boolean isActivated = result.booleanValue();

		 if ( isActivated  == true) {
			ontologyService.setActivated(true);
		 } //end if ()
		 else {
			ontologyService.setActivated(false);
		 } //end else

		 fireTableCellUpdated(row, column);
		 table.repaint();
	  } //end if ()

   }



}

/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/
package pedro.ontology;


import java.net.URL;
import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.StreamTokenizer;
import java.util.ArrayList;
import java.util.Arrays;
import javax.swing.JPopupMenu;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.io.Serializable;
import java.awt.Component;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class DefaultOntologyProvider 
   implements ActionListener, OntologyProvider, Serializable {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private OntologyServiceManager ontologyServiceManager;
   private ArrayList ontologyServices;
   private OntologyListener ontologyListener;
   private JPopupMenu menu;
   private JMenuItem configureServices;
   private JMenuItem clearValues;
   private boolean allowClearValuesOption;
   
   // ==========================================
   // Section Construction
   // ==========================================
   public DefaultOntologyProvider(OntologyServiceManager _ontologyServiceManager) {
	  configureServices = new JMenuItem("Service Configuration...");
	  configureServices.addActionListener(this);

	  clearValues = new JMenuItem("Clear Values");
	  clearValues.addActionListener(this);
	  allowClearValuesOption = false;

	  this.ontologyServiceManager = _ontologyServiceManager;
   }

   // ==========================================
   // Section Accessors
   // ==========================================

   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================

   // ==========================================
   // Section Interfaces
   // ==========================================
   //Interface ActionListener
   public void actionPerformed(ActionEvent event) {
	  Object source = event.getSource();
	  if ( event.getSource() == configureServices) {
		 OntologyConfigurationDialog configurationDialog
			= new OntologyConfigurationDialog();
		 configurationDialog.setOntologyServiceManager(ontologyServiceManager);
		 configurationDialog.show();
	  } //end if ()
	  else if ( source == clearValues) {
		 if ( ontologyListener != null) {
			ontologyListener.clearValues();
		 } //end if ()
	  } //end else ()

   }

   //Interface OntologyProvider

   public JPopupMenu getMenu() {
	  //if ( menu == null) {
		 menu = new JPopupMenu("Ontology Services");
		 menu.add(configureServices);


		 ArrayList activeOntologyServices
			= ontologyServiceManager.getActiveServices();

		 int numberOfServices = activeOntologyServices.size();
		 for ( int i = 0; i < numberOfServices; i++) {
			OntologyService ontologyService
			   = (OntologyService) activeOntologyServices.get(i);
			
			OntologyMenuListener menuListener
			   = new OntologyMenuListener(ontologyService,
										  ontologyListener);

			menu.add(menuListener.getMenu() );
		 } // end for ()

		 if ( allowClearValuesOption == true) {
			menu.add(clearValues);
		 } //end if ()

	  return menu;
   }

   public void allowClearValuesOption(boolean allowClearValuesOption) {
	  this.allowClearValuesOption = allowClearValuesOption;
   }

   public void setOntologyListener(OntologyListener ontologyListener) {
	  this.ontologyListener = ontologyListener;
   }
   
   // ==========================================
   // Section Overload
   // ==========================================



}

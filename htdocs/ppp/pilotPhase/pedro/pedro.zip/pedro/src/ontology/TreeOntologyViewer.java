/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.ontology;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.JTree;
import javax.swing.tree.TreePath;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JDialog;
import java.util.ArrayList;
import java.io.File;

import javax.swing.JDialog;

import pedro.validation.StringMaskValidator;
import pedro.util.ErrorDialog;
import pedro.system.GlobalConstants;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class TreeOntologyViewer extends JDialog
   implements ActionListener {


   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private JButton ok;
   
   private JLabel searchLabel;
   private JTextField searchField;
   private JButton applySearch;
   private JButton clearSearch;

   private OntologyTermNode masterRootNode;

   private ArrayList clonedSearchResults;
   private ArrayList masterSearchResults;

   private JTree tree;
   // ==========================================
   // Section Construction
   // ==========================================
   public TreeOntologyViewer() {

	  clonedSearchResults = new ArrayList();
	  masterSearchResults = new ArrayList();

	  JPanel searchPanel = createSearchPanel();
	  DefaultTreeModel model 
		 = new DefaultTreeModel(new OntologyTermNode(new OntologyTerm() ) );
	  tree = new JTree(model);
	  tree.setRootVisible(false);
	  JScrollPane scrollPane = new JScrollPane(tree);
	  JPanel buttonPanel = createButtonPanel();

	  JPanel panel = new JPanel(new GridBagLayout() );
	  GridBagConstraints panelGC = new GridBagConstraints();
	  panelGC.weightx = 0;
	  panelGC.anchor = GridBagConstraints.NORTHWEST;
	  panelGC.fill = GridBagConstraints.HORIZONTAL;
	  panelGC.gridx = 0;
	  panelGC.gridy = 0;
	  panel.add(searchPanel, panelGC);

	  panelGC.gridy = 1;
	  panelGC.fill = GridBagConstraints.BOTH;
	  panelGC.weightx = 100;
	  panelGC.weighty = 100;
	  panel.add(scrollPane, panelGC);

	  
	  panelGC.gridy = 2;
	  panelGC.anchor = GridBagConstraints.SOUTHEAST;
	  panelGC.fill = GridBagConstraints.NONE;
	  panelGC.weightx = 0;
	  panelGC.weighty = 0;
	  panel.add(buttonPanel, panelGC);

	  getContentPane().add(panel);
	  pack();
	  setModal(true);
   }

   private JPanel createSearchPanel() {

	  JPanel panel = new JPanel(new GridBagLayout() );

	  searchLabel = new JLabel("Search:");
	  searchField = new JTextField(20);
	  applySearch = new JButton("Apply");
	  applySearch.addActionListener(this);
	  clearSearch = new JButton("Clear");
	  clearSearch.addActionListener(this);

	  GridBagConstraints panelGC = new GridBagConstraints();
	  panelGC.weightx = 0;
	  panelGC.anchor = GridBagConstraints.NORTHWEST;
	  panelGC.fill = GridBagConstraints.NONE;
	  panelGC.gridx = 0;
	  panelGC.gridy = 0;
	  panel.add(searchLabel, panelGC);

	  panelGC.gridx++;
	  panelGC.weightx = 100;
	  panelGC.fill = GridBagConstraints.HORIZONTAL;
	  panel.add(searchField, panelGC);

	  panelGC.gridx++;
	  panelGC.weightx = 0;
	  panelGC.fill = GridBagConstraints.NONE;
	  panel.add(applySearch, panelGC);
	  panelGC.gridx++;
	  panel.add(clearSearch, panelGC);

	  return panel;
   }

   private JPanel createButtonPanel() {
	  JPanel panel = new JPanel(new GridBagLayout() );
	  
	  ok = new JButton("OK");
	  ok.addActionListener(this);

	  GridBagConstraints panelGC = new GridBagConstraints();
	  panelGC.weightx = 0;
	  panelGC.anchor = GridBagConstraints.NORTHWEST;
	  panelGC.fill = GridBagConstraints.NONE;
	  panelGC.gridy = 0;

	  panelGC.gridx = 0;
	  panel.add(ok, panelGC);

	  return panel;
   }
   // ==========================================
   // Section Accessors
   // ==========================================
   public OntologyTerm[] getSelectedTerms() {

	  TreePath[] selectedPaths = tree.getSelectionPaths();


	  if (selectedPaths == null) {
		 return new OntologyTerm[0];
	  } //end if ()

	  OntologyTerm[] ontologyTerms 
		 = new OntologyTerm[selectedPaths.length];

	  for ( int i = 0; i < selectedPaths.length; i++) {
		 
		 OntologyTermNode selectedNode
			= (OntologyTermNode) selectedPaths[i].getLastPathComponent();

		 ontologyTerms[i] = selectedNode.getOntologyTerm();
	  } // end for ()
	  return ontologyTerms;
   }

   // ==========================================
   // Section Mutators
   // ==========================================

   public void setSource(TreeOntologySource ontologySource) {
	  

	  StringBuffer title = new StringBuffer();
	  title.append("Ontology for ");
	  title.append(ontologySource.getName() );
	  setTitle(title.toString() );

	  masterRootNode = ontologySource.getTreeRoot();
	  if ( masterRootNode == null) {
		 masterRootNode = new OntologyTermNode(new OntologyTerm() );
	  } //end if ()
	  
	  resetTree();
	  
   }

   private void applySearch() {

	  String searchMask = searchField.getText();
	  
	  searchNode(searchMask,
				 masterRootNode);

	  //now add each child as a subtree 
	  OntologyTermNode cloneRoot = cloneSubTree(masterRootNode);
	  DefaultTreeModel model = (DefaultTreeModel) tree.getModel();

	  OntologyTermNode searchRoot
		 = new OntologyTermNode(new OntologyTerm("Search Results..."));

	  int numberOfResults = clonedSearchResults.size();
	  for ( int i = 0; i < numberOfResults; i++) {
		 OntologyTermNode currentResult
			= (OntologyTermNode) clonedSearchResults.get(i);
		 searchRoot.add(currentResult);
	  } // end for ()

	  model.setRoot(searchRoot);
	  tree.updateUI();

   }

   private boolean valueMatchesMask(String stringMask,
									String candidateValue) {

	  String upperCaseMask = stringMask.toUpperCase();
	  String upperCaseValue = candidateValue.toUpperCase();

	  int index = upperCaseValue.indexOf(upperCaseMask);
	  if ( index == -1) {
		 return false;
	  } //end if ()
	  else {
		 return true;
	  } //end else
	  
   }


   private void searchNode(String mask,
						   OntologyTermNode masterNode) {

	  String nodeName = (String) masterNode.getUserObject();

	  if ( valueMatchesMask(mask,nodeName) == true) {
	  
		 //match found
		 if ( masterNode.getChildCount() == 0) {
			OntologyTermNode parentNode 
			   = (OntologyTermNode) masterNode.getParent();
			if ( parentNode != null) {
			   if ( masterSearchResults.contains(parentNode) == false) {
				  OntologyTermNode cloneNode = cloneSubTree(parentNode);
				  clonedSearchResults.add(cloneNode);
			   } //end if ()
			} //end if ()
			masterSearchResults.add(parentNode);
		 }
		 else {
			OntologyTermNode cloneNode = cloneSubTree(masterNode);
			clonedSearchResults.add(cloneNode);
			masterSearchResults.add(masterNode);
		 } //end else

	  } //end if ()
	  
	  int numberOfChildren = masterNode.getChildCount();
	  for (int i = 0; i < numberOfChildren; i++ ) {
		 OntologyTermNode currentChild 
			= (OntologyTermNode) masterNode.getChildAt(i);
		 searchNode(mask,
					currentChild);
	  } // end for ()

   }

   private void clearSearch() {
	  masterSearchResults.clear();
	  clonedSearchResults.clear();
	  resetTree();
   }

   private void resetTree() {
	  OntologyTermNode cloneRoot = cloneSubTree(masterRootNode);
	  DefaultTreeModel model = (DefaultTreeModel) tree.getModel();
	  model.setRoot(cloneRoot);
	  tree.updateUI();
   }

   private OntologyTermNode cloneSubTree(OntologyTermNode masterNode) {
	  OntologyTermNode cloneNode 
		 = (OntologyTermNode) masterNode.clone();
	  int numberOfChildren = masterNode.getChildCount();
	  for ( int i = 0; i < numberOfChildren; i++) {
		 OntologyTermNode childNode 
			= (OntologyTermNode) masterNode.getChildAt(i);
		 OntologyTermNode cloneChild = cloneSubTree(childNode);
		 cloneNode.add(cloneChild);
	  } // end for ()
	  return cloneNode;
   }


   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================
   public void actionPerformed(ActionEvent event) {
	  Object button = event.getSource();

	  if ( button == applySearch) {
		 applySearch();
	  } //end if ()
	  else if ( button == clearSearch) {
		 clearSearch();
	  } //end else ()
	  else if ( button == ok) {
		 dispose();
	  } //end else ()
   }


   // ==========================================
   // Section Overload
   // ==========================================

}


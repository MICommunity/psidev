/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.ontology;

import java.io.Serializable;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

public interface OntologySource extends Serializable {
   public String getName();
   public String getDescription();
   public OntologyTerm[] getTerms();
   public OntologyTerm[] getRelatedTerms(OntologyTerm term);
   public boolean containsTerm(OntologyTerm term);
   public void setFileName(String fileName);
   public boolean isWorking();
   public String test();
   public OntologySource getView(String parameters);
}



/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/


package pedro.ontology;


/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class TreeOntologyView extends AbstractTreeOntologySource {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private String parameters;
   private String status;
   private String description;

   // ==========================================
   // Section Construction
   // ==========================================
   public TreeOntologyView() {

	  status = "";
	  description = "";
   }


   // ==========================================
   // Section Accessors
   // ==========================================
   public void setRoot(OntologyTermNode _rootNode) {
	  this.rootNode = _rootNode;
   }
   
   public String getStatus() {
	  return status;
   }

   public String getDescription() {
	  return description;
   }

   // ==========================================
   // Section Mutators
   // ==========================================
   public void setParameters(String _parameters) {
	  this.parameters = _parameters;
   }

   public void setStatus(String _status) {
	  this.status = _status;
   }

   public void setDescription(String _description) {
	  StringBuffer buffer = new StringBuffer();
	  buffer.append(_description);
	  buffer.append("\n");
	  buffer.append("Parameters:");
	  buffer.append(parameters);
	  this.description = buffer.toString();
   }

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================
   public boolean isSourceWorking() {
	  return isSourceWorking;
   }

   public void setSourceWorking(boolean _isSourceWorking) {
	  this.isSourceWorking = _isSourceWorking;
   }

   public void setFileName(String _fileName) {
	  this.fileName = _fileName;
   }

   public OntologySource getView(String parameters) {
	  return this;
   }



}

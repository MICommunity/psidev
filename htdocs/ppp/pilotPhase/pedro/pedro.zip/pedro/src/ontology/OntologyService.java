/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.ontology;

import java.io.Serializable;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class OntologyService implements Serializable {
   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private OntologyServiceDescription serviceDescription;
   private OntologySource source;
   private String status;
   private boolean isActivated;

   // ==========================================
   // Section Construction
   // ==========================================
   public OntologyService(OntologyServiceDescription _serviceDescription,
						  OntologySource _source) {

	  this.serviceDescription = _serviceDescription;
	  this.source = _source;
	  this.isActivated = false;
   }

   public String test() {
	  return source.test();
   }

   // ==========================================
   // Section Accessors
   // ==========================================
   
   public OntologyServiceDescription getServiceDescription() {
	  return serviceDescription;
   }

   public OntologySource getSource() {
	  return source;
   }

   public boolean isActivated() {
	  return isActivated;
   }

   // ==========================================
   // Section Mutators
   // ==========================================
   public void setActivated(boolean _isActivated) {
	  this.isActivated = _isActivated;

   }

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================

}

/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
* @version 1.0
*
*/

package pedro.ontology;

import javax.swing.JMenuItem;


/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class OntologyTermMenuItem extends JMenuItem {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private OntologyTerm ontologyTerm;

   // ==========================================
   // Section Construction
   // ==========================================
   public OntologyTermMenuItem(OntologyTerm ontologyTerm) {
	  super(ontologyTerm.getTerm() );
	  this.ontologyTerm = ontologyTerm;
   }


   // ==========================================
   // Section Accessors
   // ==========================================
   public OntologyTerm getOntologyTerm() {
	  return ontologyTerm;
   }

   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================

}

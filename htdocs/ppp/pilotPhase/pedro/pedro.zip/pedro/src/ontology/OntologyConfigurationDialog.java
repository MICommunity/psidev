
/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/
package pedro.ontology;


import javax.swing.ButtonGroup;
import javax.swing.JPanel;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;

import javax.swing.JSeparator;
import javax.swing.border.LineBorder;
import java.awt.BorderLayout;
import java.awt.Insets;
import javax.swing.JCheckBox;

import javax.swing.event.ListSelectionListener;
import javax.swing.event.ListSelectionEvent;

import javax.swing.event.TableModelListener;
import javax.swing.event.TableModelEvent;

import pedro.system.GlobalConstants;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class OntologyConfigurationDialog extends JFrame 
   implements ActionListener, ListSelectionListener, TableModelListener {

   public static void main (String[] args) {
	  OntologyConfigurationDialog dialog = new OntologyConfigurationDialog();

	  OntologyServiceManager manager = new OntologyServiceManager();
	  dialog.setOntologyServiceManager(manager);

	  dialog.show();
   } // end main ()
   

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================

   private JLabel servicesLabel;
   private OntologyServiceTable table;
   private JScrollPane tablePane;
   private OntologyServiceModel serviceModel;

   private JLabel serviceDescriptionLabel;
   private JTextArea serviceDescription;

   private JLabel statusLabel;
   private JTextArea statusResult;

   private JLabel optionsLabel;
   private JCheckBox useFallBackServices;

   private JButton ok;

   private OntologyServiceManager serviceManager;

   private static final int VERTICAL_SPACING_GAP = 10;

   // ==========================================
   // Section Construction
   // ==========================================
   public OntologyConfigurationDialog() {

	  init();

   }

   private void init() {

	  setTitle("Ontology Service Configuration");
	  JPanel panel = new JPanel(new GridBagLayout() );
	  GridBagConstraints panelGC = new GridBagConstraints();
	  panelGC.anchor = GridBagConstraints.NORTHWEST;
	  panelGC.ipady = VERTICAL_SPACING_GAP;
	  panelGC.gridx = 0;
	  panelGC.gridy = 0;

	  //add in the service table
	  panelGC.weightx = 100;
	  panelGC.weighty = 100;
	  panelGC.fill = GridBagConstraints.BOTH;
	  panel.add(createTablePanel(), panelGC);
	  panelGC.gridy++;

	  //add the description text area
	  panelGC.weightx = 100;
	  panelGC.weighty = 0;
	  panelGC.fill = GridBagConstraints.HORIZONTAL;
	  panel.add(createDescriptionPanel(), panelGC);
	  panelGC.gridy++;

	  //add the test area
	  panel.add(createTestServicePanel(), panelGC);
	  panelGC.gridy++;

	  //add the option panel
	  //panel.add(createOptionPanel(), panelGC);
	  panelGC.gridy++;

	  //add button panel 
	  panel.add(new JSeparator() );
	  panelGC.gridy++;

	  panelGC.fill = GridBagConstraints.NONE;
	  panelGC.anchor = GridBagConstraints.SOUTHEAST;
	  panel.add(createButtonPanel(), panelGC);

	  JPanel mainPanel = new JPanel(new BorderLayout() );
	  mainPanel.add(panel, BorderLayout.NORTH);

	  getContentPane().add(mainPanel);

	  pack();
   }

   private JPanel createTablePanel() {

	  JPanel panel = new JPanel(new GridBagLayout() );
	  GridBagConstraints panelGC = new GridBagConstraints();
	  panelGC.weightx = 100;
	  panelGC.weighty = 0;
	  panelGC.anchor = GridBagConstraints.NORTHWEST;
	  panelGC.gridx = 0;
	  panelGC.gridy = 0;

	  //add in the service table
	  servicesLabel = new JLabel("Services:");
	  panelGC.fill = GridBagConstraints.NONE;
	  panel.add(servicesLabel, panelGC);
	  panelGC.gridy++;

	  table = new OntologyServiceTable();
	  table.addListSelectionListener(this);

	  serviceModel 
		 = (OntologyServiceModel) table.getModel();
	  serviceModel.addTableModelListener(this);

	  tablePane = new JScrollPane(table);
	  panelGC.fill = GridBagConstraints.BOTH;
	  panel.add(tablePane, panelGC);
	  panelGC.gridy++;

	  return panel;

   }

   private JPanel createDescriptionPanel() {

	  JPanel panel = new JPanel(new GridBagLayout() );
	  GridBagConstraints panelGC = new GridBagConstraints();
	  panelGC.weightx = 100;
	  panelGC.weighty = 0;
	  panelGC.anchor = GridBagConstraints.NORTHWEST;
	  panelGC.gridx = 0;
	  panelGC.gridy = 0;

	  panelGC.gridx = 0;
	  panelGC.gridy = 0;
	  panelGC.fill = GridBagConstraints.NONE;
	  serviceDescriptionLabel = new JLabel("Description:");
	  panel.add(serviceDescriptionLabel, panelGC);
	  panelGC.gridy++;

	  panelGC.fill = GridBagConstraints.HORIZONTAL;
	  serviceDescription = new JTextArea(4,30);
	  serviceDescription.setLineWrap(true);
	  serviceDescription.setWrapStyleWord(true);
	  JScrollPane descriptionPane = new JScrollPane(serviceDescription);
	  panel.add(descriptionPane, panelGC);
	  panelGC.gridy++;

	  return panel;

   }

   private JPanel createTestServicePanel() {

	  JPanel panel = new JPanel(new GridBagLayout() );
	  GridBagConstraints panelGC = new GridBagConstraints();
	  panelGC.weightx = 100;
	  panelGC.weighty = 0;
	  panelGC.anchor = GridBagConstraints.NORTHWEST;
	  panelGC.gridx = 0;
	  panelGC.gridy = 0;

	  panelGC.fill = GridBagConstraints.NONE;
	  statusLabel = new JLabel("Status:");
	  panel.add(statusLabel, panelGC);
	  panelGC.gridy++;

	  panelGC.fill = GridBagConstraints.HORIZONTAL;
	  statusResult = new JTextArea(4,30);
	  statusResult.setLineWrap(true);
	  statusResult.setWrapStyleWord(true);
	  JScrollPane testResultPane = new JScrollPane(statusResult);
	  panel.add(testResultPane, panelGC);
	  panelGC.gridy++;

	  return panel;

   }
   
   private JPanel createOptionPanel() {

	  JPanel panel = new JPanel(new GridBagLayout() );
	  GridBagConstraints panelGC = new GridBagConstraints();
	  panelGC.weightx = 100;
	  panelGC.weighty = 0;
	  panelGC.anchor = GridBagConstraints.NORTHWEST;
	  panelGC.gridx = 0;
	  panelGC.gridy = 0;

	  //add options
	  panelGC.anchor = GridBagConstraints.NORTHWEST;
	  panelGC.fill = GridBagConstraints.NONE;
	  optionsLabel = new JLabel("Options");
	  panel.add(optionsLabel, panelGC);

	  panelGC.gridy++;
	  
	  useFallBackServices 
		 = new JCheckBox("use backup services when active service fails");
	  useFallBackServices.addActionListener(this);
	  //panel.add(useFallBackServices, panelGC);

	  return panel;

   }


   private JPanel createButtonPanel() {

	  JPanel panel = new JPanel(new GridBagLayout() );
	  GridBagConstraints panelGC = new GridBagConstraints();
	  panelGC.weightx = 0;
	  panelGC.anchor = GridBagConstraints.SOUTHEAST;
	  panelGC.fill = GridBagConstraints.NONE;
	  panelGC.gridx = 0;
	  panelGC.gridy = 0;

	  ok = new JButton("OK");
	  ok.addActionListener(this);
	  panel.add(ok, panelGC);

	  return panel;

   }


   // ==========================================
   // Section Accessors
   // ==========================================
   





   // ==========================================
   // Section Mutators
   // ==========================================
   public void setOntologyServiceManager(OntologyServiceManager _serviceManager) {
	  this.serviceManager = _serviceManager;
	  table.setOntologyServices(serviceManager.getServices());

	  tablePane.setViewportView(table);
	  //updateDescriptionForActiveRow();
   }

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================
   //Interface: ListSelectionListener
   public void valueChanged(ListSelectionEvent event) {

	  updateDescriptionForActiveRow();

   }

   private void updateDescriptionForActiveRow() {

	  OntologyService ontologyService = table.getSelectedService();
	  OntologyServiceDescription serviceDescriptionText
		 = ontologyService.getServiceDescription();
	  
	  serviceDescription.setText(serviceDescriptionText.getDescription() );

	  if ( ontologyService.isActivated() == true) {
		 statusResult.setText(ontologyService.test() );
	  } //end if ()
	  else {
		 StringBuffer statusUnknown = new StringBuffer();
		 statusUnknown.append("Status unknown.  Activate the service ");
		 statusUnknown.append("to determine the status.");
		 statusResult.setText(statusUnknown.toString() );
	  } //end else

   }


   private void testService() {

	  OntologyService ontologyService = table.getSelectedService();

	  if ( ontologyService != null) {

		 serviceDescription.setText(ontologyService.test() );
	  }

   }


   //Interface: ActionListener
   public void actionPerformed(ActionEvent event) {
	  Object button = event.getSource();

	  if ( button == useFallBackServices) {


	  }
	  else if ( button == ok) {
		 dispose();
	  } //end else ()

   }
   

   public void tableChanged(TableModelEvent event) {

	  int column = event.getColumn();
	  int row = event.getFirstRow();

	  System.out.println("OntologyConfigurationDialog table event");

	  if ( column == OntologyServiceModel.ACTIVATION) {

		 String value = (String) serviceModel.getValueAt(row,
														 column);

		 OntologyService ontologyService
			= serviceModel.getService(row);

		 OntologyServiceDescription serviceDescriptionText
			= ontologyService.getServiceDescription();
		 
		 serviceDescription.setText(serviceDescriptionText.getDescription() );


		 if (value.equals("true")== true) {
			statusResult.setText(ontologyService.test() );
		 } //end if ()
		 else {
			StringBuffer statusUnknown = new StringBuffer();
			statusUnknown.append("Status unknown.  Activate the service ");
			statusUnknown.append("to determine the status.");
			statusResult.setText(statusUnknown.toString() );
		 } //end else
			 
		 
	  } //end if ()
	  


   }
 

   // ==========================================
   // Section Overload
   // ==========================================

}

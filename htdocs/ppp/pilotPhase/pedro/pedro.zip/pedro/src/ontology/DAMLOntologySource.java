/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
* @version 1.0
*
*/

package pedro.ontology;

import daml.DAMLOntologyNode;
import daml.DAMLClass;
import daml.DAMLOntologyService;
import java.io.File;
import pedro.system.GlobalConstants;


/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class DAMLOntologySource extends AbstractTreeOntologySource
   implements OntologyProvenance {
   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private DAMLOntologyService damlParser;

   // ==========================================
   // Section Construction
   // ==========================================
   public DAMLOntologySource() {
	  damlParser = new DAMLOntologyService();
   }

   public void load() {

	  try {

		 File modelDirectory = GlobalConstants.getModelDirectory();
		 StringBuffer fileNameBuffer = new StringBuffer();
		 fileNameBuffer.append(modelDirectory.getAbsolutePath());
		 fileNameBuffer.append("//resources//");
		 fileNameBuffer.append(fileName.trim() );

		 file = new File(fileNameBuffer.toString());
		 if ( file.exists() == false) {
			status = new StringBuffer();
		    status.append("ERROR: Can't find a file called ");
			status.append(file.getAbsolutePath() );
			isSourceWorking = false;
			return;
		 } //end if ()

		 isSourceWorking = true;
		 setName("Ontology for " + file.getAbsolutePath() );
		 damlParser.load(file);
		 convertDAMLNodesToPedroNodes();

		 isSourceWorking = true;
		 status = new StringBuffer();
		 status.append("File ");
		 status.append(file.getAbsolutePath() );
		 status.append("is accessible and the contents can ");
		 status.append("be interpretted correctly.");

	  } catch (Exception err) {
		 status = new StringBuffer("ERROR: " + err.toString() );
		 isSourceWorking = false;
	  } // end try-catch
   }

   private void convertDAMLNodesToPedroNodes() {
	  DAMLOntologyNode damlRoot = damlParser.getRoot();

	  OntologyTermNode pedroNode
		 = convertDAMLToPedroNode(damlRoot);
	  DAMLtoPedroNode(damlRoot,
					  pedroNode);
	  rootNode = pedroNode;
   }

   private void DAMLtoPedroNode(DAMLOntologyNode damlParentNode,
								OntologyTermNode pedroParentNode) {

	  int numberOfChildren = damlParentNode.getChildCount();
	  for (int i = 0; i < numberOfChildren; i++) {

		 DAMLOntologyNode childDAMLNode 
			= (DAMLOntologyNode) damlParentNode.getChildAt(i);

		 OntologyTermNode pedroCloneNode
			= convertDAMLToPedroNode(childDAMLNode);

		 pedroParentNode.add(pedroCloneNode);

		 DAMLtoPedroNode(childDAMLNode,
						 pedroCloneNode);
	  } // end for ()
   }

   private OntologyTermNode convertDAMLToPedroNode(DAMLOntologyNode damlOntologyNode) {

	  DAMLClass damlClass = damlOntologyNode.getDAMLClass();

	  OntologyTerm ontologyTerm = new OntologyTerm();

	  ontologyTerm.setTerm(damlClass.getTerm() );
	  ontologyTerm.setIdentifier(damlClass.getIdentifier() );
	  ontologyTerm.setProvenanceLink(damlClass.getProvenanceLink() );
	  ontologyTerm.setDefinition(damlClass.getDefinition() );

	  OntologyTermNode ontologyTermNode 
		 = new OntologyTermNode(ontologyTerm);
	  
	  return ontologyTermNode;
   }




   // ==========================================
   // Section Accessors
   // ==========================================


   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================
   public void setFileName(String _fileName) {
	  this.fileName = _fileName;
	  load();
   }



}

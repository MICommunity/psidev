/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
* @version 1.0
*
* describes an ontology term.  Originally, ontology terms were just viewed as
* strings.  However, some of the ontologists we've talked to advise us that 
* each term might be associated with an identifier or a URL link.  We give
* you the ability to choose the same term from multiple ontology services.
* Other people may want to know which list you got your terms from.
* As of this release, we're not sure how this feature will work out.  
* Identifiers might be used to access some kind of web site.
*
* e.g: "testosterone" might have an ID of "234" to mean it was a hormone.
*      "testosterone" might have an ID of "555" to mean it's a steroid.
*
* one day you might be able to click on a hyperlink "testosterone" in one of 
* the fields, and be taken to one of these web pages:
*
* http://www.medicalterms.org/234
* or
* http://www.medicalterms.org/678
*
* The URL field provides a more complete definition of a web page. 
* Both of these fields are optional for now.
*/

package pedro.ontology;

import java.net.URL;

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class OntologyTerm {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   /** the word */
   private String term;

   /** an identifier */
   private String identifier;

   /** a link to a definition page */
   private URL provenanceLink;

   private String definition;

   // ==========================================
   // Section Construction
   // ==========================================
   public OntologyTerm(String term) {
	  this.term = term;
	  init();
   }
   
   public OntologyTerm() {
	  term = "";
	  init();
   }

   private void init() {
	  identifier = null;
	  provenanceLink = null;
	  definition = "";
   }
   
   // ==========================================
   // Section Accessors
   // ==========================================
   /**
	* Get the value of term.
	* @return value of term.
	*/
   public String getTerm() {
	  return term;
   }

   /**
	* Get the value of identifier.
	* @return value of identifier.
	*/
   public String getIdentifier() {
	  return identifier;
   }

   /**
	* Get the value of provenanceLink.
	* @return value of provenanceLink.
	*/
   public URL getProvenanceLink() {
	  return provenanceLink;
   }

   /**
	* get the definition of the term
	*/
   public String getDefinition() {
	  return definition;
   }

   // ==========================================
   // Section Mutators
   // ==========================================
   /**
	* Set the value of term.
	* @param term Value to assign to term.
	*/
   public void setTerm(String term) {
	  this.term = term;
   }
   
   /**
	* Set the value of identifier.
	* @param identifier Value to assign to identifier.
	*/
   public void setIdentifier(String identifier) {
	  this.identifier = identifier;
   }
   
   /**
	* Set the value of provenanceLink.
	* @param provenanceLink Value to assign to provenanceLink.
	*/
   public void setProvenanceLink(URL provenanceLink) {
	  this.provenanceLink = provenanceLink;
   }

   /**
	* sets definition of the term
	*/
   public void setDefinition(String definition) {
	  this.definition = definition;
   }

   // ==========================================
   // Section Validation   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================

}

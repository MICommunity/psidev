/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/
package pedro.ontology;

import java.net.URL;
import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.StreamTokenizer;
import java.util.ArrayList;
import java.util.Arrays;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import pedro.util.ErrorDialog;
import pedro.system.GlobalConstants;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class FlatFileOntologySource 
   implements OntologySource {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private File file;
   private String[] vocabulary;
   private StringBuffer status;
   private String fileName;
   private boolean isSourceWorking;
   private boolean isRemoteSource;
   // ==========================================
   // Section Construction
   // ==========================================
   public FlatFileOntologySource() {
	  status = new StringBuffer();
	  isSourceWorking = false;
   }

   private void loadVocabulary() {

	  try {

		 File modelDirectory = GlobalConstants.getModelDirectory();
		 StringBuffer fileNameBuffer = new StringBuffer();

		 fileNameBuffer.append(modelDirectory.getAbsolutePath());

		 fileNameBuffer.append(File.separator);
		 fileNameBuffer.append("resources");

		 fileNameBuffer.append(File.separator);

		 fileNameBuffer.append(fileName.trim() );

		 file = new File(fileNameBuffer.toString());
		 if ( file.exists() == false) {
			isSourceWorking = false;
			status = new StringBuffer();
			status.append("ERROR: Can't find a file called ");
			status.append(file.getAbsolutePath() );
			return;
		 } //end if ()

		 
		 FileReader fileReader = new FileReader(file);
		 BufferedReader bufferedReader = new BufferedReader(fileReader);
		 
		 ArrayList results = new ArrayList();
		 String currentLine = bufferedReader.readLine();
		 while (currentLine != null ) {
			results.add(currentLine.trim() );
			currentLine = bufferedReader.readLine();
		 } //end while ()
		 


		 this.vocabulary = (String[]) results.toArray(new String[0]);
		 Arrays.sort(vocabulary);

		 status = new StringBuffer();
		 status.append("File ");
		 status.append(file.getAbsolutePath() );
		 status.append(" is accessible and the contents can ");
		 status.append("be interpretted correctly.");
		 isSourceWorking = true;
		 

	  } catch (Exception err) {
		 isSourceWorking = false;
		 status = new StringBuffer();
		 status.append("ERROR: ");
		 status.append(err.toString());
	  } // end try-catch
   }


   // ==========================================
   // Section Accessors
   // ==========================================
   public String getName() {
	  return("Ontology: " + file.getAbsolutePath() );
   }

   // ==========================================
   // Section Mutators
   // ==========================================
   public void setRemoteSource(boolean isRemoteSource) {
	  this.isRemoteSource = isRemoteSource;
   }
   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================

   //Interface OntologySource


   public boolean isRemoteSource() {
	  return isRemoteSource;
   }

   public boolean isWorking() {
	  return isSourceWorking;
   }

   public String getDescription() {
	  StringBuffer description = new StringBuffer();
	  description.append("Reads a list of words from file ");
	  description.append(file.getAbsolutePath() );
	  return description.toString();
   }

   public String test() {
	  return status.toString();
   }

   public OntologyTerm[] getTerms() {
	  OntologyTerm[] ontologyTerms = new OntologyTerm[vocabulary.length];

	  for ( int i = 0; i < vocabulary.length; i++) {
		 ontologyTerms[i] = new OntologyTerm(vocabulary[i]);
	  } // end for ()
	  
	  return ontologyTerms;
   }
   
   public OntologyTerm[] getRelatedTerms(OntologyTerm ontologyTerm) {
	  if ( containsTerm(ontologyTerm) == true) {
		 OntologyTerm[] relatedTerms = new OntologyTerm[1];
		 relatedTerms[0] = ontologyTerm;
		 return relatedTerms;
	  } //end if ()
	  else {
		 return new OntologyTerm[0];
	  } //end else
   }


   public boolean containsTerm(OntologyTerm ontologyTerm) {
	  String term = ontologyTerm.getTerm();
	  for ( int i = 0 ; i < vocabulary.length; i++) {
		 if ( vocabulary[i].equals(term) == true) {
			return true;
		 } //end if ()
	  } // end for ()
	  return false;
   }

   // ==========================================
   // Section Overload
   // ==========================================
   public void setFileName(String _fileName) {
	  this.fileName = _fileName;
	  loadVocabulary();
   }

   public OntologySource getView(String parameters) {
	  return this;
   }


}

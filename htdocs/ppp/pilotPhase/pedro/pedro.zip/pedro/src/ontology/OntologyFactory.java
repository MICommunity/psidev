/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.ontology;

import java.util.ArrayList;
import java.lang.reflect.Constructor;
import java.lang.Class;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class OntologyFactory {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private ArrayList ontologySourceRecords;
   private static OntologyFactory ontologyFactory = null;
   // ==========================================
   // Section Construction
   // ==========================================
   public OntologyFactory() {
	  ontologySourceRecords = new ArrayList();
   }

   public static OntologyFactory getOntologyFactory() {
	  if ( ontologyFactory == null) {
		 ontologyFactory = new OntologyFactory();
	  } //end if ()

	  return ontologyFactory;
   }

   

   public OntologySource createSource(Class ontologyClass,
									  String fileName) {
	  
	  int numberOfSources = ontologySourceRecords.size();
	  for ( int i = 0; i < numberOfSources; i++) {
		 OntologySourceRecord currentOntology 
			= (OntologySourceRecord) ontologySourceRecords.get(i);

		 if ((ontologyClass == currentOntology.getClass()) &&
			  (fileName == currentOntology.getFileName())) {
			return currentOntology.getOntologySource();
		 } //end if ()

	  } // end for ()

	  try {
	  
		 OntologySourceRecord ontologySourceRecord 
			= new OntologySourceRecord(ontologyClass,
									   fileName);
		 
		 //use reflection to instantiate

		 Constructor constructor = ontologyClass.getConstructor(new Class[0]);
		 OntologySource ontologySource = (OntologySource) constructor.newInstance(new Object[0]);
		 ontologySource.setFileName(fileName);
		 ontologySourceRecord.setOntologySource(ontologySource);
		 ontologySourceRecords.add(ontologySourceRecord);


		 return ontologySource;

	  } catch (Exception err) {
		 System.out.println("OntologyFactory" + err.toString());
		 return null;
	  } // end try-catch
	  


   }


   // ==========================================
   // Section Accessors
   // ==========================================


   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================

}

class OntologySourceRecord {
   
   private Class ontologyClass;
   private String fileName;
   private OntologySource ontologySource;

   public OntologySourceRecord(Class _ontologyClass,
							   String _fileName) {

	  this.ontologyClass = _ontologyClass;
	  this.fileName = _fileName;
   }

   public Class getOntologyClass() {
	  return ontologyClass;
   }

   public String getFileName() {
	  return fileName;
   }

   public OntologySource getOntologySource() {
	  return ontologySource;
   }

   public void setOntologySource(OntologySource _ontologySource) {
	  this.ontologySource = _ontologySource;
   }
}

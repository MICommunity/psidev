/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.ontology;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JDialog;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.text.JTextComponent;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.util.Hashtable;

import pedro.util.WindowCloser;
import pedro.util.FilteredList;

import javax.swing.event.CaretListener;
import javax.swing.event.CaretEvent;


/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class TouchTypeOntologyDialog extends JDialog
   implements ActionListener, CaretListener {

   
   // ==========================================
   // Section Constants
   // ==========================================

   // ==========================================
   // Section Properties
   // ==========================================

   private static TouchTypeOntologyDialog touchTypeOntologyDialog;

   private JTextArea ontologyServiceDescription;
   private FilteredList filteredList;
   private JButton close;
   private JButton useTerm;
   private JTextComponent textComponent;
   private boolean isAdjusting;
   private Hashtable ontologyTermFromWord;

   // ==========================================
   // Section Construction
   // ==========================================
   public TouchTypeOntologyDialog() {

	  
	  setTitle("Touch Type Ontology Dialog");
	  addWindowListener(new WindowCloser() );

	  JPanel mainPanel = new JPanel(new GridBagLayout() );
	  GridBagConstraints mainPanelGC = new GridBagConstraints();
	  mainPanelGC.anchor = GridBagConstraints.NORTHWEST;
	  mainPanelGC.fill = GridBagConstraints.HORIZONTAL;
	  mainPanelGC.gridx = 0;
	  mainPanelGC.gridy = 0;
	  mainPanelGC.weightx = 0;
	  mainPanelGC.weighty = 0;

	  //add in the ontology service description
	  ontologyServiceDescription = new JTextArea(4, 30);
	  ontologyServiceDescription.setLineWrap(true);
	  ontologyServiceDescription.setWrapStyleWord(true);
	  ontologyServiceDescription.setEditable(false);
	  ontologyServiceDescription.setBackground( mainPanel.getBackground() );
	  JScrollPane descriptionPane 
		 = new JScrollPane(ontologyServiceDescription);
	  mainPanel.add(descriptionPane, mainPanelGC);

	  

	  //add in the changing list
	  mainPanelGC.fill = GridBagConstraints.BOTH;
	  mainPanelGC.gridy++;
	  mainPanelGC.weightx = 100;
	  mainPanelGC.weighty = 100;
	  filteredList = new FilteredList();
	  JScrollPane filteredListPane = new JScrollPane(filteredList);
	  mainPanel.add(filteredListPane, mainPanelGC);
	  
	  //create button panel
	  mainPanelGC.gridy++;
	  mainPanelGC.anchor = GridBagConstraints.SOUTHEAST;
	  mainPanelGC.fill = GridBagConstraints.NONE;
	  mainPanelGC.weightx = 0;
	  mainPanelGC.weighty = 0;
	  mainPanel.add(createButtonPanel(), mainPanelGC);

	  isAdjusting = false;

	  getContentPane().add(mainPanel);
	  pack();

	  ontologyTermFromWord = new Hashtable();

   }


   public boolean isAdjusting() {
	  return isAdjusting;
   }

   private JPanel createButtonPanel() {

	  JPanel panel = new JPanel(new GridBagLayout() );
	  GridBagConstraints panelGC = new GridBagConstraints();
	  panelGC.anchor = GridBagConstraints.SOUTHEAST;
	  panelGC.gridx = 0;
	  panelGC.gridy = 0;

	  //add in the service table
	  panelGC.weightx = 0;
	  panelGC.weighty = 0;
	  panelGC.fill = GridBagConstraints.NONE;

	  useTerm = new JButton("Use Term");
	  useTerm.addActionListener(this);
	  panel.add(useTerm, panelGC);
	  panelGC.gridx++;

	  close = new JButton("Close");
	  close.addActionListener(this);
	  panel.add(close, panelGC);

	  return panel;

   }


   static public TouchTypeOntologyDialog getTouchTypeOntologyDialog() {
	  if ( touchTypeOntologyDialog == null) {
		 touchTypeOntologyDialog = new TouchTypeOntologyDialog();
	  } //end if ()
	  return touchTypeOntologyDialog;
   }

   private void close() {
	  isAdjusting = true;
	  hide();
   }

   // ==========================================
   // Section Accessors
   // ==========================================
   public void setAdjusting(boolean _isAdjusting) {
	  this.isAdjusting = _isAdjusting;
   }

   public void registerOntologyService(OntologyService ontologyService,
									   JTextComponent _textComponent) {

	  //if there's already a text component registered, remove 
	  //the caretlistener from it
	  if ( textComponent != null) {
		 textComponent.removeCaretListener(this);
	  } //end if ()

	  OntologySource ontologySource
		 = ontologyService.getSource();

	  OntologyTerm[] ontologyTerms = ontologySource.getTerms();
	  String[] terms = new String[ontologyTerms.length];
	  for (int i = 0; i < ontologyTerms.length; i++) {
		 terms[i] = ontologyTerms[i].getTerm();
		 ontologyTermFromWord.put(terms[i],ontologyTerms[i]);
	  } // end for ()

	  filteredList.setTerms(terms);

	  OntologyServiceDescription serviceDescription 
		 = ontologyService.getServiceDescription();
	  ontologyServiceDescription.setText(serviceDescription.getDescription() );
	  
	  this.textComponent = _textComponent;
	  textComponent.addCaretListener(this);
   }

   public void deregisterOntologyService() {
	  if ( textComponent == null) {
		 return;
	  } //end if ()
	  
	  textComponent.removeCaretListener(this);
	  textComponent = null;
   }

   public void hide() {
	  if ( textComponent != null) {
		 textComponent.removeCaretListener(this);
	  } //end if ()
	  
	  super.hide();
   }

   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================

   // ==========================================
   // Section Interfaces
   // ==========================================

   private static int count = 0;
   
   //Interface: CaretListener
   public void caretUpdate(CaretEvent event) {
	  count++;
	  
	  if ( textComponent == null) {
		 return;
	  } //end if ()
	  
	  //if character before the current position is a space or
	  //if current position is zero reset
	  int currentPosition = textComponent.getCaretPosition();
	  String textFieldValue = textComponent.getText();

	  if ( currentPosition == 0) {
		 filteredList.reset();
	  } //end if ()
	  else if (textFieldValue.charAt(currentPosition - 1) == ' ') {
		 filteredList.reset();
	  } //end else ()
	  else {
		 String filterMask = textFieldValue.substring(0,currentPosition);

		 int lastSpaceIndex = filterMask.lastIndexOf(" ");
		 if ( lastSpaceIndex != -1) {
			filterMask = filterMask.substring(lastSpaceIndex, currentPosition);
			filterMask = filterMask.trim();
		 } //end if ()

		 filteredList.filterList(filterMask);
		 
	  } //end else

   } 

   public void useTerm() {
	  if ( textComponent == null) {
		 return;
	  } //end if ()


	  String selectedTerm = (String) filteredList.getSelectedValue();

	  String textFieldValue = textComponent.getText();
	  //eg: The qui^ brown fox...
	  int caretPosition = textComponent.getCaretPosition();

	  String afterCursorPart 
		 = textFieldValue.substring(caretPosition);

	  //this variable is used to move the cursor to the end of the
	  //inserted term
	  int newCaretPosition;
	  

	  //deal with part of string that is before the caret
	  //eg: The qui

	  String beforeCursorPart;

	  if ( caretPosition == 0) {
		 //in the case of
		 //eg:Tquick brown fox
		 //   ^
		 beforeCursorPart = "";
	  } //end if ()
	  else {
		 beforeCursorPart
		 = textFieldValue.substring(0,caretPosition-1);
	  } //end else

	  int lastSpaceLocation = beforeCursorPart.lastIndexOf(" ");
	  if ( lastSpaceLocation == -1) {
		 //no space found so it means the term will replace the
		 //first word in the text field phrase
		 
		 //eg:Quibrown foxes like to run
		 //     ^
		 beforeCursorPart = selectedTerm;
		 //eg:Quickbrown foxes like to run
		 //       ^
		 newCaretPosition = selectedTerm.length();
	  } //end if ()
	  else {
		 //concatenate all the words before this one
		 //eg:
		 //Step 1:The quibrown fox jumped over the fence
		 //             ^
		 //Step 2:The quickbrown 
		 //Step 3:        ^


		 beforeCursorPart 
			= beforeCursorPart.substring(0, lastSpaceLocation+1) +
			selectedTerm;
		 newCaretPosition = beforeCursorPart.length();
	  } //end else
	  
	  String resultTextFieldValue 
		 = beforeCursorPart + afterCursorPart;
	  

	  textComponent.setText(resultTextFieldValue);
	  textComponent.setCaretPosition(newCaretPosition);


   }

   //Interface: ActionListener
   public void actionPerformed(ActionEvent event) {
	  Object source = event.getSource();
	  if ( source == useTerm) {
		 useTerm();
	  } //end else ()
	  else if ( source == close) {
		 close();
	  } //end else ()
   }

   // ==========================================
   // Section Overload
   // ==========================================

}

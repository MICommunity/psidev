/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.ontology;


import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JDialog;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JPanel;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.util.Hashtable;


import pedro.util.WindowCloser;
import pedro.util.FilteredList;
import pedro.util.OrderedListPanel;
import pedro.util.FilteredListPanel;

import java.awt.BorderLayout;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class TermSelectorDialog extends JDialog
   implements ActionListener {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private JTextField quickSearch;
   private FilteredListPanel masterListPanel;
   private OrderedListPanel orderedListPanel;
   private JButton close;
   private Hashtable ontologyTermFromWord;

   // ==========================================
   // Section Construction
   // ==========================================
   public TermSelectorDialog(OntologyTerm[] ontologyTerms, String title) {

	  setTitle(title);
	  setModal(true);
	  addWindowListener(new WindowCloser() );
	  quickSearch = new JTextField();

	  String[] terms = new String[ontologyTerms.length];
	  ontologyTermFromWord = new Hashtable();
	  for ( int i = 0; i < ontologyTerms.length; i++) {
		 terms[i] = ontologyTerms[i].getTerm();
		 ontologyTermFromWord.put(terms[i], ontologyTerms[i]);
	  } // end for ()

	  masterListPanel = new FilteredListPanel(terms);
	  
	  orderedListPanel = new OrderedListPanel();

	  masterListPanel.setSelectedItemList(orderedListPanel);

	  FilteredList filteredList = masterListPanel.getFilteredList();
	  quickSearch.addCaretListener(filteredList);

	  JPanel mainPanel = new JPanel(new GridBagLayout() );
	  GridBagConstraints mainPanelGC = new GridBagConstraints();

	  mainPanelGC.anchor = GridBagConstraints.NORTHWEST;
	  mainPanelGC.fill = GridBagConstraints.HORIZONTAL;
	  mainPanelGC.gridx = 0;
	  mainPanelGC.gridy = 0;
	  mainPanelGC.weightx = 100;
	  mainPanelGC.weighty = 0;
	  mainPanel.add(quickSearch, mainPanelGC);

	  JPanel listPanel = new JPanel(new BorderLayout() );

	  listPanel.add(masterListPanel, BorderLayout.WEST);
	  listPanel.add(orderedListPanel, BorderLayout.EAST);
	  
	  mainPanelGC.anchor = GridBagConstraints.NORTHWEST;
	  mainPanelGC.fill = GridBagConstraints.BOTH;
	  mainPanelGC.gridx = 0;
	  mainPanelGC.gridy = 1;
	  mainPanel.add(listPanel, mainPanelGC);

	  mainPanelGC.gridx = 0;
	  mainPanelGC.gridy = 2;
	  mainPanelGC.anchor = GridBagConstraints.SOUTHEAST;
	  mainPanelGC.fill = GridBagConstraints.NONE;
	  mainPanelGC.weightx = 0;
	  mainPanelGC.weighty = 0;

	  close = new JButton("Close");
	  close.addActionListener(this);

	  mainPanel.add(close, mainPanelGC);

	  getContentPane().add(mainPanel);
	  pack();
   }

   private void close() {
	  hide();
   }

   // ==========================================
   // Section Accessors
   // ==========================================
   public OntologyTerm[] getSelectedTerms() {
	  String[] items
		 = orderedListPanel.getItems();

	  OntologyTerm[] selectedOntologyTerms 
		 = new OntologyTerm[items.length];

	  if ( items.length == 0) {
		 return null;
	  } //end if ()

	  for ( int i = 0; i < selectedOntologyTerms.length; i++) {
		 selectedOntologyTerms[i] 
			= (OntologyTerm) ontologyTermFromWord.get(items[i]);
	  } // end for ()
	  
	  return selectedOntologyTerms;
   }

   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================

   // ==========================================
   // Section Interfaces
   // ==========================================
   //Interface: ActionListener
   public void actionPerformed(ActionEvent event) {
	  Object source = event.getSource();

	  if ( source == close) {
		 close();
	  } //end else ()
   }


   // ==========================================
   // Section Overload
   // ==========================================

}

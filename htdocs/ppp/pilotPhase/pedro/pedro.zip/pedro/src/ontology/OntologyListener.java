/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/
package pedro.ontology;


/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

public interface OntologyListener {
   public void termsSelected(OntologyTerm[] terms);
   public void clearValues();
}

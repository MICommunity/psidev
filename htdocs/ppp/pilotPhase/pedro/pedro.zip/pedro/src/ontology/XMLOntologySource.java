/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.ontology;

import java.io.IOException;
import java.io.File;

import javax.swing.JTree;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

import pedro.util.ErrorDialog;
import pedro.validation.StringMaskValidator;
import pedro.system.GlobalConstants;
/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class XMLOntologySource extends AbstractTreeOntologySource {


    
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   // ==========================================
   // Section Construction
   // ==========================================
   public XMLOntologySource() {
   }

   public void load() {

	  try {

		 File modelDirectory = GlobalConstants.getModelDirectory();
		 StringBuffer fileNameBuffer = new StringBuffer();
		 fileNameBuffer.append(modelDirectory.getAbsolutePath());
		 fileNameBuffer.append("//resources//");
		 fileNameBuffer.append(fileName.trim() );

		 file = new File(fileNameBuffer.toString());
		 if ( file.exists() == false) {
			status = new StringBuffer();
		    status.append("ERROR: Can't find a file called ");
			status.append(file.getAbsolutePath() );
			isSourceWorking = false;
			return;
		 } //end if ()

		 isSourceWorking = true;

		 setName("Ontology for " + file.getAbsolutePath() );
		 parseDocument(file);

		 isSourceWorking = true;
		 status = new StringBuffer();
		 status.append("File ");
		 status.append(file.getAbsolutePath() );
		 status.append("is accessible and the contents can ");
		 status.append("be interpretted correctly.");



	  } catch (Exception err) {
		 status = new StringBuffer("ERROR: " + err.toString() );
		 isSourceWorking = false;
	  } // end try-catch

   }

   public void parseDocument(File file) 
   throws ParserConfigurationException, 
		  SAXException,
		  IOException {

	  DocumentBuilderFactory documentBuilderFactory
		 = DocumentBuilderFactory.newInstance();
	  DocumentBuilder documentBuilder
		 = documentBuilderFactory.newDocumentBuilder();

	  Document document = documentBuilder.parse(file);


	  Node currentChild = document.getFirstChild();

	  Element rootElement = null;
	  while ( currentChild != null) {
		 if ( currentChild.getNodeType() == Node.ELEMENT_NODE) {
			Element currentElement = (Element) currentChild;
			rootElement = currentElement;
			break;
		 } //end if ()
		 currentChild = currentChild.getNextSibling();
	  } //end while ()

	  rootNode = parseElement(rootElement);
   }
   

   private OntologyTermNode parseElement(Element element) {
	  //String tagName = element.getTagName();
	  String value = element.getAttribute("value");
	  if ( value.equals("") == true) {
		 value = element.getTagName();
	  } //end if ()

	  OntologyTermNode node 
		 = new OntologyTermNode(new OntologyTerm(value) );

	  Node currentNode = element.getFirstChild();
	  while ( currentNode != null) {
		 if ( currentNode.getNodeType() == Node.ELEMENT_NODE) {
			Element currentElement = (Element) currentNode;
			node.add(parseElement(currentElement));
		 } //end if ()

		 currentNode = currentNode.getNextSibling();
	  } //end while ()
	  
	  return node;
   }


   // ==========================================
   // Section Accessors
   // ==========================================


   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================



   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================
   public void setFileName(String _fileName) {
	  this.fileName = _fileName;
	  load();
   }



}

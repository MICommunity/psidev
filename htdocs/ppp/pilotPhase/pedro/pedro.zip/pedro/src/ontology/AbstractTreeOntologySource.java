/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.ontology;

import java.util.ArrayList;
import java.util.Arrays;
import java.io.StringReader;
import java.io.StreamTokenizer;
import java.io.IOException;

import java.io.File;

import pedro.validation.StringMaskValidator;
import pedro.util.UniqueArrayList;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */



/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public abstract class AbstractTreeOntologySource implements TreeOntologySource {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   protected OntologyTermNode rootNode;
   protected OntologyTermNode searchResultNode;

   private UniqueArrayList currentTerms;
   protected StringMaskValidator maskValidator;
   private String name;
   protected File file;
   protected StringBuffer status;
   protected boolean isSourceWorking;
   protected String fileName;
   protected String parameters;
   protected boolean isRemoteSource;
   // ==========================================
   // Section Construction
   // ==========================================
   public AbstractTreeOntologySource() {
	  currentTerms = new UniqueArrayList();
	  status = new StringBuffer();
	  
	  searchResultNode 
		 = new OntologyTermNode(new OntologyTerm("Search Results"));
	  isSourceWorking = false;
   }

   // ==========================================
   // Section Accessors
   // ==========================================

   protected void setFileName(File _file) {
	  this.file = _file;
   }
   
   protected OntologyTermNode search(String mask) {
	  //maskValidator = new StringMaskValidator(mask);
	  return search(mask,rootNode);
   }

   private OntologyTermNode search(String mask,
										 OntologyTermNode node) {

	  String value = (String) node.getUserObject();


	  if ( value.lastIndexOf(mask) != -1) {
		 return node;
	  } //end if ()


	  /*
	  if ( maskValidator.validate(value) == null) {
		 return node;
	  } //end if ()
	  */

	  int numberOfChildren = node.getChildCount();
	  for ( int i = 0; i < numberOfChildren; i++) {
		 OntologyTermNode childNode 
			= (OntologyTermNode) node.getChildAt(i);
		 
		 OntologyTermNode result 
			= search(mask,
					 (OntologyTermNode) node.getChildAt(i) );

		 if ( result != null) {
			return result;
		 } //end if ()
	  } // end for ()

	  return null;
   }

   // ==========================================
   // Section Mutators
   // ==========================================
   private void collectTerms(OntologyTermNode node) {
	  String currentTerm = (String) node.getUserObject();
	  currentTerms.addTerm( currentTerm );

	  int numberOfChildren = node.getChildCount();
	  for ( int i = 0; i < numberOfChildren; i++) {
		 OntologyTermNode childNode 
			= (OntologyTermNode) node.getChildAt(i);
		 collectTerms(childNode);
	  } // end for ()
   }

   public void setName(String name) {
	  this.name = name;
   }

   public void setRemoteSource(boolean isRemoteSource) {
	  this.isRemoteSource = isRemoteSource;
   }
   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================
   //Interface: TreeOntologySource

   public boolean isRemoteSource() {
	  return isRemoteSource;
   }

   public boolean isWorking() {
	  return isSourceWorking;
   }
   
   abstract public void setFileName(String fileName);

   public String getDescription() {
	  StringBuffer description = new StringBuffer();

	  if ( file != null) {
		 description.append("Reads vocabulary from ");
		 description.append(file.getAbsolutePath() );
	  } //end if ()
	  else {
		 description.append("Reads vocabulary from ");
		 description.append(fileName);
	  } //end else

	  return description.toString();
   }

   public String test() {
	  return status.toString();
   }


   public String getName() {
	  return name;
   }

   public OntologyTerm[] getTerms() {
	  if ( rootNode == null) {
		 return null;
	  } //end if ()
	  else {
		 collectTerms(rootNode);
		 String[] terms = (String[]) currentTerms.toArray(new String[0]);
		 Arrays.sort(terms);
		 
		 //now package them into ontology terms
		 OntologyTerm[] ontologyTerms 
			= new OntologyTerm[terms.length];
		 
		 for ( int i = 0; i < terms.length; i++) {
			ontologyTerms[i] = new OntologyTerm(terms[i]);
		 } // end for ()

		 return ontologyTerms;
	  } //end else
	  
   }

   public OntologyTerm[] getRelatedTerms(OntologyTerm ontologyTerm) {
	  //returns terms that fall below it in a subcategory
	  //"kinds of"
	  currentTerms.clear();

	  //maskValidator = new StringMaskValidator(term);
	  OntologyTermNode result = search(ontologyTerm.getTerm(),rootNode);
	  if ( result == null) {
		 return new OntologyTerm[0];
	  } //end if ()
	  else {
		 collectTerms(result);
		 String[] relatedTerms = (String[]) currentTerms.toArray(new String[0]);
		 OntologyTerm[] ontologyTerms 
			= new OntologyTerm[relatedTerms.length];

		 for ( int i = 0; i < relatedTerms.length; i++) {
			ontologyTerms[i] = new OntologyTerm(relatedTerms[i]);
		 } // end for ()

		 return ontologyTerms;
	  } //end else
   }

   public boolean containsTerm(OntologyTerm ontologyTerm) {

	  maskValidator = new StringMaskValidator(ontologyTerm.getTerm() );
   
	  OntologyTermNode result 
		 = search(ontologyTerm.getTerm(),
				  rootNode);

	  if ( result == null) {
		 return false;
	  } //end if ()
	  else {
		 return true;
	  } //end else
   }


   public OntologyTermNode getTreeRoot() {
	  return rootNode;
   }

   private ArrayList viewRootNodes;

   public OntologySource getView(String parameters) {
	  viewRootNodes = new ArrayList();

	  StringReader stringReader = new StringReader(parameters);
	  StreamTokenizer tokenizer = new StreamTokenizer(stringReader);
	  tokenizer.eolIsSignificant(true);
	  tokenizer.quoteChar('"');
	  
	  try {
		 while ( tokenizer.nextToken() != StreamTokenizer.TT_EOL) {
			String currentAnchorTerm = tokenizer.sval;
			if ( currentAnchorTerm == null) {
			   break;
			} //end if ()
			
			addSearchToView(currentAnchorTerm);
		 } //end while ()
	  } catch (IOException err) {
		 System.out.println(err);
	  } // end try-catch

	  OntologyTermNode viewRootNode = null;
 
	  int numberOfViewRoots = viewRootNodes.size();
	  viewRootNode 
		 = new OntologyTermNode(new OntologyTerm("Filtered Subcategories") );
	  
	  for ( int i = 0; i < numberOfViewRoots; i++) {
		 OntologyTermNode currentRoot 
			= (OntologyTermNode) viewRootNodes.get(i);
		 viewRootNode.add(currentRoot);
	  } // end for ()

	  TreeOntologyView view = new TreeOntologyView();
	  view.setRoot(viewRootNode);
	  view.setSourceWorking(isSourceWorking);
	  view.setFileName(fileName);
	  view.setParameters(parameters);
	  view.setRemoteSource(isRemoteSource);
	  view.setStatus(test() );
	  view.setDescription(getDescription() );

	  return view;
   }


   private void addSearchToView(String currentAnchorTerm) {
	  
	  //finds first occurrence in tree where the node name
	  //equals the current anchor term

	  OntologyTermNode node = search(currentAnchorTerm);
	  if ( node != null) {
		 
		 int numberOfViewRootNodes = viewRootNodes.size();

		 boolean nodeIsAncestorOfExistingViewRoot = false;
		 for ( int i = 0; i < numberOfViewRootNodes; i++) {
			OntologyTermNode currentViewRoot 
			   = (OntologyTermNode) viewRootNodes.get(i);
			
			nodeIsAncestorOfExistingViewRoot
			   = nodeIsAncestor(currentViewRoot,
								node);
						   
			if ( nodeIsAncestorOfExistingViewRoot == true) {
			   break;
			} //end if ()
			
		 } // end for ()

		 if ( nodeIsAncestorOfExistingViewRoot == false) {
			viewRootNodes.add(node);
		 } //end if ()

	  } //end if ()
   }
   
   private boolean nodeIsAncestor(OntologyTermNode candidateParent,
								  OntologyTermNode node) {
	  
	  if ( candidateParent == node) {
		 return true;
	  } //end if ()
	  else {
		 OntologyTermNode parentNode = (OntologyTermNode) node.getParent();
		 if ( parentNode == null) {
			return false;
		 } //end if ()
		 else {
			return nodeIsAncestor(candidateParent,
								  parentNode);
		 } //end else
		 
	  } //end else

   }




   // ==========================================
   // Section Overload
   // ==========================================



}

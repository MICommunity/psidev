/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
* @version 1.0
*
*/

package pedro.ontology;

import javax.swing.JTable;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.table.DefaultTableColumnModel;

import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.Point;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionListener;

import java.util.ArrayList;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.DefaultCellEditor;
import javax.swing.JCheckBox;
/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class OntologyServiceTable extends JTable 
   implements ActionListener,
			  MouseListener {
   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private OntologyServiceModel serviceModel;
   private int targetRowStartPosition;
   private ActiveServiceTableCellRenderer activeServiceCellRenderer;
   private TableColumn activationColumn;

   // ==========================================
   // Section Construction
   // ==========================================
   public OntologyServiceTable() {
	  //set up the data model
	  serviceModel = new OntologyServiceModel();

	  //Priority Column
	  TableColumn priorityColumn = new TableColumn();
	  priorityColumn.setModelIndex(OntologyServiceModel.SERVICE_PRIORITY);
	  String priorityColumnName 
		 = serviceModel.getColumnName(OntologyServiceModel.SERVICE_PRIORITY);
	  priorityColumn.setModelIndex(OntologyServiceModel.SERVICE_PRIORITY);
	  priorityColumn.setHeaderValue(priorityColumnName);
	  priorityColumn.setResizable(false);

	  //Name Column
	  TableColumn serviceNameColumn = new TableColumn();
	  serviceNameColumn.setModelIndex(OntologyServiceModel.SERVICE_NAME);
	  String serviceNameColumnName 
		 = serviceModel.getColumnName(OntologyServiceModel.SERVICE_NAME);
	  serviceNameColumn.setHeaderValue(serviceNameColumnName);
	  serviceNameColumn.setModelIndex(OntologyServiceModel.SERVICE_NAME);
	  
	  //Activation Column
	  activationColumn = new TableColumn();
	  String activationColumnName
		 = serviceModel.getColumnName(OntologyServiceModel.ACTIVATION);

	  activationColumn.setModelIndex(OntologyServiceModel.ACTIVATION);

	  activeServiceCellRenderer
		 = new ActiveServiceTableCellRenderer();
	  activationColumn.setCellRenderer(activeServiceCellRenderer);


	  DefaultCellEditor activationCellEditor
		 = new DefaultCellEditor(new JCheckBox() );
	  activationColumn.setCellEditor(activationCellEditor);

	  activationColumn.setHeaderValue(activationColumnName);
	  activationColumn.setResizable(false);

	  //Local/Remote Column
	  TableColumn localRemoteColumn = new TableColumn();
	  localRemoteColumn.setModelIndex(OntologyServiceModel.LOCAL_OR_REMOTE_SERVICE);
	  String localRemoteColumnName 
		 = serviceModel.getColumnName(OntologyServiceModel.LOCAL_OR_REMOTE_SERVICE);
	  localRemoteColumn.setModelIndex(OntologyServiceModel.LOCAL_OR_REMOTE_SERVICE);
	  localRemoteColumn.setHeaderValue(localRemoteColumnName);

	  //Name Status
	  TableColumn statusColumn = new TableColumn();
	  statusColumn.setModelIndex(OntologyServiceModel.STATUS);
	  String statusColumnName 
		 = serviceModel.getColumnName(OntologyServiceModel.STATUS);
	  statusColumn.setHeaderValue(statusColumnName);
	  statusColumn.setModelIndex(OntologyServiceModel.STATUS);

	  //eliminate existing table columns for the model



	  setModel(serviceModel);

	  DefaultTableColumnModel columnModel = new DefaultTableColumnModel();
	  columnModel.addColumn(activationColumn);
	  columnModel.addColumn(priorityColumn);
	  columnModel.addColumn(serviceNameColumn);
	  columnModel.addColumn(localRemoteColumn);
	  columnModel.addColumn(statusColumn);
	  columnModel.addColumnModelListener(this);
	  
	  setColumnModel(columnModel);

	  ListSelectionModel selectionModel
		 = getSelectionModel();
	  selectionModel.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

	  getTableHeader().setReorderingAllowed(false); 

	  serviceModel.setTable(this);
	  addMouseListener(this);


   }

   // ==========================================
   // Section Accessors
   // ==========================================
   public void addListSelectionListener(ListSelectionListener listSelectionListener) {

	  ListSelectionModel selectionModel
		 = getSelectionModel();
	  selectionModel.addListSelectionListener(listSelectionListener);

   }

   public OntologyService getSelectedService() {
	  int selectedIndex = getSelectedRow();
	  if ( selectedIndex == -1) {
		 return null;
	  } //end if ()
	  else {
		 return serviceModel.getService(selectedIndex);
	  } //end else
	  
   }

   // ==========================================
   // Section Mutators
   // ==========================================
   public void setOntologyServices(ArrayList ontologyServices) {
	  serviceModel.setOntologyServices(ontologyServices);
	  if (ontologyServices.size() > 0) {
		 ListSelectionModel selectionModel
			= getSelectionModel();
		 selectionModel.clearSelection();
		 selectionModel.setSelectionInterval(0,0);
	  } //end if ()
	  
	  updateUI();
   }

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================
   //Interface: ActionListener
   public void actionPerformed(ActionEvent event) {
   }


   //Interface: MouseListener
   public void mouseClicked(MouseEvent event) {
	  
   }
 
   public void mouseEntered(MouseEvent event) {
	  
   }
 
   public void mouseExited(MouseEvent event) {

   }
 
   public void mousePressed(MouseEvent event) {
	  //user has begun to reprioritise rows; mousePressed
	  //will signal the row which will be moved

	  Point location = event.getPoint();
	  int column = columnAtPoint(location);

	  TableColumnModel columnModel
		 = getColumnModel();

	  TableColumn currentColumn 
		 = columnModel.getColumn(column);

	  if ( currentColumn == activationColumn) {
		 return;
	  } //end if ()
	  
	  targetRowStartPosition = rowAtPoint(location);
   }
 
   public void mouseReleased(MouseEvent event) {

	  //user is finishing the action of reprioritising; 
	  //mouseReleased will indicate the destination row
	  //and should cause row to be moved.
	  Point location = event.getPoint();

	  int column = columnAtPoint(location);

	  TableColumnModel columnModel
		 = getColumnModel();

	  TableColumn currentColumn 
		 = columnModel.getColumn(column);

	  if ( currentColumn == activationColumn) {
		 return;
	  } //end if ()

	  int targetRowEndPosition = rowAtPoint(location);
	  
	  serviceModel.adjustServicePriority(targetRowStartPosition,
										 targetRowEndPosition);
   }
 

   // ==========================================
   // Section Overload
   // ==========================================

}

/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
* @version 1.0
*
* this class describes a tree node that can contain an ontology term.
*
*/

package pedro.ontology;

import javax.swing.tree.DefaultMutableTreeNode;
import java.lang.Cloneable;

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class OntologyTermNode extends DefaultMutableTreeNode 
   implements Cloneable {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private OntologyTerm ontologyTerm;

   // ==========================================
   // Section Construction
   // ==========================================
   public OntologyTermNode(OntologyTerm ontologyTerm) {
	  this.ontologyTerm = ontologyTerm;
	  setUserObject(ontologyTerm.getTerm() );
   }


   // ==========================================
   // Section Accessors
   // ==========================================
   public OntologyTerm getOntologyTerm() {
	  return ontologyTerm;
   }

   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================
   public Object clone() {
	  OntologyTermNode cloneNode = new OntologyTermNode(ontologyTerm);
	  return cloneNode;
   }


   // ==========================================
   // Section Overload
   // ==========================================

}

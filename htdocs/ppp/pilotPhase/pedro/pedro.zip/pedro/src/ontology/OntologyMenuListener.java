/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/
package pedro.ontology;

import javax.swing.JMenuItem;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JMenu;
import javax.swing.JLabel;
/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class OntologyMenuListener implements ActionListener {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private JMenuItem selectTerms;
   private OntologySource ontologySource;
   private OntologyService ontologyService;
   private OntologyListener ontologyListener;
   private JMenu menu;

   // ==========================================
   // Section Construction
   // ==========================================
   public OntologyMenuListener(OntologyService ontologyService,
							   OntologyListener ontologyListener) {

	  this.ontologyService = ontologyService;
	  this.ontologyListener = ontologyListener;

	  selectTerms = new JMenuItem("Select terms...");
	  selectTerms.addActionListener(this);

   }

   public void populateMenu() {

	  OntologyServiceDescription serviceDescription
		 = ontologyService.getServiceDescription();

	  menu = new JMenu(serviceDescription.getName() );

	  
	  ontologySource = ontologyService.getSource();
	  if ( ontologySource == null) {
		 menu.add(new JLabel("No service available see information"));
		 return;
	  } //end if ()
	  if ( ontologySource.isWorking() == false) {
		 menu.add(new JLabel("service isn't working"));
		 return;
	  } //end if ()
	  
	  



	  OntologyTerm[] ontologyTerms = ontologySource.getTerms();
	  
	  if ( ontologyTerms == null) {
		 menu.add(new JLabel("No terms in ontology"));
		 return;
	  } //end if ()
	  

	  int numberOfTerms = ontologyTerms.length;

	  if ( numberOfTerms == 0) {
		 return;
	  } //end if ()
	  if ( ontologySource instanceof TreeOntologySource) {
		 menu.add(selectTerms);
	  } //end if ()
	  else if ( numberOfTerms < 20) {
		 for ( int i = 0; i < numberOfTerms; i++) {
			OntologyTermMenuItem item 
			   = new OntologyTermMenuItem(ontologyTerms[i]);
			item.addActionListener(this);
			menu.add(item);
		 } // end for ()
	  } //end if ()
	  else if ( numberOfTerms < 40) {

		 //divide the list into five sublists
		 
		 int ithSubMenu = 0;

		 while ( ithSubMenu < 5 ) {
			
			int startingIndex = ithSubMenu*5;
			int endingIndex = startingIndex+4;
			if ( endingIndex >= numberOfTerms) {
			   endingIndex = numberOfTerms - 1;
			} //end if ()

			String subMenuName = getSubMenuName(ontologyTerms[startingIndex],
												ontologyTerms[endingIndex]);
			
			JMenu subMenu = new JMenu(subMenuName);
			for ( int i = startingIndex; i <= endingIndex; i++ ) {
			   OntologyTermMenuItem item = new OntologyTermMenuItem(ontologyTerms[i]);
			   item.addActionListener(this);
			   subMenu.add(item);
			} // end for ()
			menu.add(subMenu);
			ithSubMenu++;
		 } //end while ()
		 
		 return;
	  } //end if ()
	  else {
		 menu.add(selectTerms);
	  } //end else
   }


   // ==========================================
   // Section Accessors
   // ==========================================
   public JMenu getMenu() {
	  populateMenu();
	  return menu;
   }

   /**
	* assumes:
	* 1)ontology provides list of unique words
	* 2)the list is alphabetically ordered in ascending order.
   */
   private String getSubMenuName(OntologyTerm startTerm,
								 OntologyTerm endTerm) {
	  return (startTerm.getTerm() + "-" + endTerm.getTerm() );
   }

   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================

   // ==========================================
   // Section Interfaces
   // ==========================================
   public void actionPerformed(ActionEvent event) {
	  JMenuItem menuItem = (JMenuItem) event.getSource();

	  if ( menuItem == selectTerms) {
		 OntologyServiceDescription serviceDescription
			= ontologyService.getServiceDescription();

		 StringBuffer dialogTitle = new StringBuffer();
		 dialogTitle.append("Ontology for \"");
		 dialogTitle.append(serviceDescription.getName() );
		 dialogTitle.append("\"");

		 if ( ontologySource instanceof TreeOntologySource) {
			TreeOntologySource treeOntologySource 
			   = (TreeOntologySource) ontologySource;

			if ( ontologySource instanceof OntologyProvenance) {
			   System.out.println("OntologyMenuListener - with provenance");
			   TreeProvenanceViewer ontologyViewer 
				  = new TreeProvenanceViewer();
			   
			   ontologyViewer.setSource(treeOntologySource);
			   ontologyViewer.setTitle(dialogTitle.toString());
			   ontologyViewer.show();
			   ontologyListener.termsSelected(ontologyViewer.getSelectedTerms() );
			} //end if ()
			else {
			   TreeOntologyViewer ontologyViewer 
				  = new TreeOntologyViewer();
			   
			   ontologyViewer.setSource(treeOntologySource);
			   ontologyViewer.setTitle(dialogTitle.toString());
			   ontologyViewer.show();
			   ontologyListener.termsSelected(ontologyViewer.getSelectedTerms() );
			} //end else
			
		 } //end if ()
		 else {
			//there are more than forty
			TermSelectorDialog termSelectorDialog
			   = new TermSelectorDialog(ontologySource.getTerms(),
										ontologySource.getName() );
			
			termSelectorDialog.setTitle(dialogTitle.toString());

			termSelectorDialog.show();
			OntologyTerm[] selectedOntologyTerms 
			   = termSelectorDialog.getSelectedTerms();
			ontologyListener.termsSelected(selectedOntologyTerms);
		 } //end else

	  } //end else ()
	  else {
		 OntologyTermMenuItem ontologyTermMenuItem
			= (OntologyTermMenuItem) menuItem;
		 OntologyTerm[] ontologyTerms = new OntologyTerm[1];
		 ontologyTerms[0] 
			= ontologyTermMenuItem.getOntologyTerm();

		 ontologyListener.termsSelected(ontologyTerms);
	  } //end else
   }


   // ==========================================
   // Section Overload
   // ==========================================

}

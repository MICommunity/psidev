/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
* @version 1.0
*
*/

package pedro.ontology;

import java.io.Serializable;

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class OntologyServiceDescription implements Serializable {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private String name;
   private String description;
   private boolean isLocalService;
   private Class ontologyParserClass;
   private Class ontologyViewerClass;
   private String parserInputFile;

   // ==========================================
   // Section Construction
   // ==========================================
   public OntologyServiceDescription() {
	  name = "";
	  description = "";
	  isLocalService = false;
	  ontologyParserClass = null;
	  ontologyViewerClass = null;
	  parserInputFile = "";
   }

   
   /**
	* Set the value of name.
	* @param name Value to assign to name.
	*/
   public void setName(String _name) {
	  this.name = _name;
   }
   
   
   /**
	* Set the value of description.
	* @param description Value to assign to description.
	*/
   public void setDescription(String _description) {
	  this.description = _description;
   }
   
   /**
	* Set the value of isLocalService.
	* @param isLocalService Value to assign to isLocalService.
	*/
   public void setLocalService(boolean _isLocalService) {
	  this.isLocalService = _isLocalService;
   }
   
   /**
	* Set the value of ontologyParserClass.
	* @param ontologyParserClass Value to assign to ontologyParserClass.
	*/
   public void setOntologyParserClass(Class _ontologyParserClass) {
	  this.ontologyParserClass = _ontologyParserClass;
   }
   
   /**
	* Set the value of ontologyViewerClass.
	* @param ontologyViewerClass Value to assign to ontologyViewerClass.
	*/
   public void setOntologyViewerClass(Class _ontologyViewerClass) {
	  this.ontologyViewerClass = _ontologyViewerClass;
   }
   
   /**
	* Set the value of parserInputFile.
	* @param parserInputFile Value to assign to parserInputFile.
	*/
   public void setParserInputFile(String parserInputFile) {
	  
	  this.parserInputFile = parserInputFile;
   }
   
   // ==========================================
   // Section Accessors
   // ==========================================
   /**
	* Get the value of name.
	* @return value of name.
	*/
   public String getName() {
	  return name;
   }

   /**
	* Get the value of description.
	* @return value of description.
	*/
   public String getDescription() {
	  return description;
   }

   /**
	* Get the value of isLocalService.
	* @return value of isLocalService.
	*/
   public boolean isLocalService() {
	  return isLocalService;
   }

   /**
	* Get the value of ontologyParserClass.
	* @return value of ontologyParserClass.
	*/
   public Class getOntologyParserClass() {
	  return ontologyParserClass;
   }

   /**
	* Get the value of ontologyViewerClass.
	* @return value of ontologyViewerClass.
	*/
   public Class getOntologyViewerClass() {
	  return ontologyViewerClass;
   }
   
   /**
	* Get the value of parserInputFile.
	* @return value of parserInputFile.
	*/
   public String getParserInputFile() {
	  return parserInputFile;
   }
   

   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================

}

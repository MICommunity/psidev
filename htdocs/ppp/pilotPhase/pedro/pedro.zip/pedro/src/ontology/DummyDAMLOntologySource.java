/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.ontology;

import java.io.IOException;
import java.io.File;

import javax.swing.JTree;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;
import org.w3c.dom.Node;
import org.w3c.dom.CDATASection;
import org.w3c.dom.Element;
import org.w3c.dom.Document;
import org.w3c.dom.Text;



import pedro.util.ErrorDialog;
import pedro.validation.StringMaskValidator;
import pedro.system.GlobalConstants;
/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class DummyDAMLOntologySource extends AbstractTreeOntologySource 
   implements OntologyProvenance {


    
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private ArrayList damlClassNodes;

   // ==========================================
   // Section Construction
   // ==========================================
   public DummyDAMLOntologySource() {
	  damlClassNodes = new ArrayList();
   }

   public void load() {

	  try {

		 /*
		 File modelDirectory = GlobalConstants.getModelDirectory();
		 StringBuffer fileNameBuffer = new StringBuffer();
		 fileNameBuffer.append(modelDirectory.getAbsolutePath());
		 fileNameBuffer.append("//resources//");
		 fileNameBuffer.append(fileName.trim() );

		 file = new File(fileNameBuffer.toString());
		 if ( file.exists() == false) {
			status = new StringBuffer();
		    status.append("ERROR: Can't find a file called ");
			status.append(file.getAbsolutePath() );
			isSourceWorking = false;
			return;
		 } //end if ()



		 isSourceWorking = true;
		 */

		 setName("Ontology for MGED" );

		 File file = new File("C://pedro//MGEDOntology.daml");

		 parseDocument(file);

		 /*
		 System.out.println("DummyDAML load 1");

		 OntologyTerm thing = new OntologyTerm("thing");
		 thing.setDefinition("A thing is something grand");
		 OntologyTermNode thingNode 
			= new OntologyTermNode(thing);

		 OntologyTerm plant = new OntologyTerm("plant");
		 plant.setDefinition("Plant is defined as...");

		 OntologyTermNode plantNode 
			= new OntologyTermNode(plant);


		 OntologyTerm mineral = new OntologyTerm("Mineral");
		 mineral.setDefinition("Mineral is defined as ...");

		 OntologyTermNode mineralNode 
			= new OntologyTermNode(mineral);


		 OntologyTerm vegetable = new OntologyTerm("Vegetable");
		 vegetable.setDefinition("Vegetable is defined as ...");

		 OntologyTermNode vegetableNode 
			= new OntologyTermNode(vegetable);


		 OntologyTerm carrot = new OntologyTerm("Carrot");
		 carrot.setDefinition("A carrot is defined as a long orange thing.");

		 OntologyTermNode carrotNode 
			= new OntologyTermNode(carrot);

		 OntologyTerm potato = new OntologyTerm("potato");
		 potato.setDefinition("A Potato is defined as ...");

		 OntologyTermNode potatoNode 
			= new OntologyTermNode(potato);

		 OntologyTerm animal = new OntologyTerm("Animal");
		 animal.setDefinition("An animal is defined as ...");

		 OntologyTermNode animalNode 
			= new OntologyTermNode(animal);

		 OntologyTerm dog = new OntologyTerm("Dog");
		 dog.setDefinition("A dog is defined as ...");

		 OntologyTermNode dogNode 
			= new OntologyTermNode(dog);

		 System.out.println("DummyDAML load 2");


		 thingNode.add(animalNode);
		 thingNode.add(plantNode);
		 thingNode.add(mineralNode);
		 animalNode.add(dogNode);
		 plantNode.add(vegetableNode);		 
		 vegetableNode.add(potatoNode);
		 vegetableNode.add(carrotNode);
		 rootNode = thingNode;

*/

		 /*
		 isSourceWorking = true;
		 status = new StringBuffer();
		 status.append("File ");
		 status.append(file.getAbsolutePath() );
		 status.append("is accessible and the contents can ");
		 status.append("be interpretted correctly.");
		 */

	  } catch (Exception err) {
		 System.out.println(err);
		 status = new StringBuffer("ERROR: " + err.toString() );
		 isSourceWorking = false;
	  } // end try-catch


   }

   public void parseDocument(File file) 
   throws ParserConfigurationException, 
		  SAXException,
		  IOException {

	  DocumentBuilderFactory documentBuilderFactory
		 = DocumentBuilderFactory.newInstance();
	  DocumentBuilder documentBuilder
		 = documentBuilderFactory.newDocumentBuilder();

	  Document document = documentBuilder.parse(file);

	  Node currentChild = document.getFirstChild();

	  //rdf is the overall tag that you have to enter
	  currentChild = currentChild.getFirstChild();

	  while ( currentChild != null) {

		 if ( currentChild.getNodeType() == Node.ELEMENT_NODE) {
			Element currentElement = (Element) currentChild;
			OntologyTermNode ontologyTermNode
			   = getDAMLClassNode(currentElement);
			if ( ontologyTermNode != null) {
			   damlClassNodes.add(ontologyTermNode);
			} //end if ()
			
		 } //end if ()
		 currentChild = currentChild.getNextSibling();

	  } //end while ()

	  rootNode = new OntologyTermNode(new DAMLClass("Ontology") );

	  //now resolve super class items
	  int numberOfClasses = damlClassNodes.size();
	  for ( int i = 0; i < numberOfClasses; i++) {
		 OntologyTermNode currentNode = (OntologyTermNode) damlClassNodes.get(i);
		 addClassToHierarchy(currentNode);
	  } // end for ()

   }

   private void addClassToHierarchy(OntologyTermNode node) {
	  
	  DAMLClass damlClass = (DAMLClass) node.getOntologyTerm();
	  String superClass = damlClass.getSuperClass();
	  if ( superClass == null) {
		 rootNode.add(node);
		 return;
	  } //end if ()

	  int numberOfClasses = damlClassNodes.size();
	  for ( int i = 0; i < numberOfClasses; i++) {
		 OntologyTermNode currentNode = (OntologyTermNode) damlClassNodes.get(i);
		 DAMLClass currentClass = (DAMLClass) currentNode.getOntologyTerm();
		 String term = currentClass.getTerm();
		 if ( term.equals(superClass) == true) {
			currentNode.add(node);
			return;
		 } //end if ()
	  } // end for ()

   }

   private String parseTerm(Element termElement) {

	  Node fieldChild  = termElement.getFirstChild();
	  
	  if ( fieldChild == null) {
		 return null;
	  } //end if ()

	  if ( fieldChild.getNodeType() == Node.TEXT_NODE) {
		 Text text = (Text) fieldChild;
		 String data = text.getData();
		 data = data.trim();
		 return data;
	  }

	  return null;

   }

   private String parseSuperClass(Element superClassElement) {
	  Node currentChild  = superClassElement.getFirstChild();
	  
	  Element referenceElement = null;
	  while ( currentChild != null) {
		 if ( currentChild.getNodeType() == Node.ELEMENT_NODE) {
			referenceElement = (Element) currentChild;
			break;
		 } //end if ()
		 currentChild = currentChild.getNextSibling();
	  } //end while ()


	  if ( referenceElement == null) {
		 return null;
	  } //end if ()

	  String superClass = referenceElement.getAttribute("rdf:about");
	  int hashIndex = superClass.lastIndexOf("#");
	  if ( hashIndex != -1) {
		 superClass = superClass.substring(hashIndex+1);
		 return superClass;
	  } //end if ()

	  return null;

   }

   private String parseDefinition(Element definitionElement) {

	  Node fieldChild  = definitionElement.getFirstChild();
	  
	  if ( fieldChild == null) {
		 return null;
	  } //end if ()
	  
	  if ( fieldChild.getNodeType() == Node.CDATA_SECTION_NODE) {
		 CDATASection cdata = (CDATASection) fieldChild;
		 String data = cdata.getData();
		 data = data.trim();
		 return data;
	  }

	  return null;
   }

   private OntologyTermNode getDAMLClassNode(Element damlClassElement) {
	  
	  String damlClassTagName = damlClassElement.getTagName();
	  damlClassTagName = damlClassTagName.toUpperCase();
	  
	  if ( damlClassTagName.startsWith("DAML:CLASS") == false) {
		 return null;
	  } //end if ()


	  DAMLClass damlClass = new DAMLClass();

	  boolean superClassDefined = false;

	  Node currentChild = damlClassElement.getFirstChild();
	  while ( currentChild != null) {

		 if ( currentChild.getNodeType() == Node.ELEMENT_NODE) {
			Element currentElement = (Element) currentChild;
			String tagName = currentElement.getTagName();
			
			if ( tagName.equals("rdfs:label") == true) {
			   String term = parseTerm(currentElement);
			   damlClass.setTerm(term);
			} //end if ()
			else if (tagName.equals("rdfs:comment") == true) {
			   String definition = parseDefinition(currentElement);
			   damlClass.setDefinition(definition);
			} //end else ()
			else if (tagName.equals("rdfs:subClassOf") == true) {
			   String superClass
				  = parseSuperClass(currentElement);
			   if ( superClass != null) {
				  if ( superClassDefined == false) {
					 superClassDefined = true;
					 damlClass.setSuperClass(superClass);
				  } //end if ()
			   } //end if ()
			} //end else ()
		 } //end if ()

		 currentChild = currentChild.getNextSibling();
	  } //end while ()

	  OntologyTermNode node = new OntologyTermNode(damlClass);
	  return node;

   } //end if ()

   // ==========================================
   // Section Accessors
   // ==========================================


   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================



   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================
   public void setFileName(String _fileName) {
	  this.fileName = _fileName;
	  load();
   }

}


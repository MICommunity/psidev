/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.text.SimpleDateFormat;
import java.awt.Toolkit;

import java.util.ArrayList;

import pedro.util.HelpEnabledMenuItem;
import pedro.util.HelpEnabledCheckBoxMenuItem;
import pedro.util.HelpDialog;
import pedro.util.ContextHelpItem;
import pedro.view.RecordView;
import pedro.view.NavigationTree;
import pedro.validation.DateValidator;
import pedro.model.RecordModel;

import pedro.view.DataFieldView;
import pedro.view.DateFieldView;
import pedro.view.TextFieldView;
import pedro.view.ListFieldView;
import pedro.view.URLFieldView;

import pedro.model.ListFieldModel;

import pedro.util.ErrorDialog;
import pedro.view.NavigationTreeNode;
import pedro.dataImport.ImportRecordSelectorDialog;
import pedro.system.PedroException;
import pedro.ontology.TouchTypeOntologyDialog;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class OptionsMenuActionListener extends MenuActionListener {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private HelpEnabledCheckBoxMenuItem enableTouchTypeOntology;
   private HelpEnabledMenuItem dateValidation;
   private DateValidationDialog dateValidationDialog;

   // ==========================================
   // Section Construction
   // ==========================================
   public OptionsMenuActionListener(PedroDialog parentDialog,
								 NavigationTree navigationTree,
								 RecordView recordView) {
	  super(parentDialog,
			navigationTree,
			recordView);

	  dateValidationDialog = new DateValidationDialog();

	  menu.setText("Options");

	  dateValidation = new HelpEnabledMenuItem("Date validation...");
	  dateValidation.addActionListener(this);
	  dateValidation.setHelpLink( createHelpLink("DateValidation.html") );

	  enableTouchTypeOntology 
		 = new HelpEnabledCheckBoxMenuItem("Enable touch type ontology");
	  enableTouchTypeOntology.addActionListener(this);
	  enableTouchTypeOntology.setHelpLink( createHelpLink("TouchTypeOntology.html") );

	  menu.add(dateValidation);
	  menu.add(enableTouchTypeOntology);

   }

   // ==========================================
   // Section Accessors
   // ==========================================


   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================


   //Interface: ActionListener
   public void actionPerformed(ActionEvent event) {

	  ContextHelpItem menuItem = (ContextHelpItem) event.getSource();

	  if ( menuItem.isContextHelpEnabled() == true) {
		 HelpDialog helpDialog = HelpDialog.getHelpDialog();
		 helpDialog.setHelpLink(menuItem.getHelpLink() );
		 helpDialog.show();
		 return;
	  } //end if ()

	  if ( menuItem == dateValidation) {
		 dateValidation();
	  }
	  else if ( menuItem == enableTouchTypeOntology) {
		 enableTouchTypeOntology();
	  } //end else ()

   }

   // ==========================================
   // Section Overload
   // ==========================================


   // ==========================================
   // Section Private Methods
   // ==========================================
   private void dateValidation() {
	  SimpleDateFormat oldFormat = DateValidator.getDateFormat();
	  dateValidationDialog.show();
	  SimpleDateFormat newFormat = DateValidator.getDateFormat();
	  if ( oldFormat != newFormat) {
		 navigationTree.updateDateFields();
	  } //end if ()
   }

   private void enableTouchTypeOntology() {
		 boolean enableTouchTyping
			= enableTouchTypeOntology.getState();

		 recordView.enableTouchTypeOntology(enableTouchTyping);

		 TouchTypeOntologyDialog touchTypeOntologyDialog
			= TouchTypeOntologyDialog.getTouchTypeOntologyDialog();

		 /*
		 if (( enableTouchTyping == false) &&
			 (touchTypeOntologyDialog.isShowing() == true) ) {

			touchTypeOntologyDialog.hide();
		 } //end if ()
		 else if ( (enableTouchTyping == true) &&
				   (touchTypeOntologyDialog.isShowing() == false)) {
			touchTypeOntologyDialog.show();
		 } //end else ()
		 */
   }

   public void enableContextHelp(boolean enableContextHelp) {
	  dateValidation.enableContextHelp(enableContextHelp);
	  enableTouchTypeOntology.enableContextHelp(enableContextHelp);
   }

}

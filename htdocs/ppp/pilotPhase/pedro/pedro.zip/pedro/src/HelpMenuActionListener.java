/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro;

import javax.swing.JMenuItem;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JCheckBoxMenuItem;
import java.awt.Component;
import java.io.File;
import java.net.URL;

import pedro.view.NavigationTree;
import pedro.view.RecordView;
import pedro.model.RecordModel;

import pedro.util.ErrorDialog;
import pedro.util.HelpDialog;
import pedro.util.SchemaInformationDialog;
/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class HelpMenuActionListener extends MenuActionListener
   implements ActionListener {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private JCheckBoxMenuItem enableContextHelp;
   private JMenuItem about;
   private JMenuItem showSchemaInformation;
   private JMenuItem mainHelp;
   private SchemaInformationDialog schemaInformationDialog;

   // ==========================================
   // Section Construction
   // ==========================================
   public HelpMenuActionListener(PedroDialog parentDialog,
								 NavigationTree navigationTree,
								 RecordView recordView) {

	  super(parentDialog,
			navigationTree,
			recordView);
	  
	  menu.setText("Help");

	  about = new JMenuItem("About...");
	  about.addActionListener(this);

	  showSchemaInformation = new JMenuItem("Schema Information...");
	  showSchemaInformation.addActionListener(this);

	  mainHelp = new JMenuItem("Help...");
	  mainHelp.addActionListener(this);

	  enableContextHelp = new JCheckBoxMenuItem("Enable context help");
	  enableContextHelp.addActionListener(parentDialog);

	  menu.add(about);
	  menu.add(showSchemaInformation);
	  menu.add(mainHelp);
	  menu.add(enableContextHelp);

	  schemaInformationDialog = null;

   }

   // ==========================================
   // Section Accessors
   // ==========================================


   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================
   public void actionPerformed(ActionEvent event) {

	  Object menuItem = event.getSource();
		 try {
	  
			if ( menuItem == about) {
			   
			   File file = new File("help//About.html");
			   URL url = file.toURL();
			   
			   HelpDialog helpDialog = HelpDialog.getHelpDialog();
			   helpDialog.setHelpLink(new URL(url.toString() ) );
			   helpDialog.setTitle("About...");
			   helpDialog.show();
			} //end if ()
			else if ( menuItem == showSchemaInformation) {
			   if ( schemaInformationDialog == null) {
				  schemaInformationDialog = new SchemaInformationDialog();
			   } //end if ()
			   schemaInformationDialog.show();
			}
			else if ( menuItem == mainHelp) {
			   File file = new File("help//Help.html");
			   URL url = file.toURL();

			   HelpDialog helpDialog = HelpDialog.getHelpDialog();
			   helpDialog.setHelpLink(new URL(url.toString() ) );

			   helpDialog.setTitle("Help...");
			   helpDialog.show();
			} //end else ()

		 } catch (Exception err) {
			ErrorDialog.show(err.toString() );
		 } // end try-catch

   }


   // ==========================================
   // Section Overload
   // ==========================================

}

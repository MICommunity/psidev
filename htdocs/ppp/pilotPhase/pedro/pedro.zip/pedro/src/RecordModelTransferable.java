/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro;

import java.awt.datatransfer.DataFlavor; 
import java.awt.datatransfer.UnsupportedFlavorException; 
import java.awt.datatransfer.Transferable; 
import java.io.IOException;

import pedro.model.RecordModel;


/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class RecordModelTransferable implements Transferable {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   static public DataFlavor RecordModelFlavour;

   static { 
	  RecordModelFlavour = new DataFlavor(RecordModel.class,
										  "Record Model");
   }
   
   private DataFlavor[] flavours = {RecordModelFlavour};
   private RecordModel model;

   // ==========================================
   // Section Properties
   // ==========================================

   // ==========================================
   // Section Construction
   // ==========================================
   public RecordModelTransferable(RecordModel model) {
	  this.model = model;
   }

   // ==========================================
   // Section Accessors
   // ==========================================


   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================

   // ==========================================
   // Section Interfaces
   // ==========================================
   public synchronized Object getTransferData(DataFlavor flavour) 
	  throws UnsupportedFlavorException, IOException {

	  if ( flavour.equals(RecordModelFlavour) == true) {
		 return model;
	  } //end if ()
	  else {
		 throw new UnsupportedFlavorException(flavour);
	  } //end else
   }

   public synchronized DataFlavor[] getTransferDataFlavors() {
	  return flavours;
   } 

   public boolean isDataFlavorSupported(DataFlavor flavour) {
	  return flavour.equals(RecordModelFlavour);
   }
  




   // ==========================================
   // Section Overload
   // ==========================================

}

/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.text.SimpleDateFormat;
import java.awt.Toolkit;

import java.awt.datatransfer.StringSelection; 
import java.awt.datatransfer.DataFlavor; 
import java.awt.datatransfer.Clipboard; 
import java.awt.datatransfer.ClipboardOwner; 
import java.awt.datatransfer.Transferable; 
import java.util.ArrayList;


import pedro.util.HelpEnabledMenuItem;
import pedro.util.HelpDialog;
import pedro.view.RecordView;
import pedro.view.NavigationTree;
import pedro.validation.DateValidator;
import pedro.model.RecordModel;

import pedro.view.DataFieldView;
import pedro.view.DateFieldView;
import pedro.view.TextFieldView;
import pedro.view.ListFieldView;
import pedro.view.URLFieldView;

import pedro.model.ListFieldModel;

import pedro.util.ErrorDialog;
import pedro.view.NavigationTreeNode;
import pedro.dataImport.ImportRecordSelectorDialog;
import pedro.system.PedroException;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class EditMenuActionListener extends MenuActionListener 
   implements ClipboardOwner {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private HelpEnabledMenuItem copy;
   private HelpEnabledMenuItem paste;

   // ==========================================
   // Section Construction
   // ==========================================
   public EditMenuActionListener(PedroDialog parentDialog,
								 NavigationTree navigationTree,
								 RecordView recordView) {
	  super(parentDialog,
			navigationTree,
			recordView);

	  menu.setText("Edit");

	  copy = new HelpEnabledMenuItem("Copy");
	  copy.addActionListener(this);
	  copy.setHelpLink( createHelpLink("Copy.html") );

	  paste = new HelpEnabledMenuItem("Paste");
	  paste.addActionListener(this);
	  paste.setHelpLink( createHelpLink("Paste.html") );

	  menu.add(copy);
	  menu.add(paste);

   }

   // ==========================================
   // Section Accessors
   // ==========================================


   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================
   //Interface: ClipboardOwner
   public void lostOwnership(Clipboard clipboard,
							 Transferable contents) {

   }


   //Interface: ActionListener
   public void actionPerformed(ActionEvent event) {

	  HelpEnabledMenuItem menuItem = (HelpEnabledMenuItem) event.getSource();

	  if ( menuItem.isContextHelpEnabled() == true) {
		 HelpDialog helpDialog = HelpDialog.getHelpDialog();
		 helpDialog.setHelpLink(menuItem.getHelpLink() );
		 helpDialog.show();
		 return;
	  } //end if ()


	  if ( menuItem == copy) {
		 copy();
	  } //end else ()
	  else if ( menuItem == paste) {
		 paste();
	  } //end else ()

   }

   // ==========================================
   // Section Overload
   // ==========================================


   // ==========================================
   // Section Private Methods
   // ==========================================
   private void copy() {
	  String selectedText = recordView.getSelectedText();

	  if (selectedText == null ) {
		 //try seeing if something selected in the tree
		
		 //validate the current record

		 String errors = recordView.validateEditFields(true);

		 if ( errors.equals("") == false) {
			ErrorDialog.show(errors);
			return;
		 } //end if ()
		 else {
			if (recordView.isDirty() == true) {
			   //prompt user to save changes
			   try {
				  recordView.keepValues();
			   } catch (PedroException err) {
				  ErrorDialog.show(err.toString() );
			   } // end try-catch
			   
			} //end else
		 }

		 RecordModel selectedModel = recordView.getRecordModel();
		 RecordModel cloneOfSelectedModel = (RecordModel) selectedModel.clone();
		 
		 RecordModelTransferable recordModelSelection
			   = new RecordModelTransferable(cloneOfSelectedModel);

		 Toolkit toolKit = Toolkit.getDefaultToolkit();
		 Clipboard clipBoard = toolKit.getSystemClipboard();
		 clipBoard.setContents(recordModelSelection,
							   this);
		 

	  } //end if ()
	  else {
		 System.out.println("EMAL==selecting records");
		 //we're copying text, not trees
		 StringSelection stringSelection = new StringSelection(selectedText);
		 Toolkit toolKit = Toolkit.getDefaultToolkit();
		 Clipboard clipBoard = toolKit.getSystemClipboard();
		 clipBoard.setContents(stringSelection,
							   this);
	  } //end else

   }

   private String getClipboardString() throws Exception {

	  Toolkit toolKit = Toolkit.getDefaultToolkit();
	  Clipboard clipBoard = toolKit.getSystemClipboard();
	  
	  Transferable contents = clipBoard.getContents(this);

	  if ( contents != null && 
		   contents.isDataFlavorSupported(DataFlavor.stringFlavor) ) {
		 
		 String selectedText
			= (String) contents.getTransferData(DataFlavor.stringFlavor);

		 return selectedText;
	  } //end if ()
	  else {
		 return "";
	  } //end else
   }

   private RecordModel getClipboardModel() throws Exception {

	  Toolkit toolKit = Toolkit.getDefaultToolkit();
	  Clipboard clipBoard = toolKit.getSystemClipboard();
	  
	  Transferable contents = clipBoard.getContents(this);

	  DataFlavor RecordModelFlavour 
		 = RecordModelTransferable.RecordModelFlavour;

	  if ( contents != null && 
		   contents.isDataFlavorSupported(RecordModelFlavour) ) {
		 
		 RecordModel selectedModel = 
			(RecordModel) contents.getTransferData(RecordModelFlavour);
		 return selectedModel;
	  } //end if ()
	  else {
		 return null;
	  } //end else

   }

   private void pasteRecordModel(RecordModel targetRecordModel,
								 RecordModel pasteRecordModel) {
	  

	  String targetRecordModelClass = targetRecordModel.getRecordClassName();
	  
	  String pasteRecordModelClass = pasteRecordModel.getRecordClassName();
	  if ( targetRecordModelClass.equals(pasteRecordModelClass) == false) {
		 
		 StringBuffer errorMessage = new StringBuffer();
		 errorMessage.append("You're trying to paste a record");
		 errorMessage.append("of typerecord type \"");
		 errorMessage.append(pasteRecordModelClass);
		 errorMessage.append("\" into a record that is of type \"");
		 errorMessage.append(targetRecordModelClass);
		 errorMessage.append("\"");
		 
		 ErrorDialog.show(errorMessage.toString() );
		 
		 return;
	  } //end if ()
	  
	  navigationTree.pasteNode(targetRecordModel,
							   pasteRecordModel);
	  
	  navigationTree.updateUI();
	  
   }

   private void paste() {

	  RecordModel recordModel = recordView.getRecordModel();
	  DataFieldView dataFieldView = recordView.getFieldWithFocus();
	  if ( dataFieldView == null) {

		 try {
			RecordModel modelToPaste
			   = getClipboardModel();
			
			if ( modelToPaste == null) {
			   ErrorDialog.show("There is nothing to paste here");
			   return;
			} //end if ()
			else {
			   RecordModel selectedRecordModel = recordView.getRecordModel();
			   pasteRecordModel(selectedRecordModel,
								modelToPaste);
			   
			} //end else
			
		 } catch (Exception err) {
			System.out.println(err);
		 } // end try-catch

	  } //end if ()
	  else {

		 try {
			
			if ( dataFieldView instanceof DateFieldView) {
			   String selectedText = getClipboardString();

				  DateFieldView dateFieldView 
					 = (DateFieldView) dataFieldView;
				  dateFieldView.setValue(selectedText);
				  
			} //end if ()
			else if ( dataFieldView instanceof TextFieldView) {
			   String selectedText = getClipboardString();
			   
			   TextFieldView textFieldView
				  = (TextFieldView) dataFieldView;
			   textFieldView.setValue(selectedText);
			} //end else ()
			else if ( dataFieldView instanceof URLFieldView) {
			   String selectedText = getClipboardString();
			   
			   URLFieldView urlFieldView
				  = (URLFieldView) dataFieldView;
			   urlFieldView.setValue(selectedText);
			} //end else ()
			else {
			   StringBuffer errorMessage = new StringBuffer();
			   errorMessage.append("You can't paste text into ");
			   errorMessage.append("this kind of field.");
			   ErrorDialog.show(errorMessage.toString() );
			   return;
			} //end else
			
		 } catch (Exception err) {
			ErrorDialog.show(err.toString() );
		 } // end try-catch
		 
	  } //end if ()
   }

   public void enableContextHelp(boolean enableContextHelp) {
	  copy.enableContextHelp(enableContextHelp);
	  paste.enableContextHelp(enableContextHelp);
   }


}

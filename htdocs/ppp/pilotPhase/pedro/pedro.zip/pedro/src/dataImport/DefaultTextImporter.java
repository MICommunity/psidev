/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
* @version 1.0
*
*/

package pedro.dataImport;

import javax.swing.JFileChooser;
import pedro.model.RecordModel;
import pedro.util.TextFileFilter;
import java.io.File;
import java.util.ArrayList;
import pedro.util.ErrorDialog;


/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class DefaultTextImporter implements RecordImporter {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private JFileChooser importFileChooser;
   private String importRecordType;
   private File importFile;

   // ==========================================
   // Section Construction
   // ==========================================
   public DefaultTextImporter() {
	  importFileChooser = new JFileChooser();
	  importFileChooser.setFileFilter(new TextFileFilter() );
   }

   // ==========================================
   // Section Accessors
   // ==========================================


   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================
   public void setDirectory(File directory) {
	  importFileChooser.setCurrentDirectory(directory);
   }

   public String getName() {
	  return "Default Text Import...";
   }

   public boolean selectFile() {

	  int result = importFileChooser.showOpenDialog(null);
	  if ( result == JFileChooser.CANCEL_OPTION) {
		 return false;
	  } //end if ()
	  
	  importFile = importFileChooser.getSelectedFile();
	  if ( importFile == null) {
		 return false;
	  } //end if ()
	  
	  return true;
   }

   public void setImportRecordType(String importRecordType) {
	 
	  this.importRecordType = importRecordType;
   }

   public ArrayList importRecords() {
	  ArrayList importedRecords = new ArrayList();

	  HeaderRemovalDialog headerRemovalDialog 
		 = new HeaderRemovalDialog();
	  headerRemovalDialog.readFile(importFile);
	  headerRemovalDialog.show();
	  
	  if ( headerRemovalDialog.isCancelled() == true) {
		 return null;
	  } //end if ()
	  
	  FlatFileReader reader = new FlatFileReader();
	  reader.setFirstDataRow(headerRemovalDialog.getFirstDataRowIndex() );
	  reader.setFile(importFileChooser.getSelectedFile());
	  
	  ImportDataToFieldDialog importDialog 
		 = new ImportDataToFieldDialog();
	  
	  if ( importRecordType == null) {
		 return null;
	  } //end if ()

	  importDialog.setRecordModelClassTag(importRecordType);

	  try {
		 importDialog.setData(reader.getData() );
		 importDialog.show();
	  } catch (Exception err) {
		 ErrorDialog.show(err.getMessage() );
	  }

	  importedRecords = importDialog.getImportedRecordModels();

	  return importedRecords;
   }

   // ==========================================
   // Section Overload
   // ==========================================

}

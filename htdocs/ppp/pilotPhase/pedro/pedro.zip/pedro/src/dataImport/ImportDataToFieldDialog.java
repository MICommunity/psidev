/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/
package pedro.dataImport;

import javax.swing.JDialog;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.BorderLayout;
import javax.swing.JFileChooser;

import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.table.DefaultTableModel;

import javax.swing.JScrollPane;
import java.awt.Dimension;
import java.util.ArrayList;

import java.util.Vector;

import javax.swing.JComboBox;

import pedro.model.RecordModelFactory;
import pedro.model.RecordModel;
import pedro.view.NavigationTree;

import pedro.util.ErrorDialog;
import pedro.system.PedroException;


import java.awt.Color;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class ImportDataToFieldDialog extends JDialog 
   implements ActionListener {

   
   // ==========================================
   // Section Constants
   // ==========================================

   // ==========================================
   // Section Properties
   // ==========================================
   private String recordClassTag;
   private JButton cancel;
   private JButton ok;
   private JTable table;
   private ImportTableHeaderClicker tableHeaderClicker;
   private String[] fieldNames;
   private ArrayList importResults;
   private NavigationTree navigationTree;
   private RecordModelFactory recordFactory;
   private TableColumnModel columnModel;
   private ImportTableModel model;

   private String[] usedFields;
   private int[] modelColumns;
   private RecordModel templateRecordModel;

   private boolean isCancelled;

   // ==========================================
   // Section Construction
   // ==========================================
   public ImportDataToFieldDialog() {
	  
	  setTitle("Matching Columns to Record Fields");
	  importResults = new ArrayList();
	  table = createTable();
	  JTableHeader tableHeader = table.getTableHeader();
	  tableHeaderClicker = new ImportTableHeaderClicker(tableHeader);
	  tableHeader.addMouseListener(tableHeaderClicker);
	  JScrollPane tablePane = new JScrollPane(table);

	  GridBagConstraints mainPanelGC = new GridBagConstraints();
	  mainPanelGC.anchor = GridBagConstraints.NORTHWEST;
	  mainPanelGC.gridx = 0;
	  mainPanelGC.gridy = 0;
	  mainPanelGC.fill = GridBagConstraints.NONE;
	  mainPanelGC.weightx = 0;
	  mainPanelGC.weighty = 0;

	  JPanel mainPanel = new JPanel(new GridBagLayout() );
	  JPanel instructionPanel = createInstructionPanel();
	  //instructionPanel.setBackground( getBackground() );
	  mainPanel.add(instructionPanel, mainPanelGC);


	  mainPanelGC.fill = GridBagConstraints.BOTH;
	  mainPanelGC.gridy = 1;
	  mainPanelGC.weightx = 100;
	  mainPanelGC.weighty = 100;

	  mainPanel.add(tablePane, mainPanelGC);
	  
	  JPanel buttonPanel = createButtonPanel();
	  mainPanelGC.anchor = GridBagConstraints.SOUTHEAST;
	  mainPanelGC.gridy = 2;
	  mainPanelGC.fill = GridBagConstraints.NONE;
	  mainPanelGC.weightx = 0;
	  mainPanelGC.weighty = 0;
	  
	  mainPanel.add(buttonPanel, mainPanelGC);


	  getContentPane().add(mainPanel);

	  recordFactory = RecordModelFactory.getRecordModelFactory();
	  columnModel = table.getColumnModel();

	  
	  pack();
	  setModal(true);

   }

   public void setData(String[][] data) {

	  if ( data == null) {
		 return;
	  } //end if ()
	  if ( data.length == 0) {
		 return;
	  } //end if ()

	  //clear existing data
	  isCancelled = false;


	  int numberOfRows = data.length;

	  int numberOfColumns = data[0].length;
	  String[] columnNames = new String[numberOfColumns];
	  for ( int i = 0; i < numberOfColumns; i++) {
		 columnNames[i] = "Column " + i;
	  } // end for ()

	  //model = (ImportTableModel) table.getModel();
	  //model.setDataVector((Object[][]) data,(Object[])columnNames);
	  model = new ImportTableModel();
	  model.setData(data, columnNames);

	  table.setModel(model);
   }


   private JTable createTable() {
	  //model = new ImportTableModel();
	  table = new JTable();
	  //table.setModel(importTableModel);
	  return table;
   }

   private JPanel createInstructionPanel() {
	  JPanel instructionPanel = new JPanel(new GridBagLayout() );
	  GridBagConstraints instructionPanelGC = new GridBagConstraints();
	  instructionPanelGC.fill = GridBagConstraints.NONE;
	  instructionPanelGC.anchor = GridBagConstraints.NORTHWEST;
	  instructionPanelGC.gridx = 0;
	  instructionPanelGC.gridy = 0;
	  
	  instructionPanelGC.weightx = 0;
	  instructionPanelGC.weighty = 0;

	  JLabel instructionTitle = new JLabel("Instructions");
	  instructionTitle.setBackground(instructionPanel.getBackground() );
	  instructionPanel.add(instructionTitle, instructionPanelGC);

	  JTextArea textArea = new JTextArea();
	  textArea.append("1. For each field you wish to import, right click");
	  textArea.append("  the column header and select a destination field name");
	  textArea.append("\n");
	  textArea.append("2.Press the \"Import\" button"); 
	  textArea.setEditable(false);
	  textArea.setWrapStyleWord(true);
	  textArea.setBackground(instructionPanel.getBackground() );

	  instructionPanelGC.gridy = 2;
	  instructionPanel.add(textArea, instructionPanelGC);

	  return instructionPanel;

   }

   private JPanel createButtonPanel() {

	  JPanel buttonPanel = new JPanel(new GridBagLayout() );
	  GridBagConstraints buttonPanelGC = new GridBagConstraints();
	  buttonPanelGC.fill = GridBagConstraints.NONE;
	  buttonPanelGC.anchor = GridBagConstraints.SOUTHEAST;
	  buttonPanelGC.gridx = 0;
	  buttonPanelGC.gridy = 0;
	  
	  buttonPanelGC.weightx = 0;
	  buttonPanelGC.weighty = 0;

	  ok = new JButton("Import");
	  ok.addActionListener(this);
	  buttonPanel.add(ok, buttonPanelGC);

	  buttonPanelGC.gridx = 1;
	  cancel = new JButton("Cancel");
	  cancel.addActionListener(this);
	  buttonPanel.add(cancel, buttonPanelGC);

	  return buttonPanel;
   }


   // ==========================================
   // Section Accessors
   // ==========================================
   public String[] getUnusedFields() {
	  JTableHeader tableHeader = table.getTableHeader();
	  

	  TableColumnModel columnModel = tableHeader.getColumnModel();
	  int numberOfColumns = columnModel.getColumnCount();
	  String[] usedFields = new String[numberOfColumns];

	  for ( int i = 0; i < numberOfColumns; i++) {
		 TableColumn currentColumn = columnModel.getColumn(i);
		 usedFields[i] = (String) currentColumn.getHeaderValue();
	  } // end for ()

	  //for each field name, determine whether it appears in any
	  //of the column names
	  ArrayList unusedFields = new ArrayList();
	  for ( int i = 0; i < fieldNames.length; i++) {
		 boolean currentFieldNameUsed = false;
		 for ( int j = 0; j < usedFields.length; j++) {
			if (fieldNames[i].equals(usedFields[j]) == true ) {
			   currentFieldNameUsed = true;
			   break;
			} //end if ()
		 } // end for ()
		 if ( currentFieldNameUsed == false) {
			unusedFields.add(fieldNames[i]);
		 } //end if ()
	  } // end for ()
	  
	  //convert to a nice list to allow easier use
	  String[] results = (String[]) unusedFields.toArray(new String[0]);
	  return results;
   }

   private String[] getUsedFields() {
	  JTableHeader tableHeader = table.getTableHeader();

	  TableColumnModel columnModel = tableHeader.getColumnModel();
	  int numberOfColumns = columnModel.getColumnCount();
	  ArrayList usedFields = new ArrayList();

	  for ( int i = 0; i < numberOfColumns; i++) {
		 TableColumn currentColumn = columnModel.getColumn(i);
		 String currentColumnHeaderValue = (String) currentColumn.getHeaderValue();

		 for ( int j = 0; j < fieldNames.length; j++) {
			if (fieldNames[j].equals(currentColumnHeaderValue) == true ) {
			   usedFields.add(currentColumnHeaderValue);
			   break;
			} //end if ()
		 } // end for ()

	  } // end for ()
	  
	  String[] results = (String[]) usedFields.toArray(new String[0]);
	  return results;
   }

   public boolean isCancelled() {
	  return isCancelled;
   }

   // ==========================================
   // Section Mutators
   // ==========================================
   public void setRecordModelClassTag(String recordClassTag) {
	  this.recordClassTag = recordClassTag;

	  RecordModelFactory recordFactory = RecordModelFactory.getRecordModelFactory();
	  RecordModel record = recordFactory.createRecordModel(recordClassTag);
	  String[] fieldNames = record.getEditFieldNames();

	  try {
		 

	  
		 boolean[] isFieldRequired = new boolean[fieldNames.length];
		 for ( int i = 0; i < isFieldRequired.length; i++) {
			isFieldRequired[i] = record.isRequiredField(fieldNames[i]);
		 } // end for ()

		 setFieldNames(fieldNames,isFieldRequired);

		 
	  } catch (Exception err) {
		 ErrorDialog.show(err.toString() );
		 dispose();
		 		 
	  } // end try-catch





   }

   private void setFieldNames(String[] fieldNames, boolean[] isFieldRequired) {
	  this.fieldNames = fieldNames;
	  tableHeaderClicker.setFieldNames(fieldNames, isFieldRequired);
   }

   public ArrayList getImportedRecordModels() {
	  return importResults;
   }

   private void importData() {
	  //get a prototype of the destination record
	  RecordModelFactory recordFactory = RecordModelFactory.getRecordModelFactory();
	  //RecordModel record = recordFactory.createRecordModel(recordClassTag);
	  templateRecordModel = recordFactory.createRecordModel(recordClassTag);

	  try {
		 importResults.clear();
	  
		 String[] unusedFields = getUnusedFields();
		 for ( int i = 0; i < unusedFields.length; i++) {
			if ( templateRecordModel.isRequiredField(unusedFields[i])==true) {
			   StringBuffer errorMessage = new StringBuffer();
			   errorMessage.append("No column has been selected for ");
			   errorMessage.append("the required field ");
			   errorMessage.append(unusedFields[i]);
			   ErrorDialog.show(errorMessage.toString() );
			   return;
			} //end if ()
		 } // end for ()


		 usedFields = getUsedFields();
		 
		 int[] columnIndices = new int[usedFields.length];
		 TableColumnModel columnModel = table.getColumnModel();
		 for ( int i = 0; i < usedFields.length; i++) {
			int columnIndex = columnModel.getColumnIndex(usedFields[i]);
			columnIndices[i] = table.convertColumnIndexToModel(columnIndex);
		 } // end for ()

		 int numberOfRows = table.getRowCount();
		 StringBuffer errorMessages = new StringBuffer();
		 int errorCount = 0;

		 values = new ArrayList();


			try {
			   for ( int i = 0; i < numberOfRows; i++) {
				  RecordModel currentRecordModel 
					 = populateRecordModel(i,columnIndices);
				  importResults.add(currentRecordModel);
			   } // end for ()

			} catch (PedroException err) {
			   errorMessages.append(err.getMessage() );
			   errorCount++;
			   System.out.println(err);
			} // end try-catch

		 if (errorCount > 0) {
			ErrorDialog.show(errorMessages.toString() );
		 } //end if ()
		 else {
			dispose();
		 } //end else
		 


	  } catch (Exception err) {
		 ErrorDialog.show(err.toString() );
	  } // end try-catch

   }

   /*
   private void prepareColumnIndices() {
	  modelColumns = new int[usedFields.length];
	  
	  for ( int i = 0; i < usedFields.length; i++) {
		 int columnIndex = columnModel.getColumnIndex(usedFields[i]);
		 int modelColumn = table.convertColumnIndexToModel(columnIndex);
		 modelColumns[i] = modelColumn;
	  } // end for ()
   }
   */

   private ArrayList values;

   private void reportAverage() {
	  Long[] vals = (Long[]) values.toArray(new Long[0]);

	  long sum = 0;
	  for ( int i = 0; i < vals.length; i++) {
		 sum = vals[i].longValue() + sum;
	  } // end for ()
	 
	  double average = sum/(vals.length);
	  values.clear();

   }

   private RecordModel populateRecordModel(int tableRow,
										   int[] columnIndices) throws PedroException {

	  long start = System.currentTimeMillis();
	  RecordModel recordModel = (RecordModel) templateRecordModel.clone();
	  long end = System.currentTimeMillis();
	  long duration = end - start;

	  values.add(new Long(duration) );

	  //	  if ( values.size() > 200) {
	  // reportAverage();
	  //} //end if ()
	  

	  //RecordModel record = recordFactory.createRecordModel(recordClassTag);

	  for ( int i = 0; i < usedFields.length; i++) {
		 //int columnIndex = columnModel.getColumnIndex(usedFields[i]);
		 //int modelColumn = table.convertColumnIndexToModel(columnIndex);
		 //String value = (String) table.getValueAt(tableRow, columnIndices[i]);
		 String value = model.directlyGetValue(tableRow,columnIndices[i]);
		 recordModel.setValue(usedFields[i],value,true);
	  } // end for ()

	  String errors = recordModel.validateEditFields();

	  if ( errors != null) {
		 StringBuffer errorMessage = new StringBuffer();
		 errorMessage.append("\n");
		 errorMessage.append("Row ");
		 errorMessage.append(tableRow);
		 errorMessage.append(":");
		 errorMessage.append(errors);
		 throw new PedroException(errorMessage.toString() );
	  } //end if ()

	  recordModel.updateDisplayName();
	  return recordModel;
   }


   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================
   //Interface: ActionListener
   public void actionPerformed(ActionEvent event) {
	  Object button = event.getSource();
	  if (button == ok) {
		 importData();
	  } //end if ()
	  else {
		 isCancelled = true;
		 dispose();
	  } //end else
	  

		 
   }


   // ==========================================
   // Section Overload
   // ==========================================

}

/*
class ImportTableModel extends DefaultTableModel {

   public boolean isCellEditable(int row, 
								 int column) {
	  return false;
   }
}
*/





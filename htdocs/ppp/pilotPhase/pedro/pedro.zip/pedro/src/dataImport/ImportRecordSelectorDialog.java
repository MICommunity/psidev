/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.dataImport;

import javax.swing.JDialog;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JList;
import javax.swing.JScrollPane;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.ListSelectionModel;

import javax.swing.event.ListSelectionListener;
import javax.swing.event.ListSelectionEvent;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import java.util.Vector;
import java.util.Hashtable;

import java.util.ArrayList;
import java.util.Collections;

import pedro.model.RecordModel;
import pedro.model.ListFieldModel;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class ImportRecordSelectorDialog extends JDialog 
   implements ListSelectionListener, ActionListener {
   
   // ==========================================
   // Section Constants
   // ==========================================
   private static String prototypeCellValue = "0123456789101112131415";
   public static void main (String[] args) {
	   ImportRecordSelectorDialog dialog
		  = new ImportRecordSelectorDialog();

	   String[] canColours = new String[2];
	   canColours[0] = "Red";
	   canColours[1] = "White";
	   
	   String[] itColours = new String[3];
	   itColours[0] = "Red";
	   itColours[1] = "Green";
	   itColours[2] = "White";

	   String[] deColours = new String[3];
	   deColours[0] = "Black";
	   deColours[1] = "Yellow";
	   deColours[2] = "Red";

	   dialog.addListFieldName("canadian", canColours);
	   dialog.addListFieldName("italy",itColours);
	   dialog.addListFieldName("germany", deColours);

	   dialog.show();

   } // end main ()
   
 

   // ==========================================
   // Section Properties
   // ==========================================
   private JList listFields;
   private JList childRecordList;
   private Vector listFieldsModel;
   private Vector childRecordModel;

   private JButton ok;
   private Hashtable childrenTypesForLists;

   // ==========================================
   // Section Construction
   // ==========================================
   public ImportRecordSelectorDialog() {
	  setTitle("Select Import Destination Field");

	  listFieldsModel = new Vector();
	  childRecordModel = new Vector();
	  childrenTypesForLists = new Hashtable();

	  JPanel panel = new JPanel(new GridBagLayout() );
	  GridBagConstraints panelGC = new GridBagConstraints();
	  panelGC.gridx = 0;
	  panelGC.gridy = 0;
	  panelGC.weightx = 0;
	  panelGC.weighty = 0;
	  panelGC.fill = GridBagConstraints.HORIZONTAL;
	  panelGC.anchor = GridBagConstraints.NORTHWEST;

	  JPanel instructionPanel = createInstructionPanel();
	  //instructionPanel.setBackground(getBackground() );
	  panel.add(instructionPanel, panelGC);

	  JPanel listPanel = createListPanel();
	  panelGC.weightx = 100;
	  panelGC.weighty = 100;
	  panelGC.gridy = 1;
	  panelGC.fill = GridBagConstraints.BOTH;
	  panel.add(listPanel, panelGC);

	  JPanel buttonPanel = createButtonPanel();
	  panelGC.gridy = 2;
	  panelGC.fill = GridBagConstraints.NONE;
	  panelGC.weightx = 0;
	  panelGC.weighty = 0;
	  panelGC.anchor = GridBagConstraints.SOUTHEAST;
	  panel.add(buttonPanel, panelGC);

	  getContentPane().add(panel);
	  pack();
	  setModal(true);
   }

   private JPanel createListPanel() {
	  JPanel panel = new JPanel(new GridBagLayout() );
	  GridBagConstraints panelGC = new GridBagConstraints();
	  panelGC.gridx = 0;
	  panelGC.gridy = 0;
	  panelGC.weightx = 50;
	  panelGC.weighty = 100;
	  panelGC.fill = GridBagConstraints.BOTH;
	  panelGC.anchor = GridBagConstraints.NORTHWEST;

	  JPanel listFieldPanel = createListFieldPanel();
	  panel.add(listFieldPanel, panelGC);

	  JPanel childRecordPanel = createChildRecordPanel();
	  panelGC.gridx = 1;
	  panel.add(childRecordPanel, panelGC);

	  return panel;

   }

   private JPanel createInstructionPanel() {
	  JPanel panel = new JPanel(new GridBagLayout() );


	  GridBagConstraints panelGC = new GridBagConstraints();
	  panelGC.gridx = 0;
	  panelGC.gridy = 0;
	  panelGC.weightx = 0;
	  panelGC.weighty = 0;
	  panelGC.fill = GridBagConstraints.NONE;
	  panelGC.anchor = GridBagConstraints.NORTHWEST;

	  JLabel instructionTitle = new JLabel("Instructions:");

	  panel.setBackground(instructionTitle.getBackground() );

	  panel.add(instructionTitle, panelGC);

	  JTextArea instructionText = new JTextArea();
	  instructionText.append("1. Choose the destination selection field in the left list.\n");
	  instructionText.append("2. Choose the child record type for the selection field.\n");
	  instructionText.append("3. Press \"Import\" ");
	  instructionText.setEditable(false);
	  instructionText.setWrapStyleWord(true);
	  instructionText.setBackground(instructionTitle.getBackground() );
	  panelGC.gridy = 1;
	  panel.add(instructionText, panelGC);

	  return panel;
   }


   private JPanel createListFieldPanel() {
	  JPanel panel = new JPanel(new GridBagLayout() );
	  GridBagConstraints panelGC = new GridBagConstraints();
	  panelGC.gridx = 0;
	  panelGC.gridy = 0;
	  panelGC.weightx = 0;
	  panelGC.weighty = 0;
	  panelGC.fill = GridBagConstraints.NONE;
	  panelGC.anchor = GridBagConstraints.NORTHWEST;

	  JLabel listFieldTitle = new JLabel("List Fields");
	  panel.add(listFieldTitle, panelGC);

	  listFields = new JList(listFieldsModel);
	  listFields.setPrototypeCellValue(prototypeCellValue);
 
	  ListSelectionModel selectionModel 
		 = listFields.getSelectionModel();
	  selectionModel.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	  listFields.addListSelectionListener(this);
	  JScrollPane listFieldsPane = new JScrollPane(listFields);

	  panelGC.fill = GridBagConstraints.BOTH;
	  panelGC.gridy = 1;
	  panel.add(listFieldsPane, panelGC);

	  return panel;
   }

   private JPanel createChildRecordPanel() {
	  JPanel panel = new JPanel(new GridBagLayout() );
	  GridBagConstraints panelGC = new GridBagConstraints();
	  panelGC.gridx = 0;
	  panelGC.gridy = 0;
	  panelGC.weightx = 0;
	  panelGC.weighty = 0;
	  panelGC.fill = GridBagConstraints.NONE;
	  panelGC.anchor = GridBagConstraints.NORTHWEST;

	  JLabel childRecordTitle = new JLabel("Child Record Types");
	  panel.add(childRecordTitle, panelGC);

	  childRecordList = new JList(childRecordModel);
	  childRecordList.setPrototypeCellValue(prototypeCellValue);

	  ListSelectionModel selectionModel 
		 = childRecordList.getSelectionModel();
	  selectionModel.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	  JScrollPane childRecordPane = new JScrollPane(childRecordList);

	  panelGC.fill = GridBagConstraints.BOTH;
	  panelGC.gridy = 1;
	  panel.add(childRecordPane, panelGC);

	  return panel;
   }

   private JPanel createButtonPanel() {

	  JPanel panel = new JPanel(new GridBagLayout() );
	  GridBagConstraints panelGC = new GridBagConstraints();
	  panelGC.gridx = 0;
	  panelGC.gridy = 0;
	  panelGC.weightx = 0;
	  panelGC.weighty = 0;
	  panelGC.fill = GridBagConstraints.NONE;
	  panelGC.anchor = GridBagConstraints.SOUTHEAST;

	  ok = new JButton("OK");
	  ok.addActionListener(this);
	  panel.add(ok, panelGC);
	  
	  return panel;
   }

   // ==========================================
   // Section Accessors
   // ==========================================
   public String getSelectedFieldName() {
	  return( (String) listFields.getSelectedValue());
   }

   public String getSelectedChildRecordType() {
	  return( (String) childRecordList.getSelectedValue());
   }

   // ==========================================
   // Section Mutators
   // ==========================================
   private void addListFieldName(String listFieldName,
								 String[] childRecordTypes) {
	  
	  childrenTypesForLists.put(listFieldName,
								childRecordTypes);
	  listFieldsModel.add(listFieldName);
	  listFields.updateUI();
   }
   
   public void setRecordModel(RecordModel recordModel) {
	  ArrayList listFields = recordModel.getListFields();
	  int numberOfListFields = listFields.size();
	  String[] listFieldNames = new String[numberOfListFields];
	  for ( int i = 0; i < numberOfListFields; i++) {
		 ListFieldModel currentListFieldModel = (ListFieldModel) listFields.get(i);
		 String currentFieldName = currentListFieldModel.getName();
		 String[] childTypes = currentListFieldModel.getChildTypes();
		 addListFieldName(currentFieldName,
						  childTypes);
	  } // end for ()
   }

   public void chooseImportField() {
	  show();
   }

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================


   

   // ==========================================
   // Section Interfaces
   // ==========================================
   //Interface ListSelectionListener
   public void valueChanged(ListSelectionEvent listEvent) {
	  //we know it's the listFields list because it is the only
	  //one we bother to put a list selection listener on
	  if ( listEvent.getValueIsAdjusting() == false) {
		 String selectedValue = (String) listFields.getSelectedValue();
		 childRecordModel.clear();

		 String[] childRecordTypes 
			= (String[]) childrenTypesForLists.get(selectedValue); 

		 if ( childRecordTypes != null) {
			for ( int i = 0; i < childRecordTypes.length; i++) {
			   childRecordModel.add(childRecordTypes[i]);
			} // end for ()
			Collections.sort(childRecordModel);
		 } //end if ()
		 childRecordList.updateUI();
	  } //end if ()
   }

   public void actionPerformed(ActionEvent event) {
	  dispose();

   }

   // ==========================================
   // Section Overload
   // ==========================================

}

/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/
package pedro.dataImport;

import javax.swing.JDialog;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.BorderLayout;
import javax.swing.JFileChooser;

import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.table.DefaultTableModel;

import javax.swing.JScrollPane;
import java.util.ArrayList;
import java.util.StringTokenizer;

import javax.swing.JComboBox;

import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;


import pedro.util.ErrorDialog;
import pedro.system.PedroException;


import java.awt.Color;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class HeaderRemovalDialog extends JDialog 
   implements ActionListener {

   
   // ==========================================
   // Section Constants
   // ==========================================

   // ==========================================
   // Section Properties
   // ==========================================
   private JButton cancel;
   private JButton ok;
   private JTable table;
   private String[] fieldNames;
   private ArrayList importResults;
   private ImportTableModel model;
   private int firstDataRowIndex;

   private boolean isCancelled;

   // ==========================================
   // Section Construction
   // ==========================================
   public HeaderRemovalDialog() {
	  
	  setTitle("Stripping Header Lines");
	  importResults = new ArrayList();
	  table = createTable();
	  JScrollPane tablePane = new JScrollPane(table);

	  GridBagConstraints mainPanelGC = new GridBagConstraints();
	  mainPanelGC.anchor = GridBagConstraints.NORTHWEST;
	  mainPanelGC.gridx = 0;
	  mainPanelGC.gridy = 0;
	  mainPanelGC.fill = GridBagConstraints.NONE;
	  mainPanelGC.weightx = 0;
	  mainPanelGC.weighty = 0;

	  JPanel mainPanel = new JPanel(new GridBagLayout() );
	  JPanel instructionPanel = createInstructionPanel();
	  mainPanel.add(instructionPanel, mainPanelGC);

	  mainPanelGC.fill = GridBagConstraints.BOTH;
	  mainPanelGC.gridy = 1;
	  mainPanelGC.weightx = 100;
	  mainPanelGC.weighty = 100;

	  mainPanel.add(tablePane, mainPanelGC);
	  
	  JPanel buttonPanel = createButtonPanel();
	  mainPanelGC.anchor = GridBagConstraints.SOUTHEAST;
	  mainPanelGC.gridy = 2;
	  mainPanelGC.fill = GridBagConstraints.NONE;
	  mainPanelGC.weightx = 0;
	  mainPanelGC.weighty = 0;
	  
	  mainPanel.add(buttonPanel, mainPanelGC);

	  getContentPane().add(mainPanel);

	  pack();
	  setModal(true);

   }

   public void readFile(File file) {
	  try {

		 FileReader fileReader = new FileReader(file);
		 BufferedReader bufferedReader = new BufferedReader(fileReader);

		 ArrayList fileHeaderLines = new ArrayList();
		 String currentLine = bufferedReader.readLine();

		 //stop reading lines from the file when four consecutive lines
		 //have the same number of tokens per line.
		 int[] tokensPerLine = new int[4];
		 int currentIndex = 0; 

		 int oldTokensPerLine = 0;
		 int currentTokensPerLine = 0;
		 int consecutiveRowsWithSameColumns = 0;

		 while (currentLine != null ) {
			currentLine = currentLine.trim();

			currentTokensPerLine = getTokensPerLine(currentLine);
			if (currentTokensPerLine == oldTokensPerLine) {
			   consecutiveRowsWithSameColumns++;
			} //end if ()
			else {
			   consecutiveRowsWithSameColumns = 0;
			} //end else

			currentLine = currentLine.replace('\t',' ');
			fileHeaderLines.add(currentLine);

			if ( consecutiveRowsWithSameColumns > 5) {
			   break;
			} //end if ()

			currentLine = bufferedReader.readLine();

			currentIndex++;
			if ( currentIndex == 4) {
			   currentIndex = 0;
			} //end if ()

		 } //end while ()

		 int numberOfLines = fileHeaderLines.size();

		 String[][] data = new String[fileHeaderLines.size()][2];
		 for ( int i = 0; i < numberOfLines; i++) {
			data[i][0] = String.valueOf(i+1);
			data[i][1] = (String) fileHeaderLines.get(i);
		 } // end for ()

		 setData(data);

	  } catch (Exception err) {
		 ErrorDialog.show(err.toString() );
	  } // end try-catch

   }

   private boolean tokensPerLineAreConsistent(int[] tokensPerLine) {
	  int sum = 0;
	  for ( int i = 0; i < tokensPerLine.length; i++) {
		 sum += tokensPerLine[i];
	  } // end for ()
	  
	  int average = sum/tokensPerLine.length;

	  if ( average == tokensPerLine[0]) {
		 return true;
	  } //end if ()
	  else {
		 return false;
	  } //end else
   }

   private int getTokensPerLine(String line) {
	  if ( line == null) {
		 return 0;
	  } //end if ()
	  
	  StringTokenizer tokenizer =
		 new StringTokenizer(line, "\t");
	  return tokenizer.countTokens();
   }


   private void setData(String[][] data) {
	  if ( data == null) {
		 return;
	  } //end if ()
	  if ( data.length == 0) {
		 return;
	  } //end if ()

	  //clear existing data
	  isCancelled = false;


	  int numberOfRows = data.length;

	  int numberOfColumns = data[0].length;
	  String[] columnNames = new String[numberOfColumns];
	  columnNames[0] = "Row";
	  columnNames[1] = "Text";

	  model = new ImportTableModel();
	  model.setData(data, columnNames);

	  table.setModel(model);
   }


   private JTable createTable() {
	  table = new JTable();
	  return table;
   }

   private JPanel createInstructionPanel() {
	  JPanel instructionPanel = new JPanel(new GridBagLayout() );
	  GridBagConstraints instructionPanelGC = new GridBagConstraints();
	  instructionPanelGC.fill = GridBagConstraints.NONE;
	  instructionPanelGC.anchor = GridBagConstraints.NORTHWEST;
	  instructionPanelGC.gridx = 0;
	  instructionPanelGC.gridy = 0;
	  
	  instructionPanelGC.weightx = 0;
	  instructionPanelGC.weighty = 0;

	  JLabel instructionTitle = new JLabel("Instructions");
	  instructionTitle.setBackground(instructionPanel.getBackground() );
	  instructionPanel.add(instructionTitle, instructionPanelGC);

	  JTextArea textArea = new JTextArea();
	  textArea.append("Select the row in the table that is the first ");
	  textArea.append("row of data.");
	  textArea.setEditable(false);
	  textArea.setWrapStyleWord(true);
	  textArea.setBackground(instructionPanel.getBackground() );

	  instructionPanelGC.gridy = 2;
	  instructionPanel.add(textArea, instructionPanelGC);

	  return instructionPanel;

   }

   private JPanel createButtonPanel() {

	  JPanel buttonPanel = new JPanel(new GridBagLayout() );
	  GridBagConstraints buttonPanelGC = new GridBagConstraints();
	  buttonPanelGC.fill = GridBagConstraints.NONE;
	  buttonPanelGC.anchor = GridBagConstraints.SOUTHEAST;
	  buttonPanelGC.gridx = 0;
	  buttonPanelGC.gridy = 0;
	  
	  buttonPanelGC.weightx = 0;
	  buttonPanelGC.weighty = 0;

	  ok = new JButton("OK");
	  ok.addActionListener(this);
	  buttonPanel.add(ok, buttonPanelGC);

	  buttonPanelGC.gridx = 1;
	  cancel = new JButton("Cancel");
	  cancel.addActionListener(this);
	  buttonPanel.add(cancel, buttonPanelGC);

	  return buttonPanel;
   }


   // ==========================================
   // Section Accessors
   // ==========================================
   public int getFirstDataRowIndex() {
	  return firstDataRowIndex;
   }

   public boolean isCancelled() {
	  return isCancelled;
   }
   // ==========================================
   // Section Mutators
   // ==========================================

   private void setFirstRowOfData() {
	  firstDataRowIndex = table.getSelectedRow();
   }


   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================
   //Interface: ActionListener
   public void actionPerformed(ActionEvent event) {
	  Object button = event.getSource();
	  if (button == ok) {
		 setFirstRowOfData();
	  } //end if ()
	  else {
		 isCancelled = true;
	  } //end else
	  dispose();

   }


   // ==========================================
   // Section Overload
   // ==========================================

}

/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/
package pedro.dataImport;

import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.JPopupMenu;
import java.awt.event.MouseAdapter;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.table.JTableHeader;
import java.awt.event.MouseEvent;
import java.awt.event.InputEvent;
import javax.swing.JMenuItem;

import java.awt.Font;


import pedro.util.ErrorDialog;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class ImportTableHeaderClicker extends MouseAdapter
   implements ActionListener {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================

   // ==========================================
   // Section Construction
   // ==========================================
   private JTableHeader tableHeader;
   private JPopupMenu popupMenu;
   private TableColumn affectedColumn;
   
   public ImportTableHeaderClicker(JTableHeader tableHeader) {
	  this.tableHeader = tableHeader;
	  affectedColumn = null;
   }



   // ==========================================
   // Section Accessors
   // ==========================================


   // ==========================================
   // Section Mutators
   // ==========================================
   public void setFieldNames(String[] fieldNames, boolean[] isRequiredField) {
	  popupMenu = new JPopupMenu();
	  
	  Font plainFont = tableHeader.getFont();
	  Font boldFont = plainFont.deriveFont(Font.BOLD);

	  for ( int i = 0; i < fieldNames.length; i++) {
		 JMenuItem candidateFieldName = new JMenuItem(fieldNames[i]);

		 if ( isRequiredField[i] == true) {
			candidateFieldName.setFont(boldFont);
		 } //end if ()
		 else {
			candidateFieldName.setFont(plainFont);
		 } //end else

		 candidateFieldName.addActionListener(this);
		 popupMenu.add(candidateFieldName); 
	  } // end for ()
   }


   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================


   // ==========================================
   // Section Interfaces
   // ==========================================
   //Interface ActionListener
   public void actionPerformed(ActionEvent event) {
	  JMenuItem selectedFieldName = (JMenuItem) event.getSource();
	  String selectedName = selectedFieldName.getText();

	  TableColumnModel columnModel = tableHeader.getColumnModel();
	  int numberOfColumns = columnModel.getColumnCount();
	  for ( int i = 0; i < numberOfColumns; i++) {
		 TableColumn currentColumn = columnModel.getColumn(i);
		 String currentColumnName = (String) currentColumn.getHeaderValue();
		 if ( currentColumnName.equals(selectedName) == true) {
			StringBuffer errorMessage = new StringBuffer();
			errorMessage.append("Cannot assign multiple columns to the");
			errorMessage.append(" same import destination field.  There is ");
			errorMessage.append("already a column assigned to ");
			errorMessage.append("\"");
			errorMessage.append(currentColumnName);
			errorMessage.append("\"");
			ErrorDialog.show(errorMessage.toString() );

			return;
		 } //end if ()
	  } // end for ()
	  
	  

	  affectedColumn.setHeaderValue(selectedFieldName.getText() );
	  tableHeader.repaint();
   }


   // ==========================================
   // Section Overload
   // ==========================================
   public void mouseClicked(MouseEvent event) {

	  int modifiers = event.getModifiers();
	  int rightClickMenuPressed = modifiers&InputEvent.BUTTON1_MASK & modifiers;
	  if (rightClickMenuPressed == 0) {
		 
		 int affectedColumnIndex = tableHeader.columnAtPoint(event.getPoint() );
		 TableColumnModel tableColumnModel = tableHeader.getColumnModel();
		 affectedColumn = tableColumnModel.getColumn(affectedColumnIndex);
		 popupMenu.show(tableHeader, event.getX(), event.getY() );
	  } //end if ()
   }



}

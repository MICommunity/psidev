/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
* @version 1.0
*
*/

package pedro.dataImport;

import pedro.util.HelpEnabledMenuItem;

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class RecordImportMenuItem extends HelpEnabledMenuItem {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private RecordImporter recordImporter;

   // ==========================================
   // Section Construction
   // ==========================================
   public RecordImportMenuItem(String name,
							   RecordImporter recordImporter) {
	  super(name);
	  this.recordImporter = recordImporter;
   }

   // ==========================================
   // Section Accessors
   // ==========================================
   public RecordImporter getRecordImporter() {
	  return recordImporter;
   }

   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================

}

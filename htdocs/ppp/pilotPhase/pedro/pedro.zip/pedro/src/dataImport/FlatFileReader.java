/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/
package pedro.dataImport;

import java.io.FileInputStream;
import java.io.File;
import java.io.FileReader;
import java.io.LineNumberReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

import pedro.system.PedroException;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class FlatFileReader {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private File inputFile;
   private ArrayList rows;

   private int firstDataRow;

   // ==========================================
   // Section Construction
   // ==========================================
   public FlatFileReader() {
	  firstDataRow = 0;
   }

   public static void main (String[] args) {
	  try {
		 FlatFileReader f = new FlatFileReader();
		 f.setFile(new File("C://out//stuff.txt"));
		 String[][] data = f.getData();
		 
		 int numRows = data.length;
 
		 for ( int i = 0; i < numRows; i++) {
			String[] currentRow = data[i];
			StringBuffer buffer = new StringBuffer();
			int numberOfColumns = currentRow.length;
			for (int j = 0; j < numberOfColumns; j++ ) {
			   buffer.append(currentRow[j]);
			   buffer.append("==");
			} // end for ()
		 } // end for ()

	  } catch (Exception err) {
		 System.out.println(err);
	  } // end try-catch

   } // end main ()
   

   // ==========================================
   // Section Accessors
   // ==========================================
   public String[][] getData() throws Exception {

	  LineNumberReader reader 
		 = new LineNumberReader(new FileReader(inputFile) );
	  
	  boolean firstLineRead = false;
	  ArrayList rows = new ArrayList();
	  
	  String currentLine = reader.readLine();
	  int expectedNumberOfTokensPerLine = 0;

	  int ithRow = 0;

	  System.out.println("FFR - first data row =="+firstDataRow);

	  while ( currentLine != null) {
		 String[] currentRow = parseRow(currentLine);

		 if ( ithRow >= firstDataRow) {
		 
			if ( firstLineRead == false) {
			   firstLineRead = true;
			   expectedNumberOfTokensPerLine = currentRow.length;
			} //end if ()
			else {
			   if ( currentRow.length != expectedNumberOfTokensPerLine) {
				  StringBuffer errorMessage = new StringBuffer();
				  errorMessage.append("Line ");
				  errorMessage.append(reader.getLineNumber() );
				  errorMessage.append(" should have ");
				  errorMessage.append(expectedNumberOfTokensPerLine);
				  errorMessage.append(" fields but has ");
				  errorMessage.append(currentRow.length);
				  errorMessage.append(" fields");
				  throw new PedroException(errorMessage.toString() );
			   } //end if ()
			   
			} //end else
			rows.add(currentRow);

		 } //end if ()

		 ithRow++;
		 currentLine = reader.readLine();
	  } //end while ()
	  
	  String[][] data = (String[][]) rows.toArray(new String[0][0]);
	  return data;
   }

   private String[] parseRow(String line) {

	  StringTokenizer tokenizer = new StringTokenizer(line,"\t");
	  int numberOfTokens = tokenizer.countTokens();
	  String[] tokens = new String[numberOfTokens];

	  for ( int i = 0; i < numberOfTokens; i++) {
		 tokens[i] = tokenizer.nextToken();
	  } // end for ()
	  
	  return tokens;
   }



   // ==========================================
   // Section Mutators
   // ==========================================
   public void setFile(File inputFile) {
	  this.inputFile = inputFile;
   }

   public void setFirstDataRow(int _firstRowData) {
	  firstDataRow = _firstRowData;
   }

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================

}

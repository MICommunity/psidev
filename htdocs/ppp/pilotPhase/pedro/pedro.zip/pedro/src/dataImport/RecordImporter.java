/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.dataImport;

import java.io.File;
import java.util.ArrayList;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

public interface RecordImporter {
   public String getName();
   public void setImportRecordType(String importRecordType);
   public ArrayList importRecords();
   public boolean selectFile();
   public void setDirectory(File directory);
}

/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/
package pedro.dataImport;

import javax.swing.table.AbstractTableModel;


/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class ImportTableModel extends AbstractTableModel {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private String[][] data;
   private String[] fieldNames;
   private int numberOfRows;
   private int numberOfColumns;

   // ==========================================
   // Section Construction
   // ==========================================
   public ImportTableModel() {
	  numberOfRows = 0;
	  numberOfColumns = 0;
   }

   // ==========================================
   // Section Accessors
   // ==========================================


   // ==========================================
   // Section Mutators
   // ==========================================
   public void setData(String[][] data, String[] fieldNames) {
	  this.data = data;
	  if ( data[0] != null) {
		 numberOfRows = data.length;
		 
		 if ( data[0][0] != null) {
			numberOfColumns = data[0].length;
		 } //end if ()
		 
	  } //end if ()
	  
	  this.fieldNames = fieldNames;
   }

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================
   public boolean isCellEditable(int row, 
								 int column) {
	  return false;
   }



   // ==========================================
   // Section Overload
   // ==========================================
   public String getColumnName(int column) {
	  return fieldNames[column];
   }

   public int getRowCount() {
	  return numberOfRows;
   }

   public int getColumnCount() {
	  return numberOfColumns;
   }

   public Object getValueAt(int row, 
							int column) {
	  
	  return data[row][column];
   }

   public String directlyGetValue(int row,
								  int column) {
	  return data[row][column];
   }

}

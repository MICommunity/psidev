/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
* @version 1.0
*
*/

package pedro;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class TestFrame extends JFrame implements KeyListener {

   
   // ==========================================
   // Section Constants
   // ==========================================
 
   public static void main (String[] args) {
	  TestFrame frame = new TestFrame();
	  frame.show();
   } // end main ()
   

   // ==========================================
   // Section Properties
   // ==========================================
   private JTextArea text;

   // ==========================================
   // Section Construction
   // ==========================================
   public TestFrame() {
	  System.out.println("TestFrame blah");
	  this.addKeyListener(this);

	  //text = new JTextArea();
	  //JScrollPane pane = new JScrollPane(text);
	  //getContentPane().add();

   }



   // ==========================================
   // Section Accessors
   // ==========================================


   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================


   // ==========================================
   // Section Interfaces
   // ==========================================
   public void keyPressed(KeyEvent e) {

   }

   public void keyReleased(KeyEvent e) {

   }
   public void keyTyped(KeyEvent e) {
	  int keyCode = e.getKeyCode();
	  System.out.println("Key code=="+keyCode+"==" );
   }
 


   // ==========================================
   // Section Overload
   // ==========================================

}

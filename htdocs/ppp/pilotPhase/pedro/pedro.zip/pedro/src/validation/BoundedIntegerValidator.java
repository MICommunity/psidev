/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.validation;

import java.lang.NumberFormatException;

/**
 * determines whether an integer field value is within minimum and maximum bounds
 * boundaries are inclusive.  The validator accepts four types of domain 
 * expression.  Examples include:
 * <ul>
 * <li>[4,10] at least 4 and at most 10
 * <li>(4,10] more than 4 and up to and including 10
 * <li>[4,10) at least 4 and below 10
 * <li>(4,10) above 4 and below 10
 * </ul>
 *
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class BoundedIntegerValidator extends IntegerValidator {

   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================

   /** value of the lower bound */
   private Integer lowerBound;

   /** whether lower bound is inclusive "[" or exclusive "(" */
   private boolean lowerBoundIsInclusive;

   /** value of the upper bound */
   private Integer upperBound;

   /** whether upper bound is inclusive ")" or exclusive "]" */
   private boolean upperBoundIsInclusive;

   // ==========================================
   // Section Construction
   // ==========================================
   /**
	* constructor
	*/
   public BoundedIntegerValidator() {
	  init();
   }

   private void init() {
	  //assume no bounds are set
	  lowerBound = null;
	  upperBound = null;
	  lowerBoundIsInclusive = false;
	  upperBoundIsInclusive = false;
   }


   // ==========================================
   // Section Accessors
   // ==========================================


   // ==========================================
   // Section Mutators
   // ==========================================
   /**
	* sets lower and upper bounds
	* @param lowerBound the lower bound value
	* @param lowerBoundIsInclusive whether lower bound is inclusive or exlusive
	* @param upperBound the upper bound value
	* @param upperBoundIsInclusive whether upper bound is inclusive or exlusive
	*/
   public void setBounds(int lowerBound,
						 boolean lowerBoundIsInclusive,
						 int upperBound,
						 boolean upperBoundIsInclusive) { 

	  setLowerBound(lowerBound,lowerBoundIsInclusive);
	  setUpperBound(upperBound, upperBoundIsInclusive);
   }

   /**
	* sets lower bounds
	* @param lowerBound the lower bound value
	* @param lowerBoundIsInclusive whether lower bound is inclusive or exlusive
	*/
   public void setLowerBound(int lowerBound,
							 boolean lowerBoundIsInclusive) { 
	  this.lowerBound = new Integer(lowerBound);
	  this.lowerBoundIsInclusive = lowerBoundIsInclusive;
   }

   /**
	* sets upper bounds
	* @param upperBound the upper bound value
	* @param upperBoundIsInclusive whether upper bound is inclusive or exlusive
	*/
   public void setUpperBound(int upperBound,
							 boolean upperBoundIsInclusive) {
	  this.upperBound = new Integer(upperBound);
	  this.upperBoundIsInclusive = upperBoundIsInclusive;
   }

   // ==========================================
   // Section Validation
   // ==========================================
   /** 
	* validates the lower bound
	* @param value field value
	* @return error message or null if no errors were found
	*/
   private String checkLowerBound(int value) {
	  boolean outOfBounds = false;
	  if ( lowerBoundIsInclusive == true) {

		 if ( value < lowerBound.intValue() ) {
			outOfBounds = true;
		 } //end if ()
	  } //end if ()
	  else {
		 if ( value <= lowerBound.intValue() ) {
			outOfBounds = true;
		 } //end if ()
	  } //end else
	  
	  if ( outOfBounds == true) {
		 StringBuffer buffer = new StringBuffer();
		 buffer.append("\"");
		 buffer.append(value);
		 buffer.append("\" falls below the lower limit ");
		 buffer.append("\"");
		 buffer.append(lowerBound.intValue());
		 buffer.append("\" for field ");
		 buffer.append("\"");
		 buffer.append(getFieldName());
		 buffer.append("\"");
		 return( buffer.toString() ); 
	  } //end if ()
	  else {
		 return null;
	  } //end else

   }

   /** 
	* validates the upper bound
	* @param value field value
	* @return error message or null if no errors were found
	*/
   private String checkUpperBound(int value) {
	  boolean outOfBounds = false;
	  if ( upperBoundIsInclusive == true) {
		 if ( value > upperBound.intValue() ) {
			outOfBounds = true;
		 } //end if ()
	  } //end if ()
	  else {
		 if ( value >= upperBound.intValue() ) {
			outOfBounds = true;
		 } //end if ()
	  } //end else
	  
	  if ( outOfBounds == true) {
		 StringBuffer buffer = new StringBuffer();
		 buffer.append("\"");
		 buffer.append(value);
		 buffer.append("\" is beyond the upper limit ");
		 buffer.append("\"");
		 buffer.append(upperBound.intValue());
		 buffer.append("\" for field ");
		 buffer.append("\"");
		 buffer.append(getFieldName());
		 buffer.append("\"");
		 return( buffer.toString() ); 
	  } //end if ()
	  else {
		 return null;
	  } //end else
   }

   // ==========================================
   // Section Errors
   // ==========================================


   // ==========================================
   // Section Interfaces
   // ==========================================

   // ==========================================
   // Section Overload
   // ==========================================

   /**
	* validates a field value
	* @param value the field value
	* @return error message or empty string null if no errors were found
	*/
   public String validate(String value) {
	  //check for empty field
	  
	  String error = super.validate(value);
	  if ( error != null) {
		 return error;
	  } //end if ()
	  
	  if ( isEmpty(value) == true) {
		 //field can be empty
		 return null;
	  } //end if ()

	  try {
		 int number = Integer.parseInt(value);
		 
		 if ( ( lowerBound != null) && ( upperBound != null) ) {
			//value falls within [x,y] limits
			error = checkLowerBound(number);
			if ( error != null) {
			   return error;
			} //end if ()
			
			error = checkUpperBound(number);
			if ( error != null) {
			   return error;
			} //end if ()

		 } //end if ()
		 else if ( lowerBound != null) {
			//value falls within [x,?] limits
			error = checkLowerBound(number);
			if ( error != null) {
			   return error;
			} //end if ()
		 } //end else ()
		 else if ( upperBound != null) {
			//value falls within [?,y] limits

			error = checkUpperBound(number);
			if ( error != null) {
			   return error;
			} //end if ()
			
		 } //end else ()
		 
		 //value parsed ok so no errors
		 return error;

	  } catch (NumberFormatException err) {
		 System.out.println(err);
		 return( value + " is not a valid integer for " + getFieldName() );
	  } // end try-catch

   }


}

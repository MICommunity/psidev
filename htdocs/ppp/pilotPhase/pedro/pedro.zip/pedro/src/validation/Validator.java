/**
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.validation;

/**
 * a generic interface used to validate field values.
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

public interface Validator {


   /**
	* validates the field value and returns any error messages
	* @param value the value of the field
	* @return an error message if the value is invalid or null 
	* if no errors were found
	*/
   public String validate(String value);
   /**
	* sets the field name
	* @param fieldName the name of the field
	*/
   public void setFieldName(String fieldName);


   /** 
	* sets whether the field is required or optional
	* @param isFieldRequired true if the field is required or false if the field
	* is optional
	*/
   public void setRequiredField(boolean isFieldRequired);

}

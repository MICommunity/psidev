/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.validation;

import java.lang.NumberFormatException;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.GregorianCalendar;
import java.util.Calendar;
import java.text.FieldPosition;
import java.lang.StringBuffer;
import java.util.Locale;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class DateValidator extends AbstractValidator {


   public static void main (String[] args) {

	  DateValidator dateValidator = new DateValidator();


	  /*
   Date date5 = DateValidator.ddmmyyFormat.parse("06/10/02", new ParsePosition(0));
   String result = DateValidator.getCanonicalValue(date5);
   System.out.println("Result =="+result+"==");

   Date resultDate = DateValidator.getCanonicalDate(result);
   System.out.println(resultDate.toString() );

   String result2 = DateValidator.getCanonicalValue(resultDate);
   System.out.println("Result2 =="+result2+"==");
	  */

	  /*
	  String date1 = "15/4/1";
	  dateValidator.validateMMDDYY(date1);
	  
	  String date2 = "12/04/2001";
	  dateValidator.validateMMDDYY(date2);
	  String date3 = "12/32/2002";
	  */

	  /*
	  String date4 = "06/31/2002";
	  System.out.println(dateValidator.validateMMDDYY(date4));
	  String date6 = "06/3/2002";
	  System.out.println(dateValidator.validateMMDDYY(date6));
	  String date7 = "02/28/2002";
	  System.out.println(dateValidator.validateMMDDYY(date7));
	  String date8 = "02/29/2002";
	  System.out.println(dateValidator.validateMMDDYY(date8));
	  String date9 = "02/29/2004";
	  System.out.println(dateValidator.validateMMDDYY(date9));
	  */

	  /*
	  String date5 = "31/06/2002";
	  System.out.println(dateValidator.validateDDMMYY(date5));
	  String date6 = "3/06/2002";
	  System.out.println(dateValidator.validateDDMMYY(date6));
	  String date7 = "28/02/2002";
	  System.out.println(dateValidator.validateDDMMYY(date7));
	  String date8 = "29/02/2002";
	  System.out.println(dateValidator.validateDDMMYY(date8));
	  String date9 = "29/02/2004";
	  System.out.println(dateValidator.validateDDMMYY(date9));
	  */

	  /*
	  String date5 = "02/06/31";
	  String date6 = "02/06/03";
	  String date7 = "02/06/28";
	  String date8 = "02/02/29";
	  String date9 = "04/02/29";
	  
	  System.out.println(dateValidator.validateYYMMDD(date5));
	  System.out.println(dateValidator.validateYYMMDD(date6));
	  System.out.println(dateValidator.validateYYMMDD(date7));
	  System.out.println(dateValidator.validateYYMMDD(date8));
	  System.out.println(dateValidator.validateYYMMDD(date9));
	  */
	  /*

	  SimpleDateFormat dateFormat = new SimpleDateFormat(pattern);

	  Date date = dateFormat.parse(date2, new ParsePosition(0) );
	  GregorianCalendar calendar = new GregorianCalendar();
	  calendar.setTime(date);

	  int month = calendar.get(Calendar.MONTH);
	  int day = calendar.get(Calendar.DAY_OF_MONTH);
	  int year = calendar.get(Calendar.YEAR);

	  */


   } // end main ()
   

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   public static final int DDMMYYYY = 11;
   public static final int MMDDYYYY = 12;
   public static final int YYYYMMDD = 13;

   private static boolean allowDateFormatValidation;
   public static SimpleDateFormat ddmmyyyyFormat = new SimpleDateFormat("dd/mm/yyyy");
   public static SimpleDateFormat mmddyyyyFormat = new SimpleDateFormat("mm/dd/yyyy");
   public static SimpleDateFormat yyyymmddFormat = new SimpleDateFormat("yyyy/mm/dd");
   public static SimpleDateFormat canonicalFormat = new SimpleDateFormat("yyyy-mm-dd");

   private int[] daysInMonth;

   private static SimpleDateFormat formatToUse = ddmmyyyyFormat;

   {
	  formatToUse = ddmmyyyyFormat;
   }

   // ==========================================
   // Section Construction
   // ==========================================
   public DateValidator() {
	  daysInMonth = new int[12];
	  daysInMonth[0] = 31;
	  daysInMonth[1] = 28;
	  daysInMonth[2] = 31;
	  daysInMonth[3] = 30;
	  daysInMonth[4] = 31;
	  daysInMonth[5] = 30;
	  daysInMonth[6] = 31;
	  daysInMonth[7] = 31;
	  daysInMonth[8] = 30;
	  daysInMonth[9] = 31;
	  daysInMonth[10] = 30;
	  daysInMonth[11] = 31;

   }
   
   public static void setDefaultDateFormat() {
	  formatToUse = ddmmyyyyFormat;
   }

   public static void setDateFormat(SimpleDateFormat format) {
 	  formatToUse = format;
   }
   
   public static SimpleDateFormat getDateFormat() {
	  return formatToUse;
   }
   
   public static SimpleDateFormat getCanonicalFormat() {
	  return canonicalFormat;
   }

   public static String getDateFormatString(SimpleDateFormat format) {
	  return format.toPattern();
   }

   public static String getCanonicalValue(Date date) {
	  StringBuffer blah = new StringBuffer();
	  StringBuffer buffer = 
		 canonicalFormat.format(date,
								blah,
								new FieldPosition(0));
	  return buffer.toString();
	  
   }

   public static String getDateValue(Date date) {
	  StringBuffer blah = new StringBuffer();
	  StringBuffer buffer = 
		 formatToUse.format(date,
							blah,
							new FieldPosition(0));
	  return buffer.toString();
   }

   public static Date getDate(String date) {
	  return formatToUse.parse(date.toUpperCase(), new ParsePosition(0) );
   }


   public static Date getCanonicalDate(String date) {
	  return canonicalFormat.parse(date.toUpperCase(), new ParsePosition(0) );
   }

   // ==========================================
   // Section Accessors
   // ==========================================
 


   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================

   //Validator
   public String validate(String value) {
	  //check for empty field
	  String error = validateRequiredField(value);
	  if ( error != null) {
		 return error;
	  } //end if ()

	  if ( isEmpty(value) == true) {
		 //field can be empty
		 return null;
	  } //end if ()

	  String dateValue = value;

	  Date date = canonicalFormat.parse(value, new ParsePosition(0) );
	  if ( date != null) {
		 dateValue = getDateValue(date);
	  }

	  if ( formatToUse == yyyymmddFormat) {
		 return validateYYYYMMDD(dateValue);
	  } //end if ()
	  else if ( formatToUse == mmddyyyyFormat) {
		 return validateMMDDYYYY(dateValue);
	  } //end else ()
	  else {
		 return validateDDMMYYYY(dateValue);
	  } //end else ()
   }

   private String validateYYYYMMDD(String value) {
	  //expects format to be "YYYY/MM/dd"
	  
	  String error = null;

	  //check for format violations
	  Date date = yyyymmddFormat.parse(value, new ParsePosition(0) );
	  if ( date == null) {
		 StringBuffer errorMessage = new StringBuffer();
		 errorMessage.append(value);
		 errorMessage.append(" is not a valid date");
		 errorMessage.append(" of form ");
		 errorMessage.append("\"");
		 errorMessage.append(yyyymmddFormat.toPattern());
		 errorMessage.append("\"");
		 errorMessage.append(" for field ");
		 errorMessage.append(getFieldName());
		 return(errorMessage.toString()  );
	  } //end if ()
	  

	  /**
	   * simple date format barfs if there is a format violation but doesn't
	   * do boundary checking on values for year, month or day. for example, you can
	   * accidentally enter "45" for a day number and it won't complain.  This section
	   * does what simple date format SHOULD be doing but doesn't as of JDK1.3
	   */

	  int yearMonthDivider = value.indexOf('/',0);
	  int monthDayDivider = value.indexOf('/',yearMonthDivider+1);

	  String dayString = value.substring(monthDayDivider+1);
	  String monthString = value.substring(yearMonthDivider+1,
										   monthDayDivider);

	  String yearString = value.substring(0,yearMonthDivider);
	  if ( yearString.length() != 4) {
		 return("Please specify a four digit year.");
	  } //end if ()
	  

	  error = validateMonth(monthString);
	  if ( error != null) {
		 return error;
	  } //end if ()

	  try {
	  
		 int year = getYear(yearString);
		 
		 GregorianCalendar calendar = new GregorianCalendar();
		 calendar.setTime(date);
		 calendar.set(GregorianCalendar.YEAR, year);
		 
		 //we actually need the date formatter to tell us what the year is so we can
		 //do leap year calculations in validating the day
		 
		 Integer month = Integer.valueOf(monthString);
		 error = validateDay(month.intValue(), year, dayString);
	  } catch (Exception err) {
		 System.out.println(err);
	  } // end try-catch
	  
	  return error;
	  
   }

   private String validateDDMMYYYY(String value) {


	  //expects format to be "DD/MM/YYYY"
	  
	  String error = null;

	  //check for format violations
	  Date date = ddmmyyyyFormat.parse(value, new ParsePosition(0) );
	  if ( date == null) {
		 StringBuffer errorMessage = new StringBuffer();
		 errorMessage.append(value);
		 errorMessage.append(" is not a valid date");
		 errorMessage.append(" of form ");
		 errorMessage.append("\"");
		 errorMessage.append(ddmmyyyyFormat.toPattern());
		 errorMessage.append("\"");
		 errorMessage.append(" for field ");
		 errorMessage.append(getFieldName());
		 return(errorMessage.toString()  );
	  } //end if ()
	  

	  /**
	   * simple date format barfs if there is a format violation but doesn't
	   * do boundary checking on values for year, month or day. for example, you can
	   * accidentally enter "45" for a day number and it won't complain.  This section
	   * does what simple date format SHOULD be doing but doesn't as of JDK1.3
	   */

	  int dayMonthDivider = value.indexOf('/',0);
	  int monthYearDivider = value.indexOf('/',dayMonthDivider+1);

	  String dayString = value.substring(0,dayMonthDivider);


	  String yearString = value.substring(monthYearDivider+1);
	  if ( yearString.length() != 4) {
		 return("Please specify a four digit year.");
	  } //end if ()

	  String monthString = value.substring(dayMonthDivider+1,
										   monthYearDivider);
	  

	  error = validateMonth(monthString);
	  if ( error != null) {
		 return error;
	  } //end if ()

	  try {
	  
		 int year = getYear(yearString);
		 GregorianCalendar calendar = new GregorianCalendar();
		 calendar.setTime(date);
		 calendar.set(GregorianCalendar.YEAR, year);
		 
		 
		 //we actually need the date formatter to tell us what the year is so we can
		 //do leap year calculations in validating the day

		 Integer month = Integer.valueOf(monthString);
		 error = validateDay(month.intValue(), year, dayString);
	  } catch (Exception err) {
		 System.out.println(err);
	  } // end try-catch
	  
	  return error;
	  
   }


   private String validateMMDDYYYY(String value) {
	  //expects format to be "MM/dd/yyyy"
	  
	  String error = null;

	  //check for format violations
	  Date date = mmddyyyyFormat.parse(value, new ParsePosition(0) );
	  if ( date == null) {
		 StringBuffer errorMessage = new StringBuffer();
		 errorMessage.append(value);
		 errorMessage.append(" is not a valid date");
		 errorMessage.append(" of form ");
		 errorMessage.append("\"");
		 errorMessage.append(mmddyyyyFormat.toPattern());
		 errorMessage.append("\"");
		 errorMessage.append(" for field ");
		 errorMessage.append(getFieldName());
		 return(errorMessage.toString()  );
	  } //end if ()
	  

	  /**
	   * simple date format barfs if there is a format violation but doesn't
	   * do boundary checking on values for year, month or day. for example, you can
	   * accidentally enter "45" for a day number and it won't complain.  This section
	   * does what simple date format SHOULD be doing but doesn't as of JDK1.3
	   */

	  int monthDayDivider = value.indexOf('/',0);
	  int dayYearDivider = value.indexOf('/',monthDayDivider+1);

	  String monthString = value.substring(0,monthDayDivider);
	  error = validateMonth(monthString);


	  String yearString = value.substring(dayYearDivider+1);
	  if ( yearString.length() != 4) {
		 return("Please specify a four digit year.");
	  } //end if ()

	  String dayString = value.substring(monthDayDivider+1,
										 dayYearDivider);
	  
	  try {

		 int year = getYear(yearString);
		 GregorianCalendar calendar = new GregorianCalendar();
		 calendar.setTime(date);
		 calendar.set(GregorianCalendar.YEAR, year);
		 
		 //we actually need the date formatter to tell us what the year is so we can
		 //do leap year calculations in validating the day
		 
		 Integer month = Integer.valueOf(monthString);
		 error = validateDay(month.intValue(), year, dayString);
	  } catch (Exception err) {
		 System.out.println(err);
	  } // end try-catch
	  
	  return error;
	  
   }


   private String validateMonth(String value) {

	  try {
		 Integer month = Integer.valueOf(value);
		 if ( ( month.intValue() < 1) || (month.intValue() > 12) ) {
			StringBuffer errorMessage = new StringBuffer();
			errorMessage.append(getFieldName() );
			errorMessage.append(" has an invalid month value \"");
			errorMessage.append(value);
			errorMessage.append("\"");
			return errorMessage.toString();
		 } //end if ()

		 //no errors
		 return null;

	  } catch (NumberFormatException err) {
		 StringBuffer errorMessage = new StringBuffer();
		 errorMessage.append(getFieldName() );
		 errorMessage.append(" has an invalid month value \"");
		 errorMessage.append(value);
		 errorMessage.append("\"");
		 return errorMessage.toString();
	  } // end try-catch

   }

   private String validateDay(int month, int year, String value) {
	  try {
		 //here month is [0...11], because this is what calendar class
		 //assumes.
		 int maximumNumberOfDays = daysInMonth[month-1];
		 
		 //do leap year calculation
		 if (( month == 2) && (year%4 == 0) ) {
			   maximumNumberOfDays = 29;
		 } //end if ()
		 

		 Integer day = Integer.valueOf(value);

		 if ( ( day.intValue() < 1) || (day.intValue() > maximumNumberOfDays) ) {
			StringBuffer errorMessage = new StringBuffer();
			errorMessage.append(getFieldName() );
			errorMessage.append(" has an invalid day value \"");
			errorMessage.append(value);
			errorMessage.append("\"");
			errorMessage.append(" for date with month ");
			errorMessage.append(month);
			errorMessage.append(" and year ");
			errorMessage.append(year);

			return errorMessage.toString();
		 } //end if ()

		 //no errors
		 return null;

	  } catch (NumberFormatException err) {
		 StringBuffer errorMessage = new StringBuffer();
		 errorMessage.append(getFieldName() );
		 errorMessage.append(" has an invalid day value \"");
		 errorMessage.append(value);
		 errorMessage.append("\"");
		 errorMessage.append(" for date with month ");
		 errorMessage.append(month);
		 errorMessage.append(" and year ");
		 errorMessage.append(year);

		 return errorMessage.toString();
	  } // end try-catch

   }
   
   private static int getYear(String yr) throws Exception {
	  if ( yr.length() == 2) {
		 Integer yearValue = Integer.valueOf(yr);
		 int year = yearValue.intValue();
		 if ( ( year >= 0) && (year < 70) ) {
			year += 2000;
		 } //end if ()
		 else {
			year += 1900;
		 } //end else
		 return year;
	  } //end if ()
	  else {
		 Integer yearValue = Integer.valueOf(yr);
		 int year = yearValue.intValue();
		 return year;
	  } //end else

   }







   // ==========================================
   // Section Overload
   // ==========================================

}






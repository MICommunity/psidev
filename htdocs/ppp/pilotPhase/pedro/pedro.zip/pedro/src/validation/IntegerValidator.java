/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.validation;

import java.lang.NumberFormatException;



/**
 * checks whether a field value is a valid integer
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class IntegerValidator extends AbstractValidator {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================

   // ==========================================
   // Section Construction
   // ==========================================

   // ==========================================
   // Section Accessors
   // ==========================================


   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================

   // ==========================================
   // Section Interfaces
   // ==========================================

   // ==========================================
   // Section Overload
   // ==========================================
   public String validate(String value) {
	  //check for empty field
	  String error = validateRequiredField(value);
	  if ( error != null) {
		 return error;
	  } //end if ()
	  
	  if ( isEmpty(value) == true) {
		 //field can be empty
		 return null;
	  } //end if ()

	  try {
		 int number = Integer.parseInt(value);
		 
		 //value parsed ok so no errors
		 return null;

	  } catch (NumberFormatException err) {
		 return( value + " is not a valid integer for " + getFieldName() );
	  } // end try-catch

   }

}

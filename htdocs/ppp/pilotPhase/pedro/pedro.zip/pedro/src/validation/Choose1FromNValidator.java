/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.validation;

import java.lang.NumberFormatException;

import pedro.system.GlobalConstants;


/**
 * used for combination box fields that have a "None" option.  The class
 * checks whether a required combination field value is "None".  The actual
 * string "None" is defined by GlobalConstants.NONE
 *
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class Choose1FromNValidator extends AbstractValidator {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   
   /** the choices available in the combination box field */
   private String[] choices;

   // ==========================================
   // Section Construction
   // ==========================================
   /**
	* constructor
	* @param choices the choices available in the combination box field
	*/
   public Choose1FromNValidator(String[] choices) {
	  this.choices = choices;
   }

   // ==========================================
   // Section Accessors
   // ==========================================
   

   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================

   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================
   public String validate(String value) {
	  //check for empty field
	  
	  //in radio buttons, there may not be a none choice
	  String error = validateRequiredField(value);
	  if ( error != null) {
		 return error;
	  } //end if ()

	  if (value.equals(GlobalConstants.NONE) == true) {
		 if ( isFieldRequired() == true) {
			return("You must select a choice for " + getFieldName() );
		 } //end if ()
		 else {
			return null;
		 } //end else

	  } //end if ()
	  if ( value.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) == true) {
		 return null;
	  } //end if ()
	  

	  
	  //check that value is in choices
	  for ( int i = 0; i < choices.length; i++) {
		 if ( choices[i].equals(value) == true) {
			return null;
		 } //end if ()
	  } // end for ()

	  return( value + " is not a valid choice for " + getFieldName() );
   }

}

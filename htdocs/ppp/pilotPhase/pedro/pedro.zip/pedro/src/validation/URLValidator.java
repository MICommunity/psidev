/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.validation;

import java.io.File;
import java.net.URL;
import java.net.MalformedURLException;

/**
 * checks whether field value is a legitimate URL
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class URLValidator extends AbstractValidator {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================

   // ==========================================
   // Section Construction
   // ==========================================


   // ==========================================
   // Section Accessors
   // ==========================================


   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================

   // ==========================================
   // Section Interfaces
   // ==========================================

   // ==========================================
   // Section Overload
   // ==========================================
   public String validate(String value) {
	  //check for empty field
	  String error = validateRequiredField(value);
	  if ( error != null) {
		 return error;
	  } //end if ()
	  
	  if ( isEmpty(value) == true) {
		 //field can be empty
		 return null;
	  } //end if ()

	  return null;
   }

}

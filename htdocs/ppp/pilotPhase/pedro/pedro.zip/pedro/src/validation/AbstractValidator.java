/**
* 
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.validation;

import java.io.Serializable;

/**
 * abstract class that has code for validating required fields
 * the has the code for validating required fields.
 *
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
Section Private
*/

public abstract class AbstractValidator 
   implements Validator, Serializable {
   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   /** the field name */
   private String fieldName;

   /** represents whether the field is optional or required */
   private boolean isFieldRequired;

   // ==========================================
   // Section Construction
   // ==========================================

   // ==========================================
   // Section Accessors
   // ==========================================
   /**
	* returns the name of the field
	* @return the field name
	*/
   protected String getFieldName() {
	  return fieldName;
   }

   /**
	* checks to see if value is an empty string
	* @param value the value 
	* @return true if the value is an empty string; otherwise false 
	*/
   public boolean isEmpty(String value) {
	  return( value.equals("") );
   }

   /**
	* returns whether the data field is required 
	* return true if field is required; otherwise false
	*/
   protected boolean isFieldRequired() {
	  return isFieldRequired;
   }

   // ==========================================
   // Section Mutators
   // ==========================================
   /**
	* sets the field name
	* @param the field name
	*/
   public void setFieldName(String fieldName) {
	  this.fieldName = fieldName;
   }

   /**
	* sets whether the field is required or optional.
	* @param isFieldRequired true if the field is required; false if field is optional.
	*/
   public void setRequiredField(boolean _isFieldRequired) {
	  this.isFieldRequired = _isFieldRequired;
   }


   // ==========================================
   // Section Validation
   // ==========================================
   /**
	* checks to make sure that a required field has a non-empty value
	* @param value the value of the field
	*/
   protected String validateRequiredField(String value) {
	  if (isFieldRequired == false) {
		 return null;
	  } //end if ()

	  if ( value.equals("") == true) {
		 return( fieldName + " " + "can't be empty" );
	  } //end if ()
	  else {
		 return null;
	  } //end else
   }

   // ==========================================
   // Section Errors
   // ==========================================

   // ==========================================
   // Section Interfaces
   // ==========================================
   //Interface: AbstractValidator
   public abstract String validate(String value);

   // ==========================================
   // Section Overload
   // ==========================================

   // ==========================================
   // Section Private
   // ==========================================


}

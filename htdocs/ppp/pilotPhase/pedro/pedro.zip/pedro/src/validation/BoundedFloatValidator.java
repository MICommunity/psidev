/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.validation;

import java.lang.NumberFormatException;

/**
 * determines whether a float field value is within minimum and maximum bounds
 * boundaries are inclusive.  The validator accepts four types of domain 
 * expression.  Examples include:
 * <ul>
 * <li>[4,10] at least 4 and at most 10
 * <li>(4,10] more than 4 and up to and including 10
 * <li>[4,10) at least 4 and below 10
 * <li>(4,10) above 4 and below 10
 * </ul>
 *
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */


/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class BoundedFloatValidator extends FloatValidator {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================

   /** value of the lower bound */
   private Float lowerBound;

   /** whether lower bound is inclusive "[" or exclusive "(" */
   private boolean lowerBoundIsInclusive;

   /** value of the upper bound */
   private Float upperBound;

   /** whether upper bound is inclusive ")" or exclusive "]" */
   private boolean upperBoundIsInclusive;


   // ==========================================
   // Section Construction
   // ==========================================
   /**
	* constructor
	*/
   public BoundedFloatValidator() {
	  init();
   }
   
   private void init() {
	  //assume no bounds are set
	  lowerBound = null;
	  upperBound = null;
	  lowerBoundIsInclusive = false;
	  upperBoundIsInclusive = false;

   }

   // ==========================================
   // Section Accessors
   // ==========================================


   // ==========================================
   // Section Mutators
   // ==========================================
   /**
	* sets lower and upper bounds
	* @param lowerBound the lower bound value
	* @param lowerBoundIsInclusive whether lower bound is inclusive or exlusive
	* @param upperBound the upper bound value
	* @param upperBoundIsInclusive whether upper bound is inclusive or exlusive
	*/
   public void setBounds(float lowerBound,
						 boolean lowerBoundIsInclusive,
						 float upperBound,
						 boolean upperBoundIsInclusive) { 

	  setLowerBound(lowerBound,lowerBoundIsInclusive);
	  setUpperBound(upperBound,upperBoundIsInclusive);

   }

   /**
	* sets lower bounds, but accepts double values
	* @param lowerBound the lower bound value
	* @param lowerBoundIsInclusive whether lower bound is inclusive or exlusive
	*/
   public void setBounds(double lowerBound,
						 boolean lowerBoundIsInclusive,
						 double upperBound,
						 boolean upperBoundIsInclusive) { 

	  setLowerBound(lowerBound,lowerBoundIsInclusive);
	  setUpperBound(upperBound,upperBoundIsInclusive);

   }

   /**
	* sets lower bounds
	* @param lowerBound the lower bound value
	* @param lowerBoundIsInclusive whether lower bound is inclusive or exlusive
	*/
   public void setLowerBound(float lowerBound, 
							 boolean lowerBoundIsInclusive) { 
	  this.lowerBound = new Float(lowerBound);
	  this.lowerBoundIsInclusive = lowerBoundIsInclusive;
   }


   /**
	* sets lower bounds but takes double values
	* @param lowerBound the lower bound value
	* @param lowerBoundIsInclusive whether lower bound is inclusive or exlusive
	*/
   public void setLowerBound(double lowerBound, 
							 boolean lowerBoundIsInclusive) { 
	  this.lowerBound = new Float(lowerBound);
	  this.lowerBoundIsInclusive = lowerBoundIsInclusive;
   }

   /**
	* sets upper bounds
	* @param upperBound the upper bound value
	* @param upperBoundIsInclusive whether upper bound is inclusive or exlusive
	*/
   public void setUpperBound(float upperBound,
							 boolean upperBoundIsInclusive) {
	  this.upperBound = new Float(upperBound);
	  this.upperBoundIsInclusive = upperBoundIsInclusive;
   }

   /**
	* sets upper bounds but takes double values
	* @param upperBound the upper bound value
	* @param upperBoundIsInclusive whether upper bound is inclusive or exlusive
	*/
   public void setUpperBound(double upperBound,
							 boolean upperBoundIsInclusive) {
	  this.upperBound = new Float(upperBound);
	  this.upperBoundIsInclusive = upperBoundIsInclusive;
   }

   // ==========================================
   // Section Validation
   // ==========================================
   /** 
	* validates the lower bound
	* @param value field value
	* @return error message or null if no errors were found
	*/
   private String checkLowerBound(float value) {
	  boolean outOfBounds = false;
	  if ( lowerBoundIsInclusive == true) {
		 if ( value < lowerBound.floatValue() ) {
			outOfBounds = true;
		 } //end if ()
	  } //end if ()
	  else {
		 if ( value <= lowerBound.floatValue() ) {
			outOfBounds = true;
		 } //end if ()
	  } //end else
	  
	  if ( outOfBounds == true) {
		 StringBuffer buffer = new StringBuffer();
		 buffer.append("\"");
		 buffer.append(value);
		 buffer.append("\" falls below the lower limit ");
		 buffer.append("\"");
		 buffer.append(lowerBound.intValue());
		 buffer.append("\" for field ");
		 buffer.append("\"");
		 buffer.append(getFieldName());
		 buffer.append("\"");
		 return( buffer.toString() ); 
	  } //end if ()
	  else {
		 return null;
	  } //end else

   }

   /** 
	* validates the upper bound
	* @param value field value
	* @return error message or null if no errors were found
	*/
   private String checkUpperBound(float value) {
	  boolean outOfBounds = false;
	  if ( upperBoundIsInclusive == true) {
		 if ( value > upperBound.floatValue() ) {
			outOfBounds = true;
		 } //end if ()
	  } //end if ()
	  else {
		 if ( value >= upperBound.floatValue() ) {
			outOfBounds = true;
		 } //end if ()
	  } //end else
	  
	  if ( outOfBounds == true) {
		 StringBuffer buffer = new StringBuffer();
		 buffer.append("\"");
		 buffer.append(value);
		 buffer.append("\" is beyond the upper limit ");
		 buffer.append("\"");
		 buffer.append(upperBound.floatValue());
		 buffer.append("\" for field ");
		 buffer.append("\"");
		 buffer.append(getFieldName());
		 buffer.append("\"");
		 return( buffer.toString() ); 
	  } //end if ()
	  else {
		 return null;
	  } //end else
   }

   // ==========================================
   // Section Errors
   // ==========================================

   // ==========================================
   // Section Interfaces
   // ==========================================

   public String validate(String value) {
	  //check for empty field
	  
	  String error = super.validate(value);
	  if ( error != null) {
		 return error;
	  } //end if ()
	  
	  if ( isEmpty(value) == true) {
		 //field can be empty
		 return null;
	  } //end if ()

	  try {
		 float number = Float.parseFloat(value);
		 
		 if ( ( lowerBound != null) && ( upperBound != null) ) {
			//value falls within [x,y] limits
			error = checkLowerBound(number);
			if ( error != null) {
			   return error;
			} //end if ()
			
			error = checkUpperBound(number);
			if ( error != null) {
			   return error;
			} //end if ()

		 } //end if ()
		 else if ( lowerBound != null) {
			//value falls within [x,?] limits
			error = checkLowerBound(number);
			if ( error != null) {
			   return error;
			} //end if ()
		 } //end else ()
		 else if ( upperBound != null) {
			//value falls within [?,y] limits

			error = checkUpperBound(number);
			if ( error != null) {
			   return error;
			} //end if ()
			
		 } //end else ()
		 
		 //value parsed ok so no errors
		 return error;

	  } catch (NumberFormatException err) {
		 System.out.println(err);
		 return( value + " is not a valid float for " + getFieldName() );
	  } // end try-catch

   }



   // ==========================================
   // Section Overload
   // ==========================================

}

/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.validation;

import org.apache.regexp.RE;
import java.lang.NumberFormatException;

/**
 * checks that a string field value matches a regular expression.  This method 
 * draws on the regular expression classes of Apache's "Regexp-1.2".
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
Section Private
*/

public class StringMaskValidator extends AbstractValidator {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   /** field values must match this regular expression mask */
   private String mask;

   /** determines whether the filter mask is a 
	* legitimate regular expression
	*/
   private boolean maskIsLegal;

   // ==========================================
   // Section Construction
   // ==========================================
   /*
	* constructor
	* @param mask the mask that field values must match
	*/
   public StringMaskValidator(String mask) {
	  maskIsLegal = true;
	  this.mask = mask;
   }

   // ==========================================
   // Section Accessors
   // ==========================================


   // ==========================================
   // Section Mutators
   // ==========================================
   /**
	* sets the mask that field values must match.
	* @param mask the field mask
	*/
   public void setMask(String mask) {
	  this.mask = mask;
	  maskIsLegal = true;


   }

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================
  private String getNoMatchError(String value) {
	  StringBuffer buffer = new StringBuffer();
	  buffer.append(value);
	  buffer.append(" doesn't match mask \"");
	  buffer.append(mask);
	  buffer.append("\" for ");
	  buffer.append(getFieldName());

	  return( buffer.toString() );
   }

   private String getRegExpError(String mask) {
	  StringBuffer buffer = new StringBuffer();
	  buffer.append(mask);
	  buffer.append(" is an unacceptable regular expression ");
	  buffer.append("for ");
	  buffer.append(getFieldName() );
	  return buffer.toString();
   }

   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================
   
   public String validate(String value) {
	  try {
		 RE regularExpression = new RE(mask);
		 boolean matchesMask = regularExpression.match(value);
		 if ( matchesMask == true) {
			//no error
			return null;
		 } //end if ()
		 else {
			return getNoMatchError(value);
		 } //end else
	  } catch (Exception err) {
		 return getRegExpError(mask);
	  } // end try-catch
   }

   // ==========================================
   // Section Private
   // ==========================================

}

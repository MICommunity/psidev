/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.model;



/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class GroupFieldModel extends EditFieldModel {

   
   // ==========================================
   // Section Constants
   // ==========================================
   public static final String TRUE = "true";
   public static final String FALSE = "false";

   // ==========================================
   // Section Properties
   // ==========================================
   private String[] choices;

   // ==========================================
   // Section Construction
   // ==========================================
   public GroupFieldModel() {

   }


   // ==========================================
   // Section Accessors
   // ==========================================
   public String[] getChoices() {
	  return choices;
   }

   // ==========================================
   // Section Mutators
   // ==========================================
   public void setChoices(String[] choices) {
	  this.choices = choices;
   }


   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================
   public Object clone() {
	  GroupFieldModel cloneField = new GroupFieldModel();
	  super.populateCloneAttributes(this,cloneField);
	  cloneField.setChoices(choices);

	  return cloneField;
   }

}

/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.model;

import java.io.Serializable;
import java.lang.Cloneable;
import java.util.ArrayList;
import java.util.Hashtable;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;


import pedro.model.DataFieldModel;
import pedro.model.EditFieldModel;
import pedro.system.GlobalConstants;
import pedro.validation.DateValidator;
import pedro.util.ErrorDialog;
/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class RecordModel 
   implements Serializable,Cloneable {

   
   // ==========================================
   // Section Constants
   // ==========================================
   private static final int MAXIMUM_DISPLAY_NAME_LENGTH = 50;

   // ==========================================
   // Section Properties
   // ==========================================
   private Hashtable fieldHash;
   private ArrayList changeListeners;
   private String recordClassName;
   private ArrayList fields;
   private boolean saveChanges;
   private String displayName;
   private boolean isNewRecord;
   private boolean enableSaveChanges;
   private URL helpLink;
   private ListFieldModel containingListModel;

   // ==========================================
   // Section Construction
   // ==========================================
   public RecordModel() {
	  fields = new ArrayList();
	  fieldHash = new Hashtable();
	  changeListeners = new ArrayList();
	  reset();
   }
 
   private void reset() {
	  containingListModel = null;
	  recordClassName = null;
	  saveChanges = false;
	  displayName = "";
	  enableSaveChanges = false;
	  helpLink = null;
   }
  
   // ==========================================
   // Section Accessors
   // ==========================================
   public String getDisplayName() {
	  return displayName;
   }

   public ArrayList getFields() {
	  return fields;
   }

   public DataFieldModel getField(String fieldName) {
	  DataFieldModel field = (DataFieldModel) fieldHash.get(fieldName);
	  return field;
   }

   public boolean isRequiredField(String fieldName) {
	  DataFieldModel field = (DataFieldModel) fieldHash.get(fieldName);
	  return field.isRequiredField();
   }


   public boolean isListField(String fieldName) {
	  DataFieldModel field = (DataFieldModel) fieldHash.get(fieldName);
	  return( field instanceof ListFieldModel);
   }

   public boolean isEditField(String fieldName) {
	  DataFieldModel field = (DataFieldModel) fieldHash.get(fieldName);
	  return( field instanceof EditFieldModel);
   }





   /**
	* Get the value of recordClassName.
	* @return value of recordClassName.
	*/
   public String getRecordClassName() {
	  return recordClassName;
   }

   public boolean saveChanges() {
	  return saveChanges;
   }


   public ArrayList getListFields() {

	  ArrayList listFields = new ArrayList();

	  int numberOfFields = fields.size();
	  for ( int i = 0; i < numberOfFields; i++) {
		 Object currentField = fields.get(i);
		 if ( currentField instanceof ListFieldModel) {
			listFields.add(currentField);
		 } //end if ()
	  } // end for ()
	  
	  return listFields;
   }

   public ArrayList getProxyListFields() {

	  ArrayList proxyFields = new ArrayList();

	  int numberOfFields = fields.size();
	  for ( int i = 0; i < numberOfFields; i++) {
		 Object currentField = fields.get(i);
		 if ( currentField instanceof ProxyListFieldModel) {
			proxyFields.add(currentField);
		 } //end if ()
	  } // end for ()
	  
	  return proxyFields;

   }

   public void replaceField(DataFieldModel oldFieldModel,
							DataFieldModel newFieldModel) {

	  int proxyIndex = fields.indexOf(oldFieldModel);
	  if ( proxyIndex != -1) {
		 fields.remove(proxyIndex);
		 fields.add(proxyIndex, newFieldModel);
	  } //end if ()

   }

   public String[] getEditFieldNames() {
	  int numberOfFields = fields.size();

	  ArrayList editFieldList = new ArrayList();

	  for ( int i = 0; i < numberOfFields;i++) {
		 DataFieldModel currentField = (DataFieldModel) fields.get(i);
		 if ( currentField instanceof EditFieldModel) {
			editFieldList.add(currentField.getName() );
		 } //end if ()
		 
	  } // end for ()

	  String[] editFieldNames = (String[]) editFieldList.toArray(new String[1]);

	  return editFieldNames;
   }
   

   public String[] getMissingRecordTypes() {

	  //for now, we'll limit missing records to 
	  //child types supplied by singletype single value records

	  ArrayList missingTypes = new ArrayList();
	  int numberOfFields = fields.size();
	  for ( int i = 0; i < numberOfFields; i++) {
		 Object currentFieldModel = fields.get(i);
		 if ( currentFieldModel instanceof ListFieldModel) {
			ListFieldModel listFieldModel 
			   = (ListFieldModel) currentFieldModel;

			if ( ( listFieldModel.isRequiredField() == true) &&
				 (listFieldModel.isListPopulated() == false) ) {

			   String[] currentChildTypes 
				  = listFieldModel.getChildTypes();
			   
			   for ( int j = 0; j < currentChildTypes.length; j++) {
				  missingTypes.add(currentChildTypes[j]);
			   } // end for ()

			} //end if ()

		 } //end if ()

	  } // end for ()

	  String[] results = (String[]) missingTypes.toArray(new String[0]);

	  return results;
   }


   public String computeDisplayName() {
	  StringBuffer name = new StringBuffer();

	  name.append(recordClassName.toUpperCase());
	  name.append(":");

	  boolean isFirstDisplayComponent = false;

	  int numberOfFieldList = fields.size();

	  for ( int i = 0; i < numberOfFieldList; i++) {
		 DataFieldModel dataFieldModel = (DataFieldModel) fields.get(i);
		 if ( dataFieldModel instanceof EditFieldModel) {
			
			EditFieldModel editFieldModel = (EditFieldModel) dataFieldModel;


			if ( editFieldModel.isDisplayNameComponent() == true) {
			   if ( isFirstDisplayComponent == false) {
				  isFirstDisplayComponent = true;
			   } //end if ()
			   else {
				  name.append("-");
			   } //end else

			   int uiRenderingType = dataFieldModel.getUIRenderingType();
			   if ( uiRenderingType == GlobalConstants.DATE_FIELD) {

				  String canonicalDateValue = editFieldModel.getValue();

				  if ( canonicalDateValue.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) == false) {

					 Date date 
						= DateValidator.getCanonicalDate(canonicalDateValue);
					 
					 if ( date == null) {
						StringBuffer dateFormatError = new StringBuffer();
						dateFormatError.append("Incorrect date value \"");
						dateFormatError.append(canonicalDateValue);
						dateFormatError.append("\".  It must be of the form");
						
						String pattern 
						   = DateValidator.getDateFormatString(DateValidator.getCanonicalFormat() );
						dateFormatError.append("\"");
						dateFormatError.append(pattern);
						dateFormatError.append("\"");

						ErrorDialog.show(dateFormatError.toString() );
						return truncateNameLength(name.toString() );
					 } //end if ()

					 SimpleDateFormat dateFormat
						= DateValidator.getDateFormat();
					 

					 String formattedDate = dateFormat.format(date);
					 
					 name.append(formattedDate);
				  } //end if ()


			   } //end if ()
			   else {
				  name.append(editFieldModel.getValue() );
			   } //end else
			} //end if ()
		 } //end if ()
		 
	  } // end for ()

	  return truncateNameLength(name.toString() );
   }

   private String truncateNameLength(String name) {
	  String result = name;

	  if ( result.length() >= MAXIMUM_DISPLAY_NAME_LENGTH) {
		 result = result.substring(0,MAXIMUM_DISPLAY_NAME_LENGTH - 1);
	  } //end if ()

	  return result;
   }


   public URL getHelpLink() {
	  return helpLink;
   }

   public boolean isNewRecord() {
	  return isNewRecord;

   }

   public ArrayList getChangeListeners() {
	  return changeListeners;
   }

   public ListFieldModel getContainingListModel() {
	  return containingListModel;
   }

   // ==========================================
   // Section Mutators
   // ==========================================
   public void setContainingListModel(ListFieldModel _containingListModel) {
	  this.containingListModel = _containingListModel;
   }


   public void addField(DataFieldModel field) {
	  fields.add(field);
	  fieldHash.put(field.getName(), field);
   }

   /**
	* assumes we are guaranteed that the field name will be legal
	* and that the fieldname will refer to some edit field.  Otherwise,
	* we'll have to toss around exceptions in try-catch loops that can
	* get expensive for large data sets.
	* assume for date fields, it's always in the cannonical format
	*/
   public void setValue(String fieldName, 
						String value,
						boolean _enableSaveChanges) {

	  this.enableSaveChanges = _enableSaveChanges;
	  
	  EditFieldModel editFieldModel
		 = (EditFieldModel) fieldHash.get(fieldName);
	  
	  int uiRenderingType = editFieldModel.getUIRenderingType();
	  if ( uiRenderingType == GlobalConstants.DATE_FIELD) {
		 //we have to deal with date fields in a special way.

		 /*
		 Date date = DateValidator.getCanonicalDate(value);
		 
		 SimpleDateFormat dateFormat
			= DateValidator.getDateFormat();
		 
		 String formattedDate = dateFormat.format(date);
		 */
		 editFieldModel.setValue(value);
	  } //end if ()
	  else {
		 editFieldModel.setValue(value);
	  } //end else

	  isNewRecord= false;
   }

   public ListFieldModel getListModelForChildType(String childType) {
	  ArrayList listFields = getListFields();
	  int numberOfListFields = listFields.size();
	  for ( int i = 0; i < numberOfListFields; i++) {
		 ListFieldModel currentListModel = (ListFieldModel) listFields.get(i);
		 String[] childTypes = currentListModel.getChildTypes();
		 for ( int j = 0; j < childTypes.length; j++) {
			if ( childType.equals(childTypes[j]) == true) {
			   return currentListModel;
			} //end if ()
		 } // end for ()
	  } // end for ()
	  return null;
   }


   /**
	* assumes selection field name will be valid and represent
	* a list field
   */
   public void addChild(String selectionFieldName,
						RecordModel child,
						boolean _enableSaveChanges) {

	  this.enableSaveChanges = _enableSaveChanges;

	  Object field = fieldHash.get(selectionFieldName);
	  ListFieldModel listFieldModel = (ListFieldModel) field;
	  listFieldModel.addChild(child);
	  child.setContainingListModel(listFieldModel);
   }

   /**
	* Set the value of recordClassName.
	* @param recordClassName Value to assign to recordClassName.
	*/
   public void setRecordClassName(String _recordClassName) {
	  this.recordClassName = _recordClassName;
   }

   public void setFields(ArrayList _fields) {
	  this.fields = _fields;
   }

   public void setSaveChanges(boolean _saveChanges) {

	  if ( enableSaveChanges == false) {
		 return;
	  } //end if ()

	  
	  this.saveChanges = _saveChanges;

   }

   public void informListenersOfNameChange() {
	  //recompute the display name
	  String newDisplayName = computeDisplayName();
	  
	  if ( displayName.equals(newDisplayName) == false) {
		 //display name has changed so notify listeners
		 updateDisplayName();
		 notifyListeners(ChangeObject.OBJECT_UPDATED);
	  } //end if ()
	  displayName = newDisplayName;
   }

   public void informListenersOfChildCreation() {
	  notifyListeners(ChangeObject.OBJECT_CREATED);
   }

   public void informListenersOfDestruction() {
	  notifyListeners(ChangeObject.OBJECT_DELETED);
   }

   public void informListenersOfGainedFocus() {
	  notifyListeners(ChangeObject.OBJECT_GAINS_FOCUS);
   }

   public void setNewRecord(boolean _isNewRecord) {
	  this.isNewRecord = _isNewRecord;
   }

   public void clearChangeListeners() {
	  changeListeners.clear();

   }

   public void addChangeListener(ChangeListener changeListener) {
	  changeListeners.add(changeListener);
   }

   public void setChangeListeners(ArrayList _changeListeners) {
	  this.changeListeners = _changeListeners;
   }

   public void setDisplayName(String displayName) {
	  this.displayName = displayName;
   }

   public void updateDisplayName() {
	  this.displayName = computeDisplayName();
   }

   public void enableSaveChanges(boolean _enableSaveChanges) {
	  this.enableSaveChanges = _enableSaveChanges;
   }


   public void setHelpLink(URL helpLink) {
	  this.helpLink = helpLink;
   }

   // ==========================================
   // Section Validation
   // ==========================================
   public String validate() {
	  //reports that there is at least one error 
	  //we could improve this later on, but it will be useful mainly
	  //for showing errors in the tree.

	  int numberOfFields = fields.size();
	  for ( int i = 0; i < numberOfFields; i++) {
		 DataFieldModel currentField 
			= (DataFieldModel) fields.get(i);
		 String validate = currentField.validate();
		 if ( validate != null) {
			return validate;
		 } //end if ()
	  } // end for ()
	  
	  return null;
   }

   public String validateEditFields() {
	  //reports that there is at least one error 
	  //we could improve this later on, but it will be useful mainly
	  //for showing errors in the tree.

	  int numberOfFields = fields.size();
	  for ( int i = 0; i < numberOfFields; i++) {
		 DataFieldModel currentField 
			= (DataFieldModel) fields.get(i);
		 if ( currentField instanceof EditFieldModel) {
			EditFieldModel editFieldModel 
			   = (EditFieldModel) currentField;

			String validate = editFieldModel.validate();
			if ( validate != null) {
			   return validate;
			} //end if ()

		 } //end if ()
		 
	  } // end for ()
	  
	  return null;
   }

   public void print() {
	  int numberOfFields = fields.size();
	  for ( int i = 0; i < numberOfFields; i++) {
		 DataFieldModel currentField 
			= (DataFieldModel) fields.get(i);
		 currentField.print();

	  } // end for ()
   }


   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================



   public Object clone() {
	  RecordModel cloneRecord = new RecordModel();
	  cloneRecord.setRecordClassName(recordClassName);

	  ArrayList cloneFields = new ArrayList();
	  int numberOfFields = fields.size();
	  
	  for ( int i = 0; i < numberOfFields; i++) {
		 DataFieldModel currentField = (DataFieldModel) fields.get(i);
		 DataFieldModel cloneField = (DataFieldModel) currentField.clone();
		 cloneField.setContainingRecord(cloneRecord);
		 cloneRecord.addField( cloneField );
	  } // end for ()

	  //cloneRecord.setFields(cloneFields);
	  cloneRecord.updateDisplayName();

	  return cloneRecord;
   }

   // ==========================================
   // Section Private
   // ==========================================
   private void notifyListeners(int changeType) {
	  ChangeObject changeObject
		 = new ChangeObject(this,
							changeType);
	  fireChangeEvent(changeObject);

   }

   private void notifyListeners(int changeType,
								RecordModel child) {

	  ChangeObject changeObject
		 = new ChangeObject(this,
							changeType);
	  changeObject.setChild(child);
	  fireChangeEvent(changeObject);

   }

   private void fireChangeEvent(ChangeObject changeObject) {
	  ChangeEvent event = new ChangeEvent(changeObject);
	  int numberOfChangeListeners = changeListeners.size();
	  for ( int i = 0; i < numberOfChangeListeners; i++) {
		 ChangeListener currentChangeListener
			= (ChangeListener) changeListeners.get(i);
		 currentChangeListener.stateChanged(event);
	  } // end for ()
   }

}

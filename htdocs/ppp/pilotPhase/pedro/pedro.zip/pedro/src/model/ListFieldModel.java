/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.model;

import java.util.ArrayList;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class ListFieldModel extends DataFieldModel {
   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private ArrayList children;
   private String[] childTypes;

   // ==========================================
   // Section Construction
   // ==========================================
   public ListFieldModel() {
	  children = new ArrayList();
   }

   // ==========================================
   // Section Accessors
   // ==========================================
   public ArrayList getChildren() {
	  return children;
   }

   public boolean isListPopulated() {
	  if ( children.size() > 0) {
		 return true;
	  } //end if ()
	  
	  return false;
   }

   public String[] getChildTypes() {
	  return childTypes;
   }

   // ==========================================
   // Section Mutators
   // ==========================================
   public void addChild(RecordModel recordModel) {
	  children.add(recordModel);
	  containingRecord.setSaveChanges(true);
   }

   /**
	*
	* assumes: child to be removed is in the list of children
	*/
   public void removeChild(RecordModel recordModel) {
	  int index = children.indexOf(recordModel);
	  children.remove(index);
	  containingRecord.setSaveChanges(true);
   }
   
   public void setChildren(ArrayList _children) {
	  this.children = _children;
   }
   
   public void setChildTypes(String[] _childTypes) {
	  this.childTypes = _childTypes;
   }

   // ==========================================
   // Section Validation
   // ==========================================
   public String validate() {
	  if (isRequiredField == true) {
		 if ( children.size() == 0) {
			StringBuffer errorMessage = new StringBuffer();
			errorMessage.append(getName() );
			errorMessage.append("requires at least one subrecord");
			return errorMessage.toString();
		 } //end if ()
	  } //end if ()
	  
	  return null;
   }


   public void print() {
	  StringBuffer buffer = new StringBuffer();
	  
	  buffer.append("LIST name:");
	  buffer.append(getName());
	  buffer.append("\t");
	  buffer.append("Parent:");
	  RecordModel parent = getContainingRecord();
	  if ( parent == null) {
 		 buffer.append("NULL"); 
	  } //end if ()
	  else {
		 buffer.append(parent.getDisplayName());
	  } //end else

	  buffer.append("\n");
	  if ( isRequiredField() == true) {
		 buffer.append("required");
	  } //end if ()
	  else {
		 buffer.append("optional");
	  } //end else

	  buffer.append("\n");
	  buffer.append("Child Types:\n");
	  for ( int i = 0 ; i < childTypes.length; i++) {
		 buffer.append(childTypes[i] + " ");
	  } // end for ()
	  buffer.append("\n");
	  
	  System.out.println(buffer.toString() );
	  

	  System.out.println("Children:");
	  int numberOfChildren = children.size();
	  for ( int i = 0; i < numberOfChildren; i++) {
		 RecordModel recordModel = (RecordModel) children.get(i);
		 recordModel.print();
	  } // end for ()
	  System.out.println("End of child list");
   }


   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================
   public Object clone() {
	  ListFieldModel cloneField = new ListFieldModel();

	  super.populateCloneAttributes(this, cloneField);
	  cloneField.setChildTypes(childTypes);
	  ArrayList cloneChildren = new ArrayList();

	  int numberOfChildren = children.size();
	  for ( int i = 0; i < numberOfChildren; i++) {
		 RecordModel childRecord = (RecordModel) children.get(i);
		 
		 cloneChildren.add( childRecord.clone() );
	  } // end for ()

	  cloneField.setChildren(cloneChildren);
	  return cloneField;
   }

}

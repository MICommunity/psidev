/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.model;


import java.net.URL;
import java.io.Serializable;
import java.lang.Cloneable;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

abstract public class DataFieldModel 
   implements Serializable,
			  Cloneable { 

   
   // ==========================================
   // Section Constants
   // ==========================================

   // ==========================================
   // Section Properties
   // ==========================================
   private String name;
   private URL helpLink;
   protected boolean isRequiredField;
   private int uiRenderingType;
   protected RecordModel containingRecord;

   // ==========================================
   // Section Construction
   // ==========================================
   public DataFieldModel() {
	  init();
   }

   private void init() {
	  name = null;
	  helpLink = null;
	  isRequiredField = false;
   }

   // ==========================================
   // Section Accessors
   // ==========================================

   
   /**
	* Get the value of name.
	* @return value of name.
	*/
   public String getName() {
	  return name;
   }
   
   
   
   
   /**
	* Get the value of helpLink.
	* @return value of helpLink.
	*/
   public URL getHelpLink() {
	  return helpLink;
   }

   public boolean isRequiredField() {
	  return isRequiredField;
   }

   public int getUIRenderingType() {
	  return uiRenderingType;
   }

   public RecordModel getContainingRecord() {
	  return containingRecord;
   }

   // ==========================================
   // Section Mutators
   // ==========================================

   /**
	* Set the value of name.
	* @param name Value to assign to name.
	*/
   public void setName(String _name) {
	  
	  this.name = _name;
   }


   /**
	* Set the value of helpLink.
	* @param helpLink Value to assign to helpLink.
	*/
   public void setHelpLink(URL _helpLink) {
	  
	  this.helpLink = _helpLink;
   }

   public void setRequiredField(boolean _isRequiredField) {
	  this.isRequiredField = _isRequiredField;
   }

   protected void populateCloneAttributes(DataFieldModel original,
										  DataFieldModel copy) {
	  copy.setName(original.getName() );
	  copy.setHelpLink(original.getHelpLink() );
	  copy.setRequiredField(original.isRequiredField() );
	  copy.setUIRenderingType(original.getUIRenderingType() );
   }
   
   public void setUIRenderingType(int _uiRenderingType) {
	  this.uiRenderingType = _uiRenderingType;
   }

   public void setContainingRecord(RecordModel _containingRecord) {
	  containingRecord = _containingRecord;
   }

   // ==========================================
   // Section Validation
   // ==========================================
   abstract public String validate();


   abstract public void print();


   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================
   //Interface: Cloneable
   abstract public Object clone();


   // ==========================================
   // Section Overload
   // ==========================================

}

/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.model;

import java.util.ArrayList;
import pedro.ontology.OntologyService;



/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class TextFieldModel extends EditFieldModel {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   //private ArrayList ontologyServices;

   // ==========================================
   // Section Construction
   // ==========================================
   public TextFieldModel() {
	  //ontologyServices = new ArrayList();
   }

   // ==========================================
   // Section Accessors
   // ==========================================
   /*
   public ArrayList getOntologyServices() {
	  return ontologyServices;
   }
   */


   // ==========================================
   // Section Mutators
   // ==========================================

   /*
   public void addOntologyService(OntologyService ontologyService) {
	  ontologyServices.add(ontologyService);
   }

   public void setOntologyServices(ArrayList _ontologyServices) {
	  this.ontologyServices = _ontologyServices;
   }
   */

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================
   public Object clone() {
	  TextFieldModel cloneField = new TextFieldModel();
	  super.populateCloneAttributes(this,cloneField);
	  //cloneField.setOntologyServices(ontologyServices);

	  return cloneField;
   }


}

/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.model;


import java.util.Hashtable;
import java.io.File;
import java.util.ArrayList;
import java.net.URL;

import pedro.util.ErrorDialog;
import pedro.system.GlobalConstants;



/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class RecordModelFactory {

   
   // ==========================================
   // Section Constants
   // ==========================================
   

   // ==========================================
   // Section Properties
   // ==========================================
   private static RecordModelFactory recordFactory = null;
   private Hashtable recordFactoryObjects;
   private Hashtable listFactoryObjects;
   private String topLevelRecordModelClass;
   //private String schemaName;
   //private String schemaXMLN;


   // ==========================================
   // Section Construction
   // ==========================================
   public RecordModelFactory() {
	  recordFactoryObjects = new Hashtable();
	  listFactoryObjects = new Hashtable();
	  topLevelRecordModelClass = null;
   }



   // ==========================================
   // Section Accessors
   // ==========================================
   public static RecordModelFactory getRecordModelFactory() {
	  if (recordFactory == null) {
		 recordFactory = new RecordModelFactory();
	  } //end if ()


	  return recordFactory;
   }

   public RecordModel createRecordModel(String recordClassTag) {
	  RecordModel record = (RecordModel) recordFactoryObjects.get(recordClassTag);

	  RecordModel clone = (RecordModel) record.clone();
	  clone.setNewRecord(true);
	  return clone;
   }
   
   public boolean recordClassRegistered(String recordClassTag) {

	  if ( recordFactoryObjects.get(recordClassTag) == null) {
		 return false;
	  } //end if ()
	  
	  return true;
	  
   }

   public String getStyleSheetStamp() {
	  StringBuffer styleSheetStamp = new StringBuffer();
	  String styleSheet = GlobalConstants.getStyleSheet();
	  if ( styleSheet == null) {
		 return null;
	  } //end if ()
	  
	  return null;

	  /**
	   * this is really wierd -- if you alter only the first x to something like
	   * <?rml-stylesheet....
	   * it works.  Otherwise, if it is
	   * <?xml-stylesheet ...
	   * then it causes errors.
	   * leave stylesheet capability out until this matter is resolved.

	  styleSheetStamp.append("<?xml-stylesheet type=\"text/xsl\" href=\"");
	  styleSheetStamp.append(styleSheet);
	  styleSheetStamp.append("\"?>");
	  System.out.println("=="+styleSheetStamp+"==");

	  return styleSheetStamp.toString();
	   */


   }

   public String getModelStamp() {
	  StringBuffer fileStamp = new StringBuffer();

	  String schemaXMLN = GlobalConstants.getSchemaInstance();
	  String schemaName = GlobalConstants.getModelName();

	  //Systeem.out.println("styleSheet=="+styleSheet+"==");

	  if ( schemaXMLN != null) {
		 if ( schemaXMLN.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) == false) {
			fileStamp.append("xmlns=\"pd\" ");
			fileStamp.append("xmlns:xsi=\"");
			fileStamp.append(schemaXMLN);

			if ( schemaXMLN.endsWith("XMLSchema") == true) {
			   fileStamp.append("-instance");
			} //end if ()

			fileStamp.append("\" ");
		 } //end if ()
		 
	  } //end if ()
	  
	  fileStamp.append("xsi:schemaLocation=\"pd ");
	  fileStamp.append(schemaName);
	  fileStamp.append("\"");

	  return fileStamp.toString();
   }


   public RecordModel createTopLevelRecordModel() {
	  if ( topLevelRecordModelClass == null) {
		 return null;
	  } //end if ()

	  return createRecordModel(topLevelRecordModelClass);
   }

   /*
   public String getSchemaName() {
	  return schemaName;
   }
   */

   public String getTopLevelRecordModelClass() {
	  return topLevelRecordModelClass;
   }

   public ArrayList getRecordFactories() {
	  ArrayList factories = new ArrayList();
	  factories.addAll(recordFactoryObjects.values() );
	  return factories;
   }

   public boolean schemaMatchesCurrentDataModel(String applicationSchema,
												String dataFileSchema) {
	  //get last bit of schema name, just the file name
	  //if the experimentFileSchema matches the end file name, then
	  //we'll assume that the same schema is being used.
	  int lastSlashIndex = applicationSchema.lastIndexOf(File.separator);
	  String fileName = applicationSchema.substring(lastSlashIndex);
	  
	  return( dataFileSchema.endsWith(fileName) );
   }
   

   public ListFieldModel getListFieldModelForProxy(ProxyListFieldModel proxyListFieldModel) {
	  String listFactoryName = proxyListFieldModel.getListFactoryName();
	  
	  ListFieldModel listFieldFactory = 
		 (ListFieldModel) listFactoryObjects.get(listFactoryName);


	  if ( listFieldFactory == null) {
		 return null;
	  } //end if ()
	  
	  ListFieldModel clonedListField = (ListFieldModel) listFieldFactory.clone();
	  
	  //eg: <xs:group name="field1" ref="Group1" minOccurs="1" maxOccurs="2"/>
	  //...
	  //...
	  //<xs:group name="Group1">
	  //   <xs:choice>
	  //      ...
	  //   </xs:choice>
	  //</xs:group>
	  
	  clonedListField.setName(proxyListFieldModel.getName() );
	  clonedListField.setRequiredField(proxyListFieldModel.isRequiredField() );
	  
	  //All proxy list fields defined in a group tag will have multiple types
	  if ( proxyListFieldModel.isMultipleValueList() == true) {
		 clonedListField.setUIRenderingType(GlobalConstants.N_TYPE_N_VALUE_LIST);
	  } //end if ()
	  else {
		 clonedListField.setUIRenderingType(GlobalConstants.N_TYPE_ONE_VALUE_LIST);
	  } //end else
	  
	  return clonedListField;

   }

   // ==========================================
   // Section Mutators
   // ==========================================
   public void resolveProxyFields() {
	  ArrayList recordFactories = getRecordFactories();

	  int numberOfFactories = recordFactories.size();
	  for ( int i = 0; i < numberOfFactories; i++) {
		 RecordModel currentRecordFactory
			= (RecordModel) recordFactories.get(i);
		 resolveModelProxyFields(currentRecordFactory);

	  } // end for ()

   }

   private void resolveModelProxyFields(RecordModel recordModel) {

	  ArrayList proxyFields = recordModel.getProxyListFields();
	  int numberOfProxyFields = proxyFields.size();


	  for ( int i = 0; i < numberOfProxyFields; i++) {

		 ProxyListFieldModel currentProxyFieldModel
			= (ProxyListFieldModel) proxyFields.get(i);

		 ListFieldModel completeListField
			= getListFieldModelForProxy(currentProxyFieldModel);

		 recordModel.replaceField(currentProxyFieldModel,
								  completeListField);

	  } // end for ()

   }
   /*
   public void setSchemaName(String schemaName) {
	  this.schemaName = schemaName;
   }
   */


   public void setTopLevelRecordModelClass(String topLevelRecordModelClass) {
	  this.topLevelRecordModelClass = topLevelRecordModelClass;
   }

   public void addFactory(String recordClassTag, 
						  RecordModel recordObject) {
 
	  recordFactoryObjects.put(recordClassTag, recordObject);
   }

   public void addListFieldFactory(String listFieldFactoryName,
								   ListFieldModel listFieldModelObject) {

	  Object listFactory = listFactoryObjects.get(listFieldFactoryName);
	  if ( listFactory == null) {
		 listFactoryObjects.put(listFieldFactoryName,
								listFieldModelObject);
	  } //end if ()
   }

   /*
   public void setSchemaXMLN(String _schemaXMLN) {
	  this.schemaXMLN = _schemaXMLN;
   }
   */

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================

}

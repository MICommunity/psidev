/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.model;

import java.util.ArrayList;

import pedro.validation.Validator;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class EditFieldModel extends DataFieldModel {

   
   // ==========================================
   // Section Constants
   // ==========================================

   // ==========================================
   // Section Properties
   // ==========================================
   private String value;
   private String defaultValue;
   private ArrayList validators;
   private boolean isDisplayNameComponent;
   private String units;

   // ==========================================
   // Section Construction
   // ==========================================
   public EditFieldModel() {
	  validators = new ArrayList();
	  value = "";
	  units = "";
   }

   // ==========================================
   // Section Accessors
   // ==========================================

   /**
	* Get the value of value.
	* @return value of value.
	*/
   public String getValue() {
	  return value;
   }

   /**
	* Get the value of defaultValue.
	* @return value of defaultValue.
	*/
   public String getDefaultValue() {
	  return defaultValue;
   }

   public ArrayList getValidators() {
	  return validators;
   }
   
   public String getUnits() {
	  return units;
   }

   // ==========================================
   // Section Mutators
   // ==========================================

   public void setDisplayNameComponent(boolean _isDisplayNameComponent) {
	  this.isDisplayNameComponent = _isDisplayNameComponent;
   }

   /**
	* Set the value of value.
	* assumes that whatever calls this model method has already checked
	* to see if it is in fact a different value than before
	* @param value Value to assign to value.
	*/
   public void setValue(String _value) {
	  this.value = _value;

	  if ( containingRecord != null) {
		 containingRecord.setSaveChanges(true);
	  } //end if ()
   }

   /**
	* Set the value of defaultValue.
	* @param defaultValue Value to assign to defaultValue.
	*/
   public void setDefaultValue(String _defaultValue) {
	  this.defaultValue = _defaultValue;
   }


   public void addValidator(Validator validator) {
	  validator.setFieldName(getName() );
	  validator.setRequiredField(isRequiredField());

	  validators.add(validator);
   }

   public void setValidators(ArrayList _validators) {
	  this.validators = _validators;
   }

   public void setRequiredField(boolean isRequiredField) {
	  super.setRequiredField(isRequiredField);
	  
	  if ( validators.size() > 0) {
		 //if there are any validators, then make sure
		 //they use this value; otherwise we depend on 
		 //an ordering of method calls and if isRequiredField has not
		 //yet been set, the defaul will be false
		 int numberOfValidators = validators.size();

		 for ( int i = 0; i < numberOfValidators; i++) {
			Validator currentValidator = (Validator) validators.get(i);
			currentValidator.setRequiredField(isRequiredField);
		 } // end for ()

	  } //end if ()

   }

   public void setUnits(String _units) {
	  this.units = _units;
   }

   public boolean isDisplayNameComponent() {
	  return isDisplayNameComponent;
   }

   public String validate() {
	  return validate(value);
   }
   public String validate(String value) {

	  //validators are processed in the order in which they are added.
	  //only one error per field is reported.

	  int numberOfValidators = validators.size();
	  for ( int i = 0; i < numberOfValidators; i++) {
		 Validator currentValidator = (Validator) validators.get(i);
		 String error = currentValidator.validate( value );
		 if ( error != null) {
			return error;
		 } //end if ()
	  } // end for ()

	  return null;
   }

   // ==========================================
   // Section Validation
   // ==========================================
   public void print() {
	  StringBuffer buffer = new StringBuffer();
	  
	  buffer.append("Edit Field:");
	  buffer.append(getName());
	  buffer.append("\t");
	  buffer.append("Parent:");
	  RecordModel parent = getContainingRecord();
	  if ( parent == null) {
 		 buffer.append("NULL"); 
	  } //end if ()
	  else {
		 buffer.append(parent.getDisplayName());
	  } //end else

	  buffer.append("\n");
	  buffer.append("Value:");
	  buffer.append(getValue());
	  buffer.append("\t");
	  if ( isRequiredField() == true) {
		 buffer.append("required");
	  } //end if ()
	  else {
		 buffer.append("optional");
	  } //end else

   }

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================
   public Object clone() {
	  EditFieldModel cloneField = new EditFieldModel();
	  
	  populateCloneAttributes(this,
							  cloneField);


	  return cloneField;
   }

   protected void populateCloneAttributes(EditFieldModel original,
										  EditFieldModel copy) {

	  super.populateCloneAttributes(original,
									copy);

	  copy.setValue(original.getValue() );
	  copy.setValidators(original.getValidators() );
	  copy.setDefaultValue(original.getDefaultValue() );
	  copy.setUnits(original.getUnits() );
	  copy.setDisplayNameComponent(original.isDisplayNameComponent() );

   }




}

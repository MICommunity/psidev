/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
* @version 1.0
*
*/

package pedro.model;

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class ProxyListFieldModel extends ListFieldModel {

   
   // ==========================================
   // Section Constants
   // ==========================================

 

   // ==========================================
   // Section Properties
   // ==========================================
   private String listFactoryName;
   private boolean multipleValueList;

   // ==========================================
   // Section Construction
   // ==========================================
   

   // ==========================================
   // Section Accessors
   // ==========================================
   public String getListFactoryName() {
	  return listFactoryName;
   }

   public boolean isMultipleValueList() {
	  return multipleValueList;
   }

   // ==========================================
   // Section Mutators
   // ==========================================
   public void setListFactoryName(String _listFactoryName) {
	  this.listFactoryName = _listFactoryName;
   }

   public void setMultipleValueList(boolean _multipleValueList) {
	  this.multipleValueList = _multipleValueList;
   }

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================
   public String validate() {
	  return "";
   }

   public void print(){}

   public Object clone() {
	  System.out.println("ProxyListFieldModel - shouldn't be here!");
	  return null;
   }

}

/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.model;


/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class ChangeObject {

   
   // ==========================================
   // Section Constants
   // ==========================================
   public static final int OBJECT_DELETED = 12;
   public static final int OBJECT_UPDATED = 13;
   public static final int OBJECT_CANCELLED = 14;
   public static final int OBJECT_GAINS_FOCUS = 15;
   public static final int OBJECT_CREATED = 16;

   // ==========================================
   // Section Properties
   // ==========================================
   private RecordModel recordModel;
   private int changeType;
   private RecordModel child;

   // ==========================================
   // Section Construction
   // ==========================================
   public ChangeObject(RecordModel recordModel,
					   int changeType) {

	  this.recordModel = recordModel;
	  this.changeType = changeType;
   }

   // ==========================================
   // Section Accessors
   // ==========================================
   public int getChangeType() {
	  return changeType;
   }

   public RecordModel getRecord() {
	  return recordModel;
   }

   public RecordModel getChild() {
	  return child;
   }
   // ==========================================
   // Section Mutators
   // ==========================================
   public void setChild(RecordModel _child) {
	  this.child = _child;
   }
   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================

}

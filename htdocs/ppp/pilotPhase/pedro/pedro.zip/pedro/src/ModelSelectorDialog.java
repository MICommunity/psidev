/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
* @version 1.0
*
*/

package pedro.system;

import javax.swing.JDialog;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import javax.swing.JPanel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.ListSelectionModel;
/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class ModelSelectorDialog extends JDialog 
   implements ActionListener {

   
   // ==========================================
   // Section Constants
   // ==========================================
   public static void main (String[] args) {
	   ModelSelectorDialog dialog
		  = new ModelSelectorDialog();
	   dialog.show();
   } // end main ()

   // ==========================================
   // Section Properties
   // ==========================================
   private JButton ok;
   private JButton cancel;
   private JList modelList;
   private JLabel instructionsLabel;
   private JTextArea instructions;
   // ==========================================
   // Section Construction
   // ==========================================
   public ModelSelectorDialog() {
	  setTitle("Model Selection Dialog");

	  JPanel panel = new JPanel(new GridBagLayout() );
	  GridBagConstraints panelGC = new GridBagConstraints();
	  panelGC.fill = GridBagConstraints.NONE;
	  panelGC.anchor = GridBagConstraints.NORTHWEST;
	  panelGC.gridx = 0;
	  panelGC.gridy = 0;

	  instructionsLabel = new JLabel("Instructions:");
	  panel.add(instructionsLabel, panelGC);

	  panelGC.gridy++;
	  instructions = new JTextArea(2,20);
	  instructions.append("Pedro has detected that you have multiple models");
	  instructions.append(" installed.  Please choose a model and press \"OK\"");
	  instructions.setEditable(false);
	  instructions.setLineWrap(true);
	  instructions.setWrapStyleWord(true);
	  instructions.setBackground( instructionsLabel.getBackground() );
	  panelGC.fill = GridBagConstraints.HORIZONTAL;
	  panel.add(instructions, panelGC);

	  modelList = new JList();
	  modelList.setPrototypeCellValue("                     ");
	  modelList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	  JScrollPane modelPane = new JScrollPane(modelList);
	  panelGC.fill = GridBagConstraints.BOTH;
	  panelGC.anchor = GridBagConstraints.NORTHWEST;
	  panelGC.weightx = 100;
	  panelGC.weighty = 100;
	  panelGC.gridy++;
	  panel.add(modelPane, panelGC);

	  panelGC.fill = GridBagConstraints.NONE;
	  panelGC.anchor = GridBagConstraints.SOUTHEAST;
	  panelGC.gridy++;
	  panel.add(createButtonPanel(), panelGC);

	  setModal(true);

	  getContentPane().add(panel);
	  pack();
   }


   private JPanel createButtonPanel() {

	  JPanel panel = new JPanel(new GridBagLayout() );
	  GridBagConstraints panelGC = new GridBagConstraints();
	  panelGC.fill = GridBagConstraints.NONE;
	  panelGC.anchor = GridBagConstraints.SOUTHEAST;
	  panelGC.gridx = 0;
	  panelGC.gridy = 0;
	  
	  panelGC.weightx = 0;
	  panelGC.weighty = 0;

	  ok = new JButton("OK");
	  ok.addActionListener(this);
	  panel.add(ok, panelGC);
	  panelGC.gridx++;
	  
	  cancel = new JButton("Cancel");
	  cancel.addActionListener(this);
	  panel.add(cancel);
	  
	  return panel;

   }

   // ==========================================
   // Section Accessors
   // ==========================================
   public String getSelectedModel() {
	  String selectedValue = (String) modelList.getSelectedValue();
	  return selectedValue;
   }

   // ==========================================
   // Section Mutators
   // ==========================================
   public void setModels(String[] models) {
	  modelList.setListData(models);
	  if ( models.length > 0) {
		 modelList.setSelectedIndex(0);
	  } //end if ()
	  
   }


   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================
   //Interface: ActionListener
   public void actionPerformed(ActionEvent event) {
	  Object source = event.getSource();
	  if ( source == ok) {
		 dispose();
	  } //end if ()
	  else if ( source == cancel) {
		 System.exit(0);
	  } //end else ()

   }


   // ==========================================
   // Section Overload
   // ==========================================

}

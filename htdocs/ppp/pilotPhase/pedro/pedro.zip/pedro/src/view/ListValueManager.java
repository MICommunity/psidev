/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.view;

import java.awt.Font;
import java.awt.Component;
import java.util.ArrayList;

import pedro.model.ListFieldModel;
import pedro.model.RecordModel;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

public interface ListValueManager {
   public void setFont(Font font);
   public void reset();
   public void setModel(ListFieldModel listFieldModel);
   public Component getEditButtons();
   public Component getListArea();
   public RecordModel getSelectedRecordModel();
   public void refresh();
}

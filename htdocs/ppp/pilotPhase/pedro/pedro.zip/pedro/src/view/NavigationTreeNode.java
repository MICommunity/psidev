/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.view;

import javax.swing.tree.DefaultMutableTreeNode;

import pedro.model.RecordModel;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class NavigationTreeNode extends DefaultMutableTreeNode {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================

   private RecordModel recordModel;
   private boolean isSelected;
   private boolean showSearchResult;
   private boolean showDeleted;
   private boolean showMissing;
   private boolean showError;
   private boolean isChanged;

   // ==========================================
   // Section Construction
   // ==========================================
   public NavigationTreeNode(RecordModel recordModel) {
	  this.recordModel = recordModel;
	  setUserObject(recordModel.getDisplayName() );
	  isSelected = false;
	  showSearchResult = false;
	  showDeleted = false;
	  showMissing = false;
	  showError = false;
	  
	  isChanged = false;

   }

   // ==========================================
   // Section Accessors
   // ==========================================

   public String getDisplayName() {
	  return userObject.toString();
   }
   
   public RecordModel getRecordModel() {
	  return recordModel;
   }

   public boolean isSelected() {
	  return isSelected;
   }

   public boolean showSearchResult() {
	  return showSearchResult;
   }

   public boolean showDeleted() {
	  return showDeleted;
   }

   public boolean showMissing() {
	  return showMissing;
   }
   public boolean showError() {
	  return showError;
   }

   public boolean isChanged() {
	  return isChanged;
   }

   // ==========================================
   // Section Mutators
   // ==========================================
   public void setSelected(boolean _isSelected) {
	  this.isSelected = _isSelected;
   }

   public void setDisplayName(String displayName) {
	  setUserObject(displayName);
   }

   public void setShowSearchResult(boolean _showSearchResult) {
	  if ( showSearchResult == true) {
		 System.out.println("setShowSearchResult is true!!!");
		 
	  } //end if ()
	  
	  this.showSearchResult = _showSearchResult;
   }

   public void setChanged(boolean _isChanged) {
	  this.isChanged = _isChanged;
   }

   public void setShowDeleted(boolean _showDeleted) {

	  this.showDeleted = _showDeleted;

	  //go through all the other child nodes of this one and 
	  //make them deleted as well
	  int numberOfChildren = getChildCount();
	  for ( int i = 0; i < numberOfChildren; i++) {
		 NavigationTreeNode currentChild = (NavigationTreeNode) getChildAt(i);
		 currentChild.setShowDeleted(showDeleted);
	  } // end for ()
	  

   }
   
   public void setShowMissing(boolean _showMissing) {
	  this.showMissing = true;
   }

   public void setShowError(boolean _showError) {
	  this.showError = _showError;
   }

   public void setRecordModel(RecordModel _recordModel) {
	  this.recordModel = _recordModel;
	  setUserObject(recordModel.getDisplayName() );
   }

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================

}

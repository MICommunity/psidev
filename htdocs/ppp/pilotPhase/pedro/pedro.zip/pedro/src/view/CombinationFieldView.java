/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.view;

import javax.swing.JComboBox;
import java.io.File;

import pedro.system.GlobalConstants;
import pedro.model.GroupFieldModel;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class CombinationFieldView extends EditFieldView {

   
   // ==========================================
   // Section Constants
   // ==========================================

   // ==========================================
   // Section Properties
   // ==========================================
   private JComboBox comboBox;
   private String[] choices;
   private String savedValue;
   private GroupFieldModel groupFieldModel;
   // ==========================================
   // Section Construction
   // ==========================================

   public CombinationFieldView() {
	  comboBox = new JComboBox();
	  setActivityArea(comboBox);
   }
						   
   public void setModel(GroupFieldModel _groupFieldModel) {
	  this.groupFieldModel = _groupFieldModel;

	  super.setModel(groupFieldModel);
	  
	  String choices[] = groupFieldModel.getChoices();
	  comboBox.removeAllItems();
	  comboBox.addItem(GlobalConstants.NONE);
	  for ( int i =0; i < choices.length; i++) {
		 comboBox.addItem(choices[i]);
	  } // end for ()

	  String modelValue = groupFieldModel.getValue();
	  if ( modelValue.equals("") == true) {
		 comboBox.setSelectedItem(GlobalConstants.NONE);
	  } //end if ()
	  else {
		 comboBox.setSelectedItem(modelValue);
	  } //end else
   }

   // ==========================================
   // Section Accessors
   // ==========================================

   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================
   public String validate(boolean highlightErrors) {
	  String selectedItem = (String) comboBox.getSelectedItem();
	  return showErrors(selectedItem,
						highlightErrors);
   }

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================
   public void keepValue() {
	  if ( isDirty() == false) {
		 return;
	  } //end if ()
	  
	  String selectedValue = (String) comboBox.getSelectedItem();
	  groupFieldModel.setValue(selectedValue);
   }

   public boolean isDirty() {
	  String savedValue = groupFieldModel.getValue();
	  String currentValue = (String) comboBox.getSelectedItem();
	  
	  if ( savedValue.equals(currentValue) == true) {
		 return false;
	  } //end if ()
	  else {
		 return true;
	  } //end else
   }

   public void restoreValue() {
	  comboBox.setSelectedItem(groupFieldModel.getValue() );
   }


}

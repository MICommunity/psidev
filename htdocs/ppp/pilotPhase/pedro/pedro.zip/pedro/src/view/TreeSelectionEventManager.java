/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.view;

import javax.swing.event.TreeSelectionListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.tree.TreePath;
import javax.swing.tree.DefaultTreeModel;
import java.io.Serializable;

import pedro.system.GlobalConstants;
import pedro.util.ErrorDialog;
import pedro.model.RecordModel;
import pedro.system.PedroException;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class TreeSelectionEventManager implements TreeSelectionListener {

   
   // ==========================================
   // Section Constants
   // ==========================================
   private static final int IGNORE_UPDATE_STAGE_0 = 11;
   private static final int IGNORE_UPDATE_STAGE_1 = 12;
   private static final int IGNORE_UPDATE_STAGE_2 = 13;
 
   // ==========================================
   // Section Properties
   // ==========================================
   private NavigationTree navigationTree;
   private RecordView recordView;
   private NavigationTreeNode sourceNode;
   private RecordModel sourceRecordModel;
   private NavigationTreeNode destinationNode;
   private RecordModel destinationRecordModel;
   private boolean isAdjusting;
   private NavigationTreeNode selectedNode;
   private boolean ignoreValueChanged;
   private boolean missingNodeSelected;
   private NavigationTreeNode nodeBeforeMissingNode;

   // ==========================================
   // Section Construction
   // ==========================================
   public TreeSelectionEventManager(NavigationTree navigationTree) {
	  
	  this.navigationTree = navigationTree;
	  isAdjusting = false;
	  selectedNode = null;
	  ignoreValueChanged = false;
	  missingNodeSelected = false;

   }


   private void checkSourceAndDestinationNodes() {

	  StringBuffer buffer = new StringBuffer();
	  buffer.append("=============CHECK====\n");
	  if ( sourceNode == null) {
		 buffer.append("Source==NULL");
	  } //end if ()
	  else {
		 RecordModel sourceRecordModel = sourceNode.getRecordModel();
		 buffer.append("Source=="+sourceRecordModel.getDisplayName());
		 buffer.append("\n");
	  } //end else
	  
	  if ( destinationNode == null) {
		 buffer.append("Destination==NULL");
	  } //end if ()
	  else {
		 RecordModel destinationRecordModel = destinationNode.getRecordModel();
		 buffer.append("Destination=="+destinationRecordModel.getDisplayName());
		 buffer.append("\n");
	  } //end else
	  
	  //System.out.println(buffer.toString() );
   }


   private void setSourceAndDestinationNodes(TreeSelectionEvent event) {
	  checkSourceAndDestinationNodes();

	  TreePath sourcePath = event.getOldLeadSelectionPath();
	  StringBuffer buffer = new StringBuffer();
	  buffer.append("=======================================\n");
	  if ( missingNodeSelected == true) {
		 missingNodeSelected = false;
		 sourceNode = nodeBeforeMissingNode;
		 if ( sourceNode == null) {
			sourceRecordModel = null;
		 } //end if ()
		 else {
			sourceRecordModel = sourceNode.getRecordModel();
		 } //end else
	  } //end if ()
	  else if ( sourcePath == null) {
		 if ( ignoreValueChanged == true) {
			ignoreValueChanged = false;

			if ( destinationNode == null) {
			   sourceNode = null;
			   sourceRecordModel = null;
			   buffer.append("Source=NULL\n");
			} //end if ()
			else {
			   sourceNode = destinationNode;
			   sourceRecordModel = sourceNode.getRecordModel();
			   buffer.append("Source=" + sourceRecordModel.getDisplayName() + "\n" );
			} //end else
		 } //end if ()
		 else {
			sourceNode = null;
			sourceRecordModel = null;
			buffer.append("Source=NULL\n");
		 }
	  } //end if ()
	  else {
		 sourceNode = (NavigationTreeNode) sourcePath.getLastPathComponent();
		 sourceRecordModel = sourceNode.getRecordModel();
		 buffer.append("Source=" + sourceRecordModel.getDisplayName() + "\n" );
	  } //end else

	  TreePath destinationPath = event.getNewLeadSelectionPath();
	  if ( destinationPath == null) {
		 destinationNode = null;
		 destinationRecordModel = null;
		 buffer.append("Destination=NULL");
	  } //end if ()
	  else {
		 destinationNode = (NavigationTreeNode) destinationPath.getLastPathComponent();
		 destinationRecordModel = destinationNode.getRecordModel();
		 buffer.append("Destination=" + destinationRecordModel.getDisplayName() );
	  } //end else

	  buffer.append("\n=======================================");
	  //System.out.println(buffer.toString());
   }

   private boolean acceptRecordModelModifications() {
	  String errors = recordView.validateEditFields(true);
	  if ( errors.equals("") == false) {
		 ErrorDialog.show(errors);
		 return false;
	  } //end if ()
	  else {
		 if (recordView.isDirty() == true) {
			//prompt user to save changes
			
 
			ImageIcon warningIcon 
			   = new ImageIcon(GlobalConstants.ICON_PATH + "warning.jpg");
			
			int answer = JOptionPane.showConfirmDialog(null, 
													   "Save changes to current record?", 
													   "Save Changes", 
													   JOptionPane.YES_NO_OPTION,
													   JOptionPane.WARNING_MESSAGE,
													   null);
			
			if ( answer == JOptionPane.YES_OPTION) {
			   //record.updateNode(record);
			   try {
				  recordView.keepValues();
			   } catch (PedroException err) {
				  ErrorDialog.show(err.getMessage() );
			   } // end try-catch
			   

			} //end if ()
			else {
			   recordView.cancel();
			} //end else
			
		 } //end else

		 return true;
	  }
	  
   }
	  
	  
   // ==========================================
   // Section Accessors
   // ==========================================
   public void setRecordView(RecordView recordView) {
	  this.recordView = recordView;
   }

   public void ignore() {
	  ignoreValueChanged = true;
	  //ignoreValueChanged = IGNORE_UPDATE_STAGE_1;
   }

   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================
   



   // ==========================================
   // Section Interfaces
   // ==========================================

   private static int counter = 0;


   private boolean missingNodeSelected(TreeSelectionEvent event) {

	  TreePath selectionPath = event.getNewLeadSelectionPath();
	  if ( selectionPath != null) {
		 NavigationTreeNode selectedNode 
			= (NavigationTreeNode) selectionPath.getLastPathComponent();

		 if ( selectedNode.showMissing() == true) {
			missingNodeSelected = true;
			nodeBeforeMissingNode = destinationNode;
			return true;
		 } //end if ()

	  } //end else

	  return false;
   }


   public void valueChanged(TreeSelectionEvent event) {

	  counter++;
	  //check if it's a missing node

	  if ( missingNodeSelected(event) == true) {
		 return;
	  } //end if ()


	  setSourceAndDestinationNodes(event);
	  if ( sourceRecordModel == null) {
		 //happens if:
		 //first node selected or node was just deleted 
		 //and control passed to parent node
		 
		 updateSelectedNode(destinationNode);
		 
		 if ( destinationRecordModel != null) {
			recordView.setModel(destinationRecordModel);
			navigationTree.repaint();
		 } //end if ()
		 else {
			//when we try to show errors, select an error node
			//and then try to move to another node, we're left with
			//no selected node.

		 } //end else
		 

		 //navigationTree.updateUI();
	  } //end if ()
	  else if ( destinationRecordModel == null) {
		 return;
	  } //end else ()
	  else {
		 //both source and destination known
		 if (acceptRecordModelModifications() == false) {
			//something is wrong with the old record
			navigationTree.removeTreeSelectionListener(this);

			setActiveNode(sourceNode);
			navigationTree.addTreeSelectionListener(this);

			//recordView.setModel(sourceRecordModel);
		 } //end if ()
		 else {
			//setActiveNode(destinationNode);
			updateSelectedNode(destinationNode);
			recordView.setModel(destinationRecordModel);
			navigationTree.repaint();
		 }


		 /*
		 System.out.println("TSEM VC - 3 "+counter);
		 if ( isAdjusting == false) {
		 System.out.println("TSEM VC - 3-1 "+counter);

			//System.out.println("1 modifications accepted");
			updateSelectedNode(destinationNode);
			recordView.setRecordModel(destinationRecordModel);
			navigationTree.repaint();
			//System.out.println("2 modifications accepted");


		 } //end if ()
		 else {
		 System.out.println("TSEM VC - 4 "+counter);

			//trying to change this
			
			else {
			   updateSelectedNode(destinationNode);
			   recordView.setRecordModel(destinationRecordModel);
			   isAdjusting = false;
			} //end else
			

			//navigationTree.updateUI();
		 } //end else
		 */
		 
	  } //end else

   }

   public void setActiveNode(NavigationTreeNode selectedNode) {
	  DefaultTreeModel model = (DefaultTreeModel) navigationTree.getModel();
	  TreePath activePath = new TreePath(model.getPathToRoot(selectedNode) );
	  //updateSelectedNode(selectedNode);
	  if ( navigationTree.isPathSelected(activePath) == false) {

		 updateSelectedNode(selectedNode);
		 navigationTree.setSelectionPath( activePath );
		 //navigationTree.updateUI();
	  } //end if ()
   }

   private void updateSelectedNode(NavigationTreeNode node) {
	  if ( selectedNode != null) {
		 selectedNode.setSelected(false);
	  } //end if ()
	  
	  selectedNode = node;
	  if ( selectedNode != null) {
		 selectedNode.setSelected(true);
	  } //end if ()
	  
   }

   // ==========================================
   // Section Overload
   // ==========================================

}

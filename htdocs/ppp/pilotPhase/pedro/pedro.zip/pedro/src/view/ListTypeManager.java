/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.view;

import java.awt.Font;
import java.awt.Component;
import java.awt.event.ActionListener;

import pedro.model.ListFieldModel;
import pedro.model.RecordModel;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

public interface ListTypeManager {

   public void reset();
   public String getSelectedType();
   public RecordModel createRecordModelFromType();
   public void setModel(ListFieldModel listFieldModel);
   public void setFont(Font font);
   public Component getTypeArea();
   public void setListTypeListener(ListTypeListener listTypeListener);
}

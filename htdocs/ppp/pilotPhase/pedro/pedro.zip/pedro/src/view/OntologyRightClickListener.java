/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.view;

import pedro.ontology.DefaultOntologyProvider;
import pedro.ontology.OntologyServiceManager;
import pedro.ontology.OntologyListener;
import java.awt.Component;
import java.util.ArrayList;
import java.awt.event.InputEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import javax.swing.JPopupMenu;


/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class OntologyRightClickListener extends MouseAdapter {
   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private ArrayList ontologyServices;
   private DefaultOntologyProvider provider;
   private Component invoker;

   // ==========================================
   // Section Construction
   // ==========================================


   // ==========================================
   // Section Accessors
   // ==========================================
   public OntologyRightClickListener(Component invoker,
									 OntologyListener ontologyListener,
									 OntologyServiceManager ontologyServiceManager) {
	  
	  this.invoker = invoker;
	  this.ontologyServices = ontologyServices;

	  provider = new DefaultOntologyProvider(ontologyServiceManager);
	  provider.setOntologyListener(ontologyListener);

   }

   public void mouseClicked(MouseEvent event) {
	  int modifiers = event.getModifiers();
	  if ( (modifiers & InputEvent.BUTTON1_MASK) == 0) {
		 JPopupMenu menu = provider.getMenu();
		 menu.show(invoker,
				   event.getX(), 
				   event.getY() ); 
	  } //end if ()
   }



   // ==========================================
   // Section Mutators
   // ==========================================
   public void allowClearValuesOption(boolean allowClearValuesButton) {
	  provider.allowClearValuesOption(allowClearValuesButton);
   }

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================

}

/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.view;

import javax.swing.JLabel;
import java.util.ArrayList;

import javax.swing.JPanel;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import pedro.model.ListFieldModel;

/**
 * @authorm Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class MTMVListFieldView extends ListFieldView {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================

   // ==========================================
   // Section Construction
   // ==========================================

   public MTMVListFieldView(RecordView recordView) {
	  super();

	  ListTypeManager listTypeManager
		 = new MultiListTypeManager();

	  ListValueManager listValueManager
		 = new MultiListValueManager(listTypeManager,
									 recordView);

	  setListTypeManager(listTypeManager);
	  setListValueManager(listValueManager);

	  setActivityArea(createActivityArea() );

   }



   private JPanel createActivityArea() {
	  JPanel panel = new JPanel(new GridBagLayout() );

	  GridBagConstraints panelGC = new GridBagConstraints();
	  panelGC.anchor = GridBagConstraints.NORTHWEST;
	  panelGC.fill = GridBagConstraints.HORIZONTAL;
	  panelGC.gridx = 0;
	  panelGC.gridy = 0;
	  panelGC.weightx = 100;
	  panelGC.weighty = 0;
	  panelGC.ipadx = 5;
	  panelGC.ipady = 5;
	  panelGC.insets = new Insets(2,2,2,2);

	  panel.add(listValueManager.getListArea(), panelGC);

	  panelGC.gridy = 1;	  
	  panelGC.weightx = 0;
	  panelGC.weighty = 0;
	  panelGC.fill = GridBagConstraints.NONE;
	  panelGC.anchor = GridBagConstraints.SOUTHEAST;

	  panel.add(createControlPanel(), panelGC);

	  return panel;

   }

   public JPanel createControlPanel() {
	  JPanel panel = new JPanel(new GridBagLayout() );

	  GridBagConstraints panelGC = new GridBagConstraints();
	  panelGC.anchor = GridBagConstraints.NORTHWEST;
	  panelGC.fill = GridBagConstraints.NONE;
	  panelGC.gridx = 0;
	  panelGC.gridy = 0;
	  panelGC.weightx = 0;
	  panelGC.weighty = 0;
	  panelGC.ipadx = 5;
	  panelGC.ipady = 5;
	  panelGC.insets = new Insets(2,2,2,2);
	  panel.add(listTypeManager.getTypeArea(), panelGC);
	  panelGC.gridx = 1;
	  panel.add(listValueManager.getEditButtons(), panelGC);
	  return panel;

   }

   // ==========================================
   // Section Accessors
   // ==========================================

   // ==========================================
   // Section Mutators
   // ==========================================
   public void setModel(ListFieldModel listFieldModel) {
	  super.setModel(listFieldModel);
   }

    // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================


   // ==========================================
   // Section Interfaces
   // ==========================================


   // ==========================================
   // Section Overload
   // ==========================================

}

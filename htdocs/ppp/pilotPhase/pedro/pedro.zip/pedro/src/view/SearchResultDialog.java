/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.view;

import javax.swing.event.ListSelectionListener;
import javax.swing.event.ListSelectionEvent;
import java.util.Hashtable;
import java.util.ArrayList;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JPanel;
import javax.swing.JDialog;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.util.Vector;
import java.util.Collections;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import pedro.model.RecordModel;


/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class SearchResultDialog extends JDialog
   implements ListSelectionListener,
			  ActionListener {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private Hashtable recordFromName;
   private Hashtable nameFromRecord;
   private NavigationTree navigationTree;
   private Vector model;
   private JList list;
   private JLabel searchFieldLabel;
   private JTextField searchField;
   private JButton applySearch;
   private JButton close;

   // ==========================================
   // Section Construction
   // ==========================================
   public SearchResultDialog() {

	  //create search field panel
	  setTitle("Search Result Dialog");
	  recordFromName = new Hashtable();
	  nameFromRecord = new Hashtable();
	  model = new Vector();
	  list = new JList(model);
	  list.setPrototypeCellValue("01234567891011");
	  list.addListSelectionListener(this);
	  //this.navigationTree = navigationTree;

	  JPanel panel = new JPanel(new GridBagLayout() );
	  
	  GridBagConstraints panelGC = new GridBagConstraints();
	  panelGC.gridx = 0;
	  panelGC.gridy = 0;
	  panelGC.fill = GridBagConstraints.HORIZONTAL;
	  panelGC.weightx = 0;
	  panelGC.weighty = 0;
	  panelGC.anchor = GridBagConstraints.NORTHWEST;
	  
	  panel.add(createSearchFieldPanel(), panelGC);

	  panelGC.fill = GridBagConstraints.BOTH;
	  panelGC.gridx = 0;
	  panelGC.gridy = 1;
	  JScrollPane scrollPane = new JScrollPane(list);
	  panel.add(scrollPane, panelGC);

	  panelGC.gridx = 0;
	  panelGC.gridy = 2;
	  panelGC.fill = GridBagConstraints.NONE;
	  panelGC.weightx = 0;
	  panelGC.weighty = 0;
	  panelGC.anchor = GridBagConstraints.SOUTHEAST;
	  panel.add(createSearchButtonPanel(), panelGC);

	  getContentPane().add(panel);
	  pack();
	  setResizable(false);

   }

   public void setNavigationTree(NavigationTree _navigationTree) {
	  this.navigationTree = _navigationTree;
   }

   private JPanel createSearchFieldPanel() {

	  JPanel panel = new JPanel(new GridBagLayout() );
	  
	  GridBagConstraints panelGC = new GridBagConstraints();
	  panelGC.gridx = 0;
	  panelGC.gridy = 0;
	  panelGC.fill = GridBagConstraints.NONE;
	  panelGC.weightx = 0;
	  panelGC.weighty = 0;
	  panelGC.anchor = GridBagConstraints.NORTHWEST;

	  searchFieldLabel = new JLabel("Search:");


	  searchField = new JTextField(30);
	  panelGC.fill = GridBagConstraints.BOTH;
	  panelGC.weightx = 100;
	  panelGC.weighty = 0;
	  panel.add(searchFieldLabel, panelGC);
	  panelGC.gridx = 1;

	  panel.add(searchField, panelGC);
	  
	  return panel;

   }

   private JPanel createSearchButtonPanel() {

	  JPanel panel = new JPanel(new GridBagLayout() );
	  
	  GridBagConstraints panelGC = new GridBagConstraints();
	  panelGC.gridx = 0;
	  panelGC.gridy = 0;
	  panelGC.fill = GridBagConstraints.NONE;
	  panelGC.weightx = 0;
	  panelGC.weighty = 0;
	  panelGC.anchor = GridBagConstraints.SOUTHEAST;

	  applySearch = new JButton("Apply");
	  applySearch.addActionListener(this);

	  panel.add(applySearch, panelGC);
	  panelGC.gridx = 1;

	  close = new JButton("Close");
	  close.addActionListener(this);
	  panel.add(close, panelGC);

	  return panel;



   }


   // ==========================================
   // Section Accessors
   // ==========================================


   // ==========================================
   // Section Mutators
   // ==========================================

   public void addRecordModel(RecordModel recordModel) {
	  String displayName = recordModel.getDisplayName();
	  recordFromName.put(displayName, recordModel);
	  nameFromRecord.put(recordModel,displayName);
	  addItem(displayName);
   }

   public void addRecords(ArrayList records) {
	  int numberOfRecords = records.size();
	  for ( int i = 0; i < numberOfRecords; i++) {
		 RecordModel currentRecord = (RecordModel) records.get(i);
		 addRecordModel(currentRecord);
	  } // end for ()
   }

   public void addItem(String item) {
	  model.addElement(item);
	  Collections.sort(model);
   }

   public void removeItem(String item) {
	  model.remove(item);
	  Collections.sort(model);
   }

   public void addItems(Object[] items) {
	  for ( int i = 0; i < items.length; i++) {
		 model.addElement( (String) items[i]);
	  } // end for ()
	  Collections.sort(model);

	  repaint();
   }
   
   public void deleteRecordModel(RecordModel recordModel) {

	  String name = (String) nameFromRecord.get(recordModel);
	  if ( name != null) {
		 model.remove(recordModel);
		 nameFromRecord.remove(recordModel);
		 recordFromName.remove(name);
		 
		 removeItem(name);
		 repaint();
	  } //end if ()
	  


   }

   public void updateRecordModel(RecordModel recordModel) {
	  
	  String oldDisplayName = (String) nameFromRecord.get(recordModel);
	  if ( oldDisplayName != null) {
		 String newDisplayName = recordModel.getDisplayName();
		 if ( oldDisplayName.equals(newDisplayName) == false) {
			deleteRecordModel(recordModel);
			addRecordModel(recordModel);
		 } //end if ()
		 repaint();
	  } //end if ()
	  
   }



   private void search() {
	  ArrayList results = navigationTree.applySearch(searchField.getText() );
	  addRecords(results);
	  repaint();
   }

   public void clear() {
	  recordFromName.clear();
	  nameFromRecord.clear();
	  model.removeAllElements();
   }
   // ============================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================
   //List Selection Listener

   public void valueChanged(ListSelectionEvent event) {
	  String displayName = (String) list.getSelectedValue();
	  RecordModel recordModel = (RecordModel) recordFromName.get(displayName);

	  if ( navigationTree != null) {
		 navigationTree.setActiveNode(recordModel);
	  } //end if ()
   } 

   public void actionPerformed(ActionEvent event) {
	  Object button = event.getSource();

	  if (button == applySearch ) {
		 search();
	  } //end if ()
	  else if ( button == close) {
		 dispose();
	  } //end else ()

   }

   // ==========================================
   // Section Overload
   // ==========================================

}

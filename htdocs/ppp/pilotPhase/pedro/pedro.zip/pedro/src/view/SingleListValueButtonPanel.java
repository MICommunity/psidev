/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.view;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JButton;
import javax.swing.JPanel;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Component;
import java.awt.Font;
import javax.swing.event.ChangeListener;
import java.util.ArrayList;

import pedro.util.ErrorDialog;
import pedro.model.ListFieldModel;
import pedro.model.RecordModel;
import pedro.system.PedroException;
import pedro.system.GlobalConstants;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */
/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class SingleListValueButtonPanel implements ActionListener {

   
   // ==========================================
   // Section Constants
   // ==========================================
 
   // ==========================================
   // Section Properties
   // ==========================================
   private ListTypeManager listTypeManager;
   private SingleListValueManager listValueManager;
   private JButton newRecord;
   private JButton editRecord;

   private JPanel panel;
   private ListFieldModel listFieldModel;
   private RecordView recordView;

   // ==========================================
   // Section Construction
   // ==========================================
   public SingleListValueButtonPanel(ListTypeManager listTypeManager,
									 SingleListValueManager listValueManager,
									 RecordView recordView) {
	  this.listTypeManager = listTypeManager;
	  this.listValueManager = listValueManager;
	  this.recordView = recordView;


	  newRecord = new JButton("New");
	  newRecord.addActionListener(this);

	  editRecord = new JButton("Edit");
	  editRecord.addActionListener(this);

	  panel = new JPanel(new GridBagLayout() );
	  GridBagConstraints panelGC = new GridBagConstraints();
	  panelGC.gridx = 0;
	  panelGC.weightx = 0;
	  panelGC.weighty = 0;
	  panelGC.fill = GridBagConstraints.NONE;
	  panelGC.anchor = GridBagConstraints.NORTHWEST;
	  panel.add(newRecord,panelGC);
	  panelGC.gridx = 1;
	  panel.add(editRecord,panelGC);

   }
   
   // ==========================================
   // Section Accessors
   // ==========================================
   public Component getPanel() {
	  return panel;
	  
   }

   // ==========================================
   // Section Mutators
   // ==========================================
   public void setModel(ListFieldModel _listFieldModel) {
	  this.listFieldModel = _listFieldModel;

	  //assert the state of the list edit buttons
   }

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================

   private void newRecord() {

	  if ( parentIsValid() == false) {
		 return;
	  } //end if ()

	  RecordModel newModel = listTypeManager.createRecordModelFromType();

	  if ( newModel == null) {
		 StringBuffer message = new StringBuffer();

		 String intendedRecordType = listTypeManager.getSelectedType().trim();
		 if ( intendedRecordType.equals(GlobalConstants.SHOW_ALL_RECORDS) == true) {
			message.append("You have to choose the type of record to create.\n\"");
			message.append(GlobalConstants.SHOW_ALL_RECORDS);
			message.append("\" is not a valid kind of record.");
		 } //end if ()
		 else {
			message.append("Can't create this type of subrecord.\n");
		 } //end else
		 
		 ErrorDialog.show(message.toString() );
		 return;
	  } //end if ()

	  newModel.setContainingListModel(listFieldModel);




	  //copy listeners from containing record to this record.
	  RecordModel containingRecord = listFieldModel.getContainingRecord();


	  ArrayList changeListeners = containingRecord.getChangeListeners();
	  newModel.setChangeListeners(changeListeners);

	  //now add this record to the parent
	  listFieldModel.addChild(newModel);

	  //and allow the containing record to update the tree
	  newModel.informListenersOfChildCreation();
   }

   private void editRecord() {

	  if ( parentIsValid() == false) {
		 return;
	  } //end if ()

	  RecordModel editRecord = listValueManager.getSelectedRecordModel();
	  editRecord.informListenersOfGainedFocus();
   }

   private boolean parentIsValid() {
	  //try to keep values of parent
	  try {
		 recordView.keepValues();
	  } catch (PedroException err) {
		 ErrorDialog.show(err.getMessage() );
		 return false;
	  } // end try-catch
	  
	  return true;

   }
   

   // ==========================================
   // Section Interfaces
   // ==========================================

   //Interface: ActionListener 
   public void actionPerformed(ActionEvent event) {
	  Object button = event.getSource();

	  if ( button == newRecord) {
		 newRecord();
	  } //end if ()
	  else {
		 editRecord();
	  } //end else

   }

   public void setFont(Font font) {
	  newRecord.setFont(font);
	  editRecord.setFont(font);
   }

   public void enableEditRecordModel(boolean enableEditRecordModel) {
		 editRecord.setEnabled(enableEditRecordModel);
   }

   public void enableNewRecordModel(boolean enableNewRecordModel) {
		 newRecord.setEnabled(enableNewRecordModel);
   }


   // ==========================================
   // Section Overload
   // ==========================================

}

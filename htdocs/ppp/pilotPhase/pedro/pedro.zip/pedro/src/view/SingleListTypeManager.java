/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.view;

import java.awt.Component;
import java.awt.Font;
import javax.swing.JPanel;

import pedro.model.ListFieldModel;
import pedro.model.RecordModel;
import pedro.model.RecordModelFactory;
/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class SingleListTypeManager
   implements ListTypeManager {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private String childType;
   // ==========================================
   // Section Construction
   // ==========================================
   public SingleListTypeManager() {
   }

   // ==========================================
   // Section Accessors
   // ==========================================


   // ==========================================
   // Section Mutators
   // ==========================================
   public void setModel(ListFieldModel listFieldModel) {

	  String[] types = listFieldModel.getChildTypes();
	  //there should be exactly one type
	  this.childType = types[0];
   }


   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================
   //Interface: ListTypeManager

   public String getSelectedType() {
	  return childType;
   }


   public void setListTypeListener(ListTypeListener actionListener) {
	  //do nothing; type will never change
   }

   public Component getTypeArea() {
	  return new JPanel();
   }

   public RecordModel createRecordModelFromType() {
	  RecordModelFactory recordModelFactory = RecordModelFactory.getRecordModelFactory();
	  return recordModelFactory.createRecordModel(childType);
   }

   public void setEnabled(boolean isEnabled) {
	  //do nothing
   }


   public void reset() {
	  //do nothing
   }

   public String[] getTypes() {
	  String[] childTypes = new String[1];
	  childTypes[0] = childType;
	  return childTypes;
   }

   public Component getUIComponent() {
	  return null;
   }

   public void setTypes(String[] types) {

	  //Assumes 1 child
	  childType = types[0];
   }

   public void setFont(Font font) {
	  //do nothing
   }



   // ==========================================
   // Section Overload
   // ==========================================

}

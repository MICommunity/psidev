/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.view;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JFileChooser;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Insets;

import java.awt.Font;
import java.awt.Color;
import java.io.File;
import java.net.URL;
import java.net.MalformedURLException;
import java.lang.Runtime;

import pedro.util.ErrorDialog;
import pedro.validation.URLValidator;
import pedro.model.EditFieldModel;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class URLFieldView extends EditFieldView 
   implements ActionListener {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private JTextField text;
   private JButton browse;
   private JButton view;
   private JFileChooser fileChooser;

   // ==========================================
   // Section Construction
   // ==========================================

   public URLFieldView() {
	  text = new JTextField();
	  activityArea = text;
	  init();
   }


   public void setModel(EditFieldModel editFieldModel) {
	  super.setModel(editFieldModel);
	  text.setText(editFieldModel.getValue() );

   }


   private void init() {
	  
	  JPanel panel = new JPanel(new GridBagLayout() );

	  GridBagConstraints panelGC = new GridBagConstraints();
	  panelGC.weightx = 100;
	  panelGC.weighty = 0;
	  panelGC.anchor = GridBagConstraints.NORTHWEST;
	  panelGC.fill = GridBagConstraints.HORIZONTAL;
	  panelGC.gridx = 0;
	  panelGC.gridy = 0;
	  panelGC.insets = new Insets(2,2,2,2);

	  text = new JTextField();

	  panel.add(text, panelGC);

	  panelGC.weightx = 0;
	  panelGC.weighty = 0;
	  panelGC.fill = GridBagConstraints.NONE;
	  panelGC.gridx = 1;

	  JPanel buttonPanel = createButtonPanel();
	  panel.add(buttonPanel, panelGC);
	  fileChooser = new JFileChooser();

	  setActivityArea(panel);

   }
   
   private JPanel createButtonPanel() {

	  browse = new JButton("Browse...");
	  browse.addActionListener(this);

	  view = new JButton("View");
	  view.addActionListener(this);

	  JPanel panel = new JPanel(new GridBagLayout() );
	  GridBagConstraints panelGC = new GridBagConstraints();
	  panelGC.gridx = 0;
	  panelGC.weightx = 0;
	  panelGC.weighty = 0;
	  panelGC.fill = GridBagConstraints.NONE;
	  panelGC.anchor = GridBagConstraints.NORTHWEST;
	  panel.add(browse,panelGC);

	  FileLauncher fileLauncher = FileLauncher.getFileLauncher();
	  if ( fileLauncher.getDescribedExtensionsCount() > 0) {
		 //there are no file extensions associated with launcher programs
		 //so do not include view button in display
		 panelGC.gridx = 1;
		 panel.add(view,panelGC);
	  } //end if ()

	  return panel;

   }

   // ==========================================
   // Section Accessors
   // ==========================================
   public String getSelectedText() {
	  return text.getSelectedText();
   }

   public boolean hasFocus() {
	  return text.hasFocus();
   }


   // ==========================================
   // Section Mutators
   // ==========================================
   public void setValue(String _value) {
	  text.setText(_value);
   }

   public void keepValue() {
	  if ( isDirty() == false) {
		 return;
	  } //end if ()
	  
	  editFieldModel.setValue(text.getText() );
   }

   public void restoreValue() {
	  text.setText(editFieldModel.getValue() );
   }

   // ==========================================
   // Section Validation
   // ==========================================
   public String validate(boolean highlightErrors) {
	  return showErrors(text.getText(),
						highlightErrors);
   }

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================
   public void actionPerformed(ActionEvent event) {
	  Object button = event.getSource();

	  if ( button == browse) {
		 fileChooser.showOpenDialog(null);
		 
		 //		 try {
			File selectedFile = fileChooser.getSelectedFile();

			if ( selectedFile != null) {
			   text.setText(selectedFile.getPath() );
			   //URL selectedURL = selectedFile.toURL();
			   // text.setText(selectedURL.toString() );
			} //end if ()
			//		 } catch (MalformedURLException err) {

			//ErrorDialog.show(err.toString() );
			//		 } // end try-catch

	  } //end if ()
	  else if ( button == view) {
		 String launchCommand = getLaunchCommand();
		 if ( launchCommand == null) {
			   StringBuffer errorMessage = new StringBuffer();
			   errorMessage.append("No programs available to launch \n");
			   errorMessage.append("files with extension \"");
			   errorMessage.append(getFileExtension(text.getText()));
			   errorMessage.append("\"");
			   ErrorDialog.show(errorMessage.toString() );
			   return;
		 } //end if ()
		 else {

			String fullCommand = null;

			
			try {
			   

			
			   String fileName = text.getText();
			   fileName = fileName.trim();
			   
			   File file = new File(fileName);
			   URL url = file.toURL();
			   
			   String urlName = url.toString();
			   
			   String error = editFieldModel.validate(fileName);
			   if ( error != null) {
				  ErrorDialog.show(error);
				  return;
			   } //end if ()
			   Runtime runTime = Runtime.getRuntime();
			   
			   fullCommand = launchCommand + " " + urlName;
			   runTime.exec(fullCommand);
			} catch (Exception err) {
			   StringBuffer errorMessage = new StringBuffer();
			   errorMessage.append("Error launching \"");
			   errorMessage.append(fullCommand);
			   errorMessage.append("\"");
			   ErrorDialog.show(errorMessage.toString() );
			   return;
			} // end try-catch
			
		 }
	  } //end else ()
   }
   
   private String getFileExtension(String file) {

	  String fileName = file;
	  fileName = fileName.trim();
	  int index = fileName.lastIndexOf('.');
	  if (index == -1) {
		 //file name has no extension
		 return null;
	  } //end if ()

	  if ( (index + 1) >= fileName.length() ) {
		 //file name somehow ends in a period
		 return null;
	  } //end if ()


	  return fileName.substring(index+1);
   }

   private String getLaunchCommand() {
	  String fileExtension = getFileExtension(text.getText() );

	  if ( fileExtension == null) {
		 return null;
	  } //end if ()

	  FileLauncher fileLauncher = FileLauncher.getFileLauncher();
	  String launchCommand = fileLauncher.getLaunchCommand(fileExtension);
	  return launchCommand;

	  //return "";
   }

   // ==========================================
   // Section Overload
   // ==========================================
   
   public boolean isDirty() {
	  String savedValue = editFieldModel.getValue();
	  String currentValue = text.getText();

	  if ( savedValue.equals(currentValue) == true) {
		 return false;
	  } //end if ()
	  else {
		 return true;
	  } //end else
   }

}

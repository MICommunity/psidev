/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.view;

import javax.swing.JLabel;

import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.Cursor;
import java.net.URL;

import pedro.system.GlobalConstants;
import pedro.util.HelpDialog;



/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class RecordViewTitle extends JLabel 
   implements MouseListener {

   
   // ==========================================
   // Section Constants
   // ==========================================


   // ==========================================
   // Section Properties
   // ==========================================
   private URL helpLink;

   // ==========================================
   // Section Construction
   // ==========================================


   public RecordViewTitle(String text) {
	  super(text);
	  init();
   }

   private void init() {
	  helpLink = null;
   }

   // ==========================================
   // Section Accessors
   // ==========================================


   // ==========================================
   // Section Mutators
   // ==========================================
   public void enableContextHelp(boolean enableContextHelp) {
	  if ( enableContextHelp == true) {
		 addMouseListener(this);
	  } //end if ()
	  else {
		 removeMouseListener(this);
	  } //end else
   }

   public void setHelpLink(URL helpLink) {
	  this.helpLink = helpLink;
   }

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================
   //Interface: MouseListener 

   public void mouseClicked(MouseEvent e) {

	  try {
		 HelpDialog helpDialog = HelpDialog.getHelpDialog();
		 helpDialog.setTitle("Context Help");
		 helpDialog.setHelpLink(helpLink);
		 helpDialog.show();
	  }
	  catch (Exception err) {
		 System.out.println(err);
	  } // end catch
	  

   }

   public void mouseEntered(MouseEvent event) {
	  setCursor(GlobalConstants.getHelpCursor() );

   }

   public void mouseExited(MouseEvent event) {
	  setCursor(Cursor.getDefaultCursor() );

   }

   public void mousePressed(MouseEvent event) {

   }

   public void mouseReleased(MouseEvent event) {

   }


   // ==========================================
   // Section Overload
   // ==========================================

}

/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.util;

import javax.swing.JDialog;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import pedro.model.RecordModelFactory;


/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class SchemaInformationDialog extends JDialog 
   implements ActionListener {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private JLabel schemaInformationLabel;
   private JButton close;

   // ==========================================
   // Section Construction
   // ==========================================
   public SchemaInformationDialog() {
	  setTitle("Schema Information Dialog");

	  JPanel panel = new JPanel(new GridBagLayout() );
	  
	  GridBagConstraints panelGC = new GridBagConstraints();
	  panelGC.weightx = 100;
	  panelGC.anchor = GridBagConstraints.NORTHWEST;
	  panelGC.fill = GridBagConstraints.HORIZONTAL;
	  panelGC.gridx = 0;
	  panelGC.gridy = 0;

	  RecordModelFactory recordModelFactory
		 = RecordModelFactory.getRecordModelFactory();

	  StringBuffer schemaInformationText = new StringBuffer();
	  schemaInformationText.append("This application is using schema \"");
	  schemaInformationText.append(recordModelFactory.getSchemaName() );
	  schemaInformationText.append("\"");
	  schemaInformationText.append(".");
	  

	  schemaInformationLabel  
		 = new JLabel(schemaInformationText.toString()  );

	  panel.add(schemaInformationLabel, panelGC);

	  panelGC.gridy = 1;
	  close = new JButton("Close");
	  close.addActionListener(this);
	  panelGC.fill = GridBagConstraints.NONE;
	  panelGC.anchor = GridBagConstraints.SOUTHEAST;
	  panel.add(close,panelGC);

	  getContentPane().add(panel);
	  pack();
	  setResizable(false);

   }

   // ==========================================
   // Section Accessors
   // ==========================================


   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================
   public void actionPerformed(ActionEvent event) {
	  dispose();
   }

   // ==========================================
   // Section Overload
   // ==========================================

}

/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.view;

import java.awt.Font;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import javax.swing.JLabel;
import javax.swing.JComponent;

import java.net.URL;

import pedro.model.DataFieldModel;
import pedro.system.GlobalConstants;
import pedro.util.ContextHelpItem;
import pedro.util.ContextHelpService;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

abstract public class DataFieldView 
   implements ContextHelpItem {
   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   protected JLabel label;
   protected Font font;
   private Font boldFont;
   private Font plainFont;
   protected String name;
   protected JComponent activityArea;
   private boolean isRequiredField;
   protected DataFieldModel dataFieldModel;

   private ContextHelpService contextHelpService;

   // ==========================================
   // Section Construction
   // ==========================================
   public DataFieldView() {
	  isRequiredField = false;
	  label = new JLabel();
	  font = label.getFont();
	  boldFont = font.deriveFont(Font.BOLD);
	  plainFont = font.deriveFont(Font.PLAIN);
	  contextHelpService = new ContextHelpService(label);
   }


   public void setModel(DataFieldModel _dataFieldModel) {
	  dataFieldModel = _dataFieldModel;
	  setHelpLink(dataFieldModel.getHelpLink());
	  isRequiredField = dataFieldModel.isRequiredField();
	  name = dataFieldModel.getName();

	  label.setText(name);
	  //adjust appearance of the label
	  if ( isRequiredField == true) {
		 //bold the default font so user knows it is a required field
		 label.setFont(boldFont);
		 label.setForeground(Color.black);
	  } //end if ()
	  else {
		 label.setFont(plainFont);
	  } //end else

   }

   // ==========================================
   // Section Accessors
   // ==========================================
   public JLabel getLabel() {
	  return label;
   }

   public JComponent getActivityArea() {
	  return activityArea;
   }

   public String getName() {
	  return name;
   }
   
   public URL getHelpLink() {
	  return contextHelpService.getHelpLink();
   }

   public boolean hasFocus() {
	  return activityArea.hasFocus();
   }

   public boolean isRequiredField() {
	  return isRequiredField;
   }

   public Font getFont() {
	  return font;
   }

   public boolean isContextHelpEnabled() {
	  return contextHelpService.isContextHelpEnabled();
   }
   

   // ==========================================
   // Section Mutators
   // ==========================================
   public void setRequiredField(boolean _isRequiredField) {
	  this.isRequiredField = _isRequiredField;
   }

   protected void setActivityArea(JComponent _activityArea) {
	  this.activityArea = _activityArea;
   }

   public abstract String validate(boolean highlightErrors);

   public void setFont(Font _font) {
	  this.font = _font;
	  plainFont = font.deriveFont(Font.PLAIN);
	  boldFont = font.deriveFont(Font.BOLD);
	  label.setFont(plainFont);

   }


   public void setName(String _name) {
	  this.name = _name;
	  label.setText(name);
   }

   public void enableContextHelp(boolean enableContextHelp) {
	  contextHelpService.enableContextHelp(enableContextHelp);
   }

   public void setHelpLink(URL helpLink) {
	  contextHelpService.setHelpLink(helpLink);
   }


   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================


   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================

}

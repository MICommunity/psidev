/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.view;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Component;

import java.util.Hashtable;
import java.util.Vector;
import java.util.Collections;

import javax.swing.event.ChangeListener;
import javax.swing.JScrollPane;
import javax.swing.JPanel;
import javax.swing.JList;
import javax.swing.ListSelectionModel;
import java.io.File;
import java.util.ArrayList;

import pedro.system.GlobalConstants;
import pedro.model.RecordModel;
import pedro.model.ListFieldModel;
/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class MultiListValueManager 
   implements ListValueManager, ListTypeListener {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private Hashtable nameFromRecordModel;
   private Hashtable recordModelFromName;
   private Vector displayNames;

   private JList list;

   
   private ListTypeManager listTypeManager;
   private MultipleListValueButtonPanel buttonPanel;
   private ListFieldModel listFieldModel;
   private JScrollPane scrollPane;

   private ChangeListener changeListener;

   // ==========================================
   // Section Construction
   // ==========================================
   public MultiListValueManager(ListTypeManager listTypeManager,
								RecordView recordView) {

	  this.listTypeManager = listTypeManager;
	  listTypeManager.setListTypeListener(this);

	  recordModelFromName = new Hashtable();
	  nameFromRecordModel = new Hashtable();
	  displayNames = new Vector();

	  list = new JList(displayNames);
	  list.setPrototypeCellValue("Index 123456789011");

	  ListSelectionModel selectionModel = list.getSelectionModel();
	  selectionModel.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);

	  scrollPane = new JScrollPane(list);

	  buttonPanel = new MultipleListValueButtonPanel(listTypeManager,
													 this,
													 recordView);

   }





   // ==========================================
   // Section Accessors
   // ==========================================
   private ArrayList getChildren() {
	  ArrayList children = new ArrayList();
	  children.addAll(recordModelFromName.values() );
	  return children;
   }

   // ==========================================
   // Section Mutators
   // ==========================================
   public void setModel(ListFieldModel _listFieldModel) {
	  this.listFieldModel = _listFieldModel;
	  buttonPanel.setModel(listFieldModel);

	  buttonPanel.enableNewRecordModel(true);
	  if ( listFieldModel.isListPopulated() == true) {
		 buttonPanel.enableEditRecordModel(true);
	  } //end if ()
	  else {
		 buttonPanel.enableEditRecordModel(false);
	  } //end else

	  ArrayList children = listFieldModel.getChildren();
	  setChildren(children);
   }

   private void filterList(String recordModelTypeTag) {

	  boolean showAllRecordModels;

	  if ( recordModelTypeTag.equals(GlobalConstants.SHOW_ALL_RECORDS) == true) {
		 showAllRecordModels = true;
	  } //end if ()
	  else {
		 showAllRecordModels = false;
	  } //end else

	  displayNames.clear();
	  ArrayList elements = getChildren();
	  int numberOfChildren = elements.size();

	  if ( showAllRecordModels == true) {
		 for (int i = 0; i < numberOfChildren; i++ ) {
			RecordModel currentRecordModel = (RecordModel) elements.get(i);
			displayNames.addElement(currentRecordModel.getDisplayName() );
		 } // end for ()
	  } //end if ()
	  else {
		 for (int i = 0; i < numberOfChildren; i++ ) {
			RecordModel currentRecordModel = (RecordModel) elements.get(i);
			String currentRecordClassName = currentRecordModel.getRecordClassName();
			
			if ( currentRecordClassName.equals(recordModelTypeTag) == true) {

			   displayNames.addElement(currentRecordModel.getDisplayName() );
			} //end if ()
			
		 } // end for ()
	  } //end else

	  if ( displayNames.size() == 0) {
		 buttonPanel.enableEditRecordModel(false);
	  } //end if ()
	  else {
		 list.setSelectedIndex(0);
		 buttonPanel.enableEditRecordModel(true);
	  } //end else
	  
	  list.updateUI();

   }


   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================
   //Interface: ListTypeListener
   public void listTypeChanged(String currentType) {
	  filterList(currentType);
   }

   //Interface: ListValueManager
   public Component getEditButtons() {
	  return buttonPanel.getPanel();
   }

   public Component getListArea() {
	  return scrollPane;
   }

   public void removeSelectedRecords() {

	  ArrayList selectedRecords = new ArrayList();

	  Object[] selectedValues = list.getSelectedValues();
	  for ( int i = 0; i < selectedValues.length; i++) {
		 String currentDisplayName = (String) selectedValues[i];
		 RecordModel currentRecordModel =
			(RecordModel) recordModelFromName.get(currentDisplayName);
		 removeRecordModel(currentRecordModel);
	  } // end for ()

	  if ( displayNames.size() > 0) {
		 list.setSelectedIndex(0);
	  } //end if ()
	  
	  list.updateUI();

   }

   private void setChildren(ArrayList children) {
	  int numberOfChildren = children.size();
	  displayNames.clear();
	  recordModelFromName.clear();
	  nameFromRecordModel.clear();

	  if (numberOfChildren > 0) {
		 buttonPanel.enableEditRecordModel(true);
	  } //end if ()

	  for ( int i = 0; i < numberOfChildren; i++) {
		 RecordModel currentChild = (RecordModel) children.get(i);
		 addRecordModel(currentChild);
	  } // end for ()

	  Collections.sort(displayNames);

	  //set first item to be selected
	  list.setSelectedIndex(0);
	  list.updateUI();
   }

   private void removeRecordModel(RecordModel recordModel) {
	  String displayName = (String) nameFromRecordModel.get(recordModel);
	  recordModelFromName.remove(displayName);
	  nameFromRecordModel.remove(recordModel);
	  displayNames.remove(displayName);
	  recordModel.informListenersOfDestruction();
   }

   private void addRecordModel(RecordModel recordModel) {
	  String displayName = recordModel.getDisplayName();
	  displayNames.add(displayName);

	  recordModelFromName.put(displayName, recordModel);
	  nameFromRecordModel.put(recordModel, displayName);
	  
   }

   public RecordModel getSelectedRecordModel() {
	  String selectedItem = (String) list.getSelectedValue();
	  RecordModel recordModel = (RecordModel) recordModelFromName.get(selectedItem);
	  return recordModel;
   }
   public void setFont(Font font) {
	  list.setFont(font);
	  buttonPanel.setFont(font);
   }

   public void refresh() {
	  System.out.println("MLVM - refresh()");
	  ArrayList children = listFieldModel.getChildren();
	  setChildren(children);

	  String selectedType = listTypeManager.getSelectedType();
	  filterList(selectedType);

   }
   public void reset() {
	  displayNames.clear();
   }

   // ==========================================
   // Section Overload
   // ==========================================

}

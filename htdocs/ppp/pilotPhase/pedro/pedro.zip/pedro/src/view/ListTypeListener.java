/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.view;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

public interface ListTypeListener {
   public void listTypeChanged(String recordType);

}

/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.view;

import java.util.Date;
import javax.swing.JTextField;
import java.text.FieldPosition;
import java.text.SimpleDateFormat;
import java.text.ParsePosition;

import pedro.validation.DateValidator; 
import pedro.model.EditFieldModel;

import pedro.system.GlobalConstants;
/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class DateFieldView extends EditFieldView {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private JTextField text;
   private Date date;

   private String savedValue;
   // ==========================================
   // Section Construction
   // ==========================================
   public DateFieldView() {

   }

   public void setModel(EditFieldModel editFieldModel) {
	  super.setModel(editFieldModel);
	  //change name to reflect date format
	  setName(editFieldModel.getName() );

	  //this will always be the canonical value
	  String value = editFieldModel.getValue();

	  text = new JTextField();
	  //text.setText(editFieldModel.getValue() );
	  activityArea = text;

	  if ( value.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) == false) {
		 date = DateValidator.getCanonicalDate(value);
		 String formattedValue = DateValidator.getDateValue(date);
		 text.setText(formattedValue );
	  } //end if ()
	  else {
		 text.setText(GlobalConstants.NO_ATTRIBUTE_VALUE);
	  } //end else

   }

   // ==========================================
   // Section Accessors
   // ===========================================
   public String getSelectedText() {
	  return text.getSelectedText();
   }


   //assumes it's valid.  
   public void keepValue() {
	  if ( isDirty() == false) {
		 return;
	  } //end if ()
	  
	  //obtain the current date format
	  SimpleDateFormat dateFormat = DateValidator.getDateFormat();

	  date = dateFormat.parse(text.getText(),
							  new ParsePosition(0));
	  
	  //now write it out 
	  String canonicalForm = DateValidator.getCanonicalValue(date);
	  editFieldModel.setValue(canonicalForm);
   }

   public void refreshLabel() {	  
	  SimpleDateFormat dateFormat = DateValidator.getDateFormat();
	  label.setText(name+ " (" + dateFormat.toPattern() + ")");
   }

   public String getCanonicalValue() {
	  String result = DateValidator.getCanonicalValue(date);
	  return result;
   }

   // ==========================================
   // Section Mutators
   // ==========================================
   public void setValue(String value) {
	  text.setText(value);
   }

   // ==========================================
   // Section Validation
   // ==========================================
   public String validate(boolean highlightErrors) {
	  return showErrors(text.getText(),
						highlightErrors);
   }

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================
   public boolean isDirty() {
	  String savedValue = editFieldModel.getValue();
	  String currentValue = text.getText();

	  Date date = DateValidator.getDate(currentValue);
	  String currentCanonicalValue = DateValidator.getCanonicalValue(date);

	  if ( savedValue.equals(currentCanonicalValue) == true) {
		 return false;
	  } //end if ()
	  else {
		 return true;
	  } //end else
   }

   public void setName(String _name) {
	  this.name = name;
	  SimpleDateFormat dateFormat = DateValidator.getDateFormat();
	  String fullName = name + " (" + dateFormat.toPattern() + ")";
	  label.setText(fullName);
   }

   public void restoreValue() {
	  text.setText(editFieldModel.getValue() );
   }

   // ==========================================
   // Section Mutators
   // ==========================================

}

/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.view;

import java.util.ArrayList;
import java.awt.Color;
import java.awt.Font;

import pedro.model.ListFieldModel;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public abstract class ListFieldView extends DataFieldView {
   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   protected ListTypeManager listTypeManager;
   protected ListValueManager listValueManager;
   protected ListFieldModel listFieldModel;
   // ==========================================
   // Section Construction
   // ==========================================
   public ListFieldView() {
	  super();
   }

   // ==========================================
   // Section Accessors
   // ==========================================

   // ==========================================
   // Section Mutators
   // ==========================================
   public void setModel(ListFieldModel _listFieldModel) {
	  this.listFieldModel = _listFieldModel;
	  super.setModel(listFieldModel);
	  listTypeManager.setModel(listFieldModel);
	  listValueManager.setModel(listFieldModel);

   }


   public void setListTypeManager(ListTypeManager listTypeManager) {
	  this.listTypeManager = listTypeManager;
   }

   public void setListValueManager(ListValueManager listValueManager) {
	  this.listValueManager = listValueManager;
   }
   
   public void setFont(Font font) {
	  super.setFont(font);
	  Font plainFont = font.deriveFont(Font.PLAIN);
	  listValueManager.setFont(plainFont);
   }

   public void refresh() {
	  listValueManager.setModel(listFieldModel);
   }
// ==========================================
// Section Validation
// ==========================================

   public String validate(boolean highlightErrors) {
	  String errors = listFieldModel.validate();
	  
	  if ( errors == null) {
		 label.setForeground(Color.black);
	  } //end if ()
	  else {
		 label.setForeground(Color.red);
	  } //end else
	  
	  return errors;
   }

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================

}

/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.view;

import javax.swing.JRadioButton;
import java.awt.GridLayout;
import java.awt.GridBagLayout;
import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import javax.swing.JPanel;
import javax.swing.ButtonGroup;
import javax.swing.ButtonModel;

import pedro.model.GroupFieldModel;
import pedro.system.GlobalConstants;
/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class RadioFieldView extends EditFieldView {

   
   // ==========================================
   // Section Constants
   // ==========================================


   // ==========================================
   // Section Properties
   // ==========================================
   private JRadioButton[] radioButtons;
   private ButtonGroup buttonGroup;
   private GroupFieldModel groupFieldModel;

   // ==========================================
   // Section Construction
   // ==========================================
   public RadioFieldView() {


   }

   public void setModel(GroupFieldModel _groupFieldModel) {
	  this.groupFieldModel = _groupFieldModel;
	  super.setModel(groupFieldModel);

	  buildUI(groupFieldModel.getChoices() );

	  String savedValue = groupFieldModel.getValue();
	  ButtonModel buttonModel = getModelFromName(savedValue);
	  buttonGroup.setSelected(buttonModel, true);

   }


   private void buildUI(String[] choices) {
	  radioButtons = new JRadioButton[choices.length];
	  buttonGroup = new ButtonGroup();

	  int numberOfRows = choices.length/3;
	  if ( choices.length%3 != 0) {
		 numberOfRows++;
	  } //end if ()


	  for ( int i = 0; i < choices.length; i++) {
		 radioButtons[i] = new JRadioButton(choices[i]);
		 ButtonModel currentModel = radioButtons[i].getModel();
		 buttonGroup.add(radioButtons[i]);
	  }

	  JPanel buttonPanel = new JPanel();

	  if ( numberOfRows == 1) {
		 //use a GridBagLayout
		 buttonPanel.setLayout(new GridBagLayout() );

		 GridBagConstraints buttonPanelGC = new GridBagConstraints();
		 buttonPanelGC.weightx = 0;
		 buttonPanelGC.anchor = GridBagConstraints.NORTHWEST;
		 buttonPanelGC.fill = GridBagConstraints.HORIZONTAL;
		 buttonPanelGC.gridx = 0;
		 buttonPanelGC.gridy = 0;

		 for ( int i =0; i < choices.length; i++) {
			buttonPanel.add(radioButtons[i],buttonPanelGC);
			buttonPanelGC.gridx++;
		 } // end for ()

	  } //end if ()
	  else {
		 buttonPanel.setLayout(new GridLayout(numberOfRows, 3) );
		 for ( int i =0; i < choices.length; i++) {
			buttonPanel.add(radioButtons[i]);
		 } // end for ()
	  } //end else


	  JPanel mainPanel = new JPanel(new BorderLayout() );
	  mainPanel.add(buttonPanel, BorderLayout.WEST);

	  setActivityArea(mainPanel);
   }

						   

   // ==========================================
   // Section Accessors
   // ==========================================

   // ==========================================
   // Section Mutators
   // ==========================================

   private String getNameFromModel(ButtonModel model) {
	  for ( int i = 0;i < radioButtons.length; i++) {
		 ButtonModel currentModel = radioButtons[i].getModel();
		 if ( currentModel == model) {
			return radioButtons[i].getText();
		 } //end if ()
	  } // end for ()
	  return null;
   }

   private ButtonModel getModelFromName(String name) {
	  for ( int i = 0;i < radioButtons.length; i++) {
		 String text = radioButtons[i].getText();
		 if ( text.equals(name) == true) {
			return radioButtons[i].getModel();
		 } //end if ()
	  } // end for ()
	  return null;
   }

   // ==========================================
   // Section Validation
   // ==========================================
   public String validate(boolean highlightErrors) {
	  ButtonModel selectedModel = buttonGroup.getSelection();
	  String currentValue = getNameFromModel(selectedModel);
	  if ( currentValue == null) {
		 currentValue = GlobalConstants.NONE;
	  } //end if ()
	  
	  return showErrors(currentValue, highlightErrors);
   }


   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================

   // ==========================================
   // Section Overload
   // ==========================================

   public boolean isDirty() {
	  String savedValue = groupFieldModel.getValue();
	  ButtonModel selectedModel = buttonGroup.getSelection();
	  String currentValue = getNameFromModel(selectedModel);
	  if ( savedValue == null) {
		 //user hasn't made selection
		 savedValue = currentValue;
		 return false;
	  } //end if ()

	  if ( savedValue.equals(currentValue) == true) {
		 return false;
	  } //end if ()
	  else {
		 return true;
	  } //end else

   }

   public void keepValue() {
	  if ( isDirty() == false) {
		 return;
	  } //end if ()
	  
	  ButtonModel selectedModel = buttonGroup.getSelection();
	  String currentValue = getNameFromModel(selectedModel);
	  groupFieldModel.setValue(currentValue);
   }
   
   public void restoreValue() {
	  String savedValue = groupFieldModel.getValue();
	  ButtonModel buttonModel = getModelFromName(savedValue);
	  buttonGroup.setSelected(buttonModel, true);

   }


}

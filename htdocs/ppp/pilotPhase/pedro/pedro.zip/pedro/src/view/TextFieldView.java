/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.view;


import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.text.JTextComponent;
import javax.swing.JScrollPane;

import javax.swing.JPopupMenu;
import javax.swing.text.JTextComponent;
import java.util.ArrayList;
import java.awt.Color;
import java.awt.Font;
import java.io.File;

import java.awt.Component;
import java.awt.event.MouseListener;

import java.awt.event.FocusListener;
import java.awt.event.FocusEvent;


import pedro.validation.Validator;
import pedro.ontology.OntologyListener;
import pedro.ontology.OntologyProvider;
import pedro.ontology.OntologyService;
import pedro.ontology.OntologyTerm;
import pedro.ontology.OntologyServiceManager;
import pedro.ontology.TouchTypeOntologyDialog;


import pedro.model.TextFieldModel;
import pedro.model.RecordModel;
import pedro.config.ConfigurationFileReader;
import pedro.config.FieldConfigurationRecord;




/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class TextFieldView extends EditFieldView
   implements OntologyListener, FocusListener {
   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private JTextComponent text;
   private OntologyProvider ontologyProvider;
   private OntologyRightClickListener rightClickListener;

   private OntologyServiceManager ontologyServiceManager;
   private ArrayList ontologyServices;
   private TextFieldModel textFieldModel;

   // ==========================================
   // Section Construction
   // ==========================================
   public TextFieldView() {
	  text = new JTextField("");
	  activityArea = text;
	  ontologyServiceManager = new OntologyServiceManager();

   }

   public void setModel(TextFieldModel _textFieldModel) {
	  this.textFieldModel = _textFieldModel;
	  super.setModel(textFieldModel);

	  //we need to determine whether this field is supposed to have
	  //a text area or a single line text field

	  ConfigurationFileReader configurationFileReader
		 = ConfigurationFileReader.getConfigurationFileReader();
	  
	  RecordModel recordModel = textFieldModel.getContainingRecord();
	  String recordClassName = recordModel.getRecordClassName();
	  String fieldName = textFieldModel.getName();
	  

	  FieldConfigurationRecord configurationRecord
		 = configurationFileReader.getConfigurationRecord(recordClassName, 
														  fieldName);
	  
	  

	  if ( configurationRecord == null) {
		 text = new JTextField("");
		 activityArea = text;
	  } //end if ()
	  else {

		 if ( configurationRecord.isScrollingTextField() == true) {
			
			JTextArea textArea = new JTextArea(5,30);
			textArea.setLineWrap(true);
			textArea.setWrapStyleWord(true);
			textArea.setEditable(!configurationRecord.disableFreeText() );
			text = textArea;
			JScrollPane scrollPane = new JScrollPane(textArea);
			activityArea = scrollPane;
		 } //end if ()
		 else {
			text = new JTextField("");
			text.setEditable(!configurationRecord.disableFreeText() );
			activityArea = text;
		 } //end else
		 
		 ontologyServices = configurationRecord.getOntologyServices();
		 if ( ontologyServices.size() > 0) {
			label.setText("*"+getName() );
			
			ontologyServiceManager.setOntologyServices(ontologyServices);
			
			rightClickListener
			   = new OntologyRightClickListener(label,
												this,
												ontologyServiceManager);

			if ( configurationRecord.disableFreeText() == true) {
			   rightClickListener.allowClearValuesOption(true);
			} //end if ()
			
			label.addMouseListener(rightClickListener);
			
			//install mouse listener to do right click menu
		 } //end if ()
	  } //end else
	  
	  text.setText(textFieldModel.getValue() );

   }

   public void reset() {
	  text.setText("");
   }


   // ==========================================
   // Section Accessors
   // ==========================================
   public String getSelectedText() {
	  return text.getSelectedText();
   }

   public String getValue() {
	  return text.getText();
   }

   // ==========================================
   // Section Mutators
   // ==========================================
   public void enableTouchTypeOntology(boolean enableTouchTypeOntology) {

	  //this method is only relevant if there are ontology services
	  //registered for this field.
	  ArrayList ontologyServices
		 = ontologyServiceManager.getServices();
	  if ( ontologyServices.size() == 0) {
		 return;
	  } //end if ()
	  

	  if ( enableTouchTypeOntology == true) {
		 text.addFocusListener(this);
	  } //end if ()
	  else {
		 text.removeFocusListener(this);
	  } //end else
   }

   public void keepValue() {
	  if ( isDirty() == false) {
		 return;
	  } //end if ()
	  
	  textFieldModel.setValue(text.getText() );
   }

   public void restoreValue() {
	  text.setText(textFieldModel.getValue() );
   }

   public void setValue(String value) {
	  text.setText(value);
   }

   // ==========================================
   // Section Validation
   // ==========================================
   public String validate(boolean highlightErrors) {
	  
	  return showErrors(text.getText(),
						highlightErrors);

   }

   // ==========================================
   // Section Errors
   // ==========================================

   // ==========================================
   // Section Interfaces
   // ==========================================

   //Interface FocusListener
   public void focusGained(FocusEvent event) {
	  TouchTypeOntologyDialog touchTypeOntologyDialog
		 = TouchTypeOntologyDialog.getTouchTypeOntologyDialog();


	  if (touchTypeOntologyDialog.isShowing() == false) {
		 if ( touchTypeOntologyDialog.isAdjusting() == true) {
			touchTypeOntologyDialog.setAdjusting(false);
		 } //end if ()
		 else {
			touchTypeOntologyDialog.show();
		 } //end else
	  } //end if ()
	  
	  OntologyService ontologyService 
		 = ontologyServiceManager.getPrimaryService();

	  touchTypeOntologyDialog.registerOntologyService(ontologyService,
													  text);
	  
   }

   public void focusLost(FocusEvent event) {
   } 

   //Interface OntologyListener
   public void termsSelected(OntologyTerm[] selectedOntologyTerms) {
	  if ( selectedOntologyTerms == null) {
		 return;
	  } //end if ()

	  StringBuffer termList = new StringBuffer();
	  termList.append(selectedOntologyTerms[0].getTerm() );

	  for ( int i = 1; i < selectedOntologyTerms.length;i++) {
		 termList.append(",");
		 termList.append(selectedOntologyTerms[i].getTerm() );
	  } // end for ()
	  
	  //insert term at current CaretPosition
	  int caretPosition = text.getCaretPosition();
	  String currentValue = text.getText();
	  
	  StringBuffer updatedValue = new StringBuffer();
	  if (caretPosition == 0) {
		 updatedValue.append(termList.toString());
		 updatedValue.append(currentValue);
	  } //end if ()
	  else {
		 updatedValue.append(currentValue.substring(0,caretPosition) );
		 updatedValue.append(termList.toString());
		 updatedValue.append(currentValue.substring(caretPosition));
	  } //end else
	  
	  text.setText(updatedValue.toString() );
   }

   public void clearValues() {
	  text.setText("");
   }

   // ==========================================
   // Section Overload
   // ==========================================

   public boolean isDirty() {
	  String savedValue = textFieldModel.getValue();
	  String currentValue = text.getText();
	  
	  
	  if ( savedValue.equals(currentValue) == true) {
		 return false;
	  } //end if ()
	  else {
		 return true;
	  } //end else
   }

}


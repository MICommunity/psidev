/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.view;

import javax.swing.JComboBox;
import java.awt.Component;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import pedro.system.GlobalConstants;
import pedro.model.RecordModelFactory;
import pedro.model.RecordModel;
import pedro.model.ListFieldModel;
/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class MultiListTypeManager 
   implements ListTypeManager,ActionListener {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private String[] childTypes;
   private JLabel showLabel;
   private JPanel uiComponent;
   private ListTypeListener listTypeListener;
   private JComboBox comboBox;
   // ==========================================
   // Section Construction
   // ==========================================
   public MultiListTypeManager() {

	  comboBox = new JComboBox();

	  comboBox.addActionListener(this);

	  uiComponent = new JPanel(new GridBagLayout() );
	  GridBagConstraints panelGC = new GridBagConstraints();
	  panelGC.gridx = 0;
	  panelGC.anchor = GridBagConstraints.NORTHWEST;
	  panelGC.fill = GridBagConstraints.NONE;
	  panelGC.weightx = 0;
	  panelGC.weighty = 0;

	  showLabel = new JLabel("Show:");
	  uiComponent.add(showLabel, panelGC);
	  panelGC.gridx = 1;
	  uiComponent.add(comboBox, panelGC);


   }

   // ==========================================
   // Section Accessors
   // ==========================================


   // ==========================================
   // Section Mutators
   // ==========================================
   public void setModel(ListFieldModel listFieldModel) {

	  childTypes = listFieldModel.getChildTypes();
	  //there should be exactly one type

	  comboBox.removeAllItems();
	  comboBox.addItem(GlobalConstants.SHOW_ALL_RECORDS);
	  this.childTypes = childTypes;
	  for ( int i = 0; i < childTypes.length; i++) {
		 comboBox.addItem(childTypes[i]);
	  } // end for ()
	  
	  

   }


   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================
   //Interface: ActionListener
   public void actionPerformed(ActionEvent event) {
	  //combo box value changed
	  String selectedItem = (String) comboBox.getSelectedItem();

	  if ( listTypeListener != null) {
		 listTypeListener.listTypeChanged(selectedItem);
	  } //end if ()
	  
   }


   //Interface: ListTypeManager
   
   public String getSelectedType() {
	  String selectedItem = (String) comboBox.getSelectedItem();
	  return selectedItem;
   }

   public void setListTypeListener(ListTypeListener listTypeListener) {
	  this.listTypeListener = listTypeListener;
   }


   public RecordModel createRecordModelFromType() {
	  //determine selected type
	  String selectedType = (String) comboBox.getSelectedItem();
	  if ( selectedType == GlobalConstants.SHOW_ALL_RECORDS) {
		 return null;
	  } //end if ()

	  RecordModelFactory recordModelFactory = RecordModelFactory.getRecordModelFactory();
	  return recordModelFactory.createRecordModel(selectedType);
   }

   public void setEnabled(boolean isEnabled) {
	  comboBox.setEnabled(isEnabled);
   }


   public void reset() {
	  //do nothing
	  comboBox.setSelectedItem(GlobalConstants.SHOW_ALL_RECORDS);
   }

   public String[] getTypes() {
	  return childTypes;
   }

   public Component getTypeArea() {
	  
	  return uiComponent;
   }

   public void setTypes(String[] childTypes) {
	  this.childTypes = childTypes;
   }

   public void setFont(Font font) {
	  if ( font == null) {
		 return;
	  } //end if ()
	  
   }



   // ==========================================
   // Section Overload
   // ==========================================

}

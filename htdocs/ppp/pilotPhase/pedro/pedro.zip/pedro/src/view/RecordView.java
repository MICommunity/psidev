/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.view;

import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JComponent;
import javax.swing.JScrollPane;
import java.util.ArrayList;
import java.awt.Insets;
import java.awt.Color;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import java.awt.BorderLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import javax.swing.event.TreeSelectionListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.tree.TreePath;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JTextArea;
import java.awt.Font;

import javax.swing.border.EmptyBorder;

import pedro.model.*;
import pedro.util.ErrorDialog;
import pedro.system.PedroException;
import pedro.system.GlobalConstants;
import pedro.config.ConfigurationFileReader;
import pedro.config.FieldConfigurationRecord;


/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class RecordView extends JPanel
   implements ActionListener {

   
   // ==========================================
   // Section Constants
   // ==========================================
   private static final int MAXIMUM_ONE_LINE_COMMENT_LENGTH = 60;


 

   // ==========================================
   // Section Properties
   // ==========================================

   private JButton keep;
   private JButton cancel;
   private JButton delete;

   //private JLabel recordLabel;

   private RecordViewTitle recordViewTitle;

   private RecordModel recordModel;
   private JPanel buttonPanel;
   private JPanel fieldPanel;
   private ArrayList fields;


   private RecordModel topLevelRecordModel;
   private boolean nodesAddedOrDeleted;
   private boolean enableContextHelp;
   private boolean enableTouchTypeOntology;

   // ==========================================
   // Section Construction
   // ==========================================
   
   public RecordView() {
	  recordModel = null;
	  nodesAddedOrDeleted = false;
	  fields = new ArrayList();
	  topLevelRecordModel = null;
	  enableTouchTypeOntology = false;

	  init();

   }

   private void init() {
	  buttonPanel = createButtonPanel();
   }

   private void buildPanel() {
	  removeAll();

	  setLayout(new GridBagLayout() );
	  
	  GridBagConstraints panelGC = new GridBagConstraints();
	  panelGC.ipadx = 20;
	  panelGC.ipady = 20;
	  panelGC.weightx = 0;
	  panelGC.anchor = GridBagConstraints.NORTHWEST;
	  panelGC.fill = GridBagConstraints.NONE;
	  panelGC.gridx = 0;
	  panelGC.gridy = 0;

	  recordViewTitle = new RecordViewTitle(recordModel.getDisplayName() );
	  recordViewTitle.setHelpLink(recordModel.getHelpLink() );
	  recordViewTitle.setForeground(Color.black);
	  add(recordViewTitle, panelGC);
	  panelGC.gridy++;
	  
	  panelGC.gridx = 0;
	  panelGC.anchor = GridBagConstraints.NORTHWEST;
	  panelGC.fill = GridBagConstraints.HORIZONTAL;
	  panelGC.weightx = 100;
	  panelGC.weighty = 0;
	  add(buildFieldPanel(), panelGC);
	  
	  panelGC.anchor = GridBagConstraints.SOUTHEAST;
	  panelGC.fill = GridBagConstraints.NONE;
	  panelGC.weightx = 0;
	  panelGC.weighty = 0;
	  panelGC.gridy++;
	  add(buttonPanel, panelGC);
	  
   }

   private void setTitle(String title) {
	  recordViewTitle.setText(title);
   }
 
   private JPanel createButtonPanel() {

	  //create button panel
	  JPanel buttonPanel = new JPanel(new GridBagLayout() );
	  GridBagConstraints buttonPanelGC = new GridBagConstraints();

	  buttonPanelGC.anchor = GridBagConstraints.CENTER;
	  buttonPanelGC.fill = GridBagConstraints.NONE;
	  buttonPanelGC.weightx = 0;
	  buttonPanelGC.weighty = 0;

	  buttonPanelGC.gridx = 0;
	  buttonPanelGC.gridy = 0;

	  keep = new JButton("Keep");
	  keep.addActionListener(this);
	  buttonPanel.add(keep, buttonPanelGC);

	  cancel = new JButton("Cancel");
	  cancel.addActionListener(this);
	  buttonPanelGC.gridx = 1;
	  buttonPanel.add(cancel, buttonPanelGC);

	  delete = new JButton("Delete");
	  
	  delete.addActionListener(this);
	  buttonPanelGC.gridx = 2;
	  buttonPanel.add(delete, buttonPanelGC);
	  return buttonPanel;
   }

   private JComponent createCommentField(JPanel panel, 
										 String comment) {
	  
	  Font font = panel.getFont();
	  Font plainFont = font.deriveFont(Font.PLAIN);

	  /*
	  if ( comment.length() <= MAXIMUM_ONE_LINE_COMMENT_LENGTH) {
		 JLabel commentLabel = new JLabel(comment);
		 commentLabel.setFont(plainFont);
		 return commentLabel;
	  } //end if ()
	  else {
	  */

		 JTextArea formComment = new JTextArea(2,30);
		 formComment.setText(comment);
		 formComment.setEditable(false);
		 formComment.setLineWrap(true);
		 formComment.setWrapStyleWord(true);
		 formComment.setBackground(panel.getBackground() );
		 formComment.setFont(plainFont);
		 JScrollPane scrollPane = new JScrollPane(formComment);
		 return scrollPane;
		 //	  } //end else
	  
	  


   }

   private JPanel buildFieldPanel() {

	  JPanel panel = new JPanel(new GridBagLayout() );

	  GridBagConstraints panelGC = new GridBagConstraints();
	  panelGC.gridy = 0;
	  panelGC.ipady = 10;

	  ArrayList fieldModels = recordModel.getFields();
	  int numberOfFields = fieldModels.size();
	  fields.clear();

	  ConfigurationFileReader configurationFileReader
		 = ConfigurationFileReader.getConfigurationFileReader();

	  //determine if there are any record level form comments to put in
	  String recordClassName = recordModel.getRecordClassName();
	  
	  FieldConfigurationRecord recordConfiguration
		 = configurationFileReader.getConfigurationRecord(recordClassName,
														  null);
	  if ( recordConfiguration != null) {
		 String recordLevelComments = recordConfiguration.getFormComments();
		 if ( recordLevelComments.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) == false) {
			panelGC.gridy++;
			panelGC.gridx = 0;
			panelGC.insets = new Insets(10,0,10,0);
			panelGC.gridwidth = GridBagConstraints.REMAINDER;
			panelGC.anchor = GridBagConstraints.NORTHWEST;
			panelGC.fill = GridBagConstraints.HORIZONTAL;
			panelGC.weightx = 100;
			panelGC.weighty = 0;
			panel.add(createCommentField(panel, recordLevelComments) , panelGC);
			panelGC.insets = new Insets(0,0,0,0);
			panelGC.gridy++;
		 } //end if ()
	  } //end if ()

	  for ( int i = 0; i < numberOfFields; i++) {

		 DataFieldModel dataFieldModel = (DataFieldModel) fieldModels.get(i);
		 FieldConfigurationRecord fieldConfiguration
			= configurationFileReader.getConfigurationRecord(recordClassName,
															 dataFieldModel.getName() );

		 if ( fieldConfiguration != null) {
			String fieldLevelComments = fieldConfiguration.getFormComments();
			if ( fieldLevelComments.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) == false) {
			   panelGC.gridx = 0;
			   //panelGC.insets = new Insets(10,0,10,0);
			   panelGC.gridwidth = GridBagConstraints.REMAINDER;
			   panelGC.anchor = GridBagConstraints.NORTHWEST;
			   panelGC.fill = GridBagConstraints.HORIZONTAL;
			   panelGC.weightx = 100;
			   panelGC.weighty = 0;
			   panel.add(createCommentField(panel, fieldLevelComments), panelGC);
			   panelGC.insets = new Insets(0,0,0,0);
			   panelGC.gridy++;
			} //end if ()
		 } //end if ()
		 
		 DataFieldView currentFieldView = getView(dataFieldModel);
		 fields.add(currentFieldView);

		 panelGC.gridx = 0;
		 panelGC.gridwidth = GridBagConstraints.RELATIVE;
		 panelGC.anchor = GridBagConstraints.NORTHWEST;
		 panelGC.fill = GridBagConstraints.NONE;
		 panelGC.weightx = 0;
		 panelGC.weighty = 0;
		 JLabel label = currentFieldView.getLabel();
		 panel.add(label, panelGC);
		 
		 panelGC.gridx = 1;
		 panelGC.gridwidth = GridBagConstraints.REMAINDER;
		 panelGC.anchor = GridBagConstraints.NORTHWEST;
		 panelGC.fill = GridBagConstraints.HORIZONTAL;
		 panelGC.weightx = 100;
		 JComponent activityArea = currentFieldView.getActivityArea();
		 
		 panel.add(activityArea, panelGC);
		 panelGC.gridy++;
	  } // end for ()
	  
	  return panel;

   }

   // ==========================================
   // Section Accessors
   // ==========================================
   public RecordModel getRecordModel() {
	  return recordModel;
   }

   public boolean nodesAddedOrDeleted() {
	  return nodesAddedOrDeleted;
   }

   public DataFieldView getFieldWithFocus() {
	  int numberOfFields = fields.size();
	  
	  for ( int i = 0; i < numberOfFields;i++) {
		 DataFieldView currentFieldView = (DataFieldView) fields.get(i);

		 if ( currentFieldView instanceof URLFieldView) {
			URLFieldView urlFieldView = (URLFieldView) currentFieldView;
			if ( urlFieldView.hasFocus() == true) {
			   return urlFieldView;
			} //end if ()
		 } //end if ()
		 else if (currentFieldView.hasFocus() == true) {
			return currentFieldView;
		 } //end else ()
	  }

	  return null;
   }

   public String getSelectedText() {
	  DataFieldView focusField = getFieldWithFocus();

	  if ( focusField == null) {
		 return null;
	  } //end if ()

	  String selectedText = null;
	  
	  if ( focusField instanceof DateFieldView) {
		 DateFieldView dateFieldView = (DateFieldView) focusField;
		 selectedText = dateFieldView.getSelectedText();
		 if ( selectedText != null) {
			return selectedText;
		 } //end if ()
	  } //end if ()
	  else if ( focusField instanceof TextFieldView) {
		 TextFieldView textField = (TextFieldView) focusField;
		 selectedText = textField.getSelectedText();
		 if ( selectedText != null) {
			return selectedText;
		 } //end if ()
	  } //end else ()
	  else if ( focusField instanceof URLFieldView) {
		 URLFieldView urlFieldView = (URLFieldView) focusField;
		 selectedText = urlFieldView.getSelectedText();
		 
		 if ( selectedText != null) {
			return selectedText;
		 } //end if ()
	  } //end else ()

	  return selectedText;
   }

   // ==========================================
   // Section Mutators
   // ==========================================
   public void enableTouchTypeOntology(boolean _enableTouchTypeOntology) {
	  this.enableTouchTypeOntology = _enableTouchTypeOntology;
	  setTouchTypeFeatureForTextFields();
   }
   
   private void setTouchTypeFeatureForTextFields() {

	  int numberOfFields = fields.size();
	  for ( int i = 0; i < numberOfFields; i++) {
		 Object currentFieldView = fields.get(i);
		 if ( currentFieldView instanceof TextFieldView) {
			TextFieldView currentTextFieldView
			   = (TextFieldView) currentFieldView;
			currentTextFieldView.enableTouchTypeOntology(enableTouchTypeOntology);
		 } //end if ()
	  } // end for ()
   }


   public void setNodesAddedOrDeleted(boolean nodesAddedOrDeleted) {
	  this.nodesAddedOrDeleted = nodesAddedOrDeleted;
   }

   public void enableContextHelp(boolean enableContextHelp) {
	  this.enableContextHelp = enableContextHelp;
	  recordViewTitle.enableContextHelp(enableContextHelp);

	  int numberOfFields = fields.size();
	  for ( int i = 0; i < numberOfFields; i++) {
		 DataFieldView currentFieldView 
			= (DataFieldView) fields.get(i);
		 currentFieldView.enableContextHelp(enableContextHelp);
	  } // end for ()

   }

   //Assumes record panel is not null
   public void setModel(RecordModel _recordModel) {
	  if ( this.recordModel != _recordModel) {
		 this.recordModel = _recordModel;
		 
		 buildPanel();
		 
		 if ( recordModel.isNewRecord() == true) {
			delete.setEnabled(false);
		 } //end if ()
		 else {
			delete.setEnabled(true);
		 } //end else


		 recordViewTitle.enableContextHelp(enableContextHelp);
		 setTouchTypeFeatureForTextFields();

		 updateUI();
		 recordModel.enableSaveChanges(true);
	  } //end if ()


   }
   
   public void updateDateFields() {
	  int numberOfFields = fields.size();
	  for ( int i = 0; i < numberOfFields; i++) {
		 DataFieldView currentFieldView 
			= (DataFieldView) fields.get(i);
		 
		 if (currentFieldView instanceof DateFieldView) {
			DateFieldView dateFieldView
			   = (DateFieldView) currentFieldView;
			dateFieldView.refreshLabel();
		 } //end if ()
	  } // end for ()
	  
   }

   private DataFieldView getView(DataFieldModel dataFieldModel) {
	  int uiRenderingType = dataFieldModel.getUIRenderingType();
	  
	  DataFieldView dataFieldView = null;

	  if ( dataFieldModel instanceof EditFieldModel) {
		 if ( dataFieldModel instanceof GroupFieldModel) {
			GroupFieldModel groupFieldModel = (GroupFieldModel) dataFieldModel;
			
			if ( uiRenderingType == GlobalConstants.COMBINATION_FIELD) {

			   CombinationFieldView combinationFieldView
				  = new CombinationFieldView();
			   combinationFieldView.setModel(groupFieldModel);
			   dataFieldView = combinationFieldView;
			} //end if ()
			else if ( uiRenderingType == GlobalConstants.RADIO_FIELD) {

			   RadioFieldView radioFieldView 
				  = new RadioFieldView();
			   radioFieldView.setModel(groupFieldModel);
			   dataFieldView = radioFieldView;
			} //end else ()
		 } //end if ()
		 else if ( dataFieldModel instanceof TextFieldModel) {

			TextFieldModel textFieldModel = (TextFieldModel) dataFieldModel;
			if ( uiRenderingType == GlobalConstants.TEXT_FIELD) {
			   TextFieldView textFieldView
				  = new TextFieldView();
			   textFieldView.setModel(textFieldModel);
			   dataFieldView = textFieldView;

			}
		 } //end else ()
		 else {
			
			EditFieldModel editFieldModel = (EditFieldModel) dataFieldModel;
			
			if ( uiRenderingType == GlobalConstants.DATE_FIELD) {

			   DateFieldView dateFieldView = new DateFieldView();
			   dateFieldView.setModel(editFieldModel);
			   dataFieldView = dateFieldView;

			} //end if ()
			else if ( uiRenderingType == GlobalConstants.URL_FIELD) {

			   URLFieldView urlFieldView = new URLFieldView();
			   urlFieldView.setModel(editFieldModel);

			   dataFieldView = urlFieldView;

			} //end else ()

		 } //end else
		 
	  } //end if ()
	  else {
		 //it's a list
		 ListFieldModel listFieldModel = (ListFieldModel) dataFieldModel;
		 
		 if ( uiRenderingType == GlobalConstants.ONE_TYPE_ONE_VALUE_LIST) {
			STSVListFieldView stsv = new STSVListFieldView(this);
			stsv.setModel(listFieldModel);
			dataFieldView = stsv;
		 } //end if ()
		 else if ( uiRenderingType == GlobalConstants.ONE_TYPE_N_VALUE_LIST) {
			STMVListFieldView stmv = new STMVListFieldView(this);
			stmv.setModel(listFieldModel);
			dataFieldView = stmv;
		 } //end else ()
		 else if ( uiRenderingType == GlobalConstants.N_TYPE_ONE_VALUE_LIST) {
			MTSVListFieldView mtsv = new MTSVListFieldView(this);
			mtsv.setModel(listFieldModel);
			dataFieldView = mtsv;
		 } //end else ()
		 else if ( uiRenderingType == GlobalConstants.N_TYPE_N_VALUE_LIST) {
			MTMVListFieldView mtmv = new MTMVListFieldView(this);
			mtmv.setModel(listFieldModel);
			dataFieldView = mtmv;
		 } //end else ()

	  } //end else

	  if ( dataFieldView != null) {
		 dataFieldView.enableContextHelp(enableContextHelp);
	  } //end if ()

	  return dataFieldView;
   }

   public void setTopLevelRecord(RecordModel _topLevelRecordModel) {
	  this.topLevelRecordModel = _topLevelRecordModel;
   }

   public void refreshList(String listFieldName) {
	  int numberOfFields = fields.size();

	  for ( int i = 0; i < numberOfFields; i++) {
		 DataFieldView currentFieldView 
			= (DataFieldView) fields.get(i);
		 if ( currentFieldView instanceof ListFieldView) {

			if ( currentFieldView.getName().equals(listFieldName) == true) {
			   ListFieldView targetListField 
				  = (ListFieldView) currentFieldView;
			   targetListField.refresh();
			   
			} //end if ()

		 } //end if ()
	  } // end for ()
	  


   }

   // ==========================================
   // Section Validation
   // ==========================================
   public String validateEditFields(boolean highlightErrors) {

	  StringBuffer errorMessages = new StringBuffer();

	  int numberOfFields = fields.size();

	  for ( int i = 0; i < numberOfFields; i++) {
		 DataFieldView currentFieldView 
			= (DataFieldView) fields.get(i);
		 if ( currentFieldView instanceof EditFieldView) {
			EditFieldView editFieldView 
			   = (EditFieldView) currentFieldView;
			String fieldError = editFieldView.validate(highlightErrors);
			if ( fieldError != null) {
			   errorMessages.append("* ");
			   errorMessages.append(fieldError);
			   errorMessages.append("\n");
			} //end if ()
			
		 } //end if ()
	  } // end for ()
	  
	  return errorMessages.toString();
	  
   }

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================

   public boolean isDirty() {
	  //go through each of the fieldviews and determine whether any of them 
	  int numberOfFields = fields.size();
	  for ( int i = 0; i < numberOfFields; i++) {
		 DataFieldView currentFieldView 
			= (DataFieldView) fields.get(i);
		 if ( currentFieldView instanceof EditFieldView) {
			EditFieldView editFieldView 
			   = (EditFieldView) currentFieldView;
			if ( editFieldView.isDirty() == true) {
			   return true;
			} //end if ()
		 } //end if ()
	  } // end for ()
	  return false;

   }

   public void keepValues() throws PedroException {
	  String errors = validateEditFields(true);
	  
	  if ( errors.equals("") == false) {
		 throw new PedroException(errors);
	  }
	  else {
		 int numberOfFields = fields.size();
		 for ( int i = 0; i < numberOfFields; i++) {
			DataFieldView currentFieldView 
			   = (DataFieldView) fields.get(i);
			if ( currentFieldView instanceof EditFieldView) {
			   EditFieldView editFieldView
				  = (EditFieldView) currentFieldView;
			   editFieldView.keepValue();
			} //end if ()
		 }

		 delete.setEnabled(true);

		 //if any changes were made to display name components,
		 //recordModel should inform its listeners


		 recordModel.informListenersOfNameChange();
		 setTitle(recordModel.getDisplayName() );
	  }
   }

   //Interface ActionListener
   public void actionPerformed(ActionEvent event) {
	  Object source = event.getSource();

	  if ( source == keep) {
		 try {
			keepValues();
		 } catch (PedroException error) {
			ErrorDialog.show(error.getMessage() );
		 } // end try-catch
		 
	  } //end else ()
	  else if ( recordModel == topLevelRecordModel) {
		 //will not allow to delete; will not allow
		 //to cancel unless it isn't a new record
		 if ( ( source == cancel) && (recordModel.isNewRecord() == false) ) {
			cancel();
		 } //end if ()
	  } //end else ()
	  else if ( source == cancel) {
		 cancel();
	  } //end else ()
	  else if ( source == delete) {
		 delete();
	  } //end else ()
   }

   // ==========================================
   // Section Overload
   // ==========================================


   // ==========================================
   // Section Private
   // ==========================================

   private void delete() {
	  recordModel.informListenersOfDestruction();
   }

   public void cancel() {


	  if ( recordModel.isNewRecord() == true) {
		 //we'll have to delete it
		 recordModel.informListenersOfDestruction();
	  } //end if ()
	  else {
		 //restore the values
	  
		 int numberOfFields = fields.size();
		 for ( int i = 0; i < numberOfFields; i++) {
			DataFieldView currentFieldView 
			   = (DataFieldView) fields.get(i);
			if ( currentFieldView instanceof EditFieldView) {
			   EditFieldView editFieldView
				  = (EditFieldView) currentFieldView;
			   editFieldView.restoreValue();
			} //end if ()
		 }

	  } //end else
   }

}

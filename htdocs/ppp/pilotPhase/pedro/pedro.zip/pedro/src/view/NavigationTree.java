/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.view;

import javax.swing.tree.TreeSelectionModel;
import javax.swing.event.TreeSelectionListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.JTree;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import javax.swing.JOptionPane;

import java.util.Hashtable;
import java.util.ArrayList;



import pedro.system.GlobalConstants;
import pedro.validation.StringMaskValidator;
import pedro.util.SaveChangesDialog;
import pedro.model.RecordModel;
import pedro.model.RecordModelFactory;
import pedro.model.ChangeObject;
import pedro.model.ListFieldModel;
/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class NavigationTree extends JTree 
   implements ChangeListener {

   
   // ==========================================
   // Section Constants
   // ==========================================
   private static final int DESTINATION_SELECTED = 11;
   private static final int SOURCE_AND_DESTINATION_SELECTED = 12;
   private static final int PENDING = 13;
   private static final int ACCEPTED = 14;
   private static final int REJECTED = 15;
   private static final int FINISHED = 16;

   // ==========================================
   // Section Properties
   // ==========================================
   private Hashtable nodeFromRecordModel;
   private NavigationTreeNode selectedNode;

   private NavigationTreeNode sourceNode;
   private RecordModel sourceRecordModel;
   private NavigationTreeNode destinationNode;
   private RecordModel destinationRecordModel;

   private RecordView recordView;
   private ArrayList searchResults;
   private SearchResultDialog searchResultDialog;

   private int selectionState;
   private int transitionState;
   
   private TreeSelectionEventManager treeSelectionEventManager;
   private boolean enableUpdateUI;

   private boolean fileHasErrors;

   private boolean nodesAddedOrDeleted;

   private DefaultTreeModel model;

   // ==========================================
   // Section Construction
   // ==========================================
   public NavigationTree() {
	  init();
   }

   private void init() {
	  nodesAddedOrDeleted = false;
	  recordView = null;
	  searchResults = new ArrayList();
	  treeSelectionEventManager = new TreeSelectionEventManager(this);
	  addTreeSelectionListener(treeSelectionEventManager);
	  nodeFromRecordModel = new Hashtable();
	  setCellRenderer(new TreeNodeRenderer() );
	  selectedNode = null;
	  selectionState = DESTINATION_SELECTED;
	  enableUpdateUI = true;
	  searchResultDialog = null;
	  TreeSelectionModel selectionModel = getSelectionModel();
	  selectionModel.setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
	  setShowsRootHandles(false); 
	  fileHasErrors = false;
   }



   // ==========================================
   // Section Accessors
   // ==========================================
   public boolean nodesAddedOrDeleted() {
	  return nodesAddedOrDeleted;
   }


   // ==========================================
   // Section Mutators
   // ==========================================
   public void acknowledgeChangesMade() {
	  setNodesAddedOrDeleted(false);

	  DefaultTreeModel model = (DefaultTreeModel) getModel();
	  NavigationTreeNode root = (NavigationTreeNode) model.getRoot();
	  clearChanges(root);
   }


   public void setNodesAddedOrDeleted(boolean nodesAddedOrDeleted) {
	  this.nodesAddedOrDeleted = nodesAddedOrDeleted;
   }


   public void setSearchResultDialog(SearchResultDialog searchResultDialog) {
	  this.searchResultDialog = searchResultDialog;
   }

   public void showChanges() {
	  DefaultTreeModel model = (DefaultTreeModel) getModel();
	  NavigationTreeNode root = (NavigationTreeNode) model.getRoot();
	  showChanges(root);
	  repaint();
   }
   
   private void showMissingNodes() {
	  DefaultTreeModel model = (DefaultTreeModel) getModel();
	  NavigationTreeNode root = (NavigationTreeNode) model.getRoot();

	  //Step I: recursively remove all missing nodes
	  removeMissingNodes(root);
	  //Step II: recursively add all missing nodes
	  addMissingNodes(root);
	  if ( enableUpdateUI == true) {
		 updateUI();
	  } //end if ()
	  
   }



   public void resetDisplay() {
	  DefaultTreeModel model = (DefaultTreeModel) getModel();
	  NavigationTreeNode root = (NavigationTreeNode) model.getRoot();
	  resetNode(root);

	  if ( enableUpdateUI == true) {
		 updateUI();
	  } //end if ()

   }

   public void updateDateFields() {
	  DefaultTreeModel model = (DefaultTreeModel) getModel();
	  NavigationTreeNode root = (NavigationTreeNode) model.getRoot();
	  updateDateFields(root);
	  updateUI();
   }

   /**
	*
	* the idea here is to "paste" pasteModel in place of targetModel in the tree.
	*
	*/
   public void pasteNode(RecordModel targetRecordModel,
						 RecordModel pasteRecordModel) {

	  if ( targetRecordModel.isNewRecord() == false) {

		 StringBuffer warningMessage = new StringBuffer();
		 warningMessage.append("Warning: this record and all its subrecords ");
		 warningMessage.append("will be replaced by the new contents.  Proceed?");

		 int answer = JOptionPane.showConfirmDialog(null,
													warningMessage.toString(),
													"Replace Record Contents", 
													JOptionPane.YES_NO_OPTION,
													JOptionPane.WARNING_MESSAGE,
													null);

		 if ( answer == JOptionPane.NO_OPTION) {
			return;
		 } //end if ()
		 
	  } //end if () 

	  ListFieldModel listFieldModel 
		 = targetRecordModel.getContainingListModel();

	  if ( listFieldModel == null) {
		 //this is the root node
		 setRoot(pasteRecordModel);
		 recordView.setModel(pasteRecordModel);
		
		 return;
	  } //end if ()

	  listFieldModel.removeChild(targetRecordModel);
	  //targetRecordModel.setContainingListModel(null);


	  boolean oldEnableUpdateUI = enableUpdateUI;
	  enableUpdateUI(false);

	  deleteNode(targetRecordModel);


	  RecordModel parentRecordModel = listFieldModel.getContainingRecord();
	  listFieldModel.addChild(pasteRecordModel);
	  pasteRecordModel.setContainingListModel(listFieldModel);
	  pasteRecordModel.setNewRecord(false);
	  pasteRecordModel.setSaveChanges(true);
	  

	  addSubTree(parentRecordModel,
				 pasteRecordModel);


	  enableUpdateUI(oldEnableUpdateUI);

	  recordView.setModel(pasteRecordModel);
	  
	  setActiveNode(pasteRecordModel);

	  updateUI();

   }



   private void updateDateFields(NavigationTreeNode node) {
	  RecordModel recordModel = node.getRecordModel();
	  recordView.updateDateFields();

	  int numberOfChildren = node.getChildCount();
	  for ( int i = 0; i < numberOfChildren; i++) {
		 NavigationTreeNode currentChildNode = (NavigationTreeNode) node.getChildAt(i);
		 updateDateFields(currentChildNode);
	  } // end for ()

   }
   
   public ArrayList applySearch(String searchMask) {
	  String upperCaseMask = searchMask.toUpperCase();
	  DefaultTreeModel model = (DefaultTreeModel) getModel();
	  NavigationTreeNode root = (NavigationTreeNode) model.getRoot();

	  searchResults.clear();
	  applySearch(root,upperCaseMask);
	  updateUI();
	  return searchResults;
   }

   public void setRecordView(RecordView recordView) {
	  this.recordView = recordView;

	  treeSelectionEventManager.setRecordView(recordView);
   }

   public void showNode(RecordModel recordModel) {
	  NavigationTreeNode node 
		 = (NavigationTreeNode) nodeFromRecordModel.get(recordModel);
	  showNode(node);
   }


   public void showNode(NavigationTreeNode node) {
	  DefaultTreeModel model = (DefaultTreeModel) getModel();
	  
	  TreePath visiblePath 
		 = new TreePath( model.getPathToRoot(node) );
	  makeVisible(visiblePath);
   }

   private boolean valueMatchesMask(String stringMask,
									String candidateValue) {

	  //we're going to borrow the StringMaskValidator code 
	  //used to validate that a text field matches a string filter
	  
	  /*

	  StringMaskValidator stringMaskValidator
		 = new StringMaskValidator(stringMask.toUpperCase());
	  */

	  String upperCaseValue = candidateValue.toUpperCase();

	  int index = upperCaseValue.indexOf(stringMask);
	  if ( index == -1) {
		 return false;
	  } //end if ()
	  else {
		 return true;
	  } //end else
	  
   }

   public void enableUpdateUI(boolean enableUpdateUI) {
	  this.enableUpdateUI = enableUpdateUI;
   }

   public void updateNode(RecordModel recordModel) {
	  NavigationTreeNode node = (NavigationTreeNode) nodeFromRecordModel.get(recordModel);
	  updateNode(node);
	  if ( searchResultDialog != null) {
		 searchResultDialog.updateRecordModel(recordModel);
	  } //end if ()
	  
   }

   public void updateNode(NavigationTreeNode node) {
	  RecordModel recordModel = node.getRecordModel();

	  String oldDisplayName = node.getDisplayName();

	  String newDisplayName = recordModel.getDisplayName();
	  
	  if ( oldDisplayName.equals(newDisplayName) == false) {
		 node.setDisplayName(newDisplayName);
	  } //end if ()


	  if ( enableUpdateUI == true) {
		 removeTreeSelectionListener(treeSelectionEventManager);
		 updateUI();
		 addTreeSelectionListener(treeSelectionEventManager);
		 treeSelectionEventManager.ignore();
	  } //end if ()
	  
   }


   public void setRoot(RecordModel rootRecordModel) {
	  NavigationTreeNode rootNode = new NavigationTreeNode(rootRecordModel);
	  nodeFromRecordModel.put(rootRecordModel,rootNode);

	  setRoot(rootNode);
	  //recordView.setRecordModel(rootRecordModel);
	  /*
	  DefaultTreeModel model = new DefaultTreeModel(rootNode);
	  setModel(model);
 	  nodeFromRecordModel.put(rootRecordModel,rootNode);
	  if ( enableUpdateUI == true) {
		 updateUI();
	  } //end if ()
	  */

   }

   public NavigationTreeNode getActiveNode() {
	  TreePath treePath = getLeadSelectionPath();
	  NavigationTreeNode node = null;

	  if ( treePath != null) {
		 node = (NavigationTreeNode) treePath.getLastPathComponent();
	  } //end if ()

	  return node;
   }


   public void setRoot(NavigationTreeNode rootNode) {
	  RecordModel rootRecordModel = rootNode.getRecordModel();

	  DefaultTreeModel model = new DefaultTreeModel(rootNode);
	  setModel(model);

	  nodeFromRecordModel.clear();
	  addToKeyList(rootNode);

	  setActiveNode(rootNode);
	  updateUI();
   }

   public void addToKeyList(NavigationTreeNode node) {
	  
	  RecordModel recordModel = node.getRecordModel();
	  recordModel.computeDisplayName();
	  node.setDisplayName(recordModel.getDisplayName() );

	  if (nodeFromRecordModel.contains(recordModel) == false) {
		 nodeFromRecordModel.put(recordModel,node);
	  } //end if ()

	  int numberOfChildren = node.getChildCount();
	  for ( int i = 0; i < numberOfChildren; i++) {
		 NavigationTreeNode currentChildNode = (NavigationTreeNode) node.getChildAt(i);
		 addToKeyList(currentChildNode);
	  } // end for ()
   }

   public void addSubTree(RecordModel parentRecordModel,
						  RecordModel childSubTreeModel) {


	  NavigationTreeNode childSubTreeNode 
		 = new NavigationTreeNode(childSubTreeModel);

	  NavigationTreeNode node 
		 = (NavigationTreeNode) nodeFromRecordModel.get(parentRecordModel);

	  ArrayList changeListeners = parentRecordModel.getChangeListeners();

	  NavigationTreeNode subTreeRoot = addSubTreeNode(node,
													  childSubTreeModel,
													  changeListeners);

	  node.add(subTreeRoot);
	  
	  nodesAddedOrDeleted = true;

   }

   public NavigationTreeNode addSubTreeNode(NavigationTreeNode parentNode,
											RecordModel childRecordModel,
											ArrayList changeListeners) {
	  
	  	
  
	  childRecordModel.setChangeListeners(changeListeners);
	  NavigationTreeNode childNode = new NavigationTreeNode(childRecordModel);
	  nodeFromRecordModel.put(childRecordModel,childNode);

	  ArrayList lists = childRecordModel.getListFields();
	  int numberOfLists = lists.size();
	  for ( int i = 0; i < numberOfLists; i++) {
		 ListFieldModel currentListField = (ListFieldModel) lists.get(i);
		 ArrayList listChildren = currentListField.getChildren();
		 int numberOfChildren = listChildren.size();
		 for ( int j = 0; j < numberOfChildren; j++) {
			RecordModel grandChild = (RecordModel) listChildren.get(j);
			NavigationTreeNode grandChildNode = 
			   addSubTreeNode(childNode, 
							  grandChild,
							  changeListeners);
			childNode.add(grandChildNode);
		 } // end for ()
		 
	  } // end for ()

	  return childNode;

   }

   public void addNode(RecordModel parentRecordModel, 
					   RecordModel childRecordModel) {


	  //Scenario I: parent has been added before the child
	  
	  //child may have already been registered when it was a parent from scenario II
	  NavigationTreeNode childNode = (NavigationTreeNode) nodeFromRecordModel.get(childRecordModel);
	  if ( childNode == null) {
		 childNode = new NavigationTreeNode(childRecordModel);
		 nodeFromRecordModel.put(childRecordModel,childNode);
	  } //end if ()
	  updateNode(childRecordModel);
 	  
	  //Scenario II: child has been added, parent not yet added
	  NavigationTreeNode parentNode = (NavigationTreeNode) nodeFromRecordModel.get(parentRecordModel);
	  if ( parentNode == null) {
		 //parentRecordModel.computeDisplayName();
		 parentNode = new NavigationTreeNode(parentRecordModel);
		 nodeFromRecordModel.put(parentRecordModel,parentNode);
	  } //end if ()
	  updateNode(parentRecordModel);
	  parentNode.add(childNode);
	  nodesAddedOrDeleted = true;

	  if ( enableUpdateUI == true) {
		 updateUI();
	  } //end if ()

   }

   public void deleteNode(RecordModel recordModel) {
	  NavigationTreeNode node 
		 = (NavigationTreeNode) nodeFromRecordModel.get(recordModel);

	  NavigationTreeNode parentNode 
		 = (NavigationTreeNode) node.getParent();

	  deleteNode(node);
	  // set selection state of tree
	  selectionState = DESTINATION_SELECTED;
	  setActiveNode(parentNode.getRecordModel() );

	  nodesAddedOrDeleted = true;


	  if ( enableUpdateUI == true) {
		 updateUI();
	  } //end if ()

   }

   //used by record panel, search result panel
   public void setActiveNode(RecordModel recordModel) {

	  NavigationTreeNode node 
		 = (NavigationTreeNode) nodeFromRecordModel.get(recordModel);

	  if ( selectedNode != null) {
		 selectedNode.setSelected(false);
	  } //end if ()

	  selectedNode = node;
	  selectedNode.setSelected(true);

	  treeSelectionEventManager.setActiveNode(node);

	  /*
	  //make this the active selection path
	  DefaultTreeModel model = (DefaultTreeModel) getModel();
	  setSelectionPath( new TreePath(model.getPathToRoot(selectedNode)) );
	  updateUI();
	  */
   }

   public void setActiveNode2(RecordModel recordModel) {
	  NavigationTreeNode node 
		 = (NavigationTreeNode) nodeFromRecordModel.get(recordModel);

	  if ( selectedNode != null) {
		 selectedNode.setSelected(false);
	  } //end if ()

	  selectedNode = node;
	  selectedNode.setSelected(true);

	  //make this the active selection path
	  DefaultTreeModel model = (DefaultTreeModel) getModel();
	  setSelectionPath( new TreePath(model.getPathToRoot(selectedNode)) );
   }



   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================

   // ==========================================
   // Section Interfaces
   // ==========================================
   //Interface: ChangeListener
   public void stateChanged(ChangeEvent event) {

	  ChangeObject changeObject = (ChangeObject) event.getSource();
	  
	  int changeType = changeObject.getChangeType();
	  RecordModel targetRecord = changeObject.getRecord();

	  if ( changeType == ChangeObject.OBJECT_DELETED) {

		 //remove the node from whatever parent owns it.
		 //RecordView guarantees this won't be called if it's the root
		 //so we can assume it isn't.

		 ListFieldModel listFieldModel = targetRecord.getContainingListModel();
		 if ( listFieldModel != null) {
			listFieldModel.removeChild(targetRecord);
		 } //end if ()

		 deleteNode(targetRecord);

	  } //end if ()
	  else if ( changeType == ChangeObject.OBJECT_UPDATED) {
		 targetRecord.setNewRecord(false);
		 //NOTE: throws an exception to do with pumping tree events.
		 updateNode(targetRecord);
	  } //end else ()
	  else if ( changeType == ChangeObject.OBJECT_CANCELLED) {
	  } //end else ()
	  else if ( changeType == ChangeObject.OBJECT_GAINS_FOCUS) {
		 setActiveNode(targetRecord );
	  } //end else ()
	  else if ( changeType == ChangeObject.OBJECT_CREATED) {

		 ListFieldModel listFieldModel = targetRecord.getContainingListModel();
		 if ( listFieldModel != null) {
			RecordModel parentRecord = listFieldModel.getContainingRecord();

			//add record to tree
			addNode(parentRecord,
					targetRecord);
			enableUpdateUI(true);
			setActiveNode(targetRecord);
			
		 } //end if ()
		 else {

		 } //end else
		 
		 
		 
	  } //end else ()


   }



   private NavigationTreeNode getCurrentlySelectedNode(TreeSelectionEvent event) {
	  TreePath activePath = event.getPath();
	  NavigationTreeNode activeNode 
		 = (NavigationTreeNode) activePath.getLastPathComponent();

	  return activeNode;
   }

   /*
   public void updateSelectedNode(NavigationTreeNode node) {
	  if ( selectedNode != null) {
		 selectedNode.setSelected(false);
	  } //end if ()

	  selectedNode = node;
	  selectedNode.setSelected(true);
   }
   */

   private static int counter = 0;

   private void setSourceAndDestinationNodes(TreeSelectionEvent event) {
	  sourceNode = destinationNode;
	  if ( sourceNode != null) {
		 sourceRecordModel = sourceNode.getRecordModel();
	  } //end if ()
	  
	  destinationNode = getCurrentlySelectedNode(event);
	  destinationRecordModel = destinationNode.getRecordModel();
   }
  
   // ==========================================
   // Section Overload
   // ==========================================

   // ==========================================
   // private methods
   // ==========================================
   //used by the tree
   private void setActiveNode(NavigationTreeNode node) {
	  
	  if ( selectedNode != null) {
		 selectedNode.setSelected(false);
	  } //end if ()
	  
	  selectedNode = node;
	  
	  //show the node
	  showNode(node.getRecordModel() );
	  //indicate it is selected
	  selectedNode.setSelected(true);
	  
	  // updateUI();
   }

   private void deleteNode(NavigationTreeNode node) {

	  DefaultTreeModel model = (DefaultTreeModel) getModel();

	  if ( searchResultDialog != null) {
		 searchResultDialog.deleteRecordModel(node.getRecordModel());
	  } //end if ()

	  //remove node from lookup hash
	  nodeFromRecordModel.remove(node);	
	  
	  //perform same for children
	  int numberOfChildren = node.getChildCount();

	  ArrayList children = new ArrayList();

	  for ( int i = 0; i < numberOfChildren; i++) {
		 NavigationTreeNode currentChild 
			= (NavigationTreeNode) node.getChildAt(i);
		 children.add(node.getChildAt(i) );
	  } // end for ()

	  for ( int i = 0; i < numberOfChildren; i++) {
		 NavigationTreeNode currentNode =
		    (NavigationTreeNode) children.get(i);
		 deleteNode(currentNode);
	  } // end for ()

	  model.removeNodeFromParent(node);

   }

   private void applySearch(NavigationTreeNode parentNode, 
							String searchMask) {

	  RecordModel currentRecordModel = parentNode.getRecordModel();
	  String currentRecordModelName = currentRecordModel.getDisplayName();
	  if ( valueMatchesMask(searchMask,currentRecordModelName) == true) {
		 parentNode.setShowSearchResult(true);
		 showNode(parentNode);
		 searchResults.add(currentRecordModel );
	  } //end if ()

	  DefaultTreeModel model = (DefaultTreeModel) getModel();

	  int numberOfChildren = model.getChildCount(parentNode);

	  for ( int i = 0; i < numberOfChildren; i++) {
		 NavigationTreeNode currentChild 
			= (NavigationTreeNode) model.getChild(parentNode,
												  i);
		 
		 applySearch(currentChild, searchMask);

	  } // end for ()


   }

   private void addMissingNodes(NavigationTreeNode node) {
	  DefaultTreeModel model = (DefaultTreeModel) getModel();
	  //NavigationTreeNode root = (NavigationTreeNode) model.getRoot();


	  RecordModel recordModel = node.getRecordModel();
	  String[] missingRecordModelTypes = recordModel.getMissingRecordTypes();
	  RecordModelFactory recordModelFactory = RecordModelFactory.getRecordModelFactory();

	  ArrayList children = new ArrayList();
	  int numberOfChildren = node.getChildCount();
	  for ( int i = 0; i < numberOfChildren; i++) {
		 children.add(node.getChildAt(i) );
	  } // end for ()

	  for ( int i = 0; i < missingRecordModelTypes.length; i++) {
		 RecordModel missingRecordModel 
			= recordModelFactory.createRecordModel(missingRecordModelTypes[i]);
		 missingRecordModel.computeDisplayName();
		 NavigationTreeNode missingNode 
			= new NavigationTreeNode(missingRecordModel);
		 missingNode.setDisplayName(missingRecordModel.getRecordClassName() );
		 missingNode.setShowMissing(true);

		 node.add(missingNode);

		 showNode(missingNode);
	  } // end for ()

	  for ( int i = 0; i < numberOfChildren; i++) {
		 NavigationTreeNode currentChild
			= (NavigationTreeNode) children.get(i);
		 addMissingNodes(currentChild);
	  } // end for ()




   }

   private void removeMissingNodes(NavigationTreeNode node) {

	  if ( node.showMissing() == true) {
		 deleteNode(node);
	  } //end if ()
	  else {
		 
		 ArrayList children = new ArrayList();
		 int numberOfChildren = node.getChildCount();
		 for ( int i = 0; i < numberOfChildren; i++) {
			children.add(node.getChildAt(i) );
		 } // end for ()
		 
		 for ( int i = 0; i < numberOfChildren; i++) {
			NavigationTreeNode currentChild
			   = (NavigationTreeNode) children.get(i);
			removeMissingNodes(currentChild);
		 } // end for ()
		 
	  } //end else
	  
   }
   
   private void resetNode(NavigationTreeNode node) {
	  removeMissingNodes(node);
	  
	  node.setChanged(false);
	  node.setShowError(false);
	  node.setShowSearchResult(false);
	  
	  ArrayList childrenToReset = new ArrayList();
	  
		 
	  int numberOfChildren = node.getChildCount();
	  for ( int i = 0; i < numberOfChildren; i++) {
		 NavigationTreeNode childNode 
			= (NavigationTreeNode) node.getChildAt(i);
		 childrenToReset.add(childNode);
	  } // end for ()
	  
	  for ( int i = 0; i < numberOfChildren; i++) {
		 NavigationTreeNode childNode
			= (NavigationTreeNode) childrenToReset.get(i);
		 resetNode(childNode);
	  } // end for ()
	  
   } //end else

   public void validateRecordModelTree() {
	  showErrors();
	  showMissingNodes();
   }

   private void showErrors() {
	  fileHasErrors = false;
	  DefaultTreeModel model = (DefaultTreeModel) getModel();
	  NavigationTreeNode root = (NavigationTreeNode) model.getRoot();
	  showErrors(root);

	  //finally, validate the edit fields of the current record

	  RecordModel currentModel = recordView.getRecordModel();
	  String errors = recordView.validateEditFields(true);

	  if ( errors.equals("") == false) {
		 NavigationTreeNode node 
			= (NavigationTreeNode) nodeFromRecordModel.get(currentModel);
		 node.setShowError(true);
	  } //end if ()

   }

   public boolean fileHasErrors() {
	  return fileHasErrors;
   }

   private void showErrors(NavigationTreeNode node) {

	  if ( node.showMissing() == true) {
		 return;
	  } //end if ()
	  
	  RecordModel recordModel = node.getRecordModel();
	  String errors = recordModel.validate();
	  if ( errors != null) {
		 System.out.println("NT errors=="+errors+"==");
		 fileHasErrors = true;
		 node.setShowError(true);
	  } //end if ()
	  else {
		 node.setShowError(false);
	  } //end else
		 
	  int numberOfChildren = node.getChildCount();
	  for ( int i = 0; i < numberOfChildren; i++) {
		 NavigationTreeNode childNode 
			= (NavigationTreeNode) node.getChildAt(i);
		 showErrors(childNode);
	  } // end for ()

   }

   private void clearChanges(NavigationTreeNode node) {
	  RecordModel recordModel = node.getRecordModel();
	  recordModel.setSaveChanges(false);

	  int numberOfChildren = node.getChildCount();
	  for ( int i = 0; i < numberOfChildren; i++) {
		 NavigationTreeNode currentChildNode = (NavigationTreeNode) node.getChildAt(i);
		 clearChanges(currentChildNode);
	  } // end for ()

   }

   private void showChanges(NavigationTreeNode node) {
	  DefaultTreeModel model = (DefaultTreeModel) getModel();
	  NavigationTreeNode root = (NavigationTreeNode) model.getRoot();

	  RecordModel recordModel = node.getRecordModel();

	  if ( recordModel.saveChanges() == true) {
		 node.setChanged(true);
	  } //end if ()
	  else {
		 node.setChanged(false);
	  } //end else
		 
	  int numberOfChildren = node.getChildCount();
	  for ( int i = 0; i < numberOfChildren; i++) {
		 NavigationTreeNode childNode 
			= (NavigationTreeNode) node.getChildAt(i);
		 showChanges(childNode);
	  } // end for ()

   }

   
}





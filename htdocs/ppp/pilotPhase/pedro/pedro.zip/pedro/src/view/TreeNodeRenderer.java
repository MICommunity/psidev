/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.view;

import javax.swing.tree.TreeCellRenderer;
import javax.swing.*;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.FontUIResource;
import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.io.*;
import java.util.*;

import pedro.system.GlobalConstants;

import javax.swing.tree.DefaultMutableTreeNode;

public class TreeNodeRenderer extends JLabel implements TreeCellRenderer
{
    /** Is the value currently selected. */
    protected boolean selected;
    /** True if has focus. */
    protected boolean hasFocus;
    /** True if draws focus border around icon as well. */
    private boolean drawsFocusBorderAroundIcon;

   transient protected ImageIcon changedClosedIcon;
   transient protected ImageIcon closedIcon;

   transient protected ImageIcon changedOpenIcon;
   transient protected ImageIcon openIcon;

   transient protected ImageIcon changedLeafIcon;
   transient protected ImageIcon leafIcon;


   private Color ghostTextColour;
   private Color ghostBorderColour;
   private Color deletedColour;
   private Color missingColour;
   private Color selectedColour;
   private Color searchResultColour;

   private Color errorColour;

   private boolean isSelected;
   private boolean isChanged;
   private boolean showMissing;
   private boolean showSearchResult;
   private boolean showError;
   private boolean showDeleted;

    /**
      * Returns a new instance of DefaultTreeCellRenderer.  Alignment is
      * set to left aligned. Icons and text color are determined from the
      * UIManager.
      */

   public TreeNodeRenderer(String name) {
	  super(name);
	  init();
   }
    public TreeNodeRenderer() {
	   init();
    }

   private void init() {
	   ghostTextColour = new Color(100,100,100);
	   ghostBorderColour = new Color(100,100,100);
	   deletedColour = new Color(200,200,200);
	   missingColour = new Color(230,230,100);
	   errorColour = Color.red;

	   //sort of a lime green
	   selectedColour = new Color(60,230,25);

	   searchResultColour = new Color(219,39,216);

	   setHorizontalAlignment(JLabel.LEFT);
	   
	   String iconPath = GlobalConstants.ICON_PATH;


	   changedClosedIcon = new ImageIcon(iconPath+ "ChangedTreeClosed.gif");
	   closedIcon = new ImageIcon(iconPath+"TreeClosed.gif");

	   changedOpenIcon = new ImageIcon(iconPath + "ChangedTreeOpen.gif");
	   openIcon = new ImageIcon(iconPath + "TreeOpen.gif");

	   changedLeafIcon = new ImageIcon(iconPath + "ChangedTreeLeaf.gif");
	   leafIcon = new ImageIcon(iconPath + "TreeLeaf.gif");
   }


    /**
      * Returns the default icon, for the current laf, that is used to
      * represent non-leaf nodes that are expanded.
      */
    public Icon getDefaultOpenIcon() {
	   return openIcon;
    }

    /**
      * Returns the default icon, for the current laf, that is used to
      * represent non-leaf nodes that are not expanded.
      */
    public Icon getDefaultClosedIcon() {
	   return closedIcon;
    }

    /**
      * Returns the default icon, for the current laf, that is used to
      * represent leaf nodes.
      */
    public Icon getDefaultLeafIcon() {
	   return leafIcon;
    }

    /**
      * Sets the icon used to represent non-leaf nodes that are expanded.
      */
    public void setOpenIcon(ImageIcon newIcon) {
	openIcon = newIcon;
    }

    /**
      * Returns the icon used to represent non-leaf nodes that are expanded.
      */
    public Icon getOpenIcon() {
	return openIcon;
    }

    /**
      * Sets the icon used to represent non-leaf nodes that are not expanded.
      */
    public void setClosedIcon(ImageIcon newIcon) {
	closedIcon = newIcon;
    }

    /**
      * Returns the icon used to represent non-leaf nodes that are not
      * expanded.
      */
    public Icon getClosedIcon() {
	return closedIcon;
    }

    /**
      * Sets the icon used to represent leaf nodes.
      */
    public void setLeafIcon(ImageIcon newIcon) {
	leafIcon = newIcon;
    }

    /**
      * Returns the icon used to represent leaf nodes.
      */
    public Icon getLeafIcon() {
	return leafIcon;
    }
 
    public void setFont(Font font) {
	if(font instanceof FontUIResource)
	    font = null;
	super.setFont(font);
    }

    public void setBackground(Color color) {
	if(color instanceof ColorUIResource)
	    color = null;
	super.setBackground(color);
    }

   public void setSelected(boolean isSelected) {
	  this.isSelected = isSelected;
   }

   public void setShowError(boolean showError) {
	  this.showError = showError;
   }

   public void setShowDeleted(boolean showDeleted) {
	  this.showDeleted = showDeleted;
   }

   public void setShowMissing(boolean showMissing) {
	  this.showMissing = showMissing;
   }

   public void setShowSearchResult(boolean showSearchResult) {
	  this.showSearchResult = showSearchResult;
   }

   public void setChanged(boolean isChanged) {
	  this.isChanged = isChanged;
   }

    public Component getTreeCellRendererComponent(JTree tree, 
												  Object value,
												  boolean selected,
												  boolean expanded,
												  boolean leaf, 
												  int row,
												  boolean hasFocus) {

	   if ( value.getClass() == DefaultMutableTreeNode.class) {
		  return this;
	   } //end if ()
	   

	NavigationTreeNode node = (NavigationTreeNode) value;
	isSelected = node.isSelected();
	if ( isSelected == false) {
	   isSelected = selected;
	} //end if ()
	
	//	this.isSelected = node.isSelected();
	setShowError(node.showError());
	setShowDeleted(node.showDeleted());
	setShowMissing(node.showMissing());
	setShowSearchResult(node.showSearchResult());
	setChanged(node.isChanged());


	this.hasFocus = hasFocus;
	setText(node.toString() );

	setEnabled(false);
	

	if ( isChanged == true) {
	   // There needs to be a way to specify disabled icons.
	   if (!tree.isEnabled()) {
		  setEnabled(false);
		  if (leaf) {
			 setDisabledIcon(getLeafIcon());
		  } else if (expanded) {
			 setDisabledIcon(getOpenIcon());
		  } else {
			 setDisabledIcon(getClosedIcon());
		  }
	   }
	   else {
		  setEnabled(true);
		  if (leaf) {
			 setIcon(changedLeafIcon);
		  } else if (expanded) {
			 setIcon(changedOpenIcon);
		  } else {
			 setIcon(changedClosedIcon);
		  }
	   }

	}
	else {
	   if (!tree.isEnabled()) {
		  setEnabled(false);
		  if (leaf) {
			 setDisabledIcon(getLeafIcon());
		  } else if (expanded) {
			 setDisabledIcon(getOpenIcon());
		  } else {
			 setDisabledIcon(getClosedIcon());
		  }
	   }
	   else {
		  setEnabled(true);
		  if (leaf) {
			 setIcon(getLeafIcon());
		  } else if (expanded) {
			 setIcon(getOpenIcon());
		  } else {
			 setIcon(getClosedIcon());
		  }
	   }
	   
	   
	} //end else
	
	


	setComponentOrientation(tree.getComponentOrientation());    
	this.selected = selected;
	
	return this;
    }

   private void drawNormalBorder(Graphics graphics) {
	  int imageOffset = getLabelStart();
	  
	  graphics.setColor(Color.black);
	  graphics.drawRect(0 + imageOffset,
						0,
						getWidth() - 1 - imageOffset,
						getHeight() - 1);

   }

   private void drawGhostBorder(Graphics graphics) {

	  int imageOffset = getLabelStart();

	  Graphics2D graphics2D = (Graphics2D) graphics;

	  float[] dashPhase = new float[2];
	  dashPhase[0] = 2;
	  dashPhase[1] = 2;
	  BasicStroke stroke = new BasicStroke(1,
										   BasicStroke.CAP_BUTT,
										   1,
										   BasicStroke.JOIN_MITER,
										   dashPhase,
										   1);
	  graphics2D.setColor(ghostBorderColour);
	  graphics2D.setStroke(stroke);
	  graphics2D.drawRect(0 + imageOffset,
						0,
						getWidth() - 1 - imageOffset,
						getHeight() - 1);


   }

   private void showMissing(Graphics graphics) {
	  int imageOffset = getLabelStart();

	  fillButton(graphics, 
				 missingColour);

	  //draw a dashed box
	  drawGhostBorder(graphics);
	  setForeground(ghostTextColour);
	  super.paint(graphics);
	  
   }



   private void showDeleted(Graphics graphics) {
	  fillButton(graphics, 
				 deletedColour);

	  //draw a dashed box
	  drawGhostBorder(graphics);


	  setForeground(ghostTextColour);
	  super.paint(graphics);
   }

   private void fillButton(Graphics graphics,
						   Color colour) {

	  int imageOffset = getLabelStart();

	  graphics.setColor(colour);
	  graphics.fillRect(0+imageOffset, 
						0, 
						getWidth() - 1 - imageOffset,
						getHeight());
   }

   private void showSelected(Graphics graphics) {
	  fillButton(graphics, 
				 selectedColour);

	  drawNormalBorder(graphics);
	  setForeground(Color.black);

	  super.paint(graphics);
   }

   private void showError(Graphics graphics) {
	  fillButton(graphics, 
				 errorColour);

	  drawNormalBorder(graphics);
	  setForeground(Color.black);

	  super.paint(graphics);
   }

   private void showSearchResult(Graphics graphics) {
	  fillButton(graphics, 
				 searchResultColour);

	  drawNormalBorder(graphics);
	  setForeground(Color.black);

	  super.paint(graphics);
   }

   private void showNormalState(Graphics graphics) {
	  setForeground(Color.black);
	  super.paint(graphics);
   }

    /**
      * Paints the value.  The background is filled based on selected.
      */
    public void paint(Graphics graphics) {

	   if ( showMissing == true) {
		  showMissing(graphics);
	   } //end else ()
	   else if ( showError == true) {
		  showError(graphics);
	   } //end else ()
	   else if (isSelected == true ) {
		  showSelected(graphics);
	   } //end else ()
	   else if (showSearchResult == true) {
		  showSearchResult(graphics);
	   } //end else ()
	   else {
		  //unselected
		  showNormalState(graphics);
	   } //end else

    }

    private int getLabelStart() {
	Icon currentI = getIcon();
	if(currentI != null && getText() != null) {
	    return currentI.getIconWidth() + Math.max(0, getIconTextGap() - 1);
	}
	return 0;
    }

    public Dimension getPreferredSize() {
	Dimension        retDimension = super.getPreferredSize();

	if(retDimension != null)
	    retDimension = new Dimension(retDimension.width + 3,
					 retDimension.height);
	return retDimension;
    }

    public void validate() {}

    public void revalidate() {}

    public void repaint(long tm, int x, int y, int width, int height) {}

    public void repaint(Rectangle r) {}

    protected void firePropertyChange(String propertyName, Object oldValue, Object newValue) {	
	// Strings get interned...
	if (propertyName=="text")
	    super.firePropertyChange(propertyName, oldValue, newValue);
    }

    public void firePropertyChange(String propertyName, byte oldValue, byte newValue) {}

    public void firePropertyChange(String propertyName, char oldValue, char newValue) {}

    public void firePropertyChange(String propertyName, short oldValue, short newValue) {}

    public void firePropertyChange(String propertyName, int oldValue, int newValue) {}

    public void firePropertyChange(String propertyName, long oldValue, long newValue) {}

    public void firePropertyChange(String propertyName, float oldValue, float newValue) {}

    public void firePropertyChange(String propertyName, double oldValue, double newValue) {}

    public void firePropertyChange(String propertyName, boolean oldValue, boolean newValue) {}

}

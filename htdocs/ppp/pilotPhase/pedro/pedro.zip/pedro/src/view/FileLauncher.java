/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.view;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import org.w3c.dom.Text;
import org.w3c.dom.NodeList;
import org.w3c.dom.*;

import java.util.Hashtable;
import java.io.File;
import java.net.URL;
import java.io.IOException;

import pedro.util.ErrorDialog;
import pedro.system.GlobalConstants;
import pedro.system.PedroException;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class FileLauncher {


   public static void main (String[] args) {
	  FileLauncher reader = new FileLauncher();
	  try {
		 reader.parseDocument(new File("C://out//models//tutorial//config//FileExtensionsToLaunch.xml"));

		 String result = reader.getLaunchCommand("jpg");

		 result = reader.getLaunchCommand("JPG");


		 result = reader.getLaunchCommand("pdf");

		 result = reader.getLaunchCommand("xyz");

	  } 
	  catch (PedroException err1) {
		 ErrorDialog.show(err1.toString());
	  } // end try-catch
	  catch (Exception err2) {
		 ErrorDialog.show(err2.toString());
	  } // end try-catch
	  

   } // end main ()
   
   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private Hashtable commandFromExtension;
   private static FileLauncher fileLauncher = null;

   // ==========================================
   // Section Construction
   // ==========================================
   public FileLauncher() {
	  commandFromExtension = new Hashtable();

	  File modelDirectory = GlobalConstants.getModelDirectory();
	  StringBuffer configurationPath = new StringBuffer();
	  configurationPath.append(modelDirectory.getAbsolutePath() );
	  configurationPath.append(File.separator);
	  configurationPath.append("config");
	  configurationPath.append(File.separator);
	  configurationPath.append("FileExtensionsToLaunch.xml");

	  File configurationFile = new File(configurationPath.toString() );


	  try {
		 parseDocument(configurationFile);
	  } catch (Exception err) {
		 ErrorDialog.show(err.toString());
		 System.exit(0);
	  } // end try-catch

   }

   public int getDescribedExtensionsCount() {
	  return commandFromExtension.size();
   }

   public static FileLauncher getFileLauncher() {
	  if ( fileLauncher == null) {
		 fileLauncher = new FileLauncher();
	  } //end if ()
	  
	  return fileLauncher;
   }

   // ==========================================
   // Section Accessors
   // ==========================================
   public void parseDocument(File file) 
	  throws ParserConfigurationException, 
			 PedroException,
			 SAXException,
			 IOException {


	  DocumentBuilderFactory documentBuilderFactory
		 = DocumentBuilderFactory.newInstance();
	  
	  DocumentBuilder documentBuilder
		 = documentBuilderFactory.newDocumentBuilder();
	  
	  Document document = documentBuilder.parse(file);

	  Element launchProgramNode = null;
	  Node currentChild = document.getFirstChild();

	  while ( currentChild != null) {
		 if ( currentChild.getNodeType() == Node.ELEMENT_NODE) {
			Element element = (Element) currentChild;
			if ( element.getTagName().equals("launch_programs") == true) {
			   launchProgramNode = element;
			   break;
			} //end if ()
			
		 } //end if ()
		 currentChild = currentChild.getNextSibling();
	  } //end while ()

	  if ( launchProgramNode == null) {
		 throw new PedroException("File ExtensionsToLaunch  doesn't have a tag \"launch_programs\"");
	  } //end if ()

	  //now parse records
	  currentChild = launchProgramNode.getFirstChild();
	  while ( currentChild != null) {
		 if ( currentChild.getNodeType() == Node.ELEMENT_NODE) {
			Element currentElement = (Element) currentChild;
			parseExtensionEntry(currentElement);
		 } //end if ()

		 currentChild = currentChild.getNextSibling();
	  } //end while ()
	  
   }

   

   private void parseExtensionEntry(Element record) throws PedroException {
	  String recordName = record.getTagName();
	  Node currentChild = record.getFirstChild();
	  
	  String currentExtension = null;
	  while ( currentChild != null) {
		 if ( currentChild.getNodeType() == Node.ELEMENT_NODE) {
			Element currentElement = (Element) currentChild;
			String attributeName = currentElement.getTagName();
			
			Node fieldChild  = currentElement.getFirstChild();
			if ( fieldChild.getNodeType() == Node.TEXT_NODE) {

			   Text text = (Text) fieldChild;
			   String data = text.getData();
			   data = data.trim();
			   if ( data.equals("") == false) {
				  if ( attributeName.equals("extension") == true) {

					 currentExtension = data.toUpperCase();
				  }
				  else if ( attributeName.equals("launch") == true) {

					 if ( currentExtension == null) {
						StringBuffer errorMessage = new StringBuffer();
						errorMessage.append("No value encountered for an extension value");
						throw new PedroException(errorMessage.toString() );
					 } //end if ()
					 else if (commandFromExtension.contains(currentExtension) == true) {
						//ERROR: user has put in duplicate value
						StringBuffer errorMessage = new StringBuffer();
						errorMessage.append("You've associated multiple programs ");
						errorMessage.append("with the same extension ");
						errorMessage.append(currentExtension);
						throw new PedroException(errorMessage.toString() );
					 } //end if ()
					 else {
						//"data" contains the launch command for the current extension
						commandFromExtension.put(currentExtension,data);
					 } //end else
				  } //end else ()
			   }
			}

		 } //end if ()
		 currentChild = currentChild.getNextSibling();

	  } //end if ()
	  
   } //end while ()

   public String getLaunchCommand(String fileExtension) {
	  
	  return (String) commandFromExtension.get(fileExtension.toUpperCase() );
   }

}


   


   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================

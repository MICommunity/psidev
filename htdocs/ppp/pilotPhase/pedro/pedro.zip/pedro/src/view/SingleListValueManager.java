/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.view;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Component;

import java.io.File;
import java.util.ArrayList;

import pedro.model.ListFieldModel;
import pedro.model.RecordModel;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class SingleListValueManager 
   implements ListValueManager {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private RecordModel onlyChild;
   private JTextField textField;
   
   private ListTypeManager listTypeManager;
   private SingleListValueButtonPanel buttonPanel;
   private Component typeArea;
   private ListFieldModel listFieldModel;

   // ==========================================
   // Section Construction
   // ==========================================
   public SingleListValueManager(ListTypeManager listTypeManager,
								 RecordView recordView) {

	  textField = new JTextField(20);
	  textField.setEditable(false);
	  this.listTypeManager = listTypeManager;
	  typeArea = listTypeManager.getTypeArea();

	  buttonPanel = new SingleListValueButtonPanel(listTypeManager,
												   this,
												   recordView);

   }

   // ==========================================
   // Section Accessors
   // ==========================================
   

   // ==========================================
   // Section Mutators
   // ==========================================
   
   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================

   //Interface: ListValueManager

   public Component getEditButtons() {
	  return buttonPanel.getPanel();
   }

   public Component getListArea() {
	  return textField;
   }

   public void setModel(ListFieldModel _listFieldModel) {
	  this.listFieldModel = _listFieldModel;
	  buttonPanel.setModel(listFieldModel);
	  

	  boolean isPop = listFieldModel.isListPopulated();

	  if ( listFieldModel.isListPopulated() == true) {
		 buttonPanel.enableEditRecordModel(true);
		 buttonPanel.enableNewRecordModel(false);
	  } //end if ()
	  else {
		 buttonPanel.enableEditRecordModel(false);
		 buttonPanel.enableNewRecordModel(true);
	  } //end else

	  setChildren();
   }
   
   private void setChildren() {
	  ArrayList children = listFieldModel.getChildren();
	  if ( children.size() == 0) {
		 textField.setText("");
	  } //end if ()
	  else {
		 onlyChild = (RecordModel) children.get(0);
		 textField.setText(onlyChild.getDisplayName() );
	  } //end else
   }

   public RecordModel getSelectedRecordModel() {
	  return onlyChild;
   }

   public void setFont(Font font) {
 	  textField.setFont(font);
	  buttonPanel.setFont(font);
   }

   public void refresh() {
	  setChildren();
   }

   public void reset() {
   }

   // ==========================================
   // Section Overload
   // ==========================================

}

/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.view;

import java.awt.Color;

import pedro.model.EditFieldModel;
import pedro.system.GlobalConstants;
/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public abstract class EditFieldView extends DataFieldView {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private String value;
   protected EditFieldModel editFieldModel;

   // ==========================================
   // Section Construction
   // ==========================================
   public EditFieldView() {
	  value = "";
   }

   // ==========================================
   // Section Accessors
   // ==========================================
   abstract public boolean isDirty();
   public String getValue() {
	  return value;
   }

   public void setModel(EditFieldModel _editFieldModel) {
	  editFieldModel = _editFieldModel;
	  super.setModel(editFieldModel);

	  String fieldName = editFieldModel.getName();
	  
	  setUnits(editFieldModel.getUnits() );

   }

   // ==========================================
   // Section Mutators
   // ==========================================
   abstract public void keepValue();
   abstract public void restoreValue();

   public void setUnits(String units) {

	  if (units.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) == true) {
		 return;
	  } //end if ()

	  StringBuffer labelText = new StringBuffer();
	  labelText.append(name);
	  labelText.append("(");
	  labelText.append(units);
	  labelText.append(")");

	  label.setText(labelText.toString() );
   }

   // ==========================================
   // Section Validation
   // ==========================================

   protected String showErrors(String currentValue,
							   boolean highlightErrors) {

	  String errors = editFieldModel.validate(currentValue);
	  if ( errors == null) {
		 label.setForeground(Color.black);
		 return null;
	  } //end if ()
	  else {
		 label.setForeground(Color.red);
		 return errors;
	  } //end else
   }

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================
   abstract public String validate(boolean highlightErrors);

}



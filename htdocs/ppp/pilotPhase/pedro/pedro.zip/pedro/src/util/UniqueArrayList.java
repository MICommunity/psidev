/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
* @version 1.0
*
*/

package pedro.util;

import java.util.ArrayList;

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class UniqueArrayList extends ArrayList {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================

   // ==========================================
   // Section Construction
   // ==========================================


   // ==========================================
   // Section Accessors
   // ==========================================


   // ==========================================
   // Section Mutators
   // ==========================================
   public void addTerm(String term) {

	  int numberOfTerms = size();
	  boolean duplicateExists = false;

	  int i;
	  for ( i = 0; i < numberOfTerms; i++) {
		 String currentTerm = (String) get(i);
		 if ( currentTerm.equals(term) == true) {
			duplicateExists = true;
			break;
		 } //end if ()
	  } // end for ()

	  if ( duplicateExists == false) {
		 super.add(term);
	  }

   }



   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================

}

/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.util;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.ImageIcon;

import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import javax.swing.JPanel;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JSeparator;

import pedro.system.GlobalConstants;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class SaveChangesDialog extends JDialog 
   implements ActionListener {

   
   // ==========================================
   // Section Constants
   // ==========================================
   public static final int SAVE_CURRENT_RECORD = 11;
   public static final int SAVE_CURRENT_FILE = 12;


   // ==========================================
   // Section Properties
   // ==========================================
   private JButton yes;
   private JButton no;
   private boolean saveChanges;

   // ==========================================
   // Section Construction
   // ==========================================
   public SaveChangesDialog(int saveOperationType) {
	  setTitle("Save Changes?");
	  saveChanges = false;
	 
	  ImageIcon warningIcon 
		 = new ImageIcon(GlobalConstants.ICON_PATH + "warning.jpg");

	  MessagePanel messagePanel;


	  if ( saveOperationType == SAVE_CURRENT_RECORD) {
		 messagePanel 
			= new MessagePanel(warningIcon,
							   "Save changes made to current record?");
	  } //end if ()
	  else {
		 messagePanel 
			= new MessagePanel(warningIcon,
							   "Save changes made to current file?");
	  } //end else ()


	  JPanel panel = new JPanel(new GridBagLayout() );
	  GridBagConstraints panelGC = new GridBagConstraints();
	  panelGC.anchor = GridBagConstraints.NORTHWEST;
	  panelGC.fill = GridBagConstraints.BOTH;
	  panelGC.weightx = 100;
	  panelGC.weighty = 100;
	  panelGC.gridx = 0;
	  panelGC.gridy = 0;
	  panel.add(messagePanel);

	  panelGC.gridy = 1;
	  panelGC.fill = GridBagConstraints.HORIZONTAL;
	  panelGC.weightx = 0;
	  panelGC.weighty = 0;

	  panel.add(new JSeparator(), panelGC);

	  panelGC.gridy = 2;
	  panelGC.anchor = GridBagConstraints.SOUTHEAST;
	  panel.add(createButtonPanel(), panelGC);
	  
	  getContentPane().add(panel);
	  
	  setModal(true);

	  System.out.println("SCD - initializing");
   }

   private JPanel createButtonPanel() {
	  
	  JPanel panel = new JPanel(new GridBagLayout() );

	  GridBagConstraints panelGC = new GridBagConstraints();
	  panelGC.anchor = GridBagConstraints.NORTHWEST;
	  panelGC.fill = GridBagConstraints.NONE;
	  panelGC.weightx = 0;
	  panelGC.weighty = 0;
	  panelGC.gridx = 0;
	  panelGC.gridy = 0;

	  yes = new JButton("Yes");
	  yes.addActionListener(this);
	  no = new JButton("No");
	  no.addActionListener(this);

	  panel.add(yes, panelGC);
	  panelGC.gridx = 1;
	  panel.add(no, panelGC);
	  
	  return panel;
   }

   // ==========================================
   // Section Accessors
   // ==========================================
   public boolean saveChanges() {
	  return saveChanges;
   }

   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================
   public void actionPerformed(ActionEvent event) {
	  Object button = event.getSource();

	  System.out.println("SaveChangesDialog actionPerformed");
	  if ( button == yes) {
		 saveChanges = true;
	  } //end if ()
	  else {
		 saveChanges = false;
	  } //end else

	  dispose();
   }


   // ==========================================
   // Section Overload
   // ==========================================

}

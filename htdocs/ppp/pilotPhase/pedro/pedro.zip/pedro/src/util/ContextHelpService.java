/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
* @version 1.0
*
*/

package pedro.util;

import java.awt.Component;
import java.net.URL;
import java.net.MalformedURLException;
import java.io.File;

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class ContextHelpService implements ContextHelpItem {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private Component component;
   private boolean enableContextHelp;
   private URL helpLink;
   private HelpLinkListener helpLinkListener;

   // ==========================================
   // Section Construction
   // ==========================================
   public ContextHelpService(Component component) {
	  this.component = component;
	  helpLinkListener = new HelpLinkListener(component);
   }

   // ==========================================
   // Section Accessors
   // ==========================================


   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================

   /**
	* @return whether context help mode is currently activated for item
	*/
   public boolean isContextHelpEnabled() {
	  return enableContextHelp;
   }

   /**
	* @return the URL for the HTML help page associated with the item
	*/
   public URL getHelpLink() {
	  return helpLinkListener.getHelpLink();
   }

   /**
	* turns context help mode on or off
	* @param enableContextHelp true means context help is on; 
	* false means it's off.
	*/
   public void enableContextHelp(boolean enableContextHelp) {
	  this.enableContextHelp = enableContextHelp;
	  if ( enableContextHelp == true) {
		 component.addMouseListener(helpLinkListener);
	  } //end if ()
	  else {
		 component.removeMouseListener(helpLinkListener);
	  } //end else
   }

   /**
	* sets the name of the help file.  Generally these documents will be
	* located in pedro/help.
	*/
   public void setHelpLink(URL helpLink) {
	  helpLinkListener.setHelpLink(helpLink);
   }



   // ==========================================
   // Section Overload
   // ==========================================

}

/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.util;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.util.Vector;
import java.util.Collections;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class OrderedListPanel extends JPanel 
   implements ActionListener {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private JLabel listTitle;
   private Vector model;
   protected JList list;
   private JButton removeSelection;

   // ==========================================
   // Section Construction
   // ==========================================
   public OrderedListPanel() {
	  
	  setLayout(new GridBagLayout() );
	  model = new Vector();
	  
	  GridBagConstraints mainPanelGC = new GridBagConstraints();
	  mainPanelGC.gridx = 0;
	  mainPanelGC.gridy = 0;
	  mainPanelGC.fill = GridBagConstraints.NONE;
	  mainPanelGC.weightx = 0;
	  mainPanelGC.weighty = 0;
	  mainPanelGC.anchor = GridBagConstraints.NORTHWEST;
	  
	  listTitle = new JLabel("Selected Items");
	  add(listTitle, mainPanelGC);


	  mainPanelGC.fill = GridBagConstraints.BOTH;
	  mainPanelGC.gridx = 0;
	  mainPanelGC.gridy = 1;
	  list = new JList(model);
	  list.setPrototypeCellValue("01234567891011");
	  JScrollPane scrollPane = new JScrollPane(list);
	  add(scrollPane, mainPanelGC);

	  removeSelection = new JButton("Remove Selected Items");
	  removeSelection.addActionListener(this);

	  mainPanelGC.gridx = 0;
	  mainPanelGC.gridy = 2;
	  mainPanelGC.fill = GridBagConstraints.NONE;
	  mainPanelGC.anchor = GridBagConstraints.SOUTHEAST;

	  add(removeSelection, mainPanelGC);
   }

   public void reset() {
	  model.removeAllElements();
   }

   // ==========================================
   // Section Accessors
   // ==========================================
   public String[] getItems() {

	  String[] items = (String[]) model.toArray(new String[0]);
	  return items;
   }

   // ==========================================
   // Section Mutators
   // ==========================================
   public void addItem(String item) {
	  System.out.println("OLP addItem");
	  model.addElement(item);
	  Collections.sort(model);
   }

   public void addItems(Object[] items) {
	  for ( int i = 0; i < items.length; i++) {
		 model.addElement( (String) items[i]);
	  } // end for ()
	  Collections.sort(model);

	  repaint();
   }

   public void setListTitle(String listTitle) {
	  this.listTitle.setText(listTitle);
   }

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================

   public void actionPerformed(ActionEvent event) {
	  //the only button in the interface is remove
	  Object[] itemsToDelete = list.getSelectedValues();
	  
	  for ( int i = 0; i < itemsToDelete.length; i++) {
		 model.remove( itemsToDelete[i]);
	  } // end for ()

	  repaint();
   }



   // ==========================================
   // Section Overload
   // ==========================================

}

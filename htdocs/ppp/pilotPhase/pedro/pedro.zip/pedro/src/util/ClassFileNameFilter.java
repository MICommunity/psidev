/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
* @version 1.0
*
*/

package pedro.util;

import java.io.FilenameFilter;
import java.io.File;

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class ClassFileNameFilter implements FilenameFilter {

   
   // ==========================================
   // Section Constants
   // ==========================================
   private static String classExtension = "CLASS";
   private static String jarExtension = "JAR";

   // ==========================================
   // Section Properties
   // ==========================================

   // ==========================================
   // Section Construction
   // ==========================================



   // ==========================================
   // Section Accessors
   // ==========================================


   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================
   public boolean accept(File directory, String fileName) {
	  int i = fileName.lastIndexOf('.');
	  if ( ( i > 0) && (i < fileName.length() - 1) ) {
		 String suffix = fileName.substring(i+1).toUpperCase();
		 if ( ( suffix.equals(classExtension) == true ) ||
			  ( suffix.equals(jarExtension) == true)) {
			return true;
		 } //end if ()
	  } //end if ()
	  return false;
   }



   // ==========================================
   // Section Overload
   // ==========================================

}

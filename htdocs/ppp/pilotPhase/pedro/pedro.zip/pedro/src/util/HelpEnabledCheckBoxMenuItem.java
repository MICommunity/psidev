/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.util;

import javax.swing.JCheckBoxMenuItem;
import java.net.URL;
import java.net.MalformedURLException;
import java.awt.event.ActionListener;

import java.io.File;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class HelpEnabledCheckBoxMenuItem extends JCheckBoxMenuItem 
   implements ContextHelpItem {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private ContextHelpService contextHelpService;

   // ==========================================
   // Section Construction
   // ==========================================
   public HelpEnabledCheckBoxMenuItem(String name) {

	  super(name);

	  contextHelpService = new ContextHelpService(this);
   }

   // ==========================================
   // Section Accessors
   // ==========================================
   public boolean isContextHelpEnabled() {
	  return contextHelpService.isContextHelpEnabled();
   }

   public URL getHelpLink() {
	  return contextHelpService.getHelpLink();
   }

   // ==========================================
   // Section Mutators
   // ==========================================
   public void enableContextHelp(boolean enableContextHelp) {
	  contextHelpService.enableContextHelp(enableContextHelp);
   }

   public void setHelpLink(URL helpLink) {
	  contextHelpService.setHelpLink(helpLink);
   }


   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================

}

/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/
package pedro.util;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JLabel;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.JPanel;
import java.util.Collections;


/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class FilteredListPanel extends JPanel 
   implements ActionListener {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private FilteredList filteredList;
   private OrderedListPanel selectedItemList;
   private JButton resetMasterList;
   private JButton addToSelectedItems;

   // ==========================================
   // Section Construction
   // ==========================================

   public FilteredListPanel(String[] terms) {
	  
	  setLayout(new GridBagLayout() );

	  JLabel listTitle = new JLabel("Master List");

	  GridBagConstraints mainPanelGC = new GridBagConstraints();
	  mainPanelGC.gridx = 0;
	  mainPanelGC.gridy = 0;
	  mainPanelGC.anchor = GridBagConstraints.NORTHWEST;
	  mainPanelGC.fill = GridBagConstraints.NONE;
	  mainPanelGC.weightx = 0;
	  mainPanelGC.weighty = 0;


	  add(listTitle, mainPanelGC);

	  filteredList = new FilteredList(terms);
	  
	  JScrollPane listPane = new JScrollPane(filteredList);

	  mainPanelGC.gridy = 1;
	  mainPanelGC.anchor = GridBagConstraints.NORTHWEST;
	  mainPanelGC.fill = GridBagConstraints.BOTH;
	  mainPanelGC.weightx = 100;
	  mainPanelGC.weighty = 100;
	  add(listPane, mainPanelGC);


	  JPanel buttonPanel = getButtonPanel();
	  mainPanelGC.gridy = 2;
	  mainPanelGC.anchor = GridBagConstraints.SOUTHEAST;
	  mainPanelGC.fill = GridBagConstraints.NONE;
	  mainPanelGC.weightx = 0;
	  mainPanelGC.weighty = 0;
	  add(buttonPanel, mainPanelGC);

   }

   private JPanel getButtonPanel() {

	  resetMasterList = new JButton("Reset");
	  resetMasterList.addActionListener(this);
	  
	  addToSelectedItems = new JButton("Add");
	  addToSelectedItems.addActionListener(this);

	  JPanel buttonPanel = new JPanel(new GridBagLayout() );
	  GridBagConstraints buttonPanelGC = new GridBagConstraints();
	  buttonPanelGC.gridx = 0;
	  buttonPanelGC.gridy = 0;
	  buttonPanelGC.anchor = GridBagConstraints.SOUTHEAST;
	  buttonPanelGC.fill = GridBagConstraints.NONE;

	  buttonPanel.add(resetMasterList, buttonPanelGC);

	  buttonPanelGC.gridx = 1;
	  buttonPanel.add(addToSelectedItems, buttonPanelGC);

	  
	  return buttonPanel;
   }
   
   public void setSelectedItemList(OrderedListPanel selectedItemList) {
	  this.selectedItemList = selectedItemList;
   }


   // ==========================================
   // Section Accessors
   // ==========================================
   public FilteredList getFilteredList() {
	  return filteredList;
   }

   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================
   //Interface ActionListener
   public void actionPerformed(ActionEvent event) {

	  Object source = event.getSource();
	  if ( source == resetMasterList) {
		 filteredList.reset();
	  } //end if ()
	  else if ( source == addToSelectedItems) {

		 if ( filteredList == null) {
			System.out.println("FLP - act performed 1");
		 } //end if ()
		 
		 Object[] values = filteredList.getSelectedValues();

		 selectedItemList.addItems(values);

	  } //end else ()
   }


   // ==========================================
   // Section Overload
   // ==========================================

}

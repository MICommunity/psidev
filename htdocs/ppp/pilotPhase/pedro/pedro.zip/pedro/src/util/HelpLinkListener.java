/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.util;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import java.net.URL;
import java.awt.Cursor;
import java.awt.Component;
import java.io.Serializable;


import pedro.system.GlobalConstants;


/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class HelpLinkListener extends MouseAdapter 
   implements Serializable {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private URL helpLink;
   private Component component;

   // ==========================================
   // Section Construction
   // ==========================================
   public HelpLinkListener(Component component) {
	  this.component = component;
   }
   

   // ==========================================
   // Section Accessors
   // ==========================================
   public URL getHelpLink() {
	  return helpLink;
   }
   // ==========================================
   // Section Mutators
   // ==========================================
   public void setHelpLink(URL _helpLink) {
	  this.helpLink = _helpLink;   
   }

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================
   //Interface: MouseListener
   public void mouseClicked(MouseEvent event) {

	  try {
		 HelpDialog helpDialog = HelpDialog.getHelpDialog();
		 helpDialog.setTitle("Context Help");
		 helpDialog.setHelpLink(helpLink);
		 helpDialog.show();
	  }
	  catch (Exception err) {
		 System.out.println(err);
	  } // end catch

   }

   public void mouseEntered(MouseEvent event) {
	  component.setCursor(GlobalConstants.getHelpCursor() );
   }

   public void mouseExited(MouseEvent event) {
	  component.setCursor(Cursor.getDefaultCursor() );

   }
   // ==========================================
   // Section Overload
   // ==========================================

}

/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.util;

import javax.swing.JList;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.DefaultListModel;
import javax.swing.text.JTextComponent;

import javax.swing.event.CaretListener;
import javax.swing.event.CaretEvent;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class FilteredList extends JList
   implements CaretListener {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private DefaultListModel model;
   private String[] masterList;
   
   // ==========================================
   // Section Construction
   // ==========================================
   public FilteredList(String[] _masterList) {
	  this.masterList = _masterList;
	  init();
   }

   public FilteredList() {
	  init();
   }
   
   private void init() {
	  model = new DefaultListModel();
	  setModel(model);
	  reset();
   }

   /*
   ** restores the list view so it shows all items in the 
   ** master list
   */
   public void reset() {
	  model.clear();
	  if ( masterList == null) {
		 return;
	  } //end if ()
	  
	  for ( int i = 0; i < masterList.length; i++) {
		 model.addElement(masterList[i]);
	  } // end for ()
   }

   public void setTerms(String[] _masterList) {
	  this.masterList = _masterList;
	  reset();
   }

   // ==========================================
   // Section Accessors
   // ==========================================
   public int getItemCount() {
	  return model.getSize();
   }

   // ==========================================
   // Section Mutators
   // ==========================================
   public void filterList(String filterMask) {
	  model.clear();
	  for ( int i = 0; i < masterList.length; i++) {
		 if ( masterList[i].startsWith(filterMask) == true) {
			model.addElement(masterList[i]);
		 } //end if ()
	  } // end for ()
	  
	  if ( model.size() > 0) {
		 //by default, set first item highlighted.
		 setSelectedIndex(0);

	  } //end if ()
	  

   }

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================
   //Interface: CaretListener
   public void caretUpdate(CaretEvent event) {
	  JTextComponent textComponent = (JTextComponent) event.getSource();
	  String currentValue = textComponent.getText();
	  filterList(currentValue);
   }

   // ==========================================
   // Section Overload
   // ==========================================

}


/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.util;

import java.net.URL;

/**
 * interface used by JMenuItems and JCheckBoxMenuItems to have
 * context sensitive help ability
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

public interface ContextHelpItem {

   /**
	* @return whether context help mode is currently activated for item
	*/
   public boolean isContextHelpEnabled();

   /**
	* @return the URL for the HTML help page associated with the item
	*/
   public URL getHelpLink();

   /**
	* turns context help mode on or off
	* @param enableContextHelp true means context help is on; 
	* false means it's off.
	*/
   public void enableContextHelp(boolean enableContextHelp);

   /**
	* sets the name of the help file.  Generally these documents will be
	* located in pedro/help.
	*/
   public void setHelpLink(URL helpLink);
}

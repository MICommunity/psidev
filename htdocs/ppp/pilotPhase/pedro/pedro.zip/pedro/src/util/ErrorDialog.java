/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.util;


import java.awt.Frame;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import pedro.system.GlobalConstants;

/**
 * the error dialog that displays errors produced in a Pedro session
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class ErrorDialog extends JOptionPane {

   
   // ==========================================
   // Section Constants
   // ==========================================
 
   // ==========================================
   // Section Properties
   // ==========================================
   private static Frame frame = new Frame();

   // ==========================================
   // Section Construction
   // ==========================================


   // ==========================================
   // Section Accessors
   // ==========================================


   // ==========================================
   // Section Mutators
   // ==========================================
   public static void show(String errorMessage) {

	  ImageIcon xctIcon = new ImageIcon(GlobalConstants.ICON_PATH+"xct.gif");
	  frame.setIconImage(xctIcon.getImage() );

	  //parent component?
		 JOptionPane.showConfirmDialog(frame, 
									   errorMessage,
									   "Error", 
									   JOptionPane.OK_CANCEL_OPTION,
									   JOptionPane.ERROR_MESSAGE,
									   null);

   }

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================

   // ==========================================
   // Section Interfaces
   // ==========================================

   // ==========================================
   // Section Overload
   // ==========================================

}

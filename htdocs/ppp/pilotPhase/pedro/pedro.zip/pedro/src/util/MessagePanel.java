/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.util;

import javax.swing.ImageIcon;
import javax.swing.JTextArea;
import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import javax.swing.JScrollPane;

import java.awt.BorderLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import javax.swing.JLabel;
/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class MessagePanel extends JPanel {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private ImagePanel imagePanel;
   private JTextArea textArea;

   // ==========================================
   // Section Construction
   // ==========================================
   public MessagePanel(ImageIcon icon,
					   String message) {
	  imagePanel = new ImagePanel(icon);

	  JLabel iconLabel = new JLabel(icon);

	  textArea = new JTextArea();
	  textArea.setText(message);
	  textArea.setEditable(false);
	  textArea.setLineWrap(true);
	  textArea.setWrapStyleWord(true);
	  textArea.setBackground(getBackground() );

	  JScrollPane scrollPane = new JScrollPane(textArea);


	  setLayout(new GridBagLayout() );
	  GridBagConstraints panelGC = new GridBagConstraints();
	  panelGC.anchor = GridBagConstraints.NORTHWEST;
	  panelGC.fill = GridBagConstraints.NONE;
	  panelGC.weightx = 0;
	  panelGC.weighty = 0;
	  panelGC.gridx = 0;
	  panelGC.gridy = 0;
	  panelGC.ipadx = 10;

	  add(iconLabel, panelGC);
	  panelGC.gridx = 1;
	  panelGC.anchor = GridBagConstraints.NORTHEAST;
	  panelGC.fill = GridBagConstraints.BOTH;
	  panelGC.weightx = 100;
	  panelGC.weighty = 100;
	  add(textArea, panelGC);

   }


   // ==========================================
   // Section Accessors
   // ==========================================


   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================

}

class ImagePanel extends JPanel {
   
   private ImageIcon imageIcon;

   public ImagePanel(ImageIcon imageIcon) {
	  this.imageIcon = imageIcon;
	  setSize(imageIcon.getIconWidth(), imageIcon.getIconHeight() );
   }

   public void paint(Graphics graphics) {
	  imageIcon.paintIcon(this,
						  graphics,
						  0,
						  0);
   }

}

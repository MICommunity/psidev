/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.util;

import javax.swing.filechooser.FileFilter;
import java.io.File;
/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class BackupFileFilter extends FileFilter {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private String backup;

   // ==========================================
   // Section Construction
   // ==========================================
   public BackupFileFilter() {
	  backup = "XML~";
   }


   // ==========================================
   // Section Accessors
   // ==========================================


   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================

   public boolean accept(File file) {
	  
	  if ( file != null) {
		 if ( file.isDirectory() == true) {
			return true;
		 } //end if ()
		 
		 String fileName = file.getName();
		 int i = fileName.lastIndexOf('.');
		 if ( ( i > 0) && (i < fileName.length() - 1) ) {
			String suffix = fileName.substring(i+1).toUpperCase();
			if ( suffix.equals(backup) == true) {
			   return true;
			} //end if ()

		 } //end if ()

	  } //end if ()

	  return false;
	  
   }
 
   public String getDescription() {
	  return "Experiment file backups";
   }



}

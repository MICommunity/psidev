/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro.util;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import javax.swing.JDialog;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JEditorPane;
import javax.swing.JScrollPane;
import javax.swing.event.HyperlinkListener;
import javax.swing.event.HyperlinkEvent;

/**
 * dialog used to show HTML help documents in all help features
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class HelpDialog extends JDialog
   implements ActionListener, HyperlinkListener {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private JEditorPane htmlPane;
   static private HelpDialog helpDialog;
   private URL noHelpURL;

   // ==========================================
   // Section Construction
   // ==========================================
   public HelpDialog() {

	  helpDialog = null;

	  //setModal(true);
	  addWindowListener(new WindowDisposer() );


	  //establish No help file
	  try {
		 File file = new File("help//NoHelp.html");
		 noHelpURL = file.toURL();
	  } catch (Exception err) {
		 System.out.println(err.toString() );
	  } // end try-catch
	  

	  JPanel mainPanel = new JPanel(new GridBagLayout() );
	  GridBagConstraints mainPanelGC = new GridBagConstraints();
	  mainPanelGC.anchor = GridBagConstraints.NORTHWEST;
	  mainPanelGC.fill = GridBagConstraints.BOTH;
	  mainPanelGC.gridx = 0;
	  mainPanelGC.gridy = 0;
	  mainPanelGC.weightx = 100;
	  mainPanelGC.weighty = 100;

	  htmlPane = new JEditorPane();

	  JScrollPane scrollPane = new JScrollPane(htmlPane);
	  mainPanel.add(scrollPane, mainPanelGC);

	  htmlPane.setEditable(false);
	  htmlPane.addHyperlinkListener(this);
	  
	  JButton close = new JButton("Close");
	  close.addActionListener(this);
	  mainPanelGC.anchor = GridBagConstraints.SOUTHEAST;
	  mainPanelGC.fill = GridBagConstraints.NONE;
	  mainPanelGC.gridy = 1;
	  mainPanelGC.weightx = 0;
	  mainPanelGC.weighty = 0;
	  mainPanel.add(close, mainPanelGC);
	

	  getContentPane().add(mainPanel);

	  setSize(600,400);
	  //pack();
   }

   /**
	* used for single instance management
	* @return the same instance of the help dialiog every time
	*/
   static public HelpDialog getHelpDialog() {
	  if ( helpDialog == null) {
		 helpDialog = new HelpDialog();
	  } //end if ()
	  
	  return helpDialog;
   }

   // ==========================================
   // Section Accessors
   // ==========================================


   // ==========================================
   // Section Mutators
   // ==========================================

   /**
	* sets the current HTML help page
	* @param helpLink the HTML help page
	*/
   public void setHelpLink(URL helpLink) {
	  try {
		 if ( helpLink == null) {
			//no help available
			htmlPane.setPage(noHelpURL);
		 } //end if ()
		 else {
			htmlPane.setPage(helpLink);
		 } //end else

	  } catch (Exception err) {
		 System.out.println(err);
	  } // end try-catch
   }


   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================


   // ==========================================
   // Section Interfaces
   // ==========================================
   //Interface ActionListener
   /**
	* the only button HelpDialog listens to is the close button.  Close 
	* hides the dialog 
	*/
   public void actionPerformed(ActionEvent event) {
	  dispose();
   }


   //Interface HyperLinkListener
   /**
	* used to allow the user to click hyperlinks in the text area
	*/
  public void hyperlinkUpdate(HyperlinkEvent event) {
    if (event.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
      try {
        htmlPane.setPage(event.getURL());
      } catch(IOException ioe) {
		 StringBuffer errorMessage = new StringBuffer();
		 errorMessage.append("Can't follow link to ");
		 errorMessage.append(event.getURL().toExternalForm() );
		 errorMessage.append(": ");
		 errorMessage.append(ioe);
		 ErrorDialog.show(errorMessage.toString() );
      }
    }
  }


   // ==========================================
   // Section Overload
   // ==========================================

}

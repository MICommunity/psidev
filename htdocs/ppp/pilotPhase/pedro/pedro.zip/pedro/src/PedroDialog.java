/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.BorderLayout;
import java.awt.Window;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import javax.swing.JScrollPane;
import javax.swing.JViewport;
import javax.swing.JPanel;
import java.io.File;
import java.util.ArrayList;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.ImageIcon;

import pedro.view.NavigationTree;
import pedro.view.RecordView;
import pedro.view.NavigationTreeNode;

import pedro.model.RecordModel;
import pedro.model.RecordModelFactory;

import pedro.io.SchemaReader;
import pedro.io.Startup;

import pedro.system.GlobalConstants;
import pedro.model.RecordModelFactory;
import pedro.util.ErrorDialog;
import pedro.system.PedroException;
import pedro.ontology.TouchTypeOntologyDialog;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * the top level class for Pedro.
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
Section Private
*/

public class PedroDialog extends JFrame 
   implements ActionListener {
   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================

   /** manages the file menu */
   private FileMenuActionListener fileMenuActionListener;
   
   /** manages the edit menu */
   private EditMenuActionListener editMenuActionListener;

   /** manages the options menu */
   private OptionsMenuActionListener optionsMenuActionListener;


   /** manages the options menu */
   private ViewMenuActionListener viewMenuActionListener;

   /** manages the windows menu showing list of currently open files */
   private WindowMenuActionListener windowMenuActionListener;

   /** manages the help menu */
   private HelpMenuActionListener helpMenuActionListener;

   /** the tree that appears in the left portion of the dialog */
   private NavigationTree navigationTree;
   
   /** the record form area that appears in the right portion of the dialog */
   private RecordView recordView;

   /** 
	* flag that indicates whether the dialog has been instantiated without
	* a file
	*/
   private boolean isNewFile;
   /**
	* the file viewed in the dialog
	*/
   private File file;

   // ==========================================
   // Section Construction
   // ==========================================

   public static void main (String[] args) {

	  int numberOfArguments = args.length;
	  int ithArgument = 0;

	  String model = null;

	  while (ithArgument < numberOfArguments) {
		 String pedroUtility = args[ithArgument];
		 if ( (pedroUtility.equals("-tutorial") == true) ||
			  (pedroUtility.equals("-bugReport") == true) ||
			  (pedroUtility.equals("-toolSurvey") == true) ) {

			GlobalConstants.setPedroUtilityUsed(pedroUtility.substring(1) );
			break;
		 } //end if ()
		 ithArgument++;
	  } //end while ()

	  if ( ithArgument == numberOfArguments) {
		 GlobalConstants.setPedroUtilityUsed(null);
	  } //end if ()

	  //load other classes
	  //PedroClassLoader classLoader = new PedroClassLoader();
	  //classLoader.loadClasses(modelDirectory);

	  PedroDialog dialog = new PedroDialog();
	  dialog.setNewFile(true);
	  

	  WindowRegistry windowRegistry = WindowRegistry.getWindowRegistry();
	  windowRegistry.registerWindowWithNewFile(dialog);
	  dialog.show();
   } // end main ()
   
   public PedroDialog() {
	  init();
   }
   
   private void init() {
	  DialogCloser closer = new DialogCloser(this);
	  addWindowListener(closer);

	  ImageIcon pedroIcon = new ImageIcon(GlobalConstants.ICON_PATH+"pedro.gif");
	  setIconImage(pedroIcon.getImage() );

	  navigationTree = new NavigationTree();
	  recordView = new RecordView();

	  navigationTree.setRecordView(recordView);

	  //retrieve the RecordModelFactory and ask it for a copy of the template
	  //top level record appearing in the XML Schema
	  Startup startup = Startup.getStartup();

	  RecordModelFactory recordFactory = RecordModelFactory.getRecordModelFactory();
	  RecordModel topLevelRecordModel = recordFactory.createTopLevelRecordModel();
	  topLevelRecordModel.computeDisplayName();

	  topLevelRecordModel.addChangeListener(navigationTree);

	  navigationTree.setRoot(topLevelRecordModel);
	  navigationTree.setActiveNode(topLevelRecordModel);
	  recordView.setTopLevelRecord(topLevelRecordModel);
	  recordView.setModel(topLevelRecordModel);
	  recordView.updateUI();

	  createMenus();

	  if ( startup.isSchemaAmbiguous() == true) {
		 fileMenuActionListener.allowXMLImport(false);
	  } //end if ()
	  else {
		 fileMenuActionListener.allowXMLImport(true);
	  } //end else

	  createBody();
	  
	  isNewFile = false;
	  setSize(900,600);
	  //pack();
   }


   private void createBody() {

	  JPanel panel = new JPanel(new BorderLayout() );

	  //JPanel rightPanel = new JPanel(new GridBagLayout() );
	  JPanel rightPanel = new JPanel(new BorderLayout() );

	  rightPanel.add(recordView, BorderLayout.NORTH);
	  Dimension recordViewSize = rightPanel.getPreferredSize();

	  //make the minimum height of the panel the scrollpane the height of the view
	  //unless the view is very tall
	  	  int minimumHeight = (int) recordViewSize.getHeight();
		  /*
	  if ( minimumHeight > 700) {
	  	 minimumHeight = 700;
	  } //end if ()
		  */
		  minimumHeight = 600;

	  rightPanel.setMinimumSize(new Dimension(600,
								minimumHeight ) );

	  JScrollPane rightScrollPane = new JScrollPane(rightPanel);

	  rightScrollPane.setMinimumSize(new Dimension(600,
												   minimumHeight) );
	  
	  JScrollPane leftScrollPane = new JScrollPane(navigationTree);
	  leftScrollPane.setMinimumSize(new Dimension(200, 
												  minimumHeight) );

	  JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
											leftScrollPane,
											rightScrollPane);
	  splitPane.setDividerLocation(0.5);

	  panel.add(splitPane, BorderLayout.CENTER);
	  

	  StatusBar statusBar = StatusBar.getStatusBar();
	  panel.add(statusBar.getPanel(), BorderLayout.SOUTH);

	  getContentPane().add(panel);

   }

   private void createMenus() {
	  fileMenuActionListener 
		 = new FileMenuActionListener(this,
									  navigationTree,
									  recordView);

	  editMenuActionListener 
		 = new EditMenuActionListener(this,
									  navigationTree,
									  recordView);


	  optionsMenuActionListener 
		 = new OptionsMenuActionListener(this,
										 navigationTree,
										 recordView);

	  viewMenuActionListener 
		 = new ViewMenuActionListener(this,
									  navigationTree,
									  recordView);

	  windowMenuActionListener
		 = new WindowMenuActionListener(this,
										navigationTree,
										recordView);

	  helpMenuActionListener 
		 = new HelpMenuActionListener(this,
									  navigationTree,
									  recordView);

	  JMenuBar menuBar = new JMenuBar();
	  menuBar.add(fileMenuActionListener.getMenu() );
	  menuBar.add(editMenuActionListener.getMenu() );
	  menuBar.add(optionsMenuActionListener.getMenu() );
	  menuBar.add(viewMenuActionListener.getMenu() );
	  menuBar.add(windowMenuActionListener.getMenu() );
	  menuBar.add(helpMenuActionListener.getMenu() );
	  setJMenuBar(menuBar);
   }
   
   // ==========================================
   // Section Accessors
   // ==========================================
   public boolean isNewFile() {
	  return isNewFile;
   }

   public File getFile() {
	  return file;
   }
   public NavigationTree getTree() {
	  return navigationTree;
   }


// ==========================================
   // Section Mutators
   // ==========================================
   /**
	* the tree has two mechanisms for detecting when changes
	* were made.  One of them is checking saved and current data field states
	* and the other is to check if nodes were added or deleted.  This method
	* helps reset save changes in the tree.
	*/
   public void acknowledgeChangesMade() {
	  navigationTree.acknowledgeChangesMade();
	  navigationTree.resetDisplay();
	  //navigationTree.updateUI();
	  repaint();
   }

   /**
	* closes the dialog
	*/
   public boolean close() {
	  return fileMenuActionListener.close();
   }

   /**
   * saves changes.  The method specifies whether the user is prompted 
   * to save changes or if changes are automatically saved without the user's
   * consent.  For example, in a "Save As..." operation, you would want 
   * to not prompt the user to save changes.  In a Close or Exit operation
   * you would want to prompt the user.
   *
   * @param promptForSaveChanges - true if the user gets prompted to save 
   * any detected changes or false if the changes get saved without prompting.
   */
   public boolean saveChanges(boolean promptForSaveChanges) throws PedroException {
	  
	  if ( promptForSaveChanges == true) {
		 if ( ( recordView.isDirty() == true) ||
			  (navigationTree.nodesAddedOrDeleted() == true) ) {
			StringBuffer message = new StringBuffer();
			message.append("Save changes to " + getTitle() );
			
			int answer = JOptionPane.showConfirmDialog(null, 
													   message.toString(),
														  "Save Changes", 
													   JOptionPane.YES_NO_CANCEL_OPTION,
													   JOptionPane.WARNING_MESSAGE,
													   null);
			
			if ( answer == JOptionPane.YES_OPTION) {
			   if ( navigationTree.nodesAddedOrDeleted() == true) {
				  navigationTree.setNodesAddedOrDeleted(false);
			   } //end else ()
			   
			   recordView.keepValues();
			   return true;
			} //end if ()
			else if ( answer == JOptionPane.NO_OPTION) {
			   return true;
			} //end else ()
			else {
			   //recordView.cancel();
			   return false;
			} //end else
		 }		 
		 //return true;
		 
	  } //end if ()
	  else {
		 recordView.keepValues();
		 return true;
	  } //end else
	  return true;
   }

   /**
	* sets the file being viewed in the dialog
	* @param file name of the file being viewed
	*/
   public void setFile(File file) {
	  this.file = file;
	  setTitle("File:"+file.getAbsolutePath() );
   }

   /**
	* establishes whether file is a dialog that has been created through a
	* "New" operation and not yet populated with a file.
	* @param isNewFile indicates whether the dialog has been instantiated without
	* a file.
	*/
   public void setNewFile(boolean isNewFile) {
	  this.isNewFile = isNewFile;
   }

   /**
	* sets the root of the tree
	* @param root the new root of the tree
	*/
   public void setRoot(NavigationTreeNode root) {
	  navigationTree.setRoot(root);
	  navigationTree.setActiveNode(root.getRecordModel() );
	  recordView.setModel(root.getRecordModel() );
	  repaint();
   }

   /**
	* a method that updates the contents of the PedroDialog's "Windows" menu
	* to reflect new files opened, or existing files deleted or renamed
	*/
   public void updateWindowList(ArrayList activeWindows) {
	  windowMenuActionListener.updateWindowList(activeWindows);
   }

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================
   //Interface: Action Listener
   public void actionPerformed(ActionEvent event) {
	  Object source = event.getSource();

	  if ( source instanceof JCheckBoxMenuItem) {
		 JCheckBoxMenuItem enableHelp = (JCheckBoxMenuItem) source;
		 boolean enableContextHelp = enableHelp.getState();
		 recordView.enableContextHelp(enableContextHelp);

		 fileMenuActionListener.enableContextHelp(enableContextHelp);
		 editMenuActionListener.enableContextHelp(enableContextHelp);
		 optionsMenuActionListener.enableContextHelp(enableContextHelp);
		 viewMenuActionListener.enableContextHelp(enableContextHelp);

		 windowMenuActionListener.enableContextHelp(enableContextHelp);
	  } //end if ()
   }

 
   // ==========================================
   // Section Overload
   // ==========================================

}

class DialogCloser extends WindowAdapter {

   private PedroDialog dialog;

   public DialogCloser(PedroDialog dialog) {
	  this.dialog = dialog;
   }

   public void windowClosing(WindowEvent event){ 
	  if ( dialog.close() == true) {
		 //close operation succeeded
		 Window window = (Window) event.getSource();
		 window.hide();
	  } //end if ()
   }
 
}

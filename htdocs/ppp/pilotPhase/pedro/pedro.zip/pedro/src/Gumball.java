
package candy;

public class Gumball {

   public Gumball() {
	  System.out.println("Instantiating Gumball");
   }

   public String getMessage() {
	  return "Gumball worked";
   }

}

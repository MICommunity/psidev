/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro;

import java.util.Hashtable;
import java.util.Enumeration;
import java.util.Set;
import java.util.ArrayList;
import java.io.File;


/**
 * keeps track of which files are currently open.  WindowRegistry keeps track of 
 * window name - dialog associations, and helps determine the name of new 
 * windows that haven't been populated with a file.
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
Section Private
*/

public class WindowRegistry {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   /** hashtable keyed on the window */
   private Hashtable nameFromWindow;
   /** hashtable keyed on the window name */
   private Hashtable windowFromName;
   
   /** only one instance of WindowRegistry will be used in an application */
   private static WindowRegistry windowRegistry = null;
   /** counter used to help determine name for new untitled dialogs */
   private static int numberOfUntitledDialogs = 0;
   /** flag used to mark the first window appearing on the screen */
   private static boolean isFirstWindow = true;
   // ==========================================
   // Section Construction
   // ==========================================
   public WindowRegistry() {
	  nameFromWindow = new Hashtable();
	  windowFromName = new Hashtable();
   }

   /** make target window the active window, bringing it to the front of
	* a stack of windows.
	* @param windowName identifier for an open PedroDialog window
	*/
   public void activateWindow(String windowName) {
	  PedroDialog dialog = (PedroDialog) windowFromName.get(windowName);
	  dialog.toFront();
   }

   /**
	* removes dialog from the active list of windows; used when 
	* a file is closed
	* @param dialog the dialog to be deregistered
	*/
   public void deregisterWindow(PedroDialog dialog) {
	  removeWindow(dialog);
	  if ( nameFromWindow.size() == 0) {
		 //we're removing last file; exit program
	  } //end if ()
	  
	  updateRegisteredWindows();
   }

   public void registerWindowWithExistingFile(PedroDialog dialog) {
	  addWindow(dialog);
	  updateRegisteredWindows();
   }

   /**
	* @param isFirstWindow true if the first window has been created
	*/
   public void setFirstWindow(boolean isFirstWindow) {
	  this.isFirstWindow = isFirstWindow;
   }


   /**
	* creates a name of the format: "Untitled + n" where n is the nth
	* dialog created during the session.  All other open windows are
	* updated to reflect the creation of the new dialog showing the file
	*/
   public void registerWindowWithNewFile(PedroDialog dialog) {
	  StringBuffer newFileName = new StringBuffer();
	  //newTitle.append(untitledDialogNamePrefix);

	  numberOfUntitledDialogs++;
	  newFileName.append("Untitled");
	  newFileName.append(numberOfUntitledDialogs);
	  newFileName.append(".pdz");
	  File file = new File(newFileName.toString() );

	  //dialog.setTitle(newTitle.toString() );
	  dialog.setFile(file);
	  addWindow(dialog);

	  updateRegisteredWindows();

   }

   /**
	* used to update the window menus in files when the name of the file in
	* the target dialog changes
	* @param dialog the target dialog
	*/
   public void updateWindow(PedroDialog dialog) {
	  String oldName = (String) nameFromWindow.get(dialog);
	  String newName = dialog.getTitle();
	  
	  if ( oldName.equals(newName) == false) {
		 nameFromWindow.remove(dialog);
		 windowFromName.remove(oldName);
		 
		 nameFromWindow.put(dialog,newName);
		 windowFromName.put(newName, dialog);
		 updateRegisteredWindows();
	  } //end if ()

   }

   // ==========================================
   // Section Accessors
   // ==========================================
   /** @returns the list of active windows */
  public ArrayList getActiveWindows() {
	  Set windowKeys = nameFromWindow.keySet();
	  ArrayList windows = new ArrayList();
	  windows.addAll(windowKeys);
	  return windows;
   }

   /**
	*@param file the data file viewed in some dialog
	*@returns the window associated with a file; null if the file
	* has no association with any open window.
	*/
   public PedroDialog getWindowForFile(File file) {
	  String name = "File:"+file.getAbsolutePath();
	  PedroDialog window = (PedroDialog) windowFromName.get(name);
	  return window;
   }

   /**
	* @returns the single instance of the application's Window Registry
	*/
   public static WindowRegistry getWindowRegistry() {
	  if ( windowRegistry == null) {
		 windowRegistry = new WindowRegistry();
	  } //end if ()

	  return windowRegistry;
   }

   /** 
	* @returns true if the registry has created the first window yet 
	*/
   public boolean isFirstWindow() {
	  return isFirstWindow;
   }


   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================


   // ==========================================
   // Section Private
   // ==========================================

   /**
	* adds the target dialog to the list of active windows
	* @param dialog the dialog to be added
	*/
   private void addWindow(PedroDialog dialog) {
	  String name = dialog.getTitle();
	  nameFromWindow.put(dialog,name);
	  windowFromName.put(name, dialog);
   }

   /**
	* removes the target dialog from the list of active windows
	* @param dialog the dialog to be removed
	*/
   private void removeWindow(PedroDialog dialog) {

	  String name = dialog.getTitle();
	  nameFromWindow.remove(dialog);
	  windowFromName.remove(name);
   }

   /** updates the active files shown in the windows menu of 
	* each active dialog
	*/
   private void updateRegisteredWindows() {

	  Set nameKeys = windowFromName.keySet();
	  ArrayList fileNames = new ArrayList();
	  fileNames.addAll(nameKeys);

	  Set windowKeys = nameFromWindow.keySet();
	  ArrayList windows = new ArrayList();
	  windows.addAll(windowKeys);
	  int numberOfWindows = windows.size();
	  for ( int i = 0;i < numberOfWindows; i++) {
		 PedroDialog currentDialog = (PedroDialog) windows.get(i);
		 currentDialog.updateWindowList(fileNames);
	  } // end for ()
	  
   }


}

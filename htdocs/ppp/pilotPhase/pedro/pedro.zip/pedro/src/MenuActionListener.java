/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro;

import javax.swing.JMenu;
import java.awt.Component;
import java.awt.Font;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Component;
import java.io.File;
import java.net.URL;
import java.net.MalformedURLException;

import pedro.view.NavigationTree;
import pedro.view.RecordView;
import pedro.util.ErrorDialog;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

abstract public class MenuActionListener implements ActionListener {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   protected JMenu menu;
   protected NavigationTree navigationTree;
   protected RecordView recordView;
   protected PedroDialog parentDialog;

   // ==========================================
   // Section Construction
   // ==========================================
   public MenuActionListener(PedroDialog parentDialog,
							 NavigationTree navigationTree,
							 RecordView recordView) {

	  this.parentDialog = parentDialog;
	  this.navigationTree = navigationTree;
	  this.recordView = recordView;
	  menu = new JMenu();
   }

   // ==========================================
   // Section Accessors
   // ==========================================
   public JMenu getMenu() {
	  return menu;
   }
   
   protected URL createHelpLink(String baseName) {

	  StringBuffer buffer = new StringBuffer();
	  buffer.append("help");
	  buffer.append(File.separator);
	  buffer.append(baseName);
	  String helpFileName = buffer.toString();

	  try {


		 File helpFile = new File(helpFileName);
		 
		 if ( helpFile.exists() == false) {
			StringBuffer errorMessage = new StringBuffer();
			errorMessage.append("HelpEnabledMenuItem ");
			errorMessage.append(helpFileName);
			errorMessage.append(" does not exist.");
			ErrorDialog.show(errorMessage.toString() );
		 } //end if ()

		 URL url = helpFile.toURL();
		 
		 URL helpLink = new URL(url.toString() );
		 return helpLink;
	  } catch (MalformedURLException err) {
		 StringBuffer errorMessage = new StringBuffer();
		 errorMessage.append("HelpEnabledMenuItem ");
		 errorMessage.append(helpFileName);
		 errorMessage.append(" is not a legal URL.");
		 ErrorDialog.show(errorMessage.toString() );
	  } // end try-catch

	  System.exit(0);
		
	  //this is bizarre - we'll never reach this code because of 
	  //system exit, but the compiler still wants a return value.
	  return null;
   }

   // ==========================================
   // Section Mutators
   // ==========================================
   public void addItem(Component component) {
	  menu.add(component);
   } 
   
   public void setFont(Font font) {
	  Component[] components = menu.getMenuComponents();
	  for ( int i = 0; i < components.length; i++) {
		 components[i].setFont(font);
	  } // end for ()
   }


   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================
   abstract public void actionPerformed(ActionEvent actionEvent);


   // ==========================================
   // Section Overload
   // ==========================================

}

/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/
package pedro;


import javax.swing.JMenuItem;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JToolBar;
import java.awt.event.ActionEvent;
import java.awt.Component;


import pedro.view.NavigationTree;
import pedro.view.RecordView;
import pedro.view.SearchResultDialog;

import pedro.util.HelpEnabledMenuItem;
import pedro.util.HelpDialog;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class ViewMenuActionListener extends MenuActionListener {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================

   private HelpEnabledMenuItem showChanges;
   private HelpEnabledMenuItem validate;
   private HelpEnabledMenuItem search;
   private HelpEnabledMenuItem clear;
   private SearchResultDialog searchResultDialog;

   // ==========================================
   // Section Construction
   // ==========================================
   public ViewMenuActionListener(PedroDialog parentDialog,
									NavigationTree navigationTree,
									RecordView recordView) {
	  super(parentDialog,
			navigationTree,
			recordView);

	  searchResultDialog = null;

	  menu.setText("View");

	  validate = new HelpEnabledMenuItem("Show Errors");
	  validate.addActionListener(this);
	  validate.setHelpLink( createHelpLink("ShowErrors.html") );

	  showChanges = new HelpEnabledMenuItem("Show Changes");
	  showChanges.addActionListener(this);
	  showChanges.setHelpLink( createHelpLink("ShowChanges.html") );

	  search = new HelpEnabledMenuItem("Search...");
	  search.addActionListener(this);
	  search.setHelpLink( createHelpLink("Search.html") );

	  clear = new HelpEnabledMenuItem("Clear");
	  clear.addActionListener(this);
	  clear.setHelpLink( createHelpLink("Clear.html") );

	  menu.add(validate);
	  menu.add(showChanges);
	  menu.add(search);
	  menu.add(clear);

   }


   private void search() {
	  if ( searchResultDialog == null) {
		 searchResultDialog = new SearchResultDialog();
	  } //end if ()
	  
	  searchResultDialog.setNavigationTree(navigationTree);
	  navigationTree.setSearchResultDialog(searchResultDialog);
	  searchResultDialog.show();
   }

   private void clear() {
	  navigationTree.resetDisplay();
	  if ( searchResultDialog != null) {
		 searchResultDialog.clear();
	  } //end if ()
	  
   }

   // ==========================================
   // Section Accessors
   // ==========================================
   

   // ==========================================
   // Section Mutators
   // ==========================================
   public void enableContextHelp(boolean enableContextHelp) {
	  showChanges.enableContextHelp(enableContextHelp);
	  validate.enableContextHelp(enableContextHelp);
	  search.enableContextHelp(enableContextHelp);
	  clear.enableContextHelp(enableContextHelp);
   }

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================
   public void actionPerformed(ActionEvent event) {

	  HelpEnabledMenuItem menuItem = (HelpEnabledMenuItem) event.getSource();

	  if ( menuItem.isContextHelpEnabled() == true) {
		 HelpDialog helpDialog = HelpDialog.getHelpDialog();
		 helpDialog.setHelpLink(menuItem.getHelpLink() );
		 helpDialog.show();
		 return;
	  } //end if ()
	  
	  if ( menuItem == validate) {
		 navigationTree.validateRecordModelTree();
	  } //end else ()
	  else if ( menuItem == showChanges) {
		 System.out.println("VMAL - showChanges");
		 navigationTree.showChanges();
	  } //end else ()
	  else if ( menuItem == search) {
		 search();
	  } //end else ()
	  else if ( menuItem == clear) {
		 clear();
	  } //end else ()


   }


   // ==========================================
   // Section Overload
   // ==========================================

}

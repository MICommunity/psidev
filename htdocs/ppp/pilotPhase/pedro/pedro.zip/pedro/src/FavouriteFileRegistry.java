/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import org.w3c.dom.Text;

import java.util.ArrayList;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;

import pedro.util.ErrorDialog;
import pedro.system.GlobalConstants;
import pedro.system.PedroException;


/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class FavouriteFileRegistry {
   
   // ==========================================
   // Section Constants
   // ==========================================
   public static final int NUMBER_OF_FAVOURITES = 5;
 

   // ==========================================
   // Section Properties
   // ==========================================
   private File favouritesConfigurationFile;
   private File templateDirectory;
   private File dataDirectory;
   private File importDirectory;

   private FavouritesList favouriteFiles;
   private static FavouriteFileRegistry favouriteFileRegistry = null;
   // ==========================================
   // Section Construction
   // ==========================================
   public FavouriteFileRegistry() {

	  File modelDirectory = GlobalConstants.getModelDirectory();
	  
	  StringBuffer favouritesPath = new StringBuffer();
	  favouritesPath.append(modelDirectory.getAbsolutePath() );
	  favouritesPath.append(File.separator);
	  favouritesPath.append("config");
	  favouritesPath.append(File.separator);
	  favouritesPath.append("FavouriteFiles.xml");
	  favouritesConfigurationFile = new File(favouritesPath.toString() );

	  dataDirectory = new File(".");
	  templateDirectory = new File(".");
	  importDirectory = new File(".");
	  
	  favouriteFiles = new FavouritesList();

	  try {
		 readFavouritesFile();
	  } catch (Exception err) {
		 ErrorDialog.show(err.toString());
	  } // end try-catch

   }

   public static FavouriteFileRegistry getFavouriteFileRegistry() {
	  if ( favouriteFileRegistry == null) {
		 favouriteFileRegistry = new FavouriteFileRegistry();
	  } //end if ()
	  
	  return favouriteFileRegistry;
   }


   // ==========================================
   // Section Accessors
   // ==========================================
   public void readFavouritesFile() 
	  throws ParserConfigurationException, 
			 PedroException,
			 SAXException,
			 IOException {
	  
	  DocumentBuilderFactory documentBuilderFactory
		 = DocumentBuilderFactory.newInstance();
	  
	  DocumentBuilder documentBuilder
		 = documentBuilderFactory.newDocumentBuilder();
	  
	  if ( favouritesConfigurationFile.exists() == false) {
		 return;
	  } //end if ()
	  

	  Document document = documentBuilder.parse(favouritesConfigurationFile);

	  Element favouriteFilesElement = null;
	  Node currentChild = document.getFirstChild();


	  while ( currentChild != null) {
		 if ( currentChild.getNodeType() == Node.ELEMENT_NODE) {
			Element element = (Element) currentChild;
			String tagName = element.getTagName();
			if ( tagName.equals("favouriteFiles") == true) {
			   favouriteFilesElement = element;
			   break;
			} //end else ()
		 } //end if ()
		 currentChild = currentChild.getNextSibling();
	  } //end while ()

	  if ( favouriteFiles == null) {
		 ErrorDialog.show("Can't read favourite files registry");
	  } //end if ()
	  

	  currentChild = favouriteFilesElement.getFirstChild();

	  while ( currentChild != null) {
		 if ( currentChild.getNodeType() == Node.ELEMENT_NODE) {
			Element element = (Element) currentChild;
			String tagName = element.getTagName();
			if ( tagName.equals("dataPath") == true) {
			   parseDataPath(element);
			} //end if ()
			else if ( tagName.equals("templatePath") == true) {
			   parseTemplatePath(element);
			} //end else ()
			else if ( tagName.equals("importPath") == true) {
			   parseImportPath(element);
			} //end else ()
			else if ( tagName.equals("favourite") == true) {
			   parseFavourite(element);
			} //end else ()
		 } //end if ()
		 currentChild = currentChild.getNextSibling();
	  } //end while ()



   }

   public void writeFavouritesFile() throws IOException {
	  
	  PrintWriter out 
		 = new PrintWriter(new FileOutputStream(favouritesConfigurationFile) );
	  
	  out.println("<favouriteFiles>");

	  out.println("<dataPath>");
	  out.println(dataDirectory.getAbsolutePath() );
	  out.println("</dataPath>");
	  
	  out.println("<templatePath>");
	  out.println(templateDirectory.getAbsolutePath() );
	  out.println("</templatePath>");
	  
	  out.println("<importPath>");
	  out.println(importDirectory.getAbsolutePath() );
	  out.println("</importPath>");

	  
	  int numberOfNewFavourites = favouriteFiles.size();
	  for ( int i = 0; i < numberOfNewFavourites; i++) {
		 out.println("<favourite>");
		 File currentFavourite = (File) favouriteFiles.get(i);
		 out.println(currentFavourite.getAbsolutePath() );
		 out.println("</favourite>");
	  } // end for ()

	  out.println("</favouriteFiles>");
	  
	  out.flush();
	  out.close();

   }



   private void parseFavourite(Element favourite) throws PedroException {
	  
	  String favouriteValue = getFieldValue(favourite);
	  if ( favouriteValue.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) == false) {
		 File favouriteFile = new File(favouriteValue);
		 if ( favouriteFile.exists() == true) {
			favouriteFiles.add(favouriteFile);
		 } //end if ()
	  } //end if ()
   }

   private void parseTemplatePath(Element templatePath) {
	  
	  String templatePathValue = getFieldValue(templatePath);
	  if ( templatePathValue.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) == false) {

		 File candidateTemplateDirectory = new File(templatePathValue);
		 if ( candidateTemplateDirectory.exists() == true) {
			templateDirectory = candidateTemplateDirectory;
		 } //end if ()
	  } //end if ()
   }

   private void parseDataPath(Element dataPath) {
	  String dataPathValue = getFieldValue(dataPath);
	  if ( dataPathValue.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) == false) {
		 File candidateDataDirectory = new File(dataPathValue);
		 if ( candidateDataDirectory.exists() == true) {
			dataDirectory = candidateDataDirectory;
		 } //end if ()
	  } //end if ()
   }

   private void parseImportPath(Element importPath) {
	  
	  String importPathValue = getFieldValue(importPath);
	  if ( importPathValue.equals(GlobalConstants.NO_ATTRIBUTE_VALUE) == false) {
		 File candidateImportDirectory = new File(importPathValue);
		 if ( candidateImportDirectory.exists() == true) {
			importDirectory = candidateImportDirectory;
		 } //end if ()
	  } //end if ()
   }


   private String getFieldValue(Element element) {
	  Node fieldChild  = element.getFirstChild();
	  if ( fieldChild.getNodeType() == Node.TEXT_NODE) {
		 Text text = (Text) fieldChild;
		 String data = text.getData();
		 data = data.trim();
		 return data;
	  }
	  return "";
   }

   public File getImportDirectory() {
	  return importDirectory;
   }

   public File getDataDirectory() {
	  return dataDirectory;
   }

   public File getTemplateDirectory() {
	  return templateDirectory;
   }

   public File[] getFavouriteFiles() {
	  File[] favouritesList = (File[]) favouriteFiles.toArray(new File[0]);
	  return favouritesList;
   }

   // ==========================================
   // Section Mutators
   // ==========================================
   public void setDataDirectory(File _dataDirectory) {
	  if ( _dataDirectory == null) {
		 return;
	  } //end if ()
	  
	  
	  if ( _dataDirectory.getAbsolutePath().equals(dataDirectory.getAbsolutePath()) == false) {
		 this.dataDirectory = _dataDirectory;
	  } //end if ()
   }

   public void setTemplateDirectory(File _templateDirectory) {
	  if ( _templateDirectory == null) {
		 return;
	  } //end if ()
	  
	  if ( _templateDirectory.getAbsolutePath().equals(templateDirectory.getAbsolutePath()) == false) {
		 this.templateDirectory = _templateDirectory;
	  } //end if ()
   }

   public void setImportDirectory(File _importDirectory) {
	  if ( _importDirectory == null) {
		 return;
	  } //end if ()
	  
	  if ( _importDirectory.getAbsolutePath().equals(importDirectory.getAbsolutePath()) == false) {
		 this.importDirectory = _importDirectory;
	  } //end if ()
   }
   

   public void registerFavouriteFile(File favouriteFile) {
	  //add at the beginning, remove from the end
	  if ( favouriteFiles.size() == NUMBER_OF_FAVOURITES) {
		 //favourites list is full; remove the least recently used
		 favouriteFiles.remove(NUMBER_OF_FAVOURITES - 1);
	  } //end if ()
	  
	  //add new favourite
	  favouriteFiles.addFile(favouriteFile);
   }


   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================



   // ==========================================
   // Section Overload
   // ==========================================

}


class FavouritesList extends ArrayList {


   public void addFile(File file) {

	  int numberOfFiles = size();
	  boolean duplicateExists = false;

	  int i;
	  for ( i = 0; i < numberOfFiles; i++) {
		 File currentFile = (File) get(i);
		 if ( currentFile.getAbsolutePath().equals(file.getAbsolutePath() ) == true) {
			duplicateExists = true;
			break;
		 }
	  } // end for ()

	  if ( duplicateExists == true) {
		 remove(i);
	  }
	  add(0,file);
		 

   }

}

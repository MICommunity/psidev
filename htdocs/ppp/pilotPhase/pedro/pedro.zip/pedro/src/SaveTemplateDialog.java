/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/

package pedro;

import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.border.LineBorder;
import javax.swing.JScrollPane;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JSeparator;
import javax.swing.ButtonModel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class SaveTemplateDialog extends JDialog 
   implements ActionListener {

   
   // ==========================================
   // Section Constants
   // ==========================================
 

   // ==========================================
   // Section Properties
   // ==========================================
   private JLabel templateDescriptionLabel;
   private JTextArea description;
   private JRadioButton saveOnlyRecord;
   private JRadioButton saveRecordAndSubrecords;
   private ButtonGroup buttonGroup;
   private JPanel buttonPanel;
   private JPanel saveOptionsPanel;
   private JButton ok;
   private JButton cancel;
   private boolean showSaveOptions;
   private JScrollPane descriptionPane;
   private boolean isCancelled;

   // ==========================================
   // Section Construction
   // ==========================================
   public SaveTemplateDialog(boolean showSaveOptions) {
	  setTitle("Save Template");
	  //templateDescriptionLabel = new JLabel("Template Description");
	  //templateDescriptionLabel.setForeground(Color.black);
	  
	  //description = new JTextArea(5, 30);
	  //descriptionPane = new JScrollPane(description);
	  
	  saveOptionsPanel = createSaveOptionsPanel();
	  buttonPanel = createButtonPanel();
	  this.showSaveOptions = showSaveOptions;

	  isCancelled = false;

	  buildDialog();
	  setModal(true);
   }

   private void buildDialog() {
	  JPanel panel = new JPanel(new GridBagLayout() );
	  GridBagConstraints panelGC = new GridBagConstraints();
	  panelGC.weightx = 0;
	  panelGC.anchor = GridBagConstraints.NORTHWEST;
	  panelGC.fill = GridBagConstraints.NONE;
	  panelGC.gridx = 0;
	  panelGC.gridy = 0;
	  //panel.add(templateDescriptionLabel, panelGC);

	  //panelGC.gridy = 1;
	  //panelGC.fill = GridBagConstraints.BOTH;
	  //panelGC.weightx = 100;
	  //panelGC.weighty = 100;
	  //panel.add(descriptionPane, panelGC);
	  
	  panelGC.gridy++;

	  //if ( showSaveOptions == true) {
		 panelGC.fill = GridBagConstraints.NONE;
		 panelGC.anchor = GridBagConstraints.WEST;
		 panelGC.weightx = 0;
		 panelGC.weighty = 0;
		 panel.add(saveOptionsPanel, panelGC);
		 panelGC.gridy++;
		 panel.add(new JSeparator(), panelGC);
		 panelGC.gridy++;
		 //} //end if ()
	  
	  panelGC.fill = GridBagConstraints.NONE;
	  panelGC.weightx = 0;
	  panelGC.weighty = 0;
	  panelGC.anchor = GridBagConstraints.SOUTHEAST;
	  panel.add(buttonPanel, panelGC);
	  getContentPane().add(panel);
	  pack();
   }


   public boolean writeChildRecords() {
	  ButtonModel selectedModel = buttonGroup.getSelection();
	  if ( selectedModel == saveOnlyRecord.getModel() ) {
		 return false;
	  } //end if ()
	  else {
		 return true;
	  } //end else
   }

   public void setShowSaveOptions(boolean showSaveOptions) {
	  this.showSaveOptions = showSaveOptions;
   }

   private JPanel createSaveOptionsPanel() {

	  JPanel panel = new JPanel(new GridBagLayout() );

	  GridBagConstraints panelGC = new GridBagConstraints();
	  panelGC.weightx = 0;
	  panelGC.anchor = GridBagConstraints.NORTHWEST;
	  panelGC.fill = GridBagConstraints.NONE;
	  panelGC.weightx = 0;
	  panelGC.weighty = 0;
	  panelGC.gridx = 0;
	  panelGC.gridy = 0;

	  saveOnlyRecord = new JRadioButton("Save selected record only");
	  saveRecordAndSubrecords = new JRadioButton("Save selected record and subrecords");
	  buttonGroup = new ButtonGroup();
	  buttonGroup.add(saveOnlyRecord);
	  buttonGroup.add(saveRecordAndSubrecords);
	  saveOnlyRecord.setSelected(true);

	  panel.add(saveOnlyRecord, panelGC);
	  panelGC.gridy++;
	  panel.add(saveRecordAndSubrecords, panelGC);

	  return panel;

   }



   private JPanel createButtonPanel() {
	  JPanel panel = new JPanel(new GridBagLayout() );

	  GridBagConstraints panelGC = new GridBagConstraints();
	  panelGC.weightx = 0;
	  panelGC.anchor = GridBagConstraints.SOUTHEAST;
	  panelGC.fill = GridBagConstraints.NONE;
	  panelGC.gridx = 0;
	  panelGC.gridy = 0;

	  ok = new JButton("OK");
	  ok.addActionListener(this);
	  panel.add(ok, panelGC);

	  panelGC.gridx = 1;
	  cancel = new JButton("Cancel");
	  cancel.addActionListener(this);
	  panel.add(cancel, panelGC);
	  
	  return panel;

   }


   // ==========================================
   // Section Accessors
   // ==========================================
   public boolean isCancelled() {
	  return isCancelled;
   }

   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================
   public void actionPerformed(ActionEvent event) {
	  Object source = event.getSource();
	  if ( source == ok) {
		 isCancelled = false;
		 
	  } //end if ()
	  else if ( source == cancel) {
		 
		 isCancelled = true;
	  } //end else ()
	  
	  dispose();
   }


   // ==========================================
   // Section Overload
   // ==========================================

}

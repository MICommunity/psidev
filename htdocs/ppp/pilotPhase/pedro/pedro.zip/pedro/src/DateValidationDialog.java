/**
*
* Copyright (c) 2003 University of Mancester.
* @author Kevin Garwood (garwood@cs.man.ac.uk)
*
*/



package pedro;


import javax.swing.JDialog;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.ButtonModel;
import javax.swing.JPanel;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.text.SimpleDateFormat;
import java.text.DateFormat;
import java.awt.Color;

import pedro.validation.DateValidator;

/**
 * @author Kevin Garwood
 * @date
 * @version 1.0
 */

/*
Code RoadMap:
Section Constants
Section Properties
Section Construction
Section Accessors
Section Mutators
Section Validation
Section Errors
Section Interfaces
Section Overload
*/

public class DateValidationDialog extends JDialog 
   implements ActionListener {

   
   // ==========================================
   // Section Constants
   // ==========================================
   /*
   public SimpleDateFormat yyyymmddFormat = new SimpleDateFormat("yyyy/mm/dd");
   public SimpleDateFormat mmddyyyyFormat = new SimpleDateFormat("mm/dd/yyyy");
   public SimpleDateFormat ddmmyyyyFormat = new SimpleDateFormat("dd/mm/yyyy");
   */ 

   // ==========================================
   // Section Properties
   // ==========================================

   private JLabel formatChoiceLabel;
   private JRadioButton yyyymmdd;
   private JRadioButton mmddyyyy;
   private JRadioButton ddmmyyyy;


   private JButton ok;
   private JButton close;
   
   private JLabel instructionsTitle;

   private ButtonGroup buttonGroup;
   private JPanel formatChoicePanel;
   private SimpleDateFormat dateFormat;
   // ==========================================
   // Section Construction
   // ==========================================
   public DateValidationDialog() {
	  
	  setTitle("Date Validation");
	  initializeDateFormats();

	  JPanel panel = new JPanel(new GridBagLayout() );

	  GridBagConstraints panelGC = new GridBagConstraints();
	  panelGC.weightx = 0;
	  panelGC.anchor = GridBagConstraints.NORTHWEST;
	  panelGC.fill = GridBagConstraints.NONE;
	  panelGC.gridx = 0;
	  panelGC.gridy = 0;

	  //add instruction area
	  panel.add(createInstructionsPanel(), panelGC);

	  panelGC.gridy++;
	  createFormatChoicePanel();
	  panel.add(formatChoicePanel, panelGC);

	  panelGC.gridy++;
	  panelGC.anchor = GridBagConstraints.SOUTHEAST;
	  panel.add(createButtonPanel(), panelGC);

	  getContentPane().add(panel);
	  pack();
	  //setSize(300,300);
	  //setResizable(false);
	  setModal(true);
   }

   private void initializeDateFormats() {

   }

   private JPanel createInstructionsPanel() {
	  JPanel panel = new JPanel(new GridBagLayout() );
	  GridBagConstraints panelGC = new GridBagConstraints();
	  panelGC.weightx = 0;
	  panelGC.anchor = GridBagConstraints.NORTHWEST;
	  panelGC.fill = GridBagConstraints.NONE;
	  panelGC.gridx = 0;
	  panelGC.gridy = 0;
	  
	  instructionsTitle = new JLabel("Instructions");
	  instructionsTitle.setForeground(Color.black);
	  panel.add(instructionsTitle, panelGC);

	  panelGC.gridy++;
	  JTextArea instructions = new JTextArea();
	  instructions.setEditable(false);
	  instructions.setForeground(Color.black);
	  instructions.setBackground(getBackground() );
	  instructions.append("These settings determine what date format\n ");
	  instructions.append("will be used to display date field values.\n ");
	  instructions.append("The default format is dd/mm/yyyy.");
	  instructions.setWrapStyleWord(true);

	  panel.add(instructions, panelGC);

	  return panel;
   }

   private void createFormatChoicePanel() {
	  
	  formatChoicePanel = new JPanel(new GridBagLayout() );
	  
	  GridBagConstraints panelGC = new GridBagConstraints();
	  panelGC.weightx = 0;
	  panelGC.anchor = GridBagConstraints.NORTHWEST;
	  panelGC.fill = GridBagConstraints.NONE;
	  panelGC.gridx = 0;
	  panelGC.gridy = 0;

	  formatChoiceLabel = new JLabel("Date format choices:");
	  formatChoicePanel.add(formatChoiceLabel, panelGC);


	  yyyymmdd = new JRadioButton("yyyy/mm/dd");
	  mmddyyyy = new JRadioButton("mm/dd/yyyy");
	  ddmmyyyy = new JRadioButton("dd/mm/yyyy");

	  buttonGroup = new ButtonGroup();
	  buttonGroup.add(yyyymmdd);
	  buttonGroup.add(mmddyyyy);
	  buttonGroup.add(ddmmyyyy);

	  panelGC.gridy++;
	  formatChoicePanel.add(yyyymmdd, panelGC);
	  panelGC.gridy++;
	  formatChoicePanel.add(mmddyyyy, panelGC);
	  panelGC.gridy++;
	  formatChoicePanel.add(ddmmyyyy, panelGC);


	  SimpleDateFormat currentFormat = DateValidator.getDateFormat();

	  ButtonModel selectedModel;

	  if ( currentFormat == DateValidator.yyyymmddFormat) {
		 selectedModel = yyyymmdd.getModel();
	  } //end if ()
	  else if ( currentFormat == DateValidator.mmddyyyyFormat) {
		 selectedModel = mmddyyyy.getModel();
	  } //end else ()
	  else {
		 selectedModel = ddmmyyyy.getModel();
	  } //end else
	  
	  buttonGroup.setSelected(selectedModel,true);
	  
   }

   private JPanel createButtonPanel() {
	  JPanel panel = new JPanel(new GridBagLayout() );
	  
	  GridBagConstraints panelGC = new GridBagConstraints();
	  panelGC.weightx = 0;
	  panelGC.anchor = GridBagConstraints.SOUTHEAST;
	  panelGC.fill = GridBagConstraints.NONE;
	  panelGC.gridx = 0;
	  panelGC.gridy = 0;

	  ok = new JButton("OK");
	  ok.addActionListener(this);
	  panel.add(ok, panelGC);

	  panelGC.gridx++;
	  close = new JButton("Close");
	  close.addActionListener(this);
	  panel.add(close, panelGC);

	  return panel;
   }

   private void sensitizeButtons(boolean sensitizeButtons) {
	  yyyymmdd.setEnabled(sensitizeButtons);
	  mmddyyyy.setEnabled(sensitizeButtons);
	  ddmmyyyy.setEnabled(sensitizeButtons);
   }

   // ==========================================
   // Section Accessors
   // ==========================================

   public DateFormat getDateFormat() {
	  return dateFormat;
   }

   private void commitDateFormatChoice() {
	  //buttonGroup
		 
	  ButtonModel selectedModel = buttonGroup.getSelection();
	  if ( selectedModel == yyyymmdd.getModel() ) {
		 DateValidator.setDateFormat(DateValidator.yyyymmddFormat);
	  } //end if ()
	  else if ( selectedModel == mmddyyyy.getModel() ) {
		 DateValidator.setDateFormat(DateValidator.mmddyyyyFormat);
	  } //end else ()
	  else {
		 //dd-mm-yyyy
		 DateValidator.setDateFormat(DateValidator.ddmmyyyyFormat);
	  } //end else

   }

   // ==========================================
   // Section Mutators
   // ==========================================

   // ==========================================
   // Section Validation
   // ==========================================

   // ==========================================
   // Section Errors
   // ==========================================




   // ==========================================
   // Section Interfaces
   // ==========================================
   public void actionPerformed(ActionEvent event) {
	  Object source = event.getSource();
	  if ( source == ok) {
		 commitDateFormatChoice();
		 hide();
	  } //end else ()
	  else if ( source == close) {
		 hide();
	  } //end else ()

   }


   // ==========================================
   // Section Overload
   // ==========================================

}

/*
 * Created on 11 juil. 2003
 *
 */
package mint.psi.filemakers.flattener;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTree;
import javax.swing.border.TitledBorder;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.TreeNode;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import mint.psi.filemakers.xsd.AbstractXsdTree;

import org.exolab.castor.xml.schema.Annotated;
import org.exolab.castor.xml.schema.Annotation;
import org.exolab.castor.xml.schema.AttributeDecl;
import org.exolab.castor.xml.schema.Documentation;
import org.exolab.castor.xml.schema.ElementDecl;
import org.exolab.castor.xml.schema.Structure;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * 
 * This class overides the abstract class AbstractXslTree
 * to provide a tree representation of a XML schema, with 
 * management of transformation of an XML file to a flat file. 
 * 
 * @author Arnaud Ceol, University of Rome "Tor Vergata", Mint group,
 * arnaud@cbm.bio.uniroma2.it 
 *
 */
public class XslTreeImpl extends AbstractXsdTree {

	/**
	 * the XML document to parse and transform into a flat file
	 */
	private Document document;

	/**
	 * the separator for the flat file
	 */
	private String separator = "|";

	/**
	 * the node associated to a line of the flat file.
	 * if null, the printer will look for the deeper node that is an ancestor of every selection.
	 */
	private XslNode lineNode = null;

	/**
	 * true if the user has choosed a node that contains what he wants to see on a line 
	 * of the flat file
	 */
	private boolean lineNodeIsSelected = false;

	/**
	 * the elements of ths XML document associated to a line of the flat file.
	 * if null, the printer will look for the deeper node that is an ancestor of every selection.
	 */
	private ArrayList lineElements = null;

	/**
	 * type of marshalling: for creating a line with columns titles
	 */
	final static int TITLE = 0;

	/**
	 * type of marshalling: for not creating a line with columns titles
	 */
	final static int FULL = 1;

	/** 
	 * used to display an overview of title line of the flat line
	 *
	 */
	private JTextArea titlesPreviewPane;

	/**
	 * create a new instance of XslTree
	 * The nodes will not be automaticaly duplicated
	 * even if the schema specify that more than one
	 * element of this type is mandatory 
	 */
	public XslTreeImpl() {
		super(false, false);

		titlesPreviewPane = new JTextArea();
		titlesPreviewPane.setEditable(false);
		
		JScrollPane scrollpane = new JScrollPane(titlesPreviewPane);

		scrollpane.setVerticalScrollBarPolicy(
			JScrollPane.VERTICAL_SCROLLBAR_NEVER);
		scrollpane.setHorizontalScrollBarPolicy(
			JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollpane.setBorder(new TitledBorder("Preview"));

		add(scrollpane, BorderLayout.SOUTH);
	}

	/**
	 * create a button panel that includes buttons for loading the schema and the document,
	 * to select and unselect a node, get informations about the node, choose a separator for the
	 * flat file and print the flat file
	 */
	protected Box getButtonPanel() {
		Box buttonsPanel = new Box(BoxLayout.Y_AXIS);

		Box treeBox = new Box(BoxLayout.Y_AXIS);
		treeBox.setBorder(new TitledBorder("Schema"));

		Box associationBox = new Box(BoxLayout.Y_AXIS);
		associationBox.setBorder(new TitledBorder("Association"));

		Box outputBox = new Box(BoxLayout.Y_AXIS);
		outputBox.setBorder(new TitledBorder("Output"));

		/* add a button for loading a XML Schema */
		JButton loadFileb = new JButton("Open a schema");
		loadFileb.setMaximumSize(buttonsDimension);
		loadFileb.addActionListener(new LoadSchemaListener());

		/* add a button for associating the content of a node to a line in the flat file */
		JButton selectLineNodeb = new JButton("Node describing a line");
		selectLineNodeb.setMaximumSize(buttonsDimension);
		selectLineNodeb.addActionListener(new SelectLineNodeListener());

		JButton selectNodeb = new JButton("Select this node");
		selectNodeb.setMaximumSize(buttonsDimension);
		selectNodeb.addActionListener(new SelectNodeListener());

		JButton unselectNodeb = new JButton("Unselect the node");
		unselectNodeb.setMaximumSize(buttonsDimension);
		unselectNodeb.addActionListener(new UnselectNodeListener());

		JButton infosb = new JButton("About the node");
		infosb.setMaximumSize(buttonsDimension);
		infosb.addActionListener(new InfosListener());

		associationBox.add(selectNodeb);
		associationBox.add(unselectNodeb);

		treeBox.add(loadFileb);

		associationBox.add(infosb);

		JButton loadXmlFileb = new JButton("Load a Xml document");
		loadXmlFileb.setMaximumSize(buttonsDimension);
		loadXmlFileb.addActionListener(new LoadDocumentListener());

		JButton setSeparatorb = new JButton("Choose the separator");
		setSeparatorb.setMaximumSize(buttonsDimension);
		setSeparatorb.addActionListener(new SetSeparatorListener());

		JButton printTabFileb = new JButton("Print the flat file");
		printTabFileb.setMaximumSize(buttonsDimension);
		printTabFileb.addActionListener(new PrintFlatFileListener());

		treeBox.add(loadXmlFileb);
		treeBox.add(selectLineNodeb);

		outputBox.add(setSeparatorb);
		outputBox.add(printTabFileb);

		buttonsPanel.add(treeBox);
		buttonsPanel.add(associationBox);
		buttonsPanel.add(outputBox);

		return buttonsPanel;
	}

	/**
	 * Set the cell renderer with the local renderer
	 */
	protected void setCellRenderer() {
		tree.setCellRenderer(new XslTreeRenderer());
	}

	/**
	 * set the separator for the flat file
	 * @param s the separator
	 */
	public void setSeparator(String s) {
		separator = s;
		updatePreview();
	}

	/**
	 * check for errors on this node (lack of associations...) and return an array 
	 * of understandable Strings describing the errors
	 * @param node the node to check
	 * @return an array of Strings describing the errors found
	 */
	protected ArrayList check(XslNode node) {
		return null;
	}

	/**
	 * this method should reinitialize every variable making reference 
	 * to the actual tree, such as any <code>List</code> used to
	 * make associations to externals objects. 
	 * 
	 * set selection as a new <code>ArrayList</code>
	 */
	protected void emptySelectionLists() {
		selections = new ArrayList();
	}

	/**
	 * XML attributes
	 */
	private static String SCHEMA_LANGUAGE =
		"http://java.sun.com/xml/jaxp/properties/schemaLanguage",
		XML_SCHEMA = "http://www.w3.org/2001/XMLSchema",
		SCHEMA_SOURCE = "http://java.sun.com/xml/jaxp/properties/schemaSource";

	/**
	 * Used to parse the XML document using XML schema
	 * 
	 * @author Arnaud Ceol 
	 * 
	 */
	protected class LoadDocumentListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			if (schema == null) {
				displayMessage(
					"Please load a XML schema first",
					"[PSI makers: flattener] loading document");
				return;
			}
			loadDocument();
		}
	}

	/**
	 * Open a frame to choose an XML document and load it.
	 *
	 */
	private void loadDocument() {
		maxCounts = new HashMap();

		try {
			JFileChooser fileChooser = new JFileChooser(".");
			int returnVal = fileChooser.showOpenDialog(new JFrame());

			if (returnVal != JFileChooser.APPROVE_OPTION) {
				return;
			}

			DocumentBuilderFactory factory =
				DocumentBuilderFactory.newInstance();
			factory.setNamespaceAware(true);
			factory.setValidating(true);

			factory.setAttribute(SCHEMA_LANGUAGE, XML_SCHEMA);
			factory.setAttribute(SCHEMA_SOURCE, schemaFile);

			DocumentBuilder builder = factory.newDocumentBuilder();

			document = builder.parse(fileChooser.getSelectedFile());
		} catch (Exception ex) {
			JOptionPane.showMessageDialog(
				new JFrame(),
				"unable to load file",
				"PSI-Tab makers: Tab Maker",
				JOptionPane.ERROR_MESSAGE);
		}
		setLineNode(lineNode);
		updatePreview();
	}

	protected class PrintFlatFileListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {

			if (rootNode == null) {
				displayMessage(
					"No schema loaded",
					"[PSI makers: flattener]");
				return;
			}

			if (document == null) {
				displayMessage(
					"No document loaded",
					"[PSI makers: flattener]");
				return;
			}

			TreeNode[] path = rootNode.getPath();
			try {
				JFileChooser fileChooser = new JFileChooser(".");
				int returnVal = fileChooser.showOpenDialog(new JFrame());

				if (returnVal != JFileChooser.APPROVE_OPTION) {
					return;
				}

				PrintWriter out =
					new PrintWriter(
						new BufferedWriter(
							new FileWriter(fileChooser.getSelectedFile())));

				System.out.println("[PSI makers: flattener] start marshalling");
				write(out);
				System.out.println("[PSI makers: flattener] marshalling done");

				out.flush();
				out.close();
			} catch (IOException ex) {
				JOptionPane.showMessageDialog(
					new JFrame(),
					"unable to write file",
					"PSI-Tab makers: Tab Maker",
					JOptionPane.ERROR_MESSAGE);
			}
		}
	}

	public class CheckListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			ArrayList paths = check((XslNode) treeModel.getRoot());
			String errors = paths.size() + " errors found: \n";
			for (int i = 0; i < paths.size(); i++) {
				errors += paths.get(i) + "\n";
			}

			JOptionPane.showMessageDialog(
				new JFrame(),
				errors,
				"[PSI makers: flattener] checking associations",
				JOptionPane.ERROR_MESSAGE);
		}
	}

	private class SetSeparatorListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			String s =
				(String) JOptionPane.showInputDialog(
					new JFrame(),
					"Enter a default value, \n");

			if (s != null)
				setSeparator(s);
		}
	}

	/**
	 * used to display informations about the node selected
	 * 
	 * @author arnaud
	 */
	private class InfosListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			XslNode node = (XslNode) tree.getLastSelectedPathComponent();

			if (node == null) {
				displayMessage(
					"No node selected",
					"[PSI makers: flattener]");
				return;
			}

			JEditorPane editorPane = new JEditorPane();
			editorPane.setEditable(false);
			editorPane.setText(getInfos(node));

			JScrollPane scrollPane = new JScrollPane(editorPane);
			scrollPane.setVerticalScrollBarPolicy(
				JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

			JOptionPane.showMessageDialog(new JFrame(), scrollPane);
		}
	}

	/**
	 * used for loading a Xml schema 
	 */
	private class LoadSchemaListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			loadSchema();
			if (schema != null)
				setXmlRoot();
		}
	}

	/**
	 * use to select the node that will describe a line of the flat file
	 */
	private class SelectLineNodeListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			if (document == null) {
				displayMessage(
					"Please load a XML document first",
					"[PSI makers: flattener] node selection for a line");
				return;
			}
			try {
				lineNode = (XslNode) tree.getLastSelectedPathComponent();
				setLineNode(lineNode);
			} catch (NullPointerException npe) {
				displayMessage(
					"No node selected",
					"[PSI makers: flattener]");
			}
		}
	}

	private void setLineNode(XslNode lineNode) {
		maxCounts = new HashMap();

		lineElements = getNodes(lineNode.getPath());
		updatePreview();
		treeModel.reload(lineNode);

		lineNodeIsSelected = true;
	}

	protected String getInfos(XslNode node) {
		String infos = super.getInfos(node);
		infos += "selected: " + selections.contains(node) + "\n";
		return infos;
	}

	/**
	 * this <code>HashMap</code> keep the maximum amount of a node type found in the 
	 * file for a type of node. The key is the String association of the name of the parent and
	 *  the name of the node 
	 */
	private HashMap maxCounts = new HashMap();

	/**
	 * follow a path in the document to find corresponding element
	 * 
	 * @return the node in the XML document that found by following
	 * the path 
	 * 
	 */
	private ArrayList getNodes(TreeNode[] path) {
		if (document == null)
			return null;

		Node value = document.getDocumentElement();
		ArrayList list = new ArrayList();

		for (int i = 1; i < path.length -1; i++) {
			//if it's not selected, there should not be more than one
			NodeList children = value.getChildNodes();

			value = null;
			for (int j = 0; j < children.getLength() ; j++) {
				if (((XslNode) path[i])
					.toString()
					.compareTo(children.item(j).getNodeName())
					== 0) {
					if (value != null) {
						System.out.println("more than one possibility");
					}
					value = children.item(j);
				}
			}
		}
		NodeList children = value.getChildNodes();
		for (int j = 0; j < children.getLength(); j++) {
			if (((XslNode) path[path.length - 1])
				.toString()
				.compareTo(children.item(j).getNodeName())
				== 0) {
				list.add(children.item(j));
			}
		}
		System.out.println(list.size() + " element found.");
		return list;
	}

	/**
	 * 
	 * @param element an element of the XML document
	 * @return value of this element if it exists, an empty String else
	 */
	private String getElementValue(Element element) {
		NodeList children = element.getChildNodes();
		for (int i = 0; i < children.getLength(); i++) {
			if (children.item(i).getNodeName() == "#text")
				return children.item(i).getNodeValue();
		}
		return "";
	}

	/**
	 * look in the XML schema for the deepest node that
	 * is an ancester of every nodes selected
	 * 
	 * @ return the deepest node in the XML schema that is an ancester of every nodes selected
	 */
	private void setXmlRoot() {
		if (lineNodeIsSelected)
			return;

		if (selections.size() == 0) {
			lineNode = (XslNode) treeModel.getRoot();
			lineElements = getNodes(lineNode.getPath());
			return;
		}

		XslNode value = rootNode;
		XslNode tmp = null;
		XslNode select = null;
		XslNode lastDuplicable = null;
		// go down while no more than one child is used and current node 
		// is not selected

		// keep last node duplicable 

		Enumeration children = value.children();
		int nb = 0;
		while (nb <= 1 && !selections.contains(tmp)) {

			if (children.hasMoreElements()) {
				XslNode child;
				child = (XslNode) children.nextElement();
				if (child.isUsed) {
					tmp = child;
					nb++;
				}
				if (selections.contains(child)) {
					select = child;
				}
			} else {
				nb = 0;
				if (tmp.isDuplicable())
					lastDuplicable = tmp;
				value = tmp;
				children = value.children();
			}
		}
		if (nb <= 1)
			value = select;
		System.out.println(
			"[PSI makers: flattener] root selected: " + value.toString());

		lineNode = lastDuplicable;

		lineElements = getNodes(lineNode.getPath());

	}

	/**
	 * true if currently printed element is the first of a ligne.
	 * Used to know if a separator is needed when prining
	 * the flat file.
	 */
	private boolean firstElement = true;

	/**
	 * create a flat file separated by specified separator 
	 * containing every element contained in the XML document and selected 
	 * on the tree, with a first line that contains the tiltles of columns
	 * @param out the <code>writer</code> where to print the file
	 * @throws IOException
	 */
	public void write(Writer out) throws IOException {
		/* get the first interresting node, ie the deepest one
		 that is an ancestor of every selected node, in the schema and 
		 corresponding nodes in the the document
		 */
		setXmlRoot();
		firstElement = true;
		/* marshall once for title */
		writeNode(lineNode, (Element) lineElements.get(0), TITLE, out);
		out.write("\n");
		firstElement = true;
		/* marshall each element */
		for (int i = 0; i < lineElements.size(); i++) {
			firstElement = true;
			writeNode(lineNode, (Element) lineElements.get(i), FULL, out);
			out.write("\n");
		}
	}

	/**
	 * get the maximum amount of element of a type as child of another type of element
	 * in the XML document.
	 * It is used to know how many columns have to be created in the flat file, 
	 * as even empty ones have to be printed.
	 */
	private int getMaxCount(XslNode node) {

		/* if no document loaded */
		if (lineElements == null)
			return 0;

		/* max count already computed */
		if (maxCounts.containsKey(node)) {
			return ((Integer) maxCounts.get(node)).intValue();
		}

		int count = 0;
		int max = 0;
		for (int i = 0; i < lineElements.size(); i++) {
			count =
				getMaxCount(
					(Node) lineElements.get(i),
					lineNode,
					node,
					node.pathFromAncestorEnumeration(lineNode));
			if (count > max)
				max = count;
		}

		/* the fields are kept even if no element have been found */
		if (max < node.min) {
			max = node.min;
		}
		if (max == 0) {
			max = 1;
		}

		/* keep the result */
		maxCounts.put(node, new Integer(max));
		return max;
	}

	/**
	 * get the maximum amount of element of a type as child of another type of element
	 * in the XML document.
	 * It is used to know how many columns have to be created in the flat file, 
	 * as even empty ones have to be printed.
	 * @param element the element in the XML document
	 * @param parent the parent of the node on the tree
	 * @param target the node on the tree
	 * @param path the path to access to the node
	 */
	private int getMaxCount(
		Node element,
		XslNode parent,
		XslNode target,
		Enumeration path) {

		if (target == parent) {
			return 1;
		}

		int currentMax = 0;
		int totalCount = 0;
		int max = 0;
		int count = 0;

		path.nextElement();
		XslNode nextNode = (XslNode) path.nextElement();

		/* get all childrens and refs */
		NodeList childrens = element.getChildNodes();

		for (int indexChildrens = 0;
			indexChildrens < childrens.getLength();
			indexChildrens++) {
			Node child = childrens.item(indexChildrens);
			/* direct childrens */
			if (child.getNodeName().compareTo(nextNode.toString()) == 0) {
				count++;
				currentMax =
					getMaxCount(
						child,
						nextNode,
						target,
						target.pathFromAncestorEnumeration(nextNode));
				totalCount += currentMax;
				if (((XslNode) target.getParent())
					.toString()
					.compareTo(parent.toString())
					== 0) {
					max += currentMax;
				} else {
					if (currentMax > max)
						max = currentMax;
				}
			}

			/* references */
			else if (isRefType(child.getNodeName())) {
				Element ref =
					document.getElementById(
						((Element) child).getAttribute(refAttribute));
				if (ref != null
					&& ref.getNodeName().compareTo(nextNode.toString()) == 0) {
					count++;
					currentMax =
						getMaxCount(
							ref,
							nextNode,
							target,
							target.pathFromAncestorEnumeration(nextNode));
					totalCount += currentMax;
					if (((XslNode) target.getParent())
						.toString()
						.compareTo(parent.toString())
						== 0) {
						max += currentMax;
					} else {
						if (currentMax > max)
							max = currentMax;
					}
				}
			}
		}

		return max;
	}

	/**
	 * add to the flat file the content of a node
	 * @param node the node in the tree to parse 
	 * @param element the element in tghe XML document
	 * @param marshallingType title or full parsing
	 * @param out 
	 * @throws IOException
	 */
	private void writeNode(
		XslNode node,
		Node element,
		int marshallingType,
		Writer out)
		throws IOException {
		if (!node.isUsed) {
			return;
		}

		if (selections.contains(node)) {
			if (firstElement)
				firstElement = false;
			else
				out.write(separator);

			if (marshallingType == TITLE) {
				out.write("[" + node.toString() + "]");
			} else {
				if (element != null) {
					out.write(getElementValue((Element) element));
				}
			}
		}

		Enumeration children = node.children();
		while (children.hasMoreElements()) {
			XslNode child = (XslNode) children.nextElement();
			if (child.isUsed) {
				switch (((Annotated) child.getUserObject())
					.getStructureType()) {
					case Structure.ELEMENT :

						int cpt = 0;

						/*	create a NodeList with all childs with tagname */
						if (element != null) {
							NodeList allElements = element.getChildNodes();
							ArrayList elements = new ArrayList();
							for (int i = 0; i < allElements.getLength(); i++) {
								if (allElements
									.item(i)
									.getNodeName()
									.compareTo(child.toString())
									== 0) {
									elements.add(allElements.item(i));
								}

								/* get references */
								else if (
									isRefType(
										allElements.item(i).getNodeName())) {
									Element ref =
										document.getElementById(
											(
												(Element) allElements.item(
													i)).getAttribute(
												refAttribute));
									if (ref != null
										&& ref.getNodeName().compareTo(
											child.toString())
											== 0) {
										elements.add(ref);
									}
								}
							}
							while (cpt < elements.size()) {
								writeNode(
									child,
									(Node) elements.get(cpt),
									marshallingType,
									out);
								cpt++;
							}
						}
						int maxCount = getMaxCount(child);
						while (cpt < maxCount) {
							writeNode(child, null, marshallingType, out);
							cpt++;
						}
						break;
					case Structure.ATTRIBUTE :
						if (firstElement)
							firstElement = false;
						else
							out.write(separator);

						if (marshallingType == TITLE)
							out.write(
								"["
									+ node.toString()
									+ ":"
									+ child.toString()
									+ "]");
						else {
							if (element != null) {
								try {
									out.write(
										((Element) element)
											.getAttributeNode(child.toString())
											.getNodeValue());
								} catch (NullPointerException ne) {
									/* main cause: the cell does not exist */
								}
							}
						}
						break;
					default :
						System.out.println(
							"[PSI makers: flattener] ERROR: the node is neither an attribute nor an element");
				}
			}
		}
	}

	/**
	 * Such as write but return a String instead of writing in a file.
	 * Only for the marshalling type title.
	 * @param node
	 * @param element
	 * @param marshallingType
	 * @return
	 */
	private String getMarshalling(
		XslNode node,
		Node element,
		int marshallingType) {

		String out = "";

		if (!node.isUsed) {
			return out;
		}

		if (selections.contains(node)) {
			if (firstElement)
				firstElement = false;
			else
				out += separator;

			if (marshallingType == TITLE) {
				out += "[" + node.toString() + "]";
			} else {
				if (element != null) {
					out += getElementValue((Element) element);
				}
			}
		}

		Enumeration children = node.children();
		while (children.hasMoreElements()) {
			XslNode child = (XslNode) children.nextElement();
			if (child.isUsed) {
				switch (((Annotated) child.getUserObject())
					.getStructureType()) {
					case Structure.ELEMENT :
						int cpt = 0;
						/*	create a NodeList with all childs with tagname */
						//						if (marshallingType == FULL && element != null) {
						//							NodeList allElements = element.getChildNodes();
						//							ArrayList elements = new ArrayList();
						//							for (int i = 0; i < allElements.getLength(); i++) {
						//								if (allElements
						//									.item(i)
						//									.getNodeName()
						//									.compareTo(child.toString())
						//									== 0) {
						//									elements.add(allElements.item(i));
						//								}
						//
						//								/* get references */
						//								else if (
						//									allElements.item(i).getNodeName().endsWith(
						//										"Ref")) {
						//
						//									Element ref =
						//										document.getElementById(
						//											(
						//												(Element) allElements.item(
						//													i)).getAttribute(
						//												refAttribute));
						//									if (ref != null
						//										&& ref.getNodeName().compareTo(
						//											child.toString())
						//											== 0) {
						//										elements.add(ref);
						//									}
						//								}
						//							}
						//							while (cpt < elements.size()) {
						//								out
						//									+= getMarshalling(
						//										child,
						//										(Node) elements.get(cpt),
						//										marshallingType);
						//								cpt++;
						//							}
						//						}
						//						while (cpt < getMaxCount(node, child)) {
						int maxCount = getMaxCount(child);
						while (cpt < maxCount) {
							out += getMarshalling(child, null, marshallingType);
							cpt++;
						}
						break;
					case Structure.ATTRIBUTE :
						if (firstElement)
							firstElement = false;
						else
							out += separator;

						if (marshallingType == TITLE)
							out += "["
								+ node.toString()
								+ ":"
								+ child.toString()
								+ "]";
						//						else {
						//							if (element != null) {
						//								try {
						//									out
						//										+= ((Element) element)
						//											.getAttributeNode(child.toString())
						//											.getNodeValue();
						//								} catch (NullPointerException ne) {
						//									/* main cause: the cell does not exist */
						//								}
						//							}
						//						}
						break;
					default :
						System.out.println(
							"[PSI makers: flattener] ERROR: the node is neither an attribute nor an element");
				}
			}
		}
		return out;
	}

	//	private ArrayList templates = new ArrayList();

	/**
	 * the renderer for the tree
	 */
	protected class XslTreeRenderer extends DefaultTreeCellRenderer {
		ImageIcon iconAttribute;
		ImageIcon iconElement;
		Font affected;
		public XslTreeRenderer() {
			iconAttribute = new ImageIcon("images/ic-att.gif");
			iconElement = new ImageIcon("images/ic-elt.gif");
		}

		public Component getTreeCellRendererComponent(
			JTree tree,
			Object value,
			boolean sel,
			boolean expanded,
			boolean leaf,
			int row,
			boolean hasFocus) {

			super.getTreeCellRendererComponent(
				tree,
				value,
				sel,
				expanded,
				leaf,
				row,
				hasFocus);
			XslNode node = (XslNode) value;
			/* set icon and tooltip */
			switch (((Annotated) node.getUserObject()).getStructureType()) {
				case Structure.GROUP :
					setIcon(null);
					break;
				case Structure.ATTRIBUTE :
					setIcon(iconAttribute);
					setToolTipText(
						"default value: "
							+ ((AttributeDecl) node.getUserObject())
								.getDefaultValue());
					break;
				case Structure.ELEMENT :
					setIcon(iconElement);
					try {
						setToolTipText(
							(
								(Documentation)
									((Annotation) ((ElementDecl) node
									.getUserObject())
								.getAnnotations()
								.nextElement())
								.getDocumentation()
								.nextElement())
								.getContent());
					} catch (Exception e) {
						setToolTipText("no documentation");
					}

					break;
			}

			switch (((Annotated) node.getUserObject()).getStructureType()) {
				case Structure.ATTRIBUTE :
					setText(
						getText()
							+ " ("
							+ ((AttributeDecl) node.getUserObject())
								.getSimpleType()
								.getName()
							+ ")");
					break;
				case Structure.ELEMENT :
					setText(
						getText()
							+ " ("
							+ ((ElementDecl) node.getUserObject())
								.getType()
								.getName()
							+ ")");
			}

			setForeground(Color.GRAY);
			if (node.isRequired)
				setForeground(Color.RED);

			if (selections.contains(node))
				setForeground(Color.BLACK);

			if (node == lineNode)
				setForeground(Color.BLUE);

			return this;
		}
	} 

	protected class SelectNodeListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			selectNode();
		}
	} 
	
	protected class UnselectNodeListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			unselectNode();
		}
	} 

	private ArrayList selections = new ArrayList();

	protected void selectNode() {
		XslNode node = (XslNode) tree.getLastSelectedPathComponent();

		if (node == null) {
			displayMessage("No node selected", "[PSI makers: flattener]");
			return;
		}

		if (!canHaveValue((XslNode) tree.getLastSelectedPathComponent())) {
			displayMessage(
				"No value should  have been associated to this node",
				"[PSI makers: flattener]");
			return;
		}

		selections.add(node);
		node.use();
		check((XslNode) treeModel.getRoot());
		treeModel.reload(node);

		setXmlRoot();
		updatePreview();
	}

	private void updatePreview() {
		firstElement = true;
		if (document != null) {
			titlesPreviewPane.setText(getMarshalling(lineNode, null, TITLE));
		}
	}

	protected void unselectNode() {
		XslNode node = (XslNode) tree.getLastSelectedPathComponent();

		if (node == null) {
			displayMessage("No node selected", "[PSI makers: flattener]");
			return;
		}

		selections.remove(node);
		node.unuse();
		check((XslNode) treeModel.getRoot());
		treeModel.reload(node);

		setXmlRoot();
		updatePreview();
	}

}

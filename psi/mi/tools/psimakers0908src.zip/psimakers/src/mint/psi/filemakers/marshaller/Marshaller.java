package mint.psi.filemakers.marshaller;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.border.TitledBorder;
/**
 * Main class for the PSI files maker: this class displays a graphical interface that allows to
 * load and display an XML schema as a tree, to load several flat files and display them as a list of columns,
 *  to select on the tree to wich nodes should be associated the flat files and to 
 * which nodes should be associated the columns, to load dictionnaries and associate them to nodes 
 * for which values form the flat file will be replaced by their definition, and to print in an XML file.
 * Some checkings can be made and some warnings are displayed that allow to know if 
 * associations respect or not the schema.
 * 
 *  
 * @author Arnaud Ceol, University of Rome "Tor Vergata", Mint group,
 * arnaud@cbm.bio.uniroma2.it 
 *
 */
public class Marshaller extends JFrame {
	private XslTreeImpl treePanel;
	private FlatFileTabbedPanel flatFileTabbedPanel;
	private CVPanel cvLists;

	public Marshaller() {
		super("PSI Maker");

		setJMenuBar(new PSIMakerMenu());

		getContentPane().setLayout(new BorderLayout());

		flatFileTabbedPanel = new FlatFileTabbedPanel();
		flatFileTabbedPanel.setBorder(new TitledBorder("Flat files"));

		cvLists = new CVPanel();
		cvLists.setBorder(new TitledBorder("Controlled Vocabulary"));

		Box associationsPanels = new Box(BoxLayout.Y_AXIS);

		associationsPanels.add(flatFileTabbedPanel);

		associationsPanels.add(cvLists);
		getContentPane().add(associationsPanels, BorderLayout.WEST);

		treePanel = new XslTreeImpl();
		treePanel.setBorder(new TitledBorder("Schema"));
		getContentPane().add(treePanel, BorderLayout.CENTER);

		treePanel.setTabFileTabbedPanel(flatFileTabbedPanel);
		treePanel.setCV(cvLists);

		treePanel = new XslTreeImpl();

		final CloseView fv = new CloseView();
		addWindowListener(fv);

		setSize(800, 600);
		setVisible(true);
	} 

	/** 
	 * close properly the frame
	 */
	private class CloseView extends WindowAdapter implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			close();
		}
		public void windowClosing(WindowEvent e) {
			close();
		}
		private void close() {
			Marshaller.this.setVisible(false);
			Marshaller.this.dispose();
			System.exit(0);
		}
	}
	
	/**
	 * the menu bar
	 */
	public class PSIMakerMenu extends JMenuBar {
		public PSIMakerMenu() {
			JMenu file = new JMenu(new String("File"));
			JMenuItem exit = new JMenuItem(new String("Exit"));
			exit.addActionListener(new CloseView());
			file.add(exit);
			add(file);

			JMenu help = new JMenu(new String("Help"));
			JMenuItem documentation = new JMenuItem("Documentation");
			documentation.addActionListener(new DisplayDocumentationListener());
			JMenuItem about = new JMenuItem("About");
			about.addActionListener(new DisplayAboutListener());
			help.add(documentation);
			help.add(about);
			add(help);
		}

		public class DisplayDocumentationListener implements ActionListener {
			public void actionPerformed(ActionEvent e) {
				JEditorPane editorPane = new JEditorPane();
				editorPane.setEditable(false);
				try {
					editorPane.setContentType("text/html");
					editorPane.setPage("file:documentation.html");

					JScrollPane areaScrollPane = new JScrollPane(editorPane);
					areaScrollPane.setVerticalScrollBarPolicy(
						JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
					areaScrollPane.setPreferredSize(new Dimension(600, 650));
					JOptionPane.showMessageDialog(new JFrame(), areaScrollPane);
				} catch (IOException ioe) {
					JOptionPane.showMessageDialog(
						new JFrame(),
						"Documentation not found.",
						"Documentation",
						JOptionPane.ERROR_MESSAGE);
				}
			}
		}
		
		public class DisplayAboutListener implements ActionListener {
			public void actionPerformed(ActionEvent e) {
				JEditorPane editorPane = new JEditorPane();
				editorPane.setEditable(false);
				try {
					editorPane.setPage("file:about.html");
					editorPane.setContentType("text/html");
					JScrollPane areaScrollPane = new JScrollPane(editorPane);
					areaScrollPane.setVerticalScrollBarPolicy(
						JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
					areaScrollPane.setPreferredSize(new Dimension(600, 650));
					JOptionPane.showMessageDialog(new JFrame(), areaScrollPane);
				} catch (IOException ioe) {
					JOptionPane.showMessageDialog(
						new JFrame(),
						"About not found.",
						"About...",
						JOptionPane.ERROR_MESSAGE);
				}
			}
		}

		
	}

	public static void main(String[] args) {
		Marshaller f = new Marshaller();
	}

}

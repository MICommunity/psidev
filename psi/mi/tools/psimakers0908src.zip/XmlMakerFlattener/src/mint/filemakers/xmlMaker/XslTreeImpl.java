/*
 * Created on 11 juil. 2003
 */

package mint.filemakers.xmlMaker;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.border.TitledBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.TreeNode;

import org.exolab.castor.xml.schema.Annotated;
import org.exolab.castor.xml.schema.Annotation;
import org.exolab.castor.xml.schema.AttributeDecl;
import org.exolab.castor.xml.schema.Documentation;
import org.exolab.castor.xml.schema.ElementDecl;
import org.exolab.castor.xml.schema.Structure;
import org.exolab.castor.xml.schema.XMLType;

/**
 * 
 * This class overides the abstract class AbstractXslTree
 * to provide a tree representation of a XML schema, with 
 * management of marshalling of several flat files to a xml file
 * that respects the schema
 * 
 * @author Arnaud Ceol, University of Rome "Tor Vergata", Mint group,
 * arnaud@cbm.bio.uniroma2.it 
 *
 */
public class XslTreeImpl
	extends mint.filemakers.xsd.AbstractXsdTree
	implements Serializable {

	public ArrayList getMenuItems() {
		ArrayList itemList = new ArrayList();
		JMenuItem save = new JMenuItem(new String("save"));
		JMenuItem load = new JMenuItem(new String("load"));
		save.addActionListener(new SaveListener());
		itemList.add(save);
		load.addActionListener(new LoadListener());
		itemList.add(load);
		return itemList;
	}

	public void load(ObjectInputStream ois) {
		try {
			String filePath = (String) ois.readObject();
			try {
				File file = new File(filePath);
				loadSchema(file);
				createTree();
			} catch (Exception ioe) {
				String fileName;
				if (filePath.lastIndexOf("/") >= 0)
					fileName =
						filePath.substring(filePath.lastIndexOf("/") + 1);
				else if (filePath.lastIndexOf("\\") >= 0)
					fileName =
						filePath.substring(filePath.lastIndexOf("\\") + 1);
				else
					fileName = filePath;

				JOptionPane.showMessageDialog(
						new JFrame(),
						"File not found: " + fileName,
						"[PSI makers]",
						JOptionPane.ERROR_MESSAGE);

				JEditorPane panel = new JEditorPane();
				panel.setEditable(false);
				panel.setText("file '" + fileName + "' not found:");
				JFileChooser fileChooser = new JFileChooser(".");
				fileChooser.setAccessory(panel);
				fileChooser.setDialogTitle(filePath + "not found");

				int returnVal = fileChooser.showOpenDialog(this);
				if (returnVal != JFileChooser.APPROVE_OPTION) {
					return;
				}

				loadSchema(fileChooser.getSelectedFile());
				createTree();
			}

			id = (String) ois.readObject();
			//			System.out.println("id: " + id);
			lastId = ois.readInt();

			/* expend choices */
			expendChoices = new ArrayList();
			int nb = ois.readInt(); /* number of associations */
			for (int i = 0; i < nb; i=i+2) {
				String path = (String) ois.readObject();
				String choice = (String) ois.readObject();
				expendChoices.add(path);
				expendChoices.add(choice);
				if (choice != null){
					 redoChoice(path, choice);
				}	else { /* duplication */
					 duplicateNode(getNodeByIndexes(path));
				}
			}
			
			
			/* associated fields */
			associatedFields = new HashMap();
			nb = ois.readInt(); /* number of associations */
			for (int i = 0; i < nb; i++) {
				XsdNode node = getNodeByIndexes((String) ois.readObject());
				String path = (String) ois.readObject();
				associatedFields.put(node, path);
				node.use();
			}

			/* associated values */
			associatedValues = new HashMap();
			nb = ois.readInt(); /* number of associations */
			for (int i = 0; i < nb; i++) {
				XsdNode node = getNodeByIndexes((String) ois.readObject());
				String value = (String) ois.readObject();
				associatedValues.put(node, value);
				node.useOnlyThis();
			}

			/* associated dictionnary */
			associatedDictionnary = new HashMap();
			nb = ois.readInt(); /* number of associations */
			for (int i = 0; i < nb; i++) {
				XsdNode node = getNodeByIndexes((String) ois.readObject());
				Integer index = (Integer) ois.readObject();
				associatedDictionnary.put(node, index);
			}

			/* associated dictionnary column */
			associatedDictionnaryColumn = new HashMap();
			nb = ois.readInt(); /* number of associations */
			for (int i = 0; i < nb; i++) {
				XsdNode node = getNodeByIndexes((String) ois.readObject());
				Integer index = (Integer) ois.readObject();
				associatedDictionnaryColumn.put(node, index);
			}

			/* associated autogeneration */
			associatedAutogeneration = new ArrayList();
			nb = ois.readInt(); /* number of associations */
			for (int i = 0; i < nb; i++) {
				XsdNode node = getNodeByIndexes((String) ois.readObject());
				associatedAutogeneration.add(node);
			}

			/* associated flatFile */
			associatedFlatFiles = new ArrayList();
			nb = ois.readInt(); /* number of associations */
			for (int i = 0; i < nb; i++) {
				//int index = ois.readInt();
				XsdNode node = getNodeByIndexes((String) ois.readObject());
				associatedFlatFiles.add(node);
				rootNode.use();
				flatFileTabbedPanel.setTabTitle(i, node.toString());
			}

			reload();
		} catch (ClassNotFoundException cnfe) {
			System.out.println("pb: " + cnfe);
			StackTraceElement[] s = cnfe.getStackTrace();
			for (int i = 0; i < s.length; i++) {
				System.out.println(s[i]);
			}
			System.out.println("failed to load schema.");
		} catch (IOException ioe) {
			System.out.println("pb: " + ioe);
			StackTraceElement[] s = ioe.getStackTrace();
			for (int i = 0; i < s.length; i++) {
				System.out.println(s[i]);
			}
			System.out.println("failed to load schema.");
		}
	}


	public void save(ObjectOutputStream oos) {
		if (schemaFile == null)
			return;
		try {

			String path = schemaFile.getPath();

			if (schemaFile != null) {
				oos.writeObject(path);
			} else {
				oos.writeObject(null);
			}

			oos.writeObject(id);
			oos.writeInt(lastId);

			/* expend choices */
			int nb = expendChoices.size();
			oos.writeInt(nb);
			for (int i = 0; i < nb; i=i+2) {
				path = (String) expendChoices.get(i);
				String value =  (String) expendChoices.get(i+1);
				oos.writeObject(path);
				oos.writeObject(value);
//				i++;
			}

			/* associated fields */
			nb = associatedFields.size();
			oos.writeInt(nb);
			Object[] keys = associatedFields.keySet().toArray();
			Object[] values = associatedFields.values().toArray();
			for (int i = 0; i < nb; i++) {
				oos.writeObject(getPathForNode((XsdNode) keys[i]));
				oos.writeObject((String) values[i]);
			}

			/* associated values */
			nb = associatedValues.size();
			oos.writeInt(nb);
			keys = associatedValues.keySet().toArray();
			values = associatedValues.values().toArray();
			for (int i = 0; i < nb; i++) {
				oos.writeObject(getPathForNode((XsdNode) keys[i]));
				oos.writeObject((String) values[i]);
			}

			/* associated dictionnary */
			nb = associatedDictionnary.size();
			oos.writeInt(nb);
			keys = associatedDictionnary.keySet().toArray();
			values = associatedDictionnary.values().toArray();
			for (int i = 0; i < nb; i++) {
				oos.writeObject(getPathForNode((XsdNode) keys[i]));
				oos.writeObject((Integer) values[i]);
			}

			/* associated dictionnary column */
			nb = associatedDictionnaryColumn.size();
			oos.writeInt(nb);
			keys = associatedDictionnaryColumn.keySet().toArray();
			values = associatedDictionnaryColumn.values().toArray();
			for (int i = 0; i < nb; i++) {
				oos.writeObject(getPathForNode((XsdNode) keys[i]));
				oos.writeObject(values[i]);
			}

			/* associated autogenerate */
			nb = associatedAutogeneration.size();
			oos.writeInt(nb);
			for (int i = 0; i < nb; i++) {
				oos.writeObject(
					getPathForNode((XsdNode) associatedAutogeneration.get(i)));
			}

			/* associated dictionnary */

			nb = associatedFlatFiles.size();
			oos.writeInt(nb);
			for (int i = 0; i < nb; i++) {
				//oos.writeInt(i);
				oos.writeObject(
					getPathForNode((XsdNode) associatedFlatFiles.get(i)));
			}

		} catch (IOException e) {
			System.out.println("pb: " + e);
			StackTraceElement[] s = e.getStackTrace();
			for (int i = 0; i < s.length; i++) {
				System.out.println(s[i]);
			}
			System.out.println("failed to save files");
		}
	}

	public String name = "";

	/** file for log messages */
	private File logoutFile;
	private PrintWriter logoutPrintWriter;

	/** id for autogeneration: type MINT-001 */
	private static String id = "ID";
	/** last id used */
	private static int lastId = 0;

	/** text area for warnings and error messages */
	//	JTextArea messagesTextArea = new JTextArea();

	/** keep references between an element and the column in the corresponding tab file */
	private HashMap associatedFields = new HashMap();
	/** keep current values for referenced fields */
	//private HashMap associatedFieldsValues = new HashMap();

	/** associate a default value to a node */
	private HashMap associatedValues = new HashMap();
	/** associate a list dictionnary value to a node */
	private HashMap associatedDictionnary = new HashMap();
	/** associate the index of the column containing the replacement value  
	 * (i.e. the postition of the definition on a line.) in the dictionnary 
	 * associated to a node. 
	 */
	private HashMap associatedDictionnaryColumn = new HashMap();
	/** list of the nodes for wich the value has to be generated */
	private ArrayList associatedAutogeneration = new ArrayList();
	/** list of the nodes at which are associated each flat file */
	private ArrayList associatedFlatFiles = new ArrayList();

	private static FlatFileTabbedPanel flatFileTabbedPanel;
	private static FlatFile curFlatFile = null;

	/** panel for dictionnaries */
	private static DictionnaryPanel dictionnaryPanel;

	/**
	 * create a new instance of XslTree
	 * The nodes will be automaticaly duplicated
	 * if the schema specify that more than one
	 * element of this type are mandatory 
	 */
	public XslTreeImpl() {
		super(true, true);

	}

	private ButtonGroup associationButtons;
	private JRadioButton fieldAssociation;
	private JRadioButton dictionnaryAssociation;
	private JRadioButton defaultAssociation;
	private JRadioButton autoGenerationAssociation;
	private JRadioButton flatFileAssociation;

	/**
	 * create a button panel that includes buttons for loading the schema,
	 * to associate a node to a flat file, a cell a default value or to specify
	 * that a value should be automaticaly generated, to get informations 
	 * about the node, print the XML file or just have a preview of it.
	 */
	protected Box getButtonPanel() {
		Box buttonsPanel = new Box(BoxLayout.Y_AXIS);

		Box treeBox = new Box(BoxLayout.Y_AXIS);
		treeBox.setBorder(new TitledBorder("Schema"));

		Box mappingBox = new Box(BoxLayout.Y_AXIS);
		mappingBox.setBorder(new TitledBorder("Mapping"));

		Box nodeBox = new Box(BoxLayout.Y_AXIS);
		nodeBox.setBorder(new TitledBorder("Node"));

		Box associationBox = new Box(BoxLayout.Y_AXIS);
		associationBox.setBorder(new TitledBorder("Associations"));

		Box outputBox = new Box(BoxLayout.Y_AXIS);
		outputBox.setBorder(new TitledBorder("Output"));

		/* add a button for loading a XML Schema */
		JButton loadFileb = new JButton("Open a schema");
		loadFileb.setMaximumSize(buttonsDimension);
		loadFileb.addActionListener(new LoadSchemaListener());

		JButton loadb = new JButton("Load");
		loadb.setMaximumSize(buttonsDimension);
		loadb.addActionListener(new LoadListener());

		JButton saveb = new JButton("Save");
		saveb.setMaximumSize(buttonsDimension);
		saveb.addActionListener(new SaveListener());

		JButton setIdb = new JButton("Set your prefix");
		setIdb.setMaximumSize(buttonsDimension);
		setIdb.addActionListener(new SetIdListener());

		/* add a button for duplicate a node (in case of lists) */
		JButton duplicateb = new JButton("Duplicate");
		duplicateb.setMaximumSize(buttonsDimension);
		duplicateb.addActionListener(new DuplicateListener());

		/* add a button for restauring original choice */
		JButton choiceb = new JButton("Restaure choice");
		choiceb.setMaximumSize(buttonsDimension);
		choiceb.addActionListener(new OriginalNodeListener());

		JButton infosb = new JButton("About the node");
		infosb.setMaximumSize(buttonsDimension);
		infosb.addActionListener(new InfosListener());

		JButton checkb = new JButton("Check");
		checkb.setMaximumSize(buttonsDimension);
		checkb.addActionListener(new CheckListener());

		JButton previewb = new JButton("Preview");
		previewb.setMaximumSize(buttonsDimension);
		previewb.addActionListener(new PreviewListener());

		JButton printb = new JButton("Print");
		printb.setMaximumSize(buttonsDimension);
		printb.addActionListener(new PrintListener());

		mappingBox.add(saveb);
		mappingBox.add(loadb);

		treeBox.add(loadFileb);
		treeBox.add(setIdb);
		treeBox.add(checkb);

		nodeBox.add(duplicateb);
		nodeBox.add(choiceb);
		nodeBox.add(infosb);

		outputBox.add(previewb);
		outputBox.add(printb);

		associationButtons = new ButtonGroup();

		fieldAssociation = new JRadioButton("to field");
		dictionnaryAssociation = new JRadioButton("to dictionnary");
		defaultAssociation = new JRadioButton("to default value");
		autoGenerationAssociation = new JRadioButton("to automatic value");
		flatFileAssociation = new JRadioButton("to flat file");

		associationButtons.add(flatFileAssociation);
		associationButtons.add(fieldAssociation);
		associationButtons.add(dictionnaryAssociation);
		associationButtons.add(defaultAssociation);
		associationButtons.add(autoGenerationAssociation);
		associationButtons.setSelected(flatFileAssociation.getModel(), true);

		JButton genericAssociationb = new JButton("Associate");
		genericAssociationb.setMaximumSize(buttonsDimension);
		genericAssociationb.addActionListener(new GenericAssociationListener());

		JButton genericCancelAssociationb = new JButton("Cancel association");
		genericCancelAssociationb.setMaximumSize(buttonsDimension);
		genericCancelAssociationb.addActionListener(
			new GenericCancelAssociationListener());

		associationBox.add(flatFileAssociation);
		associationBox.add(fieldAssociation);
		associationBox.add(dictionnaryAssociation);
		associationBox.add(defaultAssociation);
		associationBox.add(autoGenerationAssociation);
		associationBox.add(genericAssociationb);
		associationBox.add(genericCancelAssociationb);

		buttonsPanel.add(mappingBox);
		buttonsPanel.add(treeBox);
		buttonsPanel.add(nodeBox);
		buttonsPanel.add(associationBox);
		buttonsPanel.add(outputBox);

		return buttonsPanel;
	}

	/**
	 * this method should reinitialize every variable makin reference 
	 * to the actual tree, such as any <code>List</code> used to
	 * make associations to externals objects. 
	 * 
	 * reinitializes associations of nodes with columns, default values, 
	 * dictionnaries, autogeneration of value and associations to flat files
	 */
	protected void emptySelectionLists() {
		associatedFields = new HashMap();
		associatedValues = new HashMap();
		associatedDictionnary = new HashMap();
		associatedDictionnaryColumn = new HashMap();
		associatedAutogeneration = new ArrayList();
		associatedFlatFiles = new ArrayList();
	}

	/**
	 * associate this Panel to a list of dictionnaries
	 * @param d a DictionnaryPanel
	 */
	public void setDictionnaryPanel(DictionnaryPanel d) {
		dictionnaryPanel = d;
	}

	/**
	 * set the FlatFile in which getting the values
	 * @param f a FlatFile
	 */
	private void setCurrentTabFile(FlatFile f) {
		curFlatFile = f;
	}

	/**
	 * associate this Panel to a FlatFileTabbedPanel
	 * @param d a FlatFileTabbedPanel
	 */
	public void setTabFileTabbedPanel(FlatFileTabbedPanel panel) {
		flatFileTabbedPanel = panel;
	}

	/**
	 * Check if a path is not the subPath of another one
	 * @param path1
	 * @param path2
	 * @return
	 */
	private boolean areSubPaths(TreeNode[] path1, TreeNode[] path2) {
		int minLength;
		if (path1.length < path2.length)
			minLength = path1.length;
		else
			minLength = path2.length;

		for (int i = 0; i < minLength; i++) {
			if (path1[i] != path2[i])
				return true;
		}
		return false;
	}

	/**
	 * Check if the node has a root node for ancestor. It is usefull when associating a node
	 * to a flat file as two root nodes (nodes associated to a flat file) should not have 
	 * children in common
	 * @param node
	 * @return
	 */
	private boolean isChildOfRootPaths(XsdNode node) {
		TreeNode[] path = node.getPath();

		for (int i = 0; i < associatedFlatFiles.size(); i++) {
			if (associatedFlatFiles.get(i) != null
				&& !areSubPaths(path,
					((XsdNode) associatedFlatFiles.get(i)).getPath()))
				return false;
		}

		return true;
	}

	/**
	 * associate the node selected to the FlatFile selected in the associated FlatFileTabbedPanel.
	 *
	 */
	private void associateFlatFile(XsdNode node) {
		XsdNode previousAssociation = null;
		/* if the file was already associated, warn the user that all associations to this file will be lost */
		try {
			previousAssociation =
				(XsdNode) associatedFlatFiles.get(
					flatFileTabbedPanel.getSelectedIndex());
			if (previousAssociation != null) {
				int confirm =
					JOptionPane.showConfirmDialog(
						new JFrame(),
						"All associations done to this file will be lost. Do you want to continue?",
						"Associatation of a flat file",
						JOptionPane.YES_NO_OPTION);
				if (confirm != JOptionPane.YES_OPTION)
					return;
			}
		} catch (Exception e) {
			/* the file was not yet associated to any node, can go on */
		}

		/* the association has to be done on a node of type element */
		if (((Annotated) (node.getUserObject())).getStructureType()
			!= Structure.ELEMENT) {
			JOptionPane.showMessageDialog(
				new JFrame(),
				"the root node should be of type Element",
				"setting a root element",
				JOptionPane.ERROR_MESSAGE);
			return;
		}

		try {
			associatedFlatFiles.set(
				flatFileTabbedPanel.getSelectedIndex(),
				null);
		} catch (Exception e) {
			/* ok, no association yet */
		}

		/* the node can not have another rootNode as ancestor */
		if (!isChildOfRootPaths(node)) {
			JOptionPane.showMessageDialog(
				new JFrame(),
				"this node is on the pathway of another root node",
				"setting a root element",
				JOptionPane.ERROR_MESSAGE);
			return;
		}

		/* remove all associations to this file */
		Iterator keyIterator = associatedFields.keySet().iterator();
		while (keyIterator.hasNext()) {
			Object key = keyIterator.next();
			String value = (String) associatedFields.get(key);
			if (value
				.substring(0, value.indexOf("."))
				.compareTo(
					String.valueOf(flatFileTabbedPanel.getSelectedIndex()))
				== 0) {
				associatedFields.remove(key);
			}
		}

		check((XsdNode) treeModel.getRoot());
		if (previousAssociation != null)
			treeModel.reload(previousAssociation);

		for (int i = associatedFlatFiles.size();
			i <= flatFileTabbedPanel.getSelectedIndex();
			i++) {
			associatedFlatFiles.add(null);
		}
		associatedFlatFiles.set(flatFileTabbedPanel.getSelectedIndex(), node);
		/* root node is mandatory */
		rootNode.use();
		flatFileTabbedPanel.setTabTitle(
			flatFileTabbedPanel.getSelectedIndex(),
			node.toString());
	}

	/**
	 * associate a default value to the node selected
	*/
	private void associateDefaultValue(XsdNode node) {

		String value;
		if (hasDefaultValue(node)) {
			value =
				(String) JOptionPane.showInputDialog(
					new JFrame(),
					"Enter a default value, \n",
					(String) associatedValues.get(node));
		} else {
			value =
				(String) JOptionPane.showInputDialog(
					new JFrame(),
					"Enter a default value, \n");
		}

		if (value != null) {
			if (((Annotated) (node.getUserObject())).getStructureType()
				!= Structure.ELEMENT
				&& ((Annotated) (node.getUserObject())).getStructureType()
					!= Structure.ATTRIBUTE) {
				JOptionPane.showMessageDialog(
					new JFrame(),
					"a value can only be associated with an node of type element or attribute",
					"associating a value",
					JOptionPane.ERROR_MESSAGE);
				return;

			}

			cancelAllAssociations(node);

			associatedValues.put(node, value);
			// change for ignoring elemts if only default values
			node.useOnlyThis();
			check((XsdNode) treeModel.getRoot());
			treeModel.reload(node);
		}
	}

	/**
	 * associate a dictionnary to the node selected.
	 * Each time a value will be requested for this node, 
	 * it will be changed for its replacement value in target list
	 * if it exists
	 * @param value the value
	 */
	private void associateDictionnary(XsdNode node) {

		int dictionnary = dictionnaryPanel.getSelectedDictionnary();

		if (dictionnary == -1) { // no selection
			displayMessage("No dictonnary selected", "[XML maker]");
			return;
		}

		if (dictionnaryPanel.getExampleList().length == 0) { // no selection
			displayMessage(
				"This dictionnary does not contain any value,"
					+ " maybe the separator has not been set properly.",
				"[XML maker]");
			return;
		}

		AssociateDictionnaryListPanel adp = new AssociateDictionnaryListPanel();
		int confirm =
			JOptionPane.showConfirmDialog(
				null,
				adp,
				"[XML maker] load dictionnary",
				JOptionPane.OK_CANCEL_OPTION,
				JOptionPane.QUESTION_MESSAGE);

		if (confirm != JOptionPane.OK_OPTION)
			return;

		if (node == null) {
			displayMessage("No node selected", "[XML maker]");
			return;
		}

		associatedDictionnary.put(node, new Integer(dictionnary));
		associatedDictionnaryColumn.put(node, new Integer(adp.getColumn()));
	}

	private class AssociateDictionnaryListPanel extends JPanel {
		int column;
		JList list;
		public int getColumn() {
			return column;
		}

		public AssociateDictionnaryListPanel() {
			super();
			setLayout(new BorderLayout());

			list = new JList(dictionnaryPanel.getExampleList());
			JScrollPane scrollList = new JScrollPane(list);
			list.addListSelectionListener(new SetColumnlistener());
			add(
				new JLabel("Select the field that contains the definition and press OK:"),
				BorderLayout.NORTH);
			add(scrollList, BorderLayout.CENTER);

		}

		private class SetColumnlistener implements ListSelectionListener {
			public void valueChanged(ListSelectionEvent e) {
				column = list.getSelectedIndex();
			}
		}
	}

	/**
	 * associate the node selected to a cell by its pat representation
	 *
	 */
	private void associateField(XsdNode node, String path) {

		/* check if a cell is selected */
		if (path.endsWith("-1")) {
			displayMessage("no cell selected", "[XML maker]");
			return;
		}

		/* check if a node is selected */
		if (node == null) {
			displayMessage("no node selected", "[XML maker]");
			return;
		}

		/* check is the file is associated to a node */
		try {
			if (associatedFlatFiles
				.get(Integer.parseInt(path.substring(0, path.indexOf("."))))
				== null) {
				displayMessage(
					"Target flat file is not yet associated to a node.\n "
						+ "You have to associate each file to a node before associating a cell to a node.\n"
						+ "e.g. : associate a file containing on each line the description of an interaction to a node named interactionList.",
					"[XML maker]");
				return;
			}

			if (!node
				.isNodeAncestor(
					(XsdNode) associatedFlatFiles.get(
						Integer.parseInt(
							path.substring(0, path.indexOf(".")))))) {
				displayMessage(
					"Fields from this file have to be descendants from "
						+ ((XsdNode) associatedFlatFiles
							.get(
								Integer.parseInt(
									path.substring(0, path.indexOf(".")))))
							.toString(),
					"[XML maker]");
				return;
			}

		} catch (IndexOutOfBoundsException e) {
			displayMessage(
				"Target flat file is not yet associated to a node. "
					+ "You have to associate each file to a node before associating a cell to a node."
					+ "e.g. : associate a file containing on each line the description of an interaction to a node named interactionList.",
				"[XML maker]");
			return;
		}

		if (((Annotated) (node.getUserObject())).getStructureType()
			!= Structure.ELEMENT
			&& ((Annotated) (node.getUserObject())).getStructureType()
				!= Structure.ATTRIBUTE) {
			JOptionPane.showMessageDialog(
				new JFrame(),
				"a value can only be associated with an node of type element or attribute",
				"associating a value",
				JOptionPane.ERROR_MESSAGE);

			return;
		}

		cancelAllAssociations(node);

		boolean error = false;
		associatedFields.put(node, path);
		node.use();
		check((XsdNode) treeModel.getRoot());
		treeModel.reload(node);
	}

	/**
	 * removes the association of the node selected with a dictionnary
	 */
	private void cancelAssociateDictionnary(XsdNode node) {
		associatedDictionnary.remove(node);
		associatedDictionnaryColumn.remove(node);
	}

	/**
	 * removes the association of the node selected with a cell
	 */
	private void cancelAssociateField(XsdNode node) {
		if (!associatedFields.containsKey(node))
			return;

		associatedFields.remove(node);
		node.unuse();
		check((XsdNode) treeModel.getRoot());
		treeModel.reload(node);
	}

	/**
	 * removes the association of the node selected with any default value
	 */
	private void cancelDefaultValue(XsdNode node) {
		if (!associatedValues.containsKey(node))
			return;

		associatedValues.remove(node);
		node.unuseOnlyThis();
		check((XsdNode) treeModel.getRoot());
		treeModel.reload(node);
	}

	/**
	 * checks if the node is associated to a default value
	 * @param node a node
	 * @return true if  such an association exists
	 */
	private boolean hasDefaultValue(XsdNode node) {
		return associatedValues.containsKey(node);
	}

	/**
	 * checks if the node is associated to a cell
	 * @param node a node
	 * @return true if  such an association exists
	 */
	private boolean isAffected(XsdNode node) {
		return associatedFields.containsKey(node);
	}

	/**
	 * get the value for a node
	 * @param node a node
	 * @return the value in the field associated to this node if the association exists 
	 * (eventually replaced by a replacement value in a dictionnary), if not a automaticaly 
	 * generated value if the node has been setted to request one, if not the default value
	 * if one has been associated to the node. Else return null 
	 */
	private String getValue(XsdNode node) {
		/* node affected to a field */
		if (isAffected(node)) {
			String value =
				flatFileTabbedPanel.getValue(
					(String) associatedFields.get(node));

			if (value == null || value.length() == 0) {
				return null;
			}

			if (associatedDictionnary.containsKey(node)) {
				String replacementValue =
					dictionnaryPanel.getReplacementValue(
						((Integer) associatedDictionnary.get(node)).intValue(),
						value,
						((Integer) associatedDictionnaryColumn.get(node))
							.intValue());

				if (replacementValue == null
					|| replacementValue.length() == 0) {
					return null;
				}
				return getXmlValue(replacementValue);
			}
			return getXmlValue(value);
		}

		/* node with value autogenerated */
		if (associatedAutogeneration.contains(node)) {
			String value = id + "-" + lastId;
			lastId++;
			return getXmlValue(value);
		}

		/* node with default value */
		if (hasDefaultValue(node)) {
			return getXmlValue((String) associatedValues.get(node));
		}
		return null;
	}

	/**
	 * return a new String where specials characters are protected
	 */
	private String getXmlValue(String value) {
		return value
			.replaceAll("&", "&amp;")
			.replaceAll("<", "&lt;")
			.replaceAll(">", "&gt;")
			.replaceAll("\"", "&apos;")
			.replaceAll("\'", "&quot;");
	}

	/**
	 * get informations about the node in an understandable String
	 */
	protected String getInfos(XsdNode node) {
		if (node == null)
			return "No node selected!";

		String infos = super.getInfos(node);
		// column associated
		String field = (String) associatedFields.get(node);
		if (field != null) {
			infos += "associated field: "
				+ "file: "
				+ ((FlatFile) flatFileTabbedPanel
					.getTabFileByIndex(
						Integer.parseInt(
							field.substring(0, field.indexOf(".")))))
					.getFileName()
				+ ", field: "
				+ field.substring(field.indexOf(".") + 1)
				+ "\n";
		}
		// default value
		if (hasDefaultValue(node)) {
			infos += "associated value: " + associatedValues.get(node) + "\n";
		}
		// dictionnary
		if (associatedDictionnary.containsKey(node)) {
			infos += "find replacement value in dictionnary: "
				+ dictionnaryPanel.getName(
					((Integer) associatedDictionnary.get(node)).intValue())
				+ "\n";
		}
		if (associatedAutogeneration.contains(node)) {
			infos += "A value will be automaticaly generated for this node.";
		}
		return infos;
	}

	/**
		* check if these are enough associations according to the shema
		* 
		* condition for being  "checkedOK":
		* attributes: if is associated to a value  or not required
		* simpleType elements: if is associated to a value
		* element, complex type: if all sub Elements are checkedOk
		* group: if the count of subElements "checkedOk" is good
		* 
		* condition for errors: elements or group is not "checkedOk"
		*  
		*/
	protected ArrayList check(XsdNode node) {

		ArrayList errorMessages = new ArrayList();

		switch (((Annotated) node.getUserObject()).getStructureType()) {

			case Structure.ATTRIBUTE :
				errorMessages = checkAttribute(node);
				break;
			case Structure.ELEMENT :
				errorMessages = checkElement(node);
				break;
			case Structure.GROUP :
				errorMessages = checkGroup(node);
				break;
			default :
				System.out.println(
					"not found type"
						+ ((Annotated) node.getUserObject()).getStructureType());
		}
		return errorMessages;
	}

	private ArrayList checkAttribute(XsdNode node) {
		ArrayList errorMessages = new ArrayList();
		if (node.isRequired
			&& !isAffected(node)
			&& !hasDefaultValue(node)
			&& !associatedAutogeneration.contains(node)) {
			errorMessages.add(
				printPath(node.getPath()) + "ERROR: cannot be empty");
			node.isCheckedOk = false;
		} else {
			node.isCheckedOk = true;
		}
		return errorMessages;
	}

	private ArrayList checkElement(XsdNode node) {
		ArrayList errorMessages = new ArrayList();

		if (!node.isUsed && !node.isRequired) {
			node.isCheckedOk = true;
			return errorMessages;
		}

		XMLType type = ((ElementDecl) node.getUserObject()).getType();

		/* simpleType */
		if (type.isSimpleType()) {
			if (node.isRequired
				&& !isAffected(node)
				&& !hasDefaultValue(node)
				&& !associatedAutogeneration.contains(node)) {
				errorMessages.add(
					printPath(node.getPath()) + "ERROR: cannot be empty");
				node.isCheckedOk = false;
			} else {
				node.isCheckedOk = true;
			}
		} else { /* complexType, ie: attributes + group */

			boolean errors = false;
			/* check if number of subelts is correct */
			HashMap maxOccurs = new HashMap();
			HashMap minOccurs = new HashMap();

			Enumeration children = node.children();

			while (children.hasMoreElements()) {
				XsdNode child = (XsdNode) children.nextElement();
				ArrayList subMessages = check(child);

				switch (((Annotated) child.getUserObject())
					.getStructureType()) {
					case Structure.ATTRIBUTE :
						if (subMessages.size() != 0)
							errors = true;
						for (int i = 0; i < subMessages.size(); i++) {
							errorMessages.add(subMessages.get(i));
						}
						break;
					case Structure.GROUP :
						if (subMessages.size() != 0)
							errors = true;
						for (int i = 0; i < subMessages.size(); i++) {
							errorMessages.add(subMessages.get(i));
						}
						break;
					case Structure.ELEMENT :

						/* initialisation if first occurence of the element */
						if (!maxOccurs.containsKey(child.toString())) {
							int max = child.max;
							if (max != -1) {
								maxOccurs.put(
									child.toString(),
									new Integer(max));
							} else {
								maxOccurs.put(child.toString(), "UNBOUNDED");
							}
							minOccurs.put(
								child.toString(),
								new Integer(child.min));
						}

						for (int i = 0; i < subMessages.size(); i++) {
							errorMessages.add(subMessages.get(i));
						}

						if (child.isCheckedOk) {
							try {
								maxOccurs.put(
									child.toString(),
									new Integer(
										((Integer) maxOccurs
											.get(child.toString()))
											.intValue()
											- 1));
							} catch (ClassCastException e) {
								/* ok, max is unbounded and exception is throws when trying to cast String to Integer */
							}
							minOccurs.put(
								child.toString(),
								new Integer(
									((Integer) minOccurs.get(child.toString()))
										.intValue()
										- 1));
						}
				}
			}

			Iterator names = minOccurs.keySet().iterator();

			Iterator mins = minOccurs.values().iterator();
			Iterator maxs = maxOccurs.values().iterator();
			while (names.hasNext()) {
				String name = (String) names.next();
				// if a min is > 0, it means that an element is missing
				if (((Integer) mins.next()).intValue() > 0) {
					errorMessages.add(
						printPath(node.getPath())
							+ "ERROR: a "
							+ name
							+ " is missing");
					errors = true;
				}

				/* if a max is < 0, it means there are too much elements */
				try {
					if (((Integer) maxs.next()).intValue() < 0) {
						errorMessages.add(
							printPath(node.getPath())
								+ " ERROR: a "
								+ name
								+ " should be removed");
						errors = true;
					}

				} catch (ClassCastException e) {
					/* ok, max is unbounded and exception is throws when trying to cast String to Integer */
				}
			}

			node.isCheckedOk = !errors;
		}
		return errorMessages;
	}

	/* 
		* a group can only be a choice (else it would be expanded 
		* if we find it, it means user has to make a choice
		*/
	private ArrayList checkGroup(XsdNode node) {
		ArrayList errorMessages = new ArrayList();

		errorMessages.add(
			printPath(node.getPath())
				+ ": WARNING: maybe something is missing.");

		return errorMessages;
	}

	/**
	 * return XML code to close the element
	 * @param node a node
	 * @param isEmptyElement if the node does not have neither attribute nor value or sub elements
	 * @return XML code
	 */
	private String closeElement(XsdNode node, boolean isEmptyElement) {
		if (isEmptyElement)
			return "";
		return "</" + node.toString() + ">";
	}

	/**
	 * write the XML code to close the element
	 * @param node a node
	 * @param isEmptyElement if the node does not have neither attribute nor value or sub elements
	 * @param out the writer used to write the code
	 */
	private void closeElement(XsdNode node, boolean isEmptyElement, Writer out)
		throws IOException {
		if (isEmptyElement)
			return;
		out.write("</" + node.toString() + ">");
	}

	/**
	 * write the whole XML file 
	 * @param out the writer used to write the file
	 * @throws IOException
	 */
	public void marshall(Writer out) throws IOException {
		marshallNode((XsdNode) treeModel.getRoot(), out);
	}

	private class DisplayMessagesListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			JEditorPane editorPane = new JEditorPane();
			editorPane.setEditable(false);
			try {
				editorPane.setPage(logoutFile.toURL());

				JScrollPane areaScrollPane = new JScrollPane(editorPane);
				areaScrollPane.setVerticalScrollBarPolicy(
					JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
				areaScrollPane.setPreferredSize(new Dimension(600, 650));
				JOptionPane.showMessageDialog(new JFrame(), areaScrollPane);
			} catch (IOException ioe) {
				JOptionPane.showMessageDialog(
					new JFrame(),
					"Documentation not found.",
					"Documentation",
					JOptionPane.ERROR_MESSAGE);
			}
		}
	}

	private void logoutPrintErrors(XsdNode node) {
		if (!node.isRequired)
			return;

		String errorType;
		if (node.isRequired)
			errorType = "[ERROR]";
		else
			errorType = "[WARNING]";

		switch (((Annotated) node.getUserObject()).getStructureType()) {
			case Structure.ATTRIBUTE :
				if (!node.isCheckedOk) {
					logoutPrintWriter.write(
						"\n 	"
							+ errorType
							+ " in element "
							+ printPath(node.getPath()));
					logoutPrintWriter.write(
						"\n 	"
							+ errorType
							+ " attribute "
							+ node.toString()
							+ " ignored ("
							+ getNodeProblem(node)
							+ ")");
				}
				break;
			case Structure.ELEMENT :
				XMLType type = ((ElementDecl) node.getUserObject()).getType();
				/* simpleType */
				if (type.isSimpleType()) {
					if (!node.isCheckedOk) {
						logoutPrintWriter.write(
							"\n 	"
								+ errorType
								+ " in element "
								+ printPath(node.getPath()));
						logoutPrintWriter.write(
							"\n	"
								+ errorType
								+ " element "
								+ node.toString()
								+ " ignored ("
								+ getNodeProblem(node)
								+ ")");
					}
				} else { /* complex type: go deeper */
					Enumeration children = node.children();

					while (children.hasMoreElements()) {
						logoutPrintErrors((XsdNode) children.nextElement());
					}
				}
				break;
			case Structure.GROUP :
				logoutPrintWriter.write(
					"	[WARNING] maybe something is missing in  "
						+ node.toString()
						+ " (you have to click on the node and make a choice).\n");
				break;
			default :
				System.out.println(
					"type not found "
						+ ((Annotated) node.getUserObject()).getStructureType());
				node.isCheckedOk = false;
		}
	}

	/**
	 * write the XML code for a node
	 * @param node the node to marshall  
	 * @param out the writer used to write the file
	 * @throws IOException
	 */
	public void marshall(XsdNode node, Writer out) throws IOException {
		lastId = 0;
		marshallNode(node, out);

		/* to reinitialize the display */
		check(node);
	}

	private void marshallAttribute(XsdNode node, Writer out)
		throws IOException {

		if (!node.isUsed)
			return;

		if (!node.isCheckedOk && node.isRequired) {
			return;
		}

		String value = getValue(node);

		if (value == null || value.length() == 0) {
			return;
		}

		out.write(
			" "
				+ ((AttributeDecl) node.getUserObject()).getName()
				+ "=\""
				+ value
				+ "\"");
	}

	private void marshallElement(XsdNode node, Writer out) throws IOException {
		if (!node.isUsed || !node.isCheckedOk)
			return;

		/* a root node */
		for (int i = 0; i < associatedFlatFiles.size(); i++) {
			if (((XsdNode) associatedFlatFiles.get(i)) == node) {
				curFlatFile =
					flatFileTabbedPanel.getTabFileByIndex(
						associatedFlatFiles.indexOf(node));
				marshallFlatFileElement(node, out);
				return;
			}
		}

		ArrayList attributeList = new ArrayList();
		ArrayList elementList = new ArrayList();
		ArrayList groupList = new ArrayList();
		String value = null;

		/*
		 *  get every childs of the node
		 * get the structureType of the userElement 
		 * and use the apropriate marshaller
		 */
		Enumeration children = node.children();
		while (children.hasMoreElements()) {
			XsdNode child = (XsdNode) children.nextElement();

			switch (((Annotated) child.getUserObject()).getStructureType()) {
				case Structure.ATTRIBUTE :
					attributeList.add(child);
					break;
				case Structure.ELEMENT :
					if (child.isUsed)
						elementList.add(child);
					break;
				case Structure.GROUP :
					if (child.isUsed)
						groupList.add(child);
					break;
			}
		}

		/* get the value affected to this element */
		value = getValue(node);

		boolean isEmptyElement =
			((value == null || value.length() == 0)
				&& elementList.size() == 0
				&& groupList.size() == 0);

		openElement(node, attributeList, isEmptyElement, out);
		if (value != null && value.length() > 0)
			out.write(value);
		for (int i = 0; i < elementList.size(); i++)
			marshallElement((XsdNode) elementList.get(i), out);
		for (int i = 0; i < groupList.size(); i++)
			marshallGroup((XsdNode) groupList.get(i), out);

		if (elementList.size() != 0 || groupList.size() != 0) {
			out.write("\n");
		}
		closeElement(node, isEmptyElement, out);

	}

	private void marshallGroup(XsdNode node, Writer out) throws IOException {

		Enumeration elements = node.children();
		while (elements.hasMoreElements()) {
			marshallNode((XsdNode) elements.nextElement(), out);
		}
	}

	private void marshallNode(XsdNode node, Writer out) throws IOException {
		if (!node.isUsed || !node.isCheckedOk)
			return;

		switch (((Annotated) node.getUserObject()).getStructureType()) {
			case Structure.ATTRIBUTE :
				marshallAttribute(node, out);
				break;
			case Structure.GROUP :
				if (!node.isUsed) {
					return;
				}
				marshallGroup(node, out);
				break;
			case Structure.ELEMENT :
				if (!node.isUsed) {
					return;
				}
				marshallElement(node, out);
				break;
			default :
				out.write("<error: unmanaged element/>");
		}
	}

	private void marshallFlatFileElement(XsdNode node, Writer out)
		throws IOException {
		ArrayList attributeList = new ArrayList();
		ArrayList elementList = new ArrayList();
		ArrayList groupList = new ArrayList();
		String value = null;

		try {
			logoutPrintWriter.write(
				"\n\n-------------- Marshalling for file:  "
					+ curFlatFile.getFileName()
					+ " --------------------------------------\n");
		} catch (NullPointerException e) { /* out of a file */
			logoutPrintWriter.write(
				"\n\n-------------- no file --------------------------------------\n");
		}

		/* get every childs of the node
		 get the structureType of the userElement 
		 and use the apropriate marshaller
		*/
		Enumeration children = node.children();
		while (children.hasMoreElements()) {
			XsdNode child = (XsdNode) children.nextElement();

			switch (((Annotated) child.getUserObject()).getStructureType()) {
				case Structure.ATTRIBUTE :
					if (child.isUsed)
						attributeList.add(child);
					break;
				case Structure.ELEMENT :
					if (child.isUsed)
						elementList.add(child);
					break;
				case Structure.GROUP :
					if (child.isUsed)
						groupList.add(child);
					break;
			}
		}

		/* get the value affected to this element */

		value = getValue(node);

		boolean isEmptyElement =
			(value == null && elementList.size() == 0 && groupList.size() == 0);

		openElement(node, attributeList, isEmptyElement, out);
		if (value != null) {
			out.write(value);
		}

		/* for each line */
		boolean endOfFile = false;
		curFlatFile.restartFile();

		/* if the first line contains title, pass througth it */
		if (curFlatFile.firstLineForTitles()) {
			curFlatFile.nextLine();
		}
		int lineNumber = 0;

		while (!endOfFile) {
			try { /* get each line */

				if (!curFlatFile.hasLine()) {
					throw new IOException("!curFlatFile.hasLine()");
				}
				marshallingCheck(node);

				/* marshall the line */
				for (int i = 0; i < elementList.size(); i++)
					marshallElement((XsdNode) elementList.get(i), out);
				for (int i = 0; i < groupList.size(); i++)
					marshallGroup((XsdNode) groupList.get(i), out);

				/* get warnings for empty fields and unfound replacement values */
				String emptyFields = "";
				String unfound = "";
				String unmarshallableElements = "";
				Iterator fieldsIt = associatedFields.keySet().iterator();
				while (fieldsIt.hasNext()) {
					XsdNode key = (XsdNode) fieldsIt.next();

					String path = ((String) associatedFields.get(key));

					String fieldValue = flatFileTabbedPanel.getValue(path);

					if (key.isNodeAncestor(node)) {
						/* only node that requires fields from current file */
						if (fieldValue == null || fieldValue.length() == 0) {
							emptyFields
								+= path.substring(path.indexOf(".") + 1)
								+ ", ";
							unmarshallableElements += key.toString() + ", ";
						} else {
							if (associatedDictionnary.containsKey(key)) {
								String replacementValue =
									dictionnaryPanel.getReplacementValue(
										((Integer) associatedDictionnary
											.get(key))
											.intValue(),
										fieldValue,
										((Integer) associatedDictionnaryColumn
											.get(key))
											.intValue());

								if (replacementValue == null
									|| replacementValue.length() == 0) {
									unfound += fieldValue + ", ";
									unmarshallableElements += key.toString()
										+ ", ";
								}
							}
						}
					}
				}

				if (!node.isCheckedOk
					|| emptyFields.length() > 0
					|| unfound.length() > 0) {
					logoutPrintWriter.write(
						"\n[line " + curFlatFile.getLineNumber() + "]");
					logoutPrintWriter.write(
						"\n	" + curFlatFile.getFieldsIndex());
					logoutPrintWriter.write(
						"\n	" + curFlatFile.getCurLine());
					if (emptyFields.length() > 0) {
						logoutPrintWriter.write(
							"\n	[Warning: empty fields] ");
						logoutPrintWriter.write(emptyFields);
					}
					if (unfound.length() > 0) {
						logoutPrintWriter.write(
							"\n	[Warning: dictionnary] no replacement value found for: ");
						logoutPrintWriter.write(unfound);
					}
					if (unmarshallableElements.length() > 0) {
						logoutPrintWriter.write(
							"\n	[Warning] following elements will not be marshalled:\n	");
						logoutPrintWriter.write(unmarshallableElements);
					}
					if (!node.isCheckedOk) {
						logoutPrintErrors(node);
						logoutPrintWriter.write(
							"\n[ERROR] line  "
								+ curFlatFile.getLineNumber()
								+ " ignored.");
					}
				}
				check(node);
				curFlatFile.nextLine();
			} catch (IOException e) { /* end of the file */
				endOfFile = true;
				curFlatFile.restartFile();

			} catch (Exception e) {
				endOfFile = true;
				curFlatFile.restartFile();
			}
		}

		if (elementList.size() == 0 && groupList.size() == 0) {
			out.write("\n");
		}

		closeElement(node, isEmptyElement, out);

	}

	/**
	 * write XML code to open the element
	 * @param out the writer used to write the code
	 * @param node a node
	 * @param isEmptyElement if the node does not have neither attribute nor value or sub elements
	 * @param attributes a string containing the XML code for the attributes of this element
	 */
	private void openElement(
		XsdNode node,
		ArrayList attributes,
		boolean isEmptyElement,
		Writer out)
		throws IOException {
		/* open */
		out.write("\n<" + node.toString());

		/* if root node of the tree */
		if (node == rootNode) {
			out.write(" xmlns=\"" + schema.getTargetNamespace() + "\" ");
			out.write(
				"xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" ");
		}

		/* attributes */
		for (int i = 0; i < attributes.size(); i++)
			marshallAttribute((XsdNode) attributes.get(i), out);

		if (isEmptyElement)
			out.write(" />");
		else
			out.write(">");
	}

	/**
	 * return XML code to open the element
	 * @param node a node
	 * @param isEmptyElement if the node does not have neither attribute nor value or sub elements
	 * @param attributes a string containing the XML code for the attributes of this element
	 * @return the XML code for the element
	 */
	private String openElement(
		XsdNode node,
		String attributes,
		boolean isEmptyElement) {
		if (isEmptyElement)
			return "\n<" + node.toString() + attributes + "/>";
		return "\n<" + node.toString() + " " + attributes + ">";
	}

	/**
	 * get a preview of the XML file with only data taken 
	 * from one line in flat files
	 * @return xml code for this preview
	 */
	public String preview() {
		return previewNode((XsdNode) treeModel.getRoot());
	}

	public String preview(XsdNode node) {
		return previewNode(node);
	}

	private String previewAttribute(XsdNode node) {
		String value = getValue(node);

		if (value != null)
			return " "
				+ ((AttributeDecl) node.getUserObject()).getName()
				+ "=\""
				+ value
				+ "\"";
		else
			return null;

	}

	private String previewElement(XsdNode node) {

		if (!node.isUsed)
			return null;

		String attributes = "";
		String elements = "";
		String value;
		/* 
		 * get every childs of the node
		 * get the structureType of the userElement 
		 * and use the apropriate marshaller
		*/
		Enumeration children = node.children();
		while (children.hasMoreElements()) {
			XsdNode child = (XsdNode) children.nextElement();
			switch (((Annotated) child.getUserObject()).getStructureType()) {
				case Structure.ATTRIBUTE :
					String attribute = previewAttribute(child);
					if (attribute != null)
						attributes += attribute;
					break;
				case Structure.ELEMENT :
					String element = previewElement(child);
					if (element != null)
						elements += element;
					break;
				case Structure.GROUP :
					String group;
					group = previewGroup(child);
					if (group != null)
						elements += group;
					break;
			}
		} /* get the value affected to this element */
		value = getValue(node);

		boolean isEmptyElement = (value == null && elements.length() == 0);
		if (elements.length() != 0)
			elements = elements + "\n";
		if (attributes.length() == 0 && isEmptyElement)
			return null;

		if (value == null)
			value = "";

		return openElement(node, attributes, isEmptyElement)
			+ value
			+ elements
			+ closeElement(node, isEmptyElement);
	}

	private String previewGroup(XsdNode node) {

		String group = "";
		Enumeration elements = node.children();
		while (elements.hasMoreElements()) {
			String element = previewNode((XsdNode) elements.nextElement());
			if (element != null)
				group += element;
		}
		return group;
	}

	private String previewNode(XsdNode node) {
		switch (((Annotated) node.getUserObject()).getStructureType()) {
			case Structure.ATTRIBUTE :
				return previewAttribute(node);
			case Structure.GROUP :
				return previewGroup(node);
			case Structure.ELEMENT :
				return previewElement(node);
			default :
				return "<error: unmanaged elementt/>";
		}
	}

	/**
	 * used to displayed in a panel 
	 * an overview of problem found
	 */
	public class CheckListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			XsdNode node = (XsdNode) treeModel.getRoot();
			String errors;

			if (node == null) {
				errors = "No schema loaded!";
			} else {
				ArrayList paths = check(node);
				errors = paths.size() + " errors found: \n";
				for (int i = 0; i < paths.size(); i++) {
					errors += paths.get(i) + "\n";
				}
			}

			JEditorPane editorPane = new JEditorPane();
			editorPane.setEditable(false);
			editorPane.setText(errors);

			JScrollPane areaScrollPane = new JScrollPane(editorPane);
			areaScrollPane.setVerticalScrollBarPolicy(
				JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
			areaScrollPane.setPreferredSize(new Dimension(500, 500));
			JFrame message = new JFrame();
			message.setResizable(true);
			//			JOptionPane.showMessageDialog(message, areaScrollPane);
			JFrame frame = new JFrame();
			frame.setSize(400, 300);
			frame.getContentPane().add(areaScrollPane);
			frame.show();

		}
	}

	/**
	 * used to display in a new panel 
	 * informations about the node selected
	 */
	public class InfosListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			XsdNode node = (XsdNode) tree.getLastSelectedPathComponent();

			if (node == null) {
				displayMessage("No node selected", "[XML maker]");
				return;
			}

			JEditorPane editorPane = new JEditorPane();
			editorPane.setEditable(false);
			editorPane.setText(name + "\n\n" + getInfos(node));

			JScrollPane scrollPane = new JScrollPane(editorPane);
			scrollPane.setVerticalScrollBarPolicy(
				JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

			JFrame frame = new JFrame();
			frame.setSize(400, 300);
			frame.getContentPane().add(scrollPane);
			frame.show();
		}
	}

	/** used  for loading the schema */
	public class LoadSchemaListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			loadSchema();
		}
	}

	public class SaveListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			try {
				JFileChooser fc = new JFileChooser(".");

				int returnVal = fc.showOpenDialog(new JFrame());
				if (returnVal != JFileChooser.APPROVE_OPTION) {
					return;
				}

				FileOutputStream fos =
					new FileOutputStream(fc.getSelectedFile());
				ObjectOutputStream oos = new ObjectOutputStream(fos);
				//			oos.writeObject(treePanel);
				//			oos.writeObject(treePanel.tree);
				flatFileTabbedPanel.save(oos);
				dictionnaryPanel.save(oos);
				save(oos);
				oos.close();
				fos.close();
			} catch (FileNotFoundException fe) {
				JOptionPane.showMessageDialog(
					new JFrame(),
					"Unable to load file",
					"[PSI makers: PSI maker] load dictionnary",
					JOptionPane.ERROR_MESSAGE);
			} catch (Exception ex) {
				System.out.println("pb: " + ex);
				StackTraceElement[] s = ex.getStackTrace();
				for (int i = 0; i < s.length; i++) {
					System.out.println(s[i]);
				}
			}
		}
	}

	public class LoadListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			try {
				JFileChooser fc = new JFileChooser(".");

				int returnVal = fc.showOpenDialog(new JFrame());
				if (returnVal != JFileChooser.APPROVE_OPTION) {
					return;
				}

				FileInputStream fis = new FileInputStream(fc.getSelectedFile());
				ObjectInputStream ois = new ObjectInputStream(fis);
				flatFileTabbedPanel.load(ois);
				dictionnaryPanel.load(ois);
				load(ois);
				//treePanel.loadFileb.doClick();
				//setTabFileTabbedPanel(flatFileTabbedPanel);
				//setDictionnaryPanel(dictionnaryLists);
				ois.close();
				fis.close();
			} catch (FileNotFoundException fe) {
				JOptionPane.showMessageDialog(
					new JFrame(),
					"Unable to load file",
					"[PSI makers: PSI maker] load dictionnary",
					JOptionPane.ERROR_MESSAGE);
			} catch (Exception ex) {
				System.out.println("pb: " + ex);
				StackTraceElement[] s = ex.getStackTrace();
				for (int i = 0; i < s.length; i++) {
					System.out.println(s[i]);
				}
			}
			//			loadSchema();
		}
	}

	/** used  to duplicate the node selected */
	public class DuplicateListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			XsdNode node = (XsdNode) tree.getLastSelectedPathComponent();
			if (node == null) {
				displayMessage("no node selected", "[XML maker]");
				return;
			}
			expendChoices.add(getPathForNode(node));
			expendChoices.add(null);
			duplicateNode(node);
		}
	}

	/** used  to replace the node by its original value, if a choce has been done. */
	public class OriginalNodeListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			XsdNode node = (XsdNode) tree.getLastSelectedPathComponent();
			if (node == null) {
				displayMessage("no node selected", "[XML maker]");
				return;
			}

			if (node.originalParent == null) {
				displayMessage(
					"No choice has been done for this node.",
					"[XML maker]");
				return;
			}

			XsdNode parent = (XsdNode) node.getParent();

			int position = parent.getIndex(node);

			parent.insert(node.originalParent, position);
			parent.remove(position + 1);
			node.originalParent.isExtended = false;
			treeModel.reload(parent);
		}
	}

	private class GenericAssociationListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			XsdNode selectedNode =
				(XsdNode) tree.getLastSelectedPathComponent();

			if (selectedNode == null) {
				displayMessage("No node selected", "[XML maker]");
				return;
			}

			if (flatFileAssociation.isSelected()) {
				associateFlatFile(selectedNode);
				return;
			}

			if (!canHaveValue((XsdNode) tree.getLastSelectedPathComponent())) {
				displayMessage(
					"No value can be associated to this node",
					"[XML maker]");
				return;
			}

			if (fieldAssociation.isSelected()) {
				String path = flatFileTabbedPanel.getSelectedPath();
				associateField(selectedNode, path);
			} else if (dictionnaryAssociation.isSelected())
				associateDictionnary(selectedNode);
			else if (defaultAssociation.isSelected())
				associateDefaultValue(selectedNode);
			else if (autoGenerationAssociation.isSelected())
				associateAutoGenerateValue(selectedNode);
		}
	}

	private class GenericCancelAssociationListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			XsdNode selectedNode =
				(XsdNode) tree.getLastSelectedPathComponent();

			if (selectedNode == null) {
				displayMessage("No node selected", "[XML maker]");
				return;
			}

			if (fieldAssociation.isSelected())
				cancelAssociateField(selectedNode);
			else if (dictionnaryAssociation.isSelected())
				cancelAssociateDictionnary(selectedNode);
			else if (defaultAssociation.isSelected())
				cancelDefaultValue(selectedNode);
			else if (autoGenerationAssociation.isSelected())
				cancelAutogenerate(selectedNode);
			else if (flatFileAssociation.isSelected())
				JOptionPane.showMessageDialog(
					new JFrame(),
					"you cannot change association to a flat file",
					"[XML maker]",
					JOptionPane.ERROR_MESSAGE);
		}
	}

	private void cancelAllAssociations(XsdNode node) {
		associatedAutogeneration.remove(node);
		//	associatedDictionnaries.remove(node);
		associatedFields.remove(node);
		associatedValues.remove(node);
		check((XsdNode) treeModel.getRoot());
		treeModel.reload(node);
	}

	private void associateAutoGenerateValue(XsdNode node) {
		cancelAllAssociations(node);
		associatedAutogeneration.add(node);

		name = node.toString();

		node.useOnlyThis();
		check((XsdNode) treeModel.getRoot());
		treeModel.reload(node);
	}

	private void cancelAutogenerate(XsdNode node) {
		if (!associatedAutogeneration.contains(node))
			return;

		associatedAutogeneration.remove(node);
		node.unuseOnlyThis();
		check((XsdNode) treeModel.getRoot());
		treeModel.reload(node);
	}

	/** used to display the preview */
	private class PreviewListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {

			if (rootNode == null) {
				displayMessage("No schema loaded", "[XML maker]");
				return;
			}

			JEditorPane editorPane = new JEditorPane();
			editorPane.setEditable(false);
			try {
				editorPane.setText(
					previewNode((XsdNode) tree.getLastSelectedPathComponent()));
			} catch (java.lang.NullPointerException noNodeExeption) {
				/* no node selected */
				editorPane.setText("No preview available.");
			}
			JFrame frame = new JFrame();
			frame.setSize(400, 300);
			frame.getContentPane().add(new JScrollPane(editorPane));
			frame.show();
		}
	}

	/**
	 * print a xml output for the whole file
	 */
	private class PrintListener implements ActionListener {
		JTextField logoutFileName = new JTextField("log.out");
		JFileChooser logFileChooser = new JFileChooser(".");

		public void actionPerformed(ActionEvent e) {

			if (rootNode == null) {
				displayMessage("No schema loaded", "[XML maker]");
				return;
			}

			TreeNode[] path = rootNode.getPath();
			try {
				JFileChooser fileChooser = new JFileChooser(".");
				JLabel logFileLabel = new JLabel("log file:");
				JButton logoutButton = new JButton("log file");
				logoutButton.addActionListener(new LogoutListener());
				Box logPanel = new Box(BoxLayout.Y_AXIS);
				logPanel.add(logFileLabel);
				logPanel.add(logoutFileName);
				logPanel.add(logoutButton);
				fileChooser.setAccessory(logPanel);

				int confirm = fileChooser.showSaveDialog(new JFrame());

				if (confirm != JOptionPane.OK_OPTION)
					return;

				PrintWriter out =
					new PrintWriter(
						new BufferedWriter(
							new FileWriter(fileChooser.getSelectedFile())));

				if ((logoutFile = logFileChooser.getSelectedFile()) == null) {
					logoutFile = new File(logoutFileName.getText());
					logoutPrintWriter =
						new PrintWriter(
							new BufferedWriter(new FileWriter(logoutFile)));
					logoutFileName.setText(logoutFile.getName());
				}

				out.println("<?xml version=\"1.0\"?>");
				logoutPrintWriter.write(
					"start marshalling to file :"
						+ fileChooser.getSelectedFile().getName()
						+ " at "
						+ new Date()
						+ "\n");
				marshall(out);
				logoutPrintWriter.write(
					"\nmarshalling done, finished at " + new Date() + "\n");

				out.flush();
				out.close();

				logoutPrintWriter.flush();
				logoutPrintWriter.close();

				JPanel panel = new JPanel();
				JButton displayMessages =
					new JButton("Click here to display error messages");
				displayMessages.addActionListener(
					new DisplayMessagesListener());
				panel.add(new JLabel("Marshalling done."));
				panel.add(displayMessages);

				JOptionPane.showMessageDialog(
					new JFrame(),
					panel,
					"[XML makers] creating the xml document",
					JOptionPane.ERROR_MESSAGE);

			} catch (FileNotFoundException fe) {
				JOptionPane.showMessageDialog(
					new JFrame(),
					"unable to write file",
					"XML maker",
					JOptionPane.ERROR_MESSAGE);
			} catch (IOException ex) {
				JOptionPane.showMessageDialog(
					new JFrame(),
					"unable to write file",
					"XML maker",
					JOptionPane.ERROR_MESSAGE);
			}
		}

		public class LogoutListener implements ActionListener {
			public void actionPerformed(ActionEvent e) {
				int confirm = logFileChooser.showSaveDialog(new JFrame());
				if (confirm != JOptionPane.OK_OPTION)
					return;
				try {
					/* log file */
					logoutFile = logFileChooser.getSelectedFile();
					logoutPrintWriter =
						new PrintWriter(
							new BufferedWriter(new FileWriter(logoutFile)));
					logoutFileName.setText(logoutFile.getName());
				} catch (FileNotFoundException fe) {
					JOptionPane.showMessageDialog(
						new JFrame(),
						"unable to write log file",
						"XML maker",
						JOptionPane.ERROR_MESSAGE);
				} catch (IOException ex) {
					JOptionPane.showMessageDialog(
						new JFrame(),
						"unable to write log file",
						"XML maker",
						JOptionPane.ERROR_MESSAGE);
				}
			}
		}
	}

	/**
	 * print a xml output for the whole file
	 */
	private class PrintErrorsListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			try {
				JFileChooser fileChooser = new JFileChooser(".");
				int confirm = fileChooser.showSaveDialog(new JFrame());

				if (confirm != JOptionPane.OK_OPTION)
					return;

				PrintWriter out =
					new PrintWriter(
						new BufferedWriter(
							new FileWriter(fileChooser.getSelectedFile())));

				//				out.write(messagesTextArea.getText());

				out.flush();
				out.close();

			} catch (FileNotFoundException fe) {
				JOptionPane.showMessageDialog(
					new JFrame(),
					"unable to write file",
					"XML maker",
					JOptionPane.ERROR_MESSAGE);
			} catch (IOException ex) {
				JOptionPane.showMessageDialog(
					new JFrame(),
					"unable to write file",
					"XML maker",
					JOptionPane.ERROR_MESSAGE);
			}
		}
	}

	/** set an id that will be used as prefix for autogenerated values */
	private class SetIdListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			String s =
				(String) JOptionPane.showInputDialog(
					new JFrame(),
					"Enter a default value, \n",
					id);

			if (s != null)
				id = s;
		}
	}

	protected void setCellRenderer() {
		tree.setCellRenderer(new XslTreeRenderer());
	}

	protected class XslTreeRenderer extends DefaultTreeCellRenderer {
		ImageIcon iconAttribute;
		ImageIcon iconElement;

		public XslTreeRenderer() {
			iconAttribute = new ImageIcon("images/ic-att.gif");
			iconElement = new ImageIcon("images/ic-elt.gif");
		}

		public Component getTreeCellRendererComponent(
			JTree tree,
			Object value,
			boolean sel,
			boolean expanded,
			boolean leaf,
			int row,
			boolean hasFocus) {

			super.getTreeCellRendererComponent(
				tree,
				value,
				sel,
				expanded,
				leaf,
				row,
				hasFocus);
			XsdNode node = (XsdNode) value;
			/* set icon and tooltip */
			switch (((Annotated) node.getUserObject()).getStructureType()) {
				case Structure.GROUP :
					setIcon(null);
					break;
				case Structure.ATTRIBUTE :
					setIcon(iconAttribute);
					setToolTipText(
						"default value: "
							+ ((AttributeDecl) node.getUserObject())
								.getDefaultValue());
					break;
				case Structure.ELEMENT :
					setIcon(iconElement);
					try {
						setToolTipText(
							(
								(Documentation)
									((Annotation) ((ElementDecl) node
									.getUserObject())
								.getAnnotations()
								.nextElement())
								.getDocumentation()
								.nextElement())
								.getContent());
					} catch (Exception e) {
						setToolTipText("no documentation");
					}

					break;
			}

			switch (((Annotated) node.getUserObject()).getStructureType()) {
				case Structure.ATTRIBUTE :
					setText(
						getText()
							+ " ("
							+ ((AttributeDecl) node.getUserObject())
								.getSimpleType()
								.getName()
							+ ")      ");
					break;
				case Structure.ELEMENT :
					String type =
						((ElementDecl) node.getUserObject())
							.getType()
							.getName();
					int max = node.max;
					String text = getText();
					try {
						text += " ["
							+ ((ElementDecl) node.getUserObject())
								.getType()
								.getBaseType()
								.getName()
							+ "]";
					} catch (Exception e) {
						/* no base type */
					}
					text += " (";
					if (type != null)
						text += type + ", ";
					text += "max: ";
					if (max == -1)
						text += "unbounded";
					else
						text += max;
					text += ")      ";
					setText(text);
			}

			if (associatedDictionnary.containsKey(node)) {
				setText(
					getText().substring(0, getText().length() - 5)
						+ "(dictionnary)");
			}

			/* show error */
			setForeground(Color.GRAY);
			if (!node.isCheckedOk && node.isRequired)
				setForeground(Color.RED);

			if (isAffected(node)
				|| hasDefaultValue(node)
				|| associatedAutogeneration.contains(node))
				setForeground(Color.BLACK);

			return this;
		}
	}

	/**
		  * check if these are enough associations according to the shema
		  * 
		  * condition for being  "checkedOK":
		  * attributes: if is associated to a value  or not required
		  * simpleType elements: if is associated to a value
		  * element, complex type: if all sub Elements are checkedOk
		  * group: if the count of subElements "checkedOk" is good
		  * 
		  * condition for errors: elements or group is not "checkedOk"
		  *  
		  */
	protected boolean marshallingCheck(XsdNode node) {

		switch (((Annotated) node.getUserObject()).getStructureType()) {
			case Structure.ATTRIBUTE :
				return marshallingCheckAttribute(node);
			case Structure.ELEMENT :
				return marshallingCheckElement(node);
			case Structure.GROUP :
				return marshallingCheckGroup(node);
			default :
				System.out.println(
					"not found type"
						+ ((Annotated) node.getUserObject()).getStructureType());
				node.isCheckedOk = false;
				return false;
		}
	}

	private boolean marshallingCheckAttribute(XsdNode node) {
		//		if (node.isRequired && getValue(node) == null) {
		if (getValue(node) == null) {
			node.isCheckedOk = false;
			if (node.isRequired)
				return false;
			else
				return true;
		} else {
			node.isCheckedOk = true;
			return true;
		}
	}

	private String getNodeProblem(XsdNode node) {
		if (isAffected(node)) {
			String value =
				flatFileTabbedPanel.getValue(
					(String) associatedFields.get(node));

			if (value == null || value.length() == 0) {
				return "the field "
					+ ((String) associatedFields.get(node)).substring(
						((String) associatedFields.get(node)).indexOf(".") + 1)
					+ " is empty";
			}

			if (associatedDictionnary.containsKey(node)) {
				String replacementValue =
					dictionnaryPanel.getReplacementValue(
						((Integer) associatedDictionnary.get(node)).intValue(),
						value,
						((Integer) associatedDictionnaryColumn.get(node))
							.intValue());

				if (replacementValue == null
					|| replacementValue.length() == 0) {
					return "no replacement value found for value "
						+ value
						+ " (in dictionnary: "
						+ dictionnaryPanel.getName(
							((Integer) associatedDictionnary.get(node))
								.intValue())
						+ ", field "
						+ ((String) associatedFields.get(node)).substring(
							((String) associatedFields.get(node)).indexOf(".")
								+ 1);
				}
			}
		}
		return "no association to this node";
	}

	private boolean marshallingCheckElement(XsdNode node) {
		XMLType type = ((ElementDecl) node.getUserObject()).getType();

		/* simpleType */
		if (type.isSimpleType()) {
			if (getValue(node) == null) {
				node.isCheckedOk = false;
				if (node.isRequired)
					return false;
				else
					return true;
			} else {
				node.isCheckedOk = true;
				return true;
			}
		} else { /* complexType, ie: attributes + group */

			boolean ok = true;
			/* check if number of subelts is correct */
			HashMap maxOccurs = new HashMap();
			HashMap minOccurs = new HashMap();

			Enumeration children = node.children();

			while (children.hasMoreElements()) {
				XsdNode child = (XsdNode) children.nextElement();
				marshallingCheck(child);
				boolean childCheckedOk = child.isCheckedOk;

				switch (((Annotated) child.getUserObject())
					.getStructureType()) {
					case Structure.ATTRIBUTE :
						if (!childCheckedOk && child.isRequired) {
							ok = false;
						}
						break;
					case Structure.GROUP :
						ok = false;
						// should not be groups anymore
						return false;
					case Structure.ELEMENT :

						/* initialisation if first occurence of the element */
						if (!maxOccurs.containsKey(child.toString())) {
							int max = child.max;
							if (max != -1) {
								maxOccurs.put(
									child.toString(),
									new Integer(max));
							} else {
								maxOccurs.put(child.toString(), "UNBOUNDED");
							}
							minOccurs.put(
								child.toString(),
								new Integer(child.min));
						}

						if (childCheckedOk) {
							try {
								maxOccurs.put(
									child.toString(),
									new Integer(
										((Integer) maxOccurs
											.get(child.toString()))
											.intValue()
											- 1));
							} catch (ClassCastException e) {
								/* ok, max is unbounded and exception is throws when trying to cast String to Integer */
							}
							minOccurs.put(
								child.toString(),
								new Integer(
									((Integer) minOccurs.get(child.toString()))
										.intValue()
										- 1));
						}
				}
			}

			Iterator names = minOccurs.keySet().iterator();

			Iterator mins = minOccurs.values().iterator();
			Iterator maxs = maxOccurs.values().iterator();
			while (names.hasNext()) {
				String name = (String) names.next();
				// if a min is > 0, it means that an element is missing
				if (((Integer) mins.next()).intValue() > 0) {
					ok = false;
				}

				/* if a max is < 0, it means there are too much elements */
				try {
					if (((Integer) maxs.next()).intValue() < 0) {
						ok = false;
					}

				} catch (ClassCastException e) {
					/* ok, max is unbounded and exception is throws when trying to cast String to Integer */
				}
			}

			node.isCheckedOk = ok;
			if (node.isRequired && !ok)
				return false;
			else
				return true;
		}
	}

	/* 
	 * a group can only be a choice (else it would be expanded 
	 * if we find it, it means user has to make a choice
	 */
	private boolean marshallingCheckGroup(XsdNode node) {
		ArrayList errorMessages = new ArrayList();
		node.isCheckedOk = false; // should not be group anymore
		return false;
	}

}

/*
 * Created on 14 juil. 2003
 */
package mint.filemakers.xmlMaker;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
/**
 * This class displayed a TabbedPane that contains the TabFiles
 * 
 * @author Arnaud Ceol, University of Rome "Tor Vergata", Mint group,
 * arnaud@cbm.bio.uniroma2.it 
 */
public class FlatFileTabbedPanel extends JPanel {

	/** 
	 * receive tabFiles 
	 * each tabFile is associated with a tab
	 */
	private JTabbedPane tabbedPane = new JTabbedPane();

	/** dimension for buttons */
	private final Dimension buttonsDimension = new Dimension(180, 25);

	/**
	 * returns a new instance of TabFileTabbedPanel
	 * with one tab displaying an empty FlatList
	 */
	public FlatFileTabbedPanel() {
		this.setLayout(new BorderLayout());
		JButton addTabb = new JButton("Add tab");
		addTabb.setMaximumSize(buttonsDimension);
		addTabb.addActionListener(new addFlatFileListener());

		tabbedPane.add(new FlatFile());
		add(tabbedPane, BorderLayout.CENTER);
		add(addTabb, BorderLayout.NORTH);
	}

	/**
	 * used to load a new flat file
	 */
	private class addFlatFileListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			tabbedPane.add(new FlatFile());
		}
	}

	/**
	 * get the path for selected cell in a list, i.e. indexOfTab.pathInTheList
	 * @return a string representing the path, i.e. indexOfTab.indexOfCellInRootList.IndexOfCellInSubList.[]
	 */
	public String getSelectedPath() {
		return tabbedPane.getSelectedIndex()
			+ "."
			+ ((FlatFile) tabbedPane.getSelectedComponent()).getSelectedPath();
	}

	/**
	 * get the value in the cell according to  the path, i.e. for the path 1.3.4 the 4th cell in 
	 * the list built with value of the 3d cell of the root list of the 1st tab
	 * @param path the path
	 * @return the value
	 */
	public String getValue(String path) {
		int tabNum = Integer.parseInt(path.substring(0, path.indexOf(".")));
		return ((FlatFile) tabbedPane.getComponentAt(tabNum)).getValue(
			path.substring(path.indexOf(".") + 1));
	}

	/**
	 * get the index of the tab sellected
	 * @return the index of the tab sellected
	 */
	public int getSelectedIndex() {
		return tabbedPane.getSelectedIndex();
	}

	/**
	 * get the FlatFile contained by the indexth tab
	 * @param index the index of a tab
	 * @return  the FlatFile contained by the indexth tab
	 */
	public FlatFile getTabFileByIndex(int index) {
		return (FlatFile) tabbedPane.getComponent(index);
	}

	/**
	 * give a name to a tab
	 * 
	 */
	public void setTabTitle(int index, String name) {
		tabbedPane.setTitleAt(index, name);
	}

	public void save(ObjectOutputStream oos) {
		int nbTab = tabbedPane.getTabCount();
		try {
			oos.writeInt(nbTab);
			for (int i = 0; i < nbTab; i++) {
				((FlatFile) tabbedPane.getComponent(i)).save(oos);
			}
		} catch (IOException e) {
			System.out.println("failed to save flat files");
		}
	}

	public void load(ObjectInputStream ois) {
		try {
			int nbTab = ois.readInt();
			tabbedPane.removeAll();			
			for (int i = 0; i < nbTab; i++) {
				FlatFile ff = new FlatFile();
				ff.load(ois);
				tabbedPane.add(ff);
			}
		} catch (IOException e) {
			System.out.println("failed to load flat files.");
		} 
	}

}

package mint.filemakers.xmlMaker;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
/**
 * Management of a dictionnary.
 * A dictionnary is readed in a file and associates the first word 
 * of each line to a list of definitions, i.e. the list of words following
 * on the same line.
 * 
 * The dictionnary can be read from a flat file, for exemble a tab delimited file ,
 * which field separator can be set.
 * 
 * @author Arnaud Ceol, University of Rome "Tor Vergata", Mint group,
 * arnaud@cbm.bio.uniroma2.it 
 */
public class Dictionnary {

	/**
	 * keep the definitions:the key is the word and the value a list (ArrayList) of definitions
	 */
	private HashMap dictionnary = new HashMap();

	/**
	 * indicates if the dictionnary has to take care of the case of the characters or not
	 */
	private  boolean caseSensitive;

	/**
	 * The name for the comtrolled vocabulary, i.e. the name of the file
	 * on which the dictionnary has been loaded. 
	 */
	private String name;

	/**
	 * The file from wich the  dictionnary has been loaded
	 */
	private File file;

	/**
	 * The field separator
	 */
	private String separator;

	/**
	 * The longest list readed on a line. Can be used to have the best 
	 * overview of a value and its available definitions or to
	 * choose a definition.
	 */
	//	private String[] maxDefintionsList;
	private String maxDefinitionLine;
	/**
	 * load a dictionnary
	 * @param f the file containing the dictionnary
	 * @param separator the string separating the words
	 * @throws FileNotFoundException
	 */
	public void loadFile(File f, String separator)
		throws FileNotFoundException {
		BufferedReader reader = new BufferedReader(new FileReader(f));

		int maxDefinitionsNumber = 0;

		while (true) {
			try {
				String line = reader.readLine();
				String[] values = line.split(separator);

				if (values.length > 0) {
					// make it possible to have empty lines

					String value = values[0].trim();
					ArrayList definitions = new ArrayList();

					for (int i = 1; i < values.length; i++) {
						definitions.add(values[i].trim());
					}

					if (definitions.size() > maxDefinitionsNumber) {
						maxDefinitionsNumber = definitions.size();
						//						maxDefintionsList = values;
						maxDefinitionLine = line;
					}

					if (!caseSensitive) {
						dictionnary.put(
							value.toLowerCase().trim(),
							definitions);
					} else {
						dictionnary.put(value.trim(), definitions);
					}
				}
				file = f;
				name = f.getName();
				this.separator = separator;
			} catch (java.util.regex.PatternSyntaxException ex) {
				JOptionPane.showMessageDialog(
					new JFrame(),
					"the separator specified is not a valid regular expression.",
					"Separator",
					JOptionPane.ERROR_MESSAGE);
				file = f;
				name = f.getName();
				return;
			} catch (Exception e) { /* end of file */
				return;
			}
		}
	}

	/**
	 * constructor by default. The ditionnary is set as case sensitive
	 *
	 */
	public Dictionnary() {
		super();
		caseSensitive = true;
	}

	/**
	 * constructor with specification of case sensitivity
	 * @param caseSensitive
	 */
	public Dictionnary(boolean caseSensitive) {
		super();
		this.caseSensitive = caseSensitive;
	}

	/**
	 * create a new instance of Dictionnary with specified case sensitivity
	 * and load specified file using the separator
	 * @param f the file to load
	 * @param separator the separator for words on each line
	 * @param caseSensitive
	 * @throws FileNotFoundException
	 */
	public Dictionnary(File f, String separator, boolean caseSensitive)
		throws FileNotFoundException {
		super();
		this.caseSensitive = caseSensitive;
		loadFile(f, separator);
	}

	/**
	 * get the value associated to this word
	 * @param value the word
	 * @param definitionNumber the number of the definition to look for, as a value 
	 * can have more than one definition, i.e. the postition of the definition on a line.
	 * @return the definition
	 */
	public String getDefinition(String value, int definitionNumber) {
		try {
			if (caseSensitive
				&& ((String) ((ArrayList) dictionnary.get(value))
					.get(definitionNumber - 1))
					.length()
					== 0) {
				return null;
			} else if (
				!caseSensitive
					&& ((String) ((ArrayList) dictionnary
						.get(value.toLowerCase()))
						.get(definitionNumber - 1))
						.length()
						== 0) {
				return null;
			}

			if (caseSensitive) {
				return (String) ((ArrayList) dictionnary.get(value)).get(
					definitionNumber);
			} /* definitionNumber -1 because we do not count the value but only the definitions */
			else {
				return (String)
					((ArrayList) dictionnary.get(value.toLowerCase())).get(
					definitionNumber - 1);
			}
		} catch (NullPointerException e) {
			return null;
		} catch (IndexOutOfBoundsException e2) {
			return null;
		}
	}

	public String[] exampleList() {
		//		if (maxDefintionsList == null) {
		//			String value[] = {
		//			};
		//			return value;
		//		}
		//		return maxDefintionsList;
		if (maxDefinitionLine == null) {
			String value[] = {
			};
			return value;
		}
		return maxDefinitionLine.split(separator);
	}

	public String exampleLine() {
		if (maxDefinitionLine == null) {
			return "";
		}
		return maxDefinitionLine;
	}

	/**
	 * @return the name of the dictionnary
	 */
	public String toString() {
		return name;
	}

	public File getFile() {
		return file;
	}

	public String getSeparator() {
		return separator;
	}

	public boolean isCaseSensitive() {
		return caseSensitive;
	}

	public void save(ObjectOutputStream oos) {
		try {
			oos.writeBoolean(caseSensitive);
			oos.writeObject(separator);
			oos.writeObject(file.getPath());
		} catch (IOException e) {
			System.out.println("failed to save");
		}
	}

	public void load(ObjectInputStream ois) {
		String filePath = "";
		try {
			this.caseSensitive = ois.readBoolean();
			this.separator = (String) ois.readObject();
			filePath = (String) ois.readObject();

			if (filePath != null) {
				loadFile(new File(filePath), separator);
			}

		} catch (IOException e) {
			System.out.println("failed to load dictionnary: " + filePath);
		} catch (ClassNotFoundException e) {
			System.out.println("failed to load dictionnary: file");
		}
	}

}

#!/bin/sh
java -Xms500M -Xmx500M -Djava.ext.dirs=libs -classpath dist/xmlMakerFlattener.jar psidev.psi.mi.filemakers.xmlFlattener.XmlFlattener
